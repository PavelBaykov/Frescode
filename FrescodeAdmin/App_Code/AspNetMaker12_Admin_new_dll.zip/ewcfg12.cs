using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET Maker 12 - Project Configuration
//
public partial class AspNetMaker12_Admin_new_base : WebPage {

	// Debug
	public const bool EW_DEBUG_ENABLED = false; // Set to true for debugging

	public static int EW_OBJECTINFO_DEPTH = 10; // ObjectInfo // ASPX

	public static int EW_OBJECTINFO_ENUMERATION_LENGTH = 1000; // ObjectInfo // ASPX

	// Project
	public const string EW_PROJECT_CLASSNAME = "AspNetMaker12_Admin_new"; // ASPX

	public static string EW_PATH_DELIMITER = Convert.ToString(Path.DirectorySeparatorChar); // Physical path delimiter // ASPX

	public static string EW_ROOT_RELATIVE_PATH = ".."; // Relative path of application root

	public static string EW_RELATIVE_PATH = ""; // Relative path of main script folder	

	public const string EW_DEFAULT_DATE_FORMAT = "";

	public const short EW_DEFAULT_DATE_FORMAT_ID = 0;

	public const string EW_DATE_SEPARATOR = "/";

	public const short EW_UNFORMAT_YEAR = 50; // Unformat year

	public const string EW_PROJECT_NAME = "Admin_new"; // Project name

	public const string EW_CONFIG_FILE_FOLDER =  EW_PROJECT_NAME + ""; // Config file name

	public const string EW_PROJECT_ID = "{6EA87CB0-ED50-4AE1-9743-D14163EABB5A}"; // Project ID (GUID)

	public static string EW_RELATED_PROJECT_ID = "";

	public static string EW_RELATED_LANGUAGE_FOLDER = "";

	public static string EW_RANDOM_KEY = "chbZ9Qb0GLtpg0mU"; // Random key for encryption

	public const string EW_PROJECT_STYLESHEET_FILENAME = "aspxcss/Admin_new.css"; // Project stylesheet file name

	public const string EW_CHARSET = ""; // Project charset

	public const string EW_EMAIL_CHARSET = EW_CHARSET; // Email charset

	public const string EW_EMAIL_KEYWORD_SEPARATOR = ""; // Email keyword separator

	public static string EW_COMPOSITE_KEY_SEPARATOR = ","; // Composite key separator

	public const bool EW_HIGHLIGHT_COMPARE = true; // Case-insensitive

	public const bool EW_USE_DOM_XML = false;

	public const int EW_FONT_SIZE = 14;

	public const string EW_TMP_IMAGE_FONT = "Verdana"; // Font for temp files

	// Database
	public const bool EW_IS_MSACCESS = false; // Access

	public const bool EW_IS_MSSQL = true; // MS SQL

	public const bool EW_IS_MYSQL = false; // MySQL

	public const bool EW_IS_POSTGRESQL = false; // PostgreSQL

	public const bool EW_IS_ORACLE = false; // Oracle	

	public static string EW_DB_CONNECTION_STRING = "";

	public const string EW_DB_PROVIDER_NAME = "System.Data.SqlClient";

  	public const string EW_DB_QUOTE_START = "["; 

	public const string EW_DB_QUOTE_END = "]";	

	public const string EW_DB_SQLPARAM_SYMBOL = "@"; // Database SQL parameter symbol

	public const string EW_DB_SCHEMA = ""; // For Oracle	

	/**
	 * Password (MD5 and case-sensitivity)
	 * Note: If you enable MD5 password, make sure that the passwords in your
	 * user table are stored as MD5 hash (32-character hexadecimal number) of the
	 * clear text password. If you also use case-insensitive password, convert the
	 * clear text passwords to lower case first before calculating MD5 hash.
	 * Otherwise, existing users will not be able to login. MD5 hash is
	 * irreversible, password will be reset during password recovery.
	 */

	public const bool EW_ENCRYPTED_PASSWORD = false; // Encrypted password	

	public const bool EW_CASE_SENSITIVE_PASSWORD = false; // Case Sensitive password

	/**
	 * Remove XSS
	 * Note: If you want to allow these keywords, remove them from the following EW_XSS_ARRAY at your own risks.
	*/

	public const bool EW_REMOVE_XSS = true;

	public static string[] EW_REMOVE_XSS_KEYWORDS = new[] {"javascript", "vbscript", "expression", "<applet", "<meta", "<xml", "<blink", "<link", "<style", "<script", "<embed", "<object", "<iframe", "<frame", "<frameset", "<ilayer", "<layer", "<bgsound", "<title", "<base", "onabort", "onactivate", "onafterprint", "onafterupdate", "onbeforeactivate", "onbeforecopy", "onbeforecut", "onbeforedeactivate", "onbeforeeditfocus", "onbeforepaste", "onbeforeprint", "onbeforeunload", "onbeforeupdate", "onblur", "onbounce", "oncellchange", "onchange", "onclick", "oncontextmenu", "oncontrolselect", "oncopy", "oncut", "ondataavailable", "ondatasetchanged", "ondatasetcomplete", "ondblclick", "ondeactivate", "ondrag", "ondragend", "ondragenter", "ondragleave", "ondragover", "ondragstart", "ondrop", "onerror", "onerrorupdate", "onfilterchange", "onfinish", "onfocus", "onfocusin", "onfocusout", "onhelp", "onkeydown", "onkeypress", "onkeyup", "onlayoutcomplete", "onload", "onlosecapture", "onmousedown", "onmouseenter", "onmouseleave", "onmousemove", "onmouseout", "onmouseover", "onmouseup", "onmousewheel", "onmove", "onmoveend", "onmovestart", "onpaste", "onpropertychange", "onreadystatechange", "onreset", "onresize", "onresizeend", "onresizestart", "onrowenter", "onrowexit", "onrowsdelete", "onrowsinserted", "onscroll", "onselect", "onselectionchange", "onselectstart", "onstart", "onstop", "onsubmit", "onunload"};

	// Check Token
	public static bool EW_CHECK_TOKEN = true; // Check post token // ASPX

	// Session names	
	public const string EW_SESSION_STATUS = EW_PROJECT_NAME + "_Status"; // Login status	

	public const string EW_SESSION_USER_NAME = EW_SESSION_STATUS + "_UserName";	// User name	

	public const string EW_SESSION_USER_ID = EW_SESSION_STATUS + "_UserID";	// User ID	

	public const string EW_SESSION_USER_PROFILE = EW_SESSION_STATUS + "_UserProfile"; // User Profile

	public const string EW_SESSION_USER_PROFILE_USER_NAME = EW_SESSION_USER_PROFILE + "_UserName";

	public const string EW_SESSION_USER_PROFILE_PASSWORD = EW_SESSION_USER_PROFILE + "_Password";

	public const string EW_SESSION_USER_PROFILE_LOGIN_TYPE = EW_SESSION_USER_PROFILE + "_LoginType";

	public const string EW_SESSION_USER_LEVEL_ID = EW_SESSION_STATUS + "_UserLevel"; // User level ID		

	public const string EW_SESSION_USER_LEVEL = EW_SESSION_STATUS + "_UserLevelValue"; // User level		

	public const string EW_SESSION_PARENT_USER_ID = EW_SESSION_STATUS + "_ParentUserID"; // Parent user ID		

	public const string EW_SESSION_SYS_ADMIN = EW_PROJECT_NAME + "_SysAdmin"; // System admin

	public const string EW_SESSION_PROJECT_ID = EW_PROJECT_NAME + "_ProjectID"; // User Level project ID

	public const string EW_SESSION_AR_USER_LEVEL = EW_PROJECT_NAME + "_arUserLevel"; // User level ArrayList	

	public const string EW_SESSION_AR_USER_LEVEL_PRIV = EW_PROJECT_NAME + "_arUserLevelPriv"; // User level privilege ArrayList		

	public const string EW_SESSION_USER_LEVEL_MSG = EW_PROJECT_NAME + "_UserLevelMessage"; // Security array

	public const string EW_SESSION_SECURITY = EW_PROJECT_NAME + "_Security"; // Security array		

	public const string EW_SESSION_MESSAGE = EW_PROJECT_NAME + "_Message"; // System message	

	public const string EW_SESSION_FAILURE_MESSAGE = EW_PROJECT_NAME + "_Failure_Message"; // System error message

	public const string EW_SESSION_SUCCESS_MESSAGE = EW_PROJECT_NAME + "_Success_Message"; // System message

	public const string EW_SESSION_WARNING_MESSAGE = EW_PROJECT_NAME + "_Warning_Message"; // Warning message

	public const string EW_SESSION_INLINE_MODE = EW_PROJECT_NAME + "_InlineMode"; // Inline mode

	public const string EW_SESSION_BREADCRUMB = EW_PROJECT_NAME + "_Breadcrumb"; // Breadcrumb

	public const string EW_SESSION_TEMP_IMAGES = EW_PROJECT_NAME + "_TempImages"; // Temp images

	// Language settings
	public const string EW_LANGUAGE_FOLDER = "aspxlang/";

	public static List<string[]> EW_LANGUAGE_FILE = new List<string[]>() {
		new[] {"en", "", "english.xml"}	
	};

	public const string EW_LANGUAGE_DEFAULT_ID = "en";

	public const string EW_SESSION_LANGUAGE_ID = EW_PROJECT_NAME + "_LanguageId"; // Language ID

	// Page Token
	public const string EW_TOKEN_NAME = "token";

	public const string EW_SESSION_TOKEN = EW_PROJECT_NAME + "_Token";

	// Data types
	public const short EW_DATATYPE_NUMBER = 1;

	public const short EW_DATATYPE_DATE = 2;

	public const short EW_DATATYPE_STRING = 3;

	public const short EW_DATATYPE_BOOLEAN = 4;

	public const short EW_DATATYPE_MEMO = 5;

	public const short EW_DATATYPE_BLOB = 6;

	public const short EW_DATATYPE_TIME = 7;

	public const short EW_DATATYPE_GUID = 8;

	public const short EW_DATATYPE_XML = 9;

	public const short EW_DATATYPE_OTHER = 10;

	// Row types
	public const short EW_ROWTYPE_VIEW = 1;	// Row type view	

	public const short EW_ROWTYPE_ADD = 2; // Row type add	

	public const short EW_ROWTYPE_EDIT = 3; // Row type edit

	public const short EW_ROWTYPE_SEARCH = 4; // Row type search

	public const short EW_ROWTYPE_MASTER = 5; // Row type master record

	public const short EW_ROWTYPE_AGGREGATEINIT = 6; // Row type aggregate init 

	public const short EW_ROWTYPE_AGGREGATE = 7; // Row type aggregate	

	// Table parameters
	public const string EW_TABLE_PREFIX = "||ASPNETReportMaker||";	

	public const string EW_TABLE_REC_PER_PAGE = "recperpage"; // Records per page	

	public const string EW_TABLE_START_REC = "start"; // Start record	

	public const string EW_TABLE_PAGE_NO = "pageno"; // Page number	

	public const string EW_TABLE_BASIC_SEARCH = "psearch"; // Basic search keyword		

	public const string EW_TABLE_BASIC_SEARCH_TYPE = "psearchtype"; // Basic search type	

	public const string EW_TABLE_ADVANCED_SEARCH = "advsrch"; // Advanced search	

	public const string EW_TABLE_SEARCH_WHERE = "searchwhere"; // Search where clause	

	public const string EW_TABLE_WHERE = "where"; // Table where

	public const string EW_TABLE_WHERE_LIST = "where_list"; // Table where (list page) 	

	public const string EW_TABLE_ORDER_BY = "orderby"; // Table order by

	public const string EW_TABLE_ORDER_BY_LIST = "orderby_list"; // Table order by (list page) 	

	public const string EW_TABLE_SORT = "sort"; // Table sort	

	public const string EW_TABLE_KEY = "key"; // Table key	

	public const string EW_TABLE_SHOW_MASTER = "showmaster"; // Table show master

	public const string EW_TABLE_SHOW_DETAIL = "showdetail"; // Table show detail	

	public const string EW_TABLE_MASTER_TABLE = "mastertable"; // Master table

	public const string EW_TABLE_DETAIL_TABLE = "detailtable"; // Detail table

	public const string EW_TABLE_RETURN_URL = "return"; // Return URL

	public const string EW_TABLE_EXPORT_RETURN_URL = "exportreturn"; // Export return URL

	public const string EW_TABLE_GRID_ADD_ROW_COUNT = "gridaddcnt"; // Grid add row count

	// Audit Trail
	public const bool EW_AUDIT_TRAIL_TO_DATABASE = false; // Write audit trail to DB

	public const string EW_AUDIT_TRAIL_TABLE_NAME = ""; // Audit trail table name

	public const string EW_AUDIT_TRAIL_FIELD_NAME_DATETIME = ""; // Audit trail DateTime field name

	public const string EW_AUDIT_TRAIL_FIELD_NAME_SCRIPT = ""; // Audit trail Script field name

	public const string EW_AUDIT_TRAIL_FIELD_NAME_USER = ""; // Audit trail User field name

	public const string EW_AUDIT_TRAIL_FIELD_NAME_ACTION = ""; // Audit trail Action field name

	public const string EW_AUDIT_TRAIL_FIELD_NAME_TABLE = ""; // Audit trail Table field name

	public const string EW_AUDIT_TRAIL_FIELD_NAME_FIELD = ""; // Audit trail Field field name

	public const string EW_AUDIT_TRAIL_FIELD_NAME_KEYVALUE = ""; // Audit trail Key Value field name

	public const string EW_AUDIT_TRAIL_FIELD_NAME_OLDVALUE = ""; // Audit trail Old Value field name

	public const string EW_AUDIT_TRAIL_FIELD_NAME_NEWVALUE = ""; // Audit trail New Value field name

	// Security
	public const string EW_ADMIN_USER_NAME = ""; // Administrator user name	

	public const string EW_ADMIN_PASSWORD = ""; // Administrator password

	public const bool EW_USE_CUSTOM_LOGIN = true; // Use custom login

	// User level constants
	public const bool EW_USER_LEVEL_COMPAT = false; // Use old user level values

	public const short EW_ALLOW_ADD = 1; // Add		

	public const short EW_ALLOW_DELETE = 2; // Delete			

	public const short EW_ALLOW_EDIT = 4; // Edit				

	public const short EW_ALLOW_LIST = 8; // List

	public const int EW_ALLOW_VIEW = 32; // View (for EW_USER_LEVEL_COMPAT = False)

	public const int EW_ALLOW_SEARCH = 64; // Search (for EW_USER_LEVEL_COMPAT = False)	

	public const short EW_ALLOW_REPORT = 8; // Report		

	public const short EW_ALLOW_ADMIN = 16; // Admin	

	// Hierarchical User ID
	public const bool EW_USER_ID_IS_HIERARCHICAL = true; // True to show all level / False to show 1 level

	// Use subquery for master/detail
	public const bool EW_USE_SUBQUERY_FOR_MASTER_USER_ID = false; // True to use subquery / False to skip

	public const int EW_USER_ID_ALLOW = 104;

	// User table filters
	// User Profile Constants
	public const string EW_USER_PROFILE_SESSION_ID = "SessionID";

	public const string EW_USER_PROFILE_LAST_ACCESSED_DATE_TIME = "LastAccessedDateTime";

	public const int EW_USER_PROFILE_CONCURRENT_SESSION_COUNT = 1; // Maximum sessions allowed

	public const int EW_USER_PROFILE_SESSION_TIMEOUT = 20;

	public const string EW_USER_PROFILE_LOGIN_RETRY_COUNT = "LoginRetryCount";

	public const string EW_USER_PROFILE_LAST_BAD_LOGIN_DATE_TIME = "LastBadLoginDateTime";

	public const int EW_USER_PROFILE_MAX_RETRY = 3;

	public const int EW_USER_PROFILE_RETRY_LOCKOUT = 20;

	public const string EW_USER_PROFILE_LAST_PASSWORD_CHANGED_DATE = "LastPasswordChangedDate";

	public const int EW_USER_PROFILE_PASSWORD_EXPIRE = 90;

	// Email
	public const string EW_SMTP_SERVER = "localhost"; // SMTP server	

	public const int EW_SMTP_SERVER_PORT = 25; // SMTP server port

	public const string EW_SMTP_SECURE_OPTION = "";	

	public const string EW_SMTP_SERVER_USERNAME = ""; // SMTP server user name	

	public const string EW_SMTP_SERVER_PASSWORD = ""; // SMTP server password	

	public const string EW_SENDER_EMAIL = ""; // Sender email	

	public const string EW_RECIPIENT_EMAIL = ""; // Recipient email

	public const int EW_MAX_EMAIL_RECIPIENT = 3;

	public const int EW_MAX_EMAIL_SENT_COUNT = 3;

	public const string EW_EXPORT_EMAIL_COUNTER = EW_SESSION_STATUS + "_EmailCounter";

	// File upload
	public const string EW_UPLOAD_DEST_PATH = "uploads/"; // Upload destination path	

	public const string EW_UPLOAD_URL = "ewupload12.cshtml"; // Upload URL

	public const string EW_UPLOAD_TEMP_FOLDER_PREFIX = "temp__"; // Upload temp folders prefix

	public const int EW_UPLOAD_TEMP_FOLDER_TIME_LIMIT = 1440; // Upload temp folder time limit (minutes)

	public const string EW_UPLOAD_THUMBNAIL_FOLDER = "thumbnail"; // Temporary thumbnail folder

	public const int EW_UPLOAD_THUMBNAIL_WIDTH = 200; // Temporary thumbnail max width

	public const int EW_UPLOAD_THUMBNAIL_HEIGHT = 0; // Temporary thumbnail max height

	public const int EW_MAX_FILE_COUNT = 0; // Max file count

	public const string EW_UPLOAD_ALLOWED_FILE_EXT = "gif,jpg,jpeg,bmp,png,doc,xls,pdf,zip"; // Allowed file extensions

	public const string EW_IMAGE_ALLOWED_FILE_EXT = "gif,jpg,png,bmp"; // Allowed file extensions for images	

	public const int EW_MAX_FILE_SIZE = 2000000; // Max file size	

	public const short EW_THUMBNAIL_DEFAULT_WIDTH = 0; // Thumbnail default width

	public const short EW_THUMBNAIL_DEFAULT_HEIGHT = 0; // Thumbnail default height

	public const short EW_THUMBNAIL_DEFAULT_QUALITY = -1; // Thumbnail default interpolation

	public const bool EW_UPLOAD_CONVERT_ACCENTED_CHARS = false; // Convert accented chars in upload file name

	public const bool EW_USE_COLORBOX = true; // Use Colorbox

	public const string EW_MULTIPLE_UPLOAD_SEPARATOR = ","; // Multiple upload separator

	// Audit trail
	public const string EW_AUDIT_TRAIL_PATH = ""; // Audit trail path (relative to app root)

	// Export records
	public const bool EW_EXPORT_ALL = true; // Export all records

	public const int EW_EXPORT_ALL_TIME_LIMIT = 120; // Export all records time limit

	public const string EW_XML_ENCODING = "utf-8"; // Encoding for Export to XML

	public const bool EW_EXPORT_ORIGINAL_VALUE = false; // True to export original value

	public const bool EW_EXPORT_FIELD_CAPTION = false; // True to export field caption

	public const bool EW_EXPORT_CSS_STYLES = true; // True to export css styles

	public const bool EW_EXPORT_MASTER_RECORD = true; // True to export master record

	public const bool EW_EXPORT_MASTER_RECORD_FOR_CSV = false; // True to export master record for CSV

	public const bool EW_EXPORT_DETAIL_RECORDS = true; // TRUE to export detail records

	public const bool EW_EXPORT_DETAIL_RECORDS_FOR_CSV = false; // TRUE to export detail records for CSV

	// Export classes
	public static Dictionary<string, string> EW_EXPORT = new Dictionary<string, string>() {
		{"email", "cExportEmail"},
		{"html", "cExportHtml"},
		{"word", "cExportWord"},
		{"excel", "cExportExcel"},
		{"pdf", "cExportPdf"},
		{"csv", "cExportCsv"},
		{"xml", "cExportXml"}
	};

	public static Dictionary<string, string> EW_EXPORT_REPORT = new Dictionary<string, string>() {
		{"print", "ExportReportHtml"},
		{"html", "ExportReportHtml"},
		{"word", "ExportReportWord"},
		{"excel", "ExportReportExcel"}
	};

	// Mime types // ASPX
	public static Dictionary<string, string> EW_MIME_TYPES = new Dictionary<string, string>() {
		{"pdf", "application/pdf"},
		{"exe", "application/octet-stream"},
		{"zip", "application/zip"},
		{"docx", "application/msword"},
		{"doc", "application/msword"},
		{"xls", "application/vnd.ms-excel"},
		{"xlsx", "application/vnd.ms-excel"},
		{"ppt", "application/vnd.ms-powerpoint"},
		{"pptx", "application/vnd.ms-powerpoint"},
		{"gif", "image/gif"},
		{"png", "image/png"},
		{"jpeg", "image/jpg"},
		{"jpg", "image/jpg"},
		{"mp3", "audio/mpeg"},
		{"wav", "audio/x-wav"},
		{"mpeg", "video/mpeg"},
		{"mpg", "video/mpeg"},
		{"mpe", "video/mpeg"},
		{"mov", "video/quicktime"},
		{"avi", "video/x-msvideo"},
		{"3gp", "video/3gpp"},
		{"css", "text/css"},
		{"jsc", "application/javascript"},
		{"js", "application/javascript"},
		{"asp", "text/html"},
		{"htm", "text/html"},
		{"html", "text/html"}
	};

	// Use token in URL (reserved, not used, do NOT change!)
	public const bool EW_USE_TOKEN_IN_URL = false; // Do not use token in URL	

	// Use ILIKE for PostgreSql
	public const bool EW_USE_ILIKE_FOR_POSTGRESQL = true;

	// Use collation for MySQL
	public const string EW_LIKE_COLLATION_FOR_MYSQL = "";

	// Use collation for MsSQL
	public const string EW_LIKE_COLLATION_FOR_MSSQL = "";

	// Null / Not Null values
	public const string EW_NULL_VALUE = "##null##";

	public const string EW_NOT_NULL_VALUE = "##notnull##";

	/**
	 * Search multi value option
	 * 1 - no multi value
	 * 2 - AND all multi values
	 * 3 - OR all multi values
	*/

	public const short EW_SEARCH_MULTI_VALUE_OPTION = 3;

	// Basic search ignore special characters
	public const string EW_BASIC_SEARCH_IGNORE_PATTERN = @"[\?,\.\^\*\(\)\[\]\""]";

	// Validate option
	public const bool EW_CLIENT_VALIDATE = true;	

	public const bool EW_SERVER_VALIDATE = false;

	// Blob field byte count for hash value calculation
	public const int EW_BLOB_FIELD_BYTE_COUNT = 200;

	// Auto suggest max entries
	public const int EW_AUTO_SUGGEST_MAX_ENTRIES = 10;

	// Auto fill original value
	public const bool EW_AUTO_FILL_ORIGINAL_VALUE = false;

	// Checkbox and radio button groups
	public const string EW_ITEM_TEMPLATE_CLASSNAME = "ewTemplate";	

	public const string EW_ITEM_TABLE_CLASSNAME = "ewItemTable";

	// Use responsive layout
	public static bool EW_USE_RESPONSIVE_LAYOUT = true;

	// Use css flip
	public const bool EW_CSS_FLIP = false;

	/**
	 * Numeric and monetary formatting options
	 * Note: DO NOT CHANGE THE FOLLOWING DEFAULT_* VARIABLES!
	 * If you want to use custom settings, customize the language file,
	 * set "use_system_locale" to "0" to override and customize the
	 * phrases under the <locale> node for ew_FormatCurrency/Number/Percent functions
	*/

	public static bool EW_USE_SYSTEM_LOCALE = true;

	public static string EW_DECIMAL_POINT = ".";

	public static string EW_THOUSANDS_SEP = ",";

	public static string EW_CURRENCY_SYMBOL = "$";

	// Cookies
	public static DateTime EW_COOKIE_EXPIRY_TIME = DateTime.Today.AddDays(365);

	// Menu
	public const string EW_MENUBAR_ID = "RootMenu";

	public const string EW_MENUBAR_BRAND = "";

	public const string EW_MENUBAR_BRAND_HYPERLINK = "";

	public const string EW_MENUBAR_CLASSNAME = "";

	//public const string EW_MENUBAR_INNER_CLASSNAME = "";
	public const string EW_MENU_CLASSNAME = "dropdown-menu";

	public const string EW_SUBMENU_CLASSNAME = "dropdown-menu";

	public const string EW_SUBMENU_DROPDOWN_IMAGE = "";

	public const string EW_SUBMENU_DROPDOWN_ICON_CLASSNAME = "";

	public const string EW_MENU_DIVIDER_CLASSNAME = "divider";

	public const string EW_MENU_ITEM_CLASSNAME = "dropdown-submenu";

	public const string EW_SUBMENU_ITEM_CLASSNAME = "dropdown-submenu";

	public const string EW_MENU_ACTIVE_ITEM_CLASS = "active";

	public const string EW_SUBMENU_ACTIVE_ITEM_CLASS = "active";

	public const bool EW_MENU_ROOT_GROUP_TITLE_AS_SUBMENU = false;

	public const bool EW_SHOW_RIGHT_MENU = false;	

	// PDF
	public const string EW_PDF_STYLESHEET_FILENAME = ""; // export PDF CSS styles

	// Image resize
	public const bool EW_RESIZE_ENABLED = false;	
}
