using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET WebPage class
//
public partial class AspNetMaker12_Admin_new_base : WebPage {

	// Checklists_edit
	public static dynamic Checklists_edit {
		get { return (dynamic)ew_PageData["Checklists_edit"]; }
		set { ew_PageData["Checklists_edit"] = value; }
	}

	//
	// Page class
	//
	public class cChecklists_edit_base<C, S> : cChecklists
		where C : cConnectionBase, new()
		where S : cAdvancedSecurityBase, new()
	{

		// Page ID
		public string PageID = "edit";

		// Project ID
		public string ProjectID = "{6EA87CB0-ED50-4AE1-9743-D14163EABB5A}";

		// Table name
		public string TableName = "Checklists";

		// Page object name
		public string PageObjName = "Checklists_edit";

		// Page name
		public string PageName {
			get { return ew_CurrentPage(); }
		}

		// Page URL
		public string PageUrl {
			get {
				string PageUrl = ew_CurrentPage() + "?";
				if (UseTokenInUrl) PageUrl += "t=" + TableVar + "&"; // Add page token
				return PageUrl;
			}
		}

		// Message
		public string Message {
			get { return Convert.ToString(ew_Session[EW_SESSION_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_MESSAGE] = msg;
			}
		}

		// Failure Message
		public string FailureMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_FAILURE_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_FAILURE_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_FAILURE_MESSAGE] = msg;
			}
		}

		// Success Message
		public string SuccessMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_SUCCESS_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_SUCCESS_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_SUCCESS_MESSAGE] = msg;
			}
		}

		// Warning Message
		public string WarningMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_WARNING_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_WARNING_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_WARNING_MESSAGE] = msg;
			}
		}

		// Show message
		public void ShowMessage() {
			bool hidden = false;
			string html = "";

			// Message
			string sMessage = Message;
			Message_Showing(ref sMessage, "");
			if (sMessage != "") { // Message in Session, display
				if (!hidden)
					sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sMessage;
				html += "<div class=\"alert alert-info ewInfo\">" + sMessage + "</div>";
				ew_Session[EW_SESSION_MESSAGE] = ""; // Clear message in Session
			}

			// Warning message
			var sWarningMessage = WarningMessage;
			Message_Showing(ref sWarningMessage, "warning");
			if (sWarningMessage != "") { // Message in Session, display
				if (!hidden)
					sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sWarningMessage;
				html += "<div class=\"alert alert-warning ewWarning\">" + sWarningMessage + "</div>";
				ew_Session[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
			}

			// Success message
			var sSuccessMessage = SuccessMessage;
			Message_Showing(ref sSuccessMessage, "success");
			if (sSuccessMessage != "") { // Message in Session, display
				if (!hidden)
					sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sSuccessMessage;
				html += "<div class=\"alert alert-success ewSuccess\">" + sSuccessMessage + "</div>";
				ew_Session[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
			}

			// Failure message
			var sErrorMessage = FailureMessage;
			Message_Showing(ref sErrorMessage, "failure");
			if (sErrorMessage != "") { // Message in Session, display
				if (!hidden)
					sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sErrorMessage;
				html += "<div class=\"alert alert-danger ewError\">" + sErrorMessage + "</div>";
				ew_Session[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
			}
			ew_Write("<div class=\"ewMessageDialog\"" + ((hidden) ? " style=\"display: none;\"" : "") + ">" + html + "</div>");
		}								

		public string PageHeader = "";

		public string PageFooter = "";

		// Show Page Header
		public void ShowPageHeader() {
			string sHeader = PageHeader;
			Page_DataRendering(ref sHeader);
			if (ew_NotEmpty(sHeader)) // Header exists, display
				ew_Write("<p>" + sHeader + "</p>");
		}

		// Show Page Footer
		public void ShowPageFooter() {
			string sFooter = PageFooter;
			Page_DataRendered(ref sFooter);
			if (ew_NotEmpty(sFooter)) // Fotoer exists, display
				ew_Write("<p>" + sFooter + "</p>");
		}

		// Validate page request
		public bool IsPageRequest {
			get {
				if (UseTokenInUrl) {			
					if (ObjForm != null)
						return (TableVar == ObjForm.GetValue("t"));
					if (ew_NotEmpty(ew_Get("t")))
						return (TableVar == ew_Get("t"));
					return false;		
				} else {
					return true;
				}
			}
		}

		// Token
		public string Token = "";

		public bool CheckToken = EW_CHECK_TOKEN;

		// Valid Post
		public bool ValidPost() {
			if (!CheckToken || !IsPost)
				return true;
			if (ew_Post(EW_TOKEN_NAME) == null)
				return false;
			return Convert.ToBoolean(ew_CheckToken(ew_Post(EW_TOKEN_NAME)));
		}

		// Create Token
		public void CreateToken() {
			if (CheckToken) {
				if (ew_Empty(Token) && CheckToken) // Create token
					Token = ew_CreateToken();
				gsToken = Token; // Save to global variable
			}
		}

		//
		// Page class constructor
		//
		public cChecklists_edit_base() {
			CurrentPage = this;

			// Language object
			if (Language == null)
				Language = new cLanguage();

			// Table object (Checklists)
			if (Checklists == null || Checklists is cChecklists) {
				Checklists = this;

				//CurrentTable = this;
			}

			// Table object (ChecklistTemplates)
			if (ChecklistTemplates == null) ChecklistTemplates = new cChecklistTemplates();

			// Start time
			StartTime = Environment.TickCount;

			// Open connection
			if (Conn == null)
				Conn = new C();
		}

		// 
		//  Page_Init
		//
		public void Page_Init() {

			// Create form object
			ObjForm = new cFormObj();
			CurrentAction = (ew_Get("a") != "") ? ew_Get("a") : ew_Post("a_list"); // Set up current action
			Id.Visible = !IsAdd && !IsCopy && !IsGridAdd;

			// Global Page Loading event
			ew_WebPage.Page_Loading();

			// Page Load event
			Page_Load();

			// Check token
			if (!ValidPost()) {
				ew_Response.Write(Language.Phrase("InvalidPostRequest"));
				Page_Terminate();
				ew_End();
			}

			// Process auto fill
			if (ew_Post("ajax") == "autofill") {
				string results = GetAutoFill(ew_Post("name"), ew_Post("q"));
				if (results != null) {

					// Clean output buffer
					if (!EW_DEBUG_ENABLED)
						ew_Response.Clear();
					ew_Response.Write(results);
					Page_Terminate();
					ew_End();
				}
			}

			// Create Token
			CreateToken();
		}

		//
		// Page_Terminate
		//
		public void Page_Terminate(string url = "") {

			// Page Unload event
			Page_Unload();

			// Global Page Unloaded event
			ew_WebPage.Page_Unloaded();

			// Export
			if (ew_NotEmpty(CustomExport) && CustomExport == Export && EW_EXPORT.ContainsKey(CustomExport)) {
				var sContent = "";
				sContent = Regex.Match(ew_WebPage.Output.ToString(), @"<html>[\s\S]+</html>", RegexOptions.IgnoreCase).Value;
				if (ew_Empty(gsExportFile))
					gsExportFile = TableVar;
				dynamic doc = ew_CreateInstance(EW_EXPORT[CustomExport], new object[] { Checklists, "" }); // ASPX
				doc.Text.Append(sContent);				
				if (Export == "email") {
				} else {
					doc.Export();
				}		
				ew_DeleteTmpImages(); // Delete temp images
				ew_GCollect(); // ASPX
				ew_End();
			}
			Page_Redirecting(ref url);

			 // Close connection
			if (Conn != null)
				Conn.Close();

			// Gargage collection // ASPX
			ew_GCollect();

			// Go to URL if specified
			if (ew_NotEmpty(url)) {  // ASPX
				if (EW_DEBUG_ENABLED)
					ew_Response.Clear();
				ew_Response.Redirect(ew_MapPath(url, false)); // ASPX
			}

			//ew_End();
		}

		public int DisplayRecs = 1; // Number of display records

		public int StartRec;

		public int StopRec;

		public int TotalRecs = 0;

		public int RecRange = 10;

		public int RecCnt;

		public Dictionary<string, string> RecKey = new Dictionary<string, string>();

		public string DbMasterFilter = "";

		public string DbDetailFilter = ""; 

		public ewDataReader Recordset; // ASPX

		// 
		// Page main
		//
		public void Page_Main() {
			string sReturnUrl = "";
			bool bMatchRecord = false;

			// Load key from QueryString
			if (ew_NotEmpty(ew_Get("Id")) || ew_Page.UrlData.Count >= 1) { // ASPX
				if (ew_NotEmpty(ew_Get("Id"))) { 
					Id.QueryStringValue = ew_Get("Id");						
				} else {
					Id.QueryStringValue = ew_Page.UrlData[0];
				}
			}

			// Set up master detail parameters
			SetUpMasterParms();

			// Set up Breadcrumb
			SetupBreadcrumb();

			// Process form if post back
			if (ew_NotEmpty(ew_Post("a_edit"))) {
				CurrentAction = ew_Post("a_edit"); // Get action code
				LoadFormValues(); // Get form values
			} else {
				CurrentAction = "I"; // Default action is display
			}

			// Check if valid key
			if (ew_Empty(Id.CurrentValue))
				Page_Terminate("Checklistslist.cshtml"); // Invalid key, return to list

			// Validate form if post back
			if (ew_NotEmpty(ew_Post("a_edit"))) {
				if (!ValidateForm()) {
					CurrentAction = ""; // Form error, reset action
					FailureMessage = gsFormError;
					EventCancelled = true; // Event cancelled
					RestoreFormValues();
				}
			}
			switch (CurrentAction) {
				case "I": // Get a record to display
					if (!LoadRow()) { // Load record based on key
						if (ew_Empty(FailureMessage))
							FailureMessage = Language.Phrase("NoRecord"); // No record found
						Page_Terminate("Checklistslist.cshtml"); // No matching record, return to list
					}
					break;
				case "U": // Update
					SendEmail = true; // Send email on update success
					if (Recordset != null) { // Close DataReader // ASPX
						Recordset.Close();
						Recordset.Dispose();	
					}
					if (EditRow()) { // Update record based on key
						if (ew_Empty(SuccessMessage))
							SuccessMessage = Language.Phrase("UpdateSuccess"); // Update success						
						sReturnUrl = Convert.ToString(GetCustomValue("TblEditReturnPage"));
						Page_Terminate(sReturnUrl); // Return to caller
					} else {
						EventCancelled = true; // Event cancelled
						RestoreFormValues(); // Restore form values if update failed
					}
					break;		
			}

			// Render the record
			RowType = EW_ROWTYPE_EDIT; // Render as Edit
			ResetAttrs();
			RenderRow();
		}

		// Set up starting record parameters
		public void SetUpStartRec() {
			int PageNo;

			// Exit if DisplayRecs = 0
			if (DisplayRecs == 0)
				return;
			if (IsPageRequest) { // Validate request

				// Check for a "start" parameter
				if (ew_NotEmpty(ew_Get(EW_TABLE_START_REC)) && Information.IsNumeric(ew_Get(EW_TABLE_START_REC))) {
					StartRec = ew_ConvertToInt(ew_Get(EW_TABLE_START_REC));
					StartRecordNumber = StartRec;
				} else if (ew_NotEmpty(ew_Get(EW_TABLE_PAGE_NO)) && Information.IsNumeric(ew_Get(EW_TABLE_PAGE_NO))) {
					PageNo = ew_ConvertToInt(ew_Get(EW_TABLE_PAGE_NO));
					StartRec = (PageNo - 1) * DisplayRecs + 1;
					if (StartRec <= 0) {
						StartRec = 1;
					} else if (StartRec >= ((TotalRecs - 1) / DisplayRecs) * DisplayRecs + 1) {
						StartRec = ((TotalRecs - 1) / DisplayRecs) * DisplayRecs + 1;
					}
					StartRecordNumber = StartRec;
				}
			}
			StartRec = StartRecordNumber;

			// Check if correct start record counter
			if (StartRec <= 0) {	// Avoid invalid start record counter
				StartRec = 1;	// Reset start record counter
				StartRecordNumber = StartRec;
			} else if (StartRec > TotalRecs) {	// Avoid starting record > total records
				StartRec = ((TotalRecs - 1) / DisplayRecs) * DisplayRecs + 1;	// Point to last page first record
				StartRecordNumber = StartRec;
			} else if ((StartRec - 1) % DisplayRecs != 0) {
				StartRec = ((StartRec - 1) / DisplayRecs) * DisplayRecs + 1;	// Point to page boundary
				StartRecordNumber = StartRec;
			}
		}

		// Confirm page
		public bool ConfirmPage = false;  // ASPX

		// Get upload files
		public void GetUploadFiles() {

			// Get upload data
		}

		// Load form values
		public void LoadFormValues() {
			if (!Id.FldIsDetailKey)
				Id.FormValue = ObjForm.GetValue("x_Id");		
			if (!ChangedBy_Id.FldIsDetailKey) {
				ChangedBy_Id.FormValue = ObjForm.GetValue("x_ChangedBy_Id");
			}
			if (!ChecklistTemplate_Id.FldIsDetailKey) {
				ChecklistTemplate_Id.FormValue = ObjForm.GetValue("x_ChecklistTemplate_Id");
			}
			if (!CreatedBy_Id.FldIsDetailKey) {
				CreatedBy_Id.FormValue = ObjForm.GetValue("x_CreatedBy_Id");
			}
			if (!Project_Id.FldIsDetailKey) {
				Project_Id.FormValue = ObjForm.GetValue("x_Project_Id");
			}
		}

		// Restore form values
		public void RestoreFormValues() {
			LoadRow();
			Id.CurrentValue = Id.FormValue;
			ChangedBy_Id.CurrentValue = ChangedBy_Id.FormValue;
			ChecklistTemplate_Id.CurrentValue = ChecklistTemplate_Id.FormValue;
			CreatedBy_Id.CurrentValue = CreatedBy_Id.FormValue;
			Project_Id.CurrentValue = Project_Id.FormValue;
		}

		// Load row based on key values
		public bool LoadRow() {
			string sFilter = KeyFilter;

			// Call Row Selecting event
			Row_Selecting(ref sFilter);

			// Load SQL based on filter
			CurrentFilter = sFilter;
			string sSql = SQL;

			// Write SQL for debug
			if (EW_DEBUG_ENABLED)
				ew_SetDebugMsg(sSql); // Show SQL for debugging
			var res = false;
			try {
				using (var rsrow = Conn.OpenDataReader(sSql)) {
					if (rsrow != null && rsrow.Read()) {				
						LoadRowValues(rsrow);								
						res = true;
					} else {
						return false;
					}
				}
			} catch {
				if (EW_DEBUG_ENABLED)
					throw;
			}
			return res;
		}

		// Load row values from recordset
		public void LoadRowValues(ewDataReader dr) {
			if (dr == null)
				return;
			string sDetailFilter;

			// Call Row Selected event
			var row = Conn.GetRow(dr);
			Row_Selected(ref row);
			Id.DbValue = row["Id"];
			DateCreated.DbValue = row["DateCreated"];
			DateOfLastChange.DbValue = row["DateOfLastChange"];
			ChangedBy_Id.DbValue = row["ChangedBy_Id"];
			ChecklistTemplate_Id.DbValue = row["ChecklistTemplate_Id"];
			CreatedBy_Id.DbValue = row["CreatedBy_Id"];
			Project_Id.DbValue = row["Project_Id"];
		}

		// Load DbValue from recordset
		public void LoadDbValues(OrderedDictionary row) {
			if (row == null) return;
			Id.SetDbValue(row["Id"]);
			DateCreated.SetDbValue(row["DateCreated"]);
			DateOfLastChange.SetDbValue(row["DateOfLastChange"]);
			ChangedBy_Id.SetDbValue(row["ChangedBy_Id"]);
			ChecklistTemplate_Id.SetDbValue(row["ChecklistTemplate_Id"]);
			CreatedBy_Id.SetDbValue(row["CreatedBy_Id"]);
			Project_Id.SetDbValue(row["Project_Id"]);
		}

		// Render row values based on field settings
		public void RenderRow() {

			// Call Row_Rendering event
			Row_Rendering();

			// Common render codes for all row types
			// Id
			// DateCreated
			// DateOfLastChange
			// ChangedBy_Id
			// ChecklistTemplate_Id
			// CreatedBy_Id
			// Project_Id

			if (RowType == EW_ROWTYPE_VIEW) { // View row

				// Id
				Id.ViewValue = Id.CurrentValue;

				// ChangedBy_Id
				if (ew_NotEmpty(ChangedBy_Id.CurrentValue)) {
					sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(ChangedBy_Id.CurrentValue).Trim(), EW_DATATYPE_STRING);
				sSqlWrk = "SELECT [Id], [FirstName] AS [DispFld], [LastName] AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld] FROM [dbo].[AspNetUsers]";
				sWhereWrk = "";
				sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "ChangedBy_Id"));
				if (ew_NotEmpty(sLookupTblFilter)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
				}
				if (ew_NotEmpty(sFilterWrk)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
				}

				// Call Lookup selecting
				Lookup_Selecting(ChangedBy_Id, ref sWhereWrk);
				if (sWhereWrk != "") {
					sSqlWrk += " WHERE " + sWhereWrk;
				}
					odwrk = Conn.GetRow(sSqlWrk);
					if (odwrk != null) {
						ChangedBy_Id.ViewValue = odwrk["DispFld"];
						ChangedBy_Id.ViewValue = String.Concat(ChangedBy_Id.ViewValue, ew_ValueSeparator(1, ChangedBy_Id), odwrk["Disp2Fld"]);
					} else {
						ChangedBy_Id.ViewValue = ChangedBy_Id.CurrentValue;
					}	
				} else {
					ChangedBy_Id.ViewValue = System.DBNull.Value;
				}

				// ChecklistTemplate_Id
				if (ew_NotEmpty(ChecklistTemplate_Id.CurrentValue)) {
					sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(ChecklistTemplate_Id.CurrentValue).Trim(), EW_DATATYPE_NUMBER);
				sSqlWrk = "SELECT [Id], [Name] AS [DispFld], '' AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld] FROM [dbo].[ChecklistTemplates]";
				sWhereWrk = "";
				sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "ChecklistTemplate_Id"));
				if (ew_NotEmpty(sLookupTblFilter)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
				}
				if (ew_NotEmpty(sFilterWrk)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
				}

				// Call Lookup selecting
				Lookup_Selecting(ChecklistTemplate_Id, ref sWhereWrk);
				if (sWhereWrk != "") {
					sSqlWrk += " WHERE " + sWhereWrk;
				}
					odwrk = Conn.GetRow(sSqlWrk);
					if (odwrk != null) {
						ChecklistTemplate_Id.ViewValue = odwrk["DispFld"];
					} else {
						ChecklistTemplate_Id.ViewValue = ChecklistTemplate_Id.CurrentValue;
					}	
				} else {
					ChecklistTemplate_Id.ViewValue = System.DBNull.Value;
				}

				// CreatedBy_Id
				if (ew_NotEmpty(CreatedBy_Id.CurrentValue)) {
					sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(CreatedBy_Id.CurrentValue).Trim(), EW_DATATYPE_STRING);
				sSqlWrk = "SELECT [Id], [FirstName] AS [DispFld], [LastName] AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld] FROM [dbo].[AspNetUsers]";
				sWhereWrk = "";
				sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "CreatedBy_Id"));
				if (ew_NotEmpty(sLookupTblFilter)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
				}
				if (ew_NotEmpty(sFilterWrk)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
				}

				// Call Lookup selecting
				Lookup_Selecting(CreatedBy_Id, ref sWhereWrk);
				if (sWhereWrk != "") {
					sSqlWrk += " WHERE " + sWhereWrk;
				}
					odwrk = Conn.GetRow(sSqlWrk);
					if (odwrk != null) {
						CreatedBy_Id.ViewValue = odwrk["DispFld"];
						CreatedBy_Id.ViewValue = String.Concat(CreatedBy_Id.ViewValue, ew_ValueSeparator(1, CreatedBy_Id), odwrk["Disp2Fld"]);
					} else {
						CreatedBy_Id.ViewValue = CreatedBy_Id.CurrentValue;
					}	
				} else {
					CreatedBy_Id.ViewValue = System.DBNull.Value;
				}

				// Project_Id
				if (ew_NotEmpty(Project_Id.CurrentValue)) {
					sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(Project_Id.CurrentValue).Trim(), EW_DATATYPE_NUMBER);
				sSqlWrk = "SELECT [Id], [Name] AS [DispFld], '' AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld] FROM [dbo].[Projects]";
				sWhereWrk = "";
				sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "Project_Id"));
				if (ew_NotEmpty(sLookupTblFilter)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
				}
				if (ew_NotEmpty(sFilterWrk)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
				}

				// Call Lookup selecting
				Lookup_Selecting(Project_Id, ref sWhereWrk);
				if (sWhereWrk != "") {
					sSqlWrk += " WHERE " + sWhereWrk;
				}
					odwrk = Conn.GetRow(sSqlWrk);
					if (odwrk != null) {
						Project_Id.ViewValue = odwrk["DispFld"];
					} else {
						Project_Id.ViewValue = Project_Id.CurrentValue;
					}	
				} else {
					Project_Id.ViewValue = System.DBNull.Value;
				}

				// Id
				Id.HrefValue = "";
				Id.TooltipValue = "";

				// ChangedBy_Id
				ChangedBy_Id.HrefValue = "";
				ChangedBy_Id.TooltipValue = "";

				// ChecklistTemplate_Id
				ChecklistTemplate_Id.HrefValue = "";
				ChecklistTemplate_Id.TooltipValue = "";

				// CreatedBy_Id
				CreatedBy_Id.HrefValue = "";
				CreatedBy_Id.TooltipValue = "";

				// Project_Id
				Project_Id.HrefValue = "";
				Project_Id.TooltipValue = "";
			} else if (RowType == EW_ROWTYPE_EDIT) { // Edit row

				// Id
				Id.EditAttrs["class"] = "form-control";
				Id.EditValue = Id.CurrentValue;

				// ChangedBy_Id
				ChangedBy_Id.EditAttrs["class"] = "form-control";
				if (ew_Empty(ChangedBy_Id.CurrentValue)) {
					sFilterWrk = "0=1";
				} else {	
					sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(ChangedBy_Id.CurrentValue), EW_DATATYPE_STRING);
				}
				sSqlWrk = "SELECT [Id], [FirstName] AS [DispFld], [LastName] AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld], '' AS [SelectFilterFld], '' AS [SelectFilterFld2], '' AS [SelectFilterFld3], '' AS [SelectFilterFld4] FROM [dbo].[AspNetUsers]";
				sWhereWrk = "";
				sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "ChangedBy_Id"));
				if (ew_NotEmpty(sLookupTblFilter)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
				}
				if (ew_NotEmpty(sFilterWrk)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
				}

				// Call Lookup selecting
				Lookup_Selecting(ChangedBy_Id, ref sWhereWrk);
				if (sWhereWrk != "") {
					sSqlWrk += " WHERE " + sWhereWrk;
				}
				alwrk = Conn.GetRows(sSqlWrk);
				alwrk.Insert(0, new OrderedDictionary() {{0, ""}, {1, Language.Phrase("PleaseSelect")}, {2, ""}, {3, ""}, {4, ""}, {5, ""}, {6, ""}, {7, ""}, {8, ""}});
				ChangedBy_Id.EditValue = alwrk;

				// ChecklistTemplate_Id
				ChecklistTemplate_Id.EditAttrs["class"] = "form-control";
				if (ew_NotEmpty(ChecklistTemplate_Id.SessionValue)) {
					ChecklistTemplate_Id.CurrentValue = ChecklistTemplate_Id.SessionValue;
				if (ew_NotEmpty(ChecklistTemplate_Id.CurrentValue)) {
					sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(ChecklistTemplate_Id.CurrentValue).Trim(), EW_DATATYPE_NUMBER);
				sSqlWrk = "SELECT [Id], [Name] AS [DispFld], '' AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld] FROM [dbo].[ChecklistTemplates]";
				sWhereWrk = "";
				sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "ChecklistTemplate_Id"));
				if (ew_NotEmpty(sLookupTblFilter)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
				}
				if (ew_NotEmpty(sFilterWrk)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
				}

				// Call Lookup selecting
				Lookup_Selecting(ChecklistTemplate_Id, ref sWhereWrk);
				if (sWhereWrk != "") {
					sSqlWrk += " WHERE " + sWhereWrk;
				}
					odwrk = Conn.GetRow(sSqlWrk);
					if (odwrk != null) {
						ChecklistTemplate_Id.ViewValue = odwrk["DispFld"];
					} else {
						ChecklistTemplate_Id.ViewValue = ChecklistTemplate_Id.CurrentValue;
					}	
				} else {
					ChecklistTemplate_Id.ViewValue = System.DBNull.Value;
				}
				} else {
				if (ew_Empty(ChecklistTemplate_Id.CurrentValue)) {
					sFilterWrk = "0=1";
				} else {	
					sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(ChecklistTemplate_Id.CurrentValue), EW_DATATYPE_NUMBER);
				}
				sSqlWrk = "SELECT [Id], [Name] AS [DispFld], '' AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld], '' AS [SelectFilterFld], '' AS [SelectFilterFld2], '' AS [SelectFilterFld3], '' AS [SelectFilterFld4] FROM [dbo].[ChecklistTemplates]";
				sWhereWrk = "";
				sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "ChecklistTemplate_Id"));
				if (ew_NotEmpty(sLookupTblFilter)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
				}
				if (ew_NotEmpty(sFilterWrk)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
				}

				// Call Lookup selecting
				Lookup_Selecting(ChecklistTemplate_Id, ref sWhereWrk);
				if (sWhereWrk != "") {
					sSqlWrk += " WHERE " + sWhereWrk;
				}
				alwrk = Conn.GetRows(sSqlWrk);
				alwrk.Insert(0, new OrderedDictionary() {{0, ""}, {1, Language.Phrase("PleaseSelect")}, {2, ""}, {3, ""}, {4, ""}, {5, ""}, {6, ""}, {7, ""}, {8, ""}});
				ChecklistTemplate_Id.EditValue = alwrk;
				}

				// CreatedBy_Id
				CreatedBy_Id.EditAttrs["class"] = "form-control";
				if (ew_Empty(CreatedBy_Id.CurrentValue)) {
					sFilterWrk = "0=1";
				} else {	
					sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(CreatedBy_Id.CurrentValue), EW_DATATYPE_STRING);
				}
				sSqlWrk = "SELECT [Id], [FirstName] AS [DispFld], [LastName] AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld], '' AS [SelectFilterFld], '' AS [SelectFilterFld2], '' AS [SelectFilterFld3], '' AS [SelectFilterFld4] FROM [dbo].[AspNetUsers]";
				sWhereWrk = "";
				sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "CreatedBy_Id"));
				if (ew_NotEmpty(sLookupTblFilter)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
				}
				if (ew_NotEmpty(sFilterWrk)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
				}

				// Call Lookup selecting
				Lookup_Selecting(CreatedBy_Id, ref sWhereWrk);
				if (sWhereWrk != "") {
					sSqlWrk += " WHERE " + sWhereWrk;
				}
				alwrk = Conn.GetRows(sSqlWrk);
				alwrk.Insert(0, new OrderedDictionary() {{0, ""}, {1, Language.Phrase("PleaseSelect")}, {2, ""}, {3, ""}, {4, ""}, {5, ""}, {6, ""}, {7, ""}, {8, ""}});
				CreatedBy_Id.EditValue = alwrk;

				// Project_Id
				Project_Id.EditAttrs["class"] = "form-control";
				if (ew_Empty(Project_Id.CurrentValue)) {
					sFilterWrk = "0=1";
				} else {	
					sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(Project_Id.CurrentValue), EW_DATATYPE_NUMBER);
				}
				sSqlWrk = "SELECT [Id], [Name] AS [DispFld], '' AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld], '' AS [SelectFilterFld], '' AS [SelectFilterFld2], '' AS [SelectFilterFld3], '' AS [SelectFilterFld4] FROM [dbo].[Projects]";
				sWhereWrk = "";
				sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "Project_Id"));
				if (ew_NotEmpty(sLookupTblFilter)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
				}
				if (ew_NotEmpty(sFilterWrk)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
				}

				// Call Lookup selecting
				Lookup_Selecting(Project_Id, ref sWhereWrk);
				if (sWhereWrk != "") {
					sSqlWrk += " WHERE " + sWhereWrk;
				}
				alwrk = Conn.GetRows(sSqlWrk);
				alwrk.Insert(0, new OrderedDictionary() {{0, ""}, {1, Language.Phrase("PleaseSelect")}, {2, ""}, {3, ""}, {4, ""}, {5, ""}, {6, ""}, {7, ""}, {8, ""}});
				Project_Id.EditValue = alwrk;

				// Edit refer script
				// Id

				Id.HrefValue = "";

				// ChangedBy_Id
				ChangedBy_Id.HrefValue = "";

				// ChecklistTemplate_Id
				ChecklistTemplate_Id.HrefValue = "";

				// CreatedBy_Id
				CreatedBy_Id.HrefValue = "";

				// Project_Id
				Project_Id.HrefValue = "";
			}
			if (RowType == EW_ROWTYPE_ADD ||
				RowType == EW_ROWTYPE_EDIT ||
				RowType == EW_ROWTYPE_SEARCH) { // Add / Edit / Search row
				SetupFieldTitles();
			}

			// Call Row Rendered event
			if (RowType != EW_ROWTYPE_AGGREGATEINIT)
				Row_Rendered();
		}

		// Validate form
		public bool ValidateForm() {

			// Initialize form error message
			gsFormError = "";

			// Check if validation required
			if (!EW_SERVER_VALIDATE)
				return (gsFormError == "");
			if (!ChecklistTemplate_Id.FldIsDetailKey && ew_Empty(ChecklistTemplate_Id.FormValue))
				gsFormError = ew_JoinMessage(gsFormError, ChecklistTemplate_Id.ReqErrMsg.Replace("%s", ChecklistTemplate_Id.FldCaption));
			if (!Project_Id.FldIsDetailKey && ew_Empty(Project_Id.FormValue))
				gsFormError = ew_JoinMessage(gsFormError, Project_Id.ReqErrMsg.Replace("%s", Project_Id.FldCaption));

			// Return validate result
			bool Valid = (ew_Empty(gsFormError));

			// Call Form_CustomValidate event
			string sFormCustomError = "";
			Valid = Valid && Form_CustomValidate(ref sFormCustomError);
			gsFormError = ew_JoinMessage(gsFormError, sFormCustomError);
			return Valid;
		}

		// Update record based on key values
		public bool EditRow() {
			bool result = false;
			OrderedDictionary rsold = null;
			var rsnew = new OrderedDictionary();
			string sFilter = KeyFilter;
			CurrentFilter = sFilter;
			string sSql = SQL;
			bool bRowHasConflict;			
			try {
				using (var rsedit = Conn.OpenDataReader(sSql)) { // Use secondary connection // ASPX
					if (rsedit == null || !rsedit.Read())
						return false;
					rsold = Conn.GetRow(rsedit);
					LoadDbValues(rsold);
				}
			} catch (Exception e) {
				if (EW_DEBUG_ENABLED)
					throw; 
				FailureMessage = e.Message;				
				return false;
			}

			// ChangedBy_Id
			ChangedBy_Id.SetDbValue(ref rsnew, ChangedBy_Id.CurrentValue, System.DBNull.Value, ChangedBy_Id.ReadOnly);

			// ChecklistTemplate_Id
			ChecklistTemplate_Id.SetDbValue(ref rsnew, ChecklistTemplate_Id.CurrentValue, 0, ChecklistTemplate_Id.ReadOnly);

			// CreatedBy_Id
			CreatedBy_Id.SetDbValue(ref rsnew, CreatedBy_Id.CurrentValue, System.DBNull.Value, CreatedBy_Id.ReadOnly);

			// Project_Id
			Project_Id.SetDbValue(ref rsnew, Project_Id.CurrentValue, 0, Project_Id.ReadOnly);
			bool bValidMasterRecord;
			object KeyValue;
			string sMasterFilter;

			// Check referential integrity for master table 'ChecklistTemplates'
			bValidMasterRecord = true;
			sMasterFilter = SqlMasterFilter_ChecklistTemplates;
			KeyValue = rsnew.Contains("ChecklistTemplate_Id") ? rsnew["ChecklistTemplate_Id"] : rsold["ChecklistTemplate_Id"];
			if (ew_NotEmpty(KeyValue)) {
				sMasterFilter = sMasterFilter.Replace("@Id@", ew_AdjustSql(KeyValue));
			} else {
				bValidMasterRecord = false;
			}
			if (bValidMasterRecord) {
				using (var rsmaster = Conn.GetDataReader(ChecklistTemplates.GetSQL(sMasterFilter))) { // ASPX
					bValidMasterRecord = (rsmaster != null && rsmaster.HasRows);
				}
			}
			if (!bValidMasterRecord) {
				FailureMessage = Language.Phrase("RelatedRecordRequired").Replace("%t", "ChecklistTemplates");
				return false;
			}

			// Call Row Updating event
			bool bUpdateRow = Row_Updating(rsold, ref rsnew);
			if (bUpdateRow) {
				try {
					result = (rsnew.Count > 0) ? (Update(rsnew, "", rsold) > 0) : true;						
					if (result) {	
					}
				} catch (Exception e) {
					if (EW_DEBUG_ENABLED) throw; 
					FailureMessage = e.Message;
					return false;
				}
			} else {
				if (ew_NotEmpty(SuccessMessage) || ew_NotEmpty(FailureMessage)) {

					// Use the message, do nothing
				} else if (ew_NotEmpty(CancelMessage)) {
					FailureMessage = CancelMessage;
					CancelMessage = "";
				} else {
					FailureMessage = Language.Phrase("UpdateCancelled");
				}
				result = false;
			}

			// Call Row_Updated event
			if (result)
				Row_Updated(rsold, rsnew);
			return result;
		}

		// Set up master/detail based on QueryString
		public void SetUpMasterParms() {
			bool bValidMaster = false;
			string sMasterTblVar = "";

			// Get the keys for master table
			if (ew_QueryString[EW_TABLE_SHOW_MASTER] != null) { // Do not use ew_Get()
				sMasterTblVar = ew_Get(EW_TABLE_SHOW_MASTER);
				if (ew_Empty(sMasterTblVar)) {
					bValidMaster = true;
					DbMasterFilter = "";
					DbDetailFilter = "";
				}
				if (sMasterTblVar == "ChecklistTemplates") {
					bValidMaster = true;
					if (ew_NotEmpty(ew_Get("fk_Id"))) {
						ChecklistTemplates.Id.QueryStringValue = ew_Get("fk_Id");
						ChecklistTemplate_Id.QueryStringValue = ChecklistTemplates.Id.QueryStringValue;
						ChecklistTemplate_Id.SessionValue = ChecklistTemplate_Id.QueryStringValue;
						if (!Information.IsNumeric(ChecklistTemplates.Id.QueryStringValue)) bValidMaster = false;					
					} else {
						bValidMaster = false;
					}
				}
			}
			if (bValidMaster) {

				// Save current master table
				CurrentMasterTable = sMasterTblVar;
				SessionWhere = DetailFilter;

				// Clear previous master key from Session
				if (sMasterTblVar != "ChecklistTemplates") {
					if (ew_Empty(ChecklistTemplate_Id.QueryStringValue)) ChecklistTemplate_Id.SessionValue = "";
				}
			}
			DbMasterFilter = MasterFilter; //  Get master filter
			DbDetailFilter = DetailFilter; // Get detail filter
		}

		// Set up Breadcrumb
		public void SetupBreadcrumb() {
			Breadcrumb = new cBreadcrumb();			
			var url = ew_CurrentUrl();
			url = url.Substring(url.LastIndexOf("/") + 1);
			Breadcrumb.Add("list", TableVar, "Checklistslist.cshtml", "", TableVar, true);
			var PageId = "edit";
			url = url.Substring(url.LastIndexOf("/") + 1);
			Breadcrumb.Add("edit", PageId, url);
		}

		// Page Load event
		public virtual void Page_Load() {

			//ew_Write("Page Load");
		}

		// Page Unload event
		public virtual void Page_Unload() {

			//ew_Write("Page Unload");
		}

		// Page Redirecting event
		public virtual void Page_Redirecting(ref string url) {

			//url = newurl;
		}

		// Message Showing event
		// type = ""|"success"|"failure"|"warning"
		public virtual void Message_Showing(ref string msg, string type) {

			// Note: Do not change msg outside the following 4 cases.
			if (type == "success") {

				//msg = "your success message";
			} else if (type == "failure") {

				//msg = "your failure message";
			} else if (type == "warning") {

				//msg = "your warning message";
			} else {

				//msg = "your message";
			}
		}

		// Page_Render event
		public virtual void Page_Render() {

			//ew_Write("Page Render");
		}

		// Page Data Rendering event
		public virtual void Page_DataRendering(ref string header) {

			// Example:
			//header = "your header";

		}

		// Page Data Rendered event
		public virtual void Page_DataRendered(ref string footer) {

			// Example:
			//footer = "your footer";

		}

		// Form Custom Validate event
		public virtual bool Form_CustomValidate(ref string CustomError) {

			//Return error message in CustomError
			return true;
		}
	}
}
