using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET WebPage class
//
public partial class AspNetMaker12_Admin_new_base : WebPage {

	// InspectionDrawingDatas_Data_blobview
	public static dynamic InspectionDrawingDatas_Data_blobview {
		get { return (dynamic)ew_PageData["InspectionDrawingDatas_Data_blobview"]; }
		set { ew_PageData["InspectionDrawingDatas_Data_blobview"] = value; }
	}

	//
	// Page class
	//
	public class cInspectionDrawingDatas_Data_blobview_base<C, S> : cInspectionDrawingDatas
		where C : cConnectionBase, new()
		where S : cAdvancedSecurityBase, new()
	{

		// Page ID
		public string PageID = "blobview";

		// Project ID
		public string ProjectID = "{6EA87CB0-ED50-4AE1-9743-D14163EABB5A}";

		// Page object name
		public string PageObjName = "InspectionDrawingDatas_Data_blobview";

		// Page name
		public string PageName {
			get { return ew_CurrentPage(); }
		}

		// Page URL
		public string PageUrl {
			get {
				string PageUrl = ew_CurrentPage() + "?";
				return PageUrl;
			}
		}

		// Message
		public string Message {
			get { return Convert.ToString(ew_Session[EW_SESSION_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_MESSAGE] = msg;
			}
		}

		// Failure Message
		public string FailureMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_FAILURE_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_FAILURE_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_FAILURE_MESSAGE] = msg;
			}
		}

		// Success Message
		public string SuccessMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_SUCCESS_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_SUCCESS_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_SUCCESS_MESSAGE] = msg;
			}
		}

		// Warning Message
		public string WarningMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_WARNING_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_WARNING_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_WARNING_MESSAGE] = msg;
			}
		}

		// Show message
		public void ShowMessage() {
			bool hidden = false;
			string html = "";

			// Message
			string sMessage = Message;
			Message_Showing(ref sMessage, "");
			if (sMessage != "") { // Message in Session, display
				if (!hidden)
					sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sMessage;
				html += "<div class=\"alert alert-info ewInfo\">" + sMessage + "</div>";
				ew_Session[EW_SESSION_MESSAGE] = ""; // Clear message in Session
			}

			// Warning message
			var sWarningMessage = WarningMessage;
			Message_Showing(ref sWarningMessage, "warning");
			if (sWarningMessage != "") { // Message in Session, display
				if (!hidden)
					sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sWarningMessage;
				html += "<div class=\"alert alert-warning ewWarning\">" + sWarningMessage + "</div>";
				ew_Session[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
			}

			// Success message
			var sSuccessMessage = SuccessMessage;
			Message_Showing(ref sSuccessMessage, "success");
			if (sSuccessMessage != "") { // Message in Session, display
				if (!hidden)
					sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sSuccessMessage;
				html += "<div class=\"alert alert-success ewSuccess\">" + sSuccessMessage + "</div>";
				ew_Session[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
			}

			// Failure message
			var sErrorMessage = FailureMessage;
			Message_Showing(ref sErrorMessage, "failure");
			if (sErrorMessage != "") { // Message in Session, display
				if (!hidden)
					sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sErrorMessage;
				html += "<div class=\"alert alert-danger ewError\">" + sErrorMessage + "</div>";
				ew_Session[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
			}
			ew_Write("<div class=\"ewMessageDialog\"" + ((hidden) ? " style=\"display: none;\"" : "") + ">" + html + "</div>");
		}								

		// Token
		public string Token = "";

		public bool CheckToken = EW_CHECK_TOKEN;

		// Valid Post
		public bool ValidPost() {
			if (!CheckToken || !IsPost)
				return true;
			if (ew_Post(EW_TOKEN_NAME) == null)
				return false;
			return Convert.ToBoolean(ew_CheckToken(ew_Post(EW_TOKEN_NAME)));
		}

		// Create Token
		public void CreateToken() {
			if (CheckToken) {
				if (ew_Empty(Token) && CheckToken) // Create token
					Token = ew_CreateToken();
				gsToken = Token; // Save to global variable
			}
		}

		//
		// Page class constructor
		//
		public cInspectionDrawingDatas_Data_blobview_base() {
			CurrentPage = this;

			// Language object
			if (Language == null)
				Language = new cLanguage();

			// Table object (InspectionDrawingDatas)
			if (InspectionDrawingDatas == null || InspectionDrawingDatas is cInspectionDrawingDatas) {
				InspectionDrawingDatas = this;

				//CurrentTable = this;
			}

			// Start time
			StartTime = Environment.TickCount;

			// Open connection
			if (Conn == null)
				Conn = new C();
		}

		// 
		//  Page_Init
		//
		public void Page_Init() {
			CurrentAction = (ew_Get("a") != "") ? ew_Get("a") : ew_Post("a_list"); // Set up current action

			// Page Load event
			Page_Load();

			// Check token
			if (!ValidPost()) {
				ew_Response.Write(Language.Phrase("InvalidPostRequest"));
				Page_Terminate();
				ew_End();
			}

			// Create Token
			CreateToken();
		}

		//
		// Page_Terminate
		//
		public void Page_Terminate(string url = "") {

			// Page Unload event
			Page_Unload();

			// Export
			Page_Redirecting(ref url);

			 // Close connection
			if (Conn != null)
				Conn.Close();

			// Gargage collection // ASPX
			ew_GCollect();

			// Go to URL if specified
			if (ew_NotEmpty(url)) {  // ASPX
				if (EW_DEBUG_ENABLED)
					ew_Response.Clear();
				ew_Response.Redirect(ew_MapPath(url, false)); // ASPX
			}

			//ew_End();
		}

		//
		// Page main
		//
		public void Page_Main() {

			// Get key
			if (ew_NotEmpty(ew_Get("Id")) || ew_Page.UrlData.Count >= 1) { // ASPX
				if (ew_NotEmpty(ew_Get("Id"))) { 
					Id.QueryStringValue = ew_Get("Id");						
				} else {
					Id.QueryStringValue = ew_Page.UrlData[0];
				}
			} else {
				Page_Terminate(); // Exit
				ew_End();
			}
			var objBinary = new cUpload("InspectionDrawingDatas", "x_Data");

			// Show thumbnail
			var iThumbnailWidth = 0;
			var iThumbnailHeight = 0;
			var iInterpolation = 0;
			var bShowThumbnail = (ew_Get("showthumbnail") == "1");
			if (ew_Empty(ew_Get("thumbnailwidth")) && ew_Empty(ew_Get("thumbnailheight"))) {
				iThumbnailWidth = EW_THUMBNAIL_DEFAULT_WIDTH; // Set default width
				iThumbnailHeight = EW_THUMBNAIL_DEFAULT_HEIGHT; // Set default height
			} else {
				if (ew_NotEmpty(ew_Get("thumbnailwidth"))) {
					iThumbnailWidth = Convert.ToInt32(ew_Get("thumbnailwidth"));
					if (!Information.IsNumeric(iThumbnailWidth) || ew_ConvertToInt(iThumbnailWidth) < 0) iThumbnailWidth = 0; 
				}
				if (ew_NotEmpty(ew_Get("thumbnailheight"))) {
					iThumbnailHeight = Convert.ToInt32(ew_Get("thumbnailheight"));
					if (!Information.IsNumeric(iThumbnailHeight) || ew_ConvertToInt(iThumbnailHeight) < 0) iThumbnailHeight = 0; 
				}
			}
			if (ew_NotEmpty(ew_Get("interpolation"))) {
				iInterpolation = Convert.ToInt32(ew_Get("interpolation"));
				if (!Information.IsNumeric(iInterpolation) || ew_ConvertToInt(iInterpolation) < 0 || ew_ConvertToInt(iInterpolation) > 2) iInterpolation = EW_THUMBNAIL_DEFAULT_QUALITY; // Set Default
			} else {
				iInterpolation = EW_THUMBNAIL_DEFAULT_QUALITY;
			}
			var sFilter = KeyFilter;

			// Set up filter (SQL WHERE clause) and get return SQL
			// SQL constructor in InspectionDrawingDatas class, InspectionDrawingDatasinfo.cs

			CurrentFilter = sFilter;
			var sSql = SQL;
			using (var rs = Conn.GetDataReader(sSql)) {
				if (rs != null && rs.Read()) {
					if (!EW_DEBUG_ENABLED)
						ew_Response.Clear();
					byte[] data = {};
					if (!Convert.IsDBNull(rs["Data"]))
						data = (byte[])rs["Data"];	
					if (bShowThumbnail && data.Length > 0)
						ew_ResizeBinary(ref data, ref iThumbnailWidth, ref iThumbnailHeight, iInterpolation);
					if (!ew_ServerVar("HTTP_USER_AGENT").Contains("MSIE"))
						ew_Response.ContentType = ew_ContentType(data.Take(11));
					if (data.Take(8).SequenceEqual(new byte[] {0x50, 0x4B, 0x03, 0x04, 0x14, 0x00, 0x06, 0x00})) { // Fix Office 2007 documents // to be tested, requires system.Linq
						if (!data.Skip(data.Length - 4).SequenceEqual(new byte[] {0x00, 0x00, 0x00, 0x00}))
							data.Concat(new byte[] {0x00, 0x00, 0x00, 0x00});
					}
					ew_BinaryWrite(data);
					ew_End(); // ASPX
				}
			}
		}

		// Page Load event
		public virtual void Page_Load() {

			//ew_Write("Page Load");
		}

		// Page Unload event
		public virtual void Page_Unload() {

			//ew_Write("Page Unload");
		}

		// Page Redirecting event
		public virtual void Page_Redirecting(ref string url) {

			//url = newurl;
		}

		// Message Showing event
		// type = ""|"success"|"failure"|"warning"
		public virtual void Message_Showing(ref string msg, string type) {

			// Note: Do not change msg outside the following 4 cases.
			if (type == "success") {

				//msg = "your success message";
			} else if (type == "failure") {

				//msg = "your failure message";
			} else if (type == "warning") {

				//msg = "your warning message";
			} else {

				//msg = "your message";
			}
		}
	}
}
