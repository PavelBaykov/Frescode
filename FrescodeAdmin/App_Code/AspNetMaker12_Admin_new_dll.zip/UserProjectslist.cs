using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET WebPage class
//
public partial class AspNetMaker12_Admin_new_base : WebPage {

	// UserProjects_list
	public static dynamic UserProjects_list {
		get { return (dynamic)ew_PageData["UserProjects_list"]; }
		set { ew_PageData["UserProjects_list"] = value; }
	}

	//
	// Page class
	//
	public class cUserProjects_list_base<C, S> : cUserProjects
		where C : cConnectionBase, new()
		where S : cAdvancedSecurityBase, new()
	{

		// Page ID
		public string PageID = "list";

		// Project ID
		public string ProjectID = "{6EA87CB0-ED50-4AE1-9743-D14163EABB5A}";

		// Table name
		public string TableName = "UserProjects";

		// Page object name
		public string PageObjName = "UserProjects_list";

		// Grid form hidden field names
		public string FormName = "fUserProjectslist";

		public string FormActionName = "k_action";

		public string FormKeyName = "k_key";

		public string FormOldKeyName = "k_oldkey";

		public string FormBlankRowName = "k_blankrow";

		public string FormKeyCountName = "key_count";	

		// Page name
		public string PageName {
			get { return ew_CurrentPage(); }
		}

		// Page URL
		public string PageUrl {
			get {
				string PageUrl = ew_CurrentPage() + "?";
				if (UseTokenInUrl) PageUrl += "t=" + TableVar + "&"; // Add page token
				return PageUrl;
			}
		}

		// Export URLs
		public string ExportPrintUrl = "";

		public string ExportHtmlUrl = "";

		public string ExportExcelUrl = "";

		public string ExportWordUrl = "";

		public string ExportXmlUrl = "";

		public string ExportCsvUrl = "";

		public string ExportPdfUrl = "";

		// Custom export
		public bool ExportExcelCustom = false;

		public bool ExportWordCustom = false;

		public bool ExportPdfCustom = false; // Not supported // ASPX

		public bool ExportEmailCustom = false;

		// Update URLs
		public string InlineAddUrl = "";

		public string GridAddUrl = "";

		public string GridEditUrl = "";

		public string MultiDeleteUrl = "";

		public string MultiUpdateUrl = "";

		// Message
		public string Message {
			get { return Convert.ToString(ew_Session[EW_SESSION_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_MESSAGE] = msg;
			}
		}

		// Failure Message
		public string FailureMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_FAILURE_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_FAILURE_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_FAILURE_MESSAGE] = msg;
			}
		}

		// Success Message
		public string SuccessMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_SUCCESS_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_SUCCESS_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_SUCCESS_MESSAGE] = msg;
			}
		}

		// Warning Message
		public string WarningMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_WARNING_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_WARNING_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_WARNING_MESSAGE] = msg;
			}
		}

		// Show message
		public void ShowMessage() {
			bool hidden = false;
			string html = "";

			// Message
			string sMessage = Message;
			Message_Showing(ref sMessage, "");
			if (sMessage != "") { // Message in Session, display
				if (!hidden)
					sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sMessage;
				html += "<div class=\"alert alert-info ewInfo\">" + sMessage + "</div>";
				ew_Session[EW_SESSION_MESSAGE] = ""; // Clear message in Session
			}

			// Warning message
			var sWarningMessage = WarningMessage;
			Message_Showing(ref sWarningMessage, "warning");
			if (sWarningMessage != "") { // Message in Session, display
				if (!hidden)
					sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sWarningMessage;
				html += "<div class=\"alert alert-warning ewWarning\">" + sWarningMessage + "</div>";
				ew_Session[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
			}

			// Success message
			var sSuccessMessage = SuccessMessage;
			Message_Showing(ref sSuccessMessage, "success");
			if (sSuccessMessage != "") { // Message in Session, display
				if (!hidden)
					sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sSuccessMessage;
				html += "<div class=\"alert alert-success ewSuccess\">" + sSuccessMessage + "</div>";
				ew_Session[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
			}

			// Failure message
			var sErrorMessage = FailureMessage;
			Message_Showing(ref sErrorMessage, "failure");
			if (sErrorMessage != "") { // Message in Session, display
				if (!hidden)
					sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sErrorMessage;
				html += "<div class=\"alert alert-danger ewError\">" + sErrorMessage + "</div>";
				ew_Session[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
			}
			ew_Write("<div class=\"ewMessageDialog\"" + ((hidden) ? " style=\"display: none;\"" : "") + ">" + html + "</div>");
		}								

		public string PageHeader = "";

		public string PageFooter = "";

		// Show Page Header
		public void ShowPageHeader() {
			string sHeader = PageHeader;
			Page_DataRendering(ref sHeader);
			if (ew_NotEmpty(sHeader)) // Header exists, display
				ew_Write("<p>" + sHeader + "</p>");
		}

		// Show Page Footer
		public void ShowPageFooter() {
			string sFooter = PageFooter;
			Page_DataRendered(ref sFooter);
			if (ew_NotEmpty(sFooter)) // Fotoer exists, display
				ew_Write("<p>" + sFooter + "</p>");
		}

		// Validate page request
		public bool IsPageRequest {
			get {
				if (UseTokenInUrl) {			
					if (ObjForm != null)
						return (TableVar == ObjForm.GetValue("t"));
					if (ew_NotEmpty(ew_Get("t")))
						return (TableVar == ew_Get("t"));
					return false;		
				} else {
					return true;
				}
			}
		}

		// Token
		public string Token = "";

		public bool CheckToken = EW_CHECK_TOKEN;

		// Valid Post
		public bool ValidPost() {
			if (!CheckToken || !IsPost)
				return true;
			if (ew_Post(EW_TOKEN_NAME) == null)
				return false;
			return Convert.ToBoolean(ew_CheckToken(ew_Post(EW_TOKEN_NAME)));
		}

		// Create Token
		public void CreateToken() {
			if (CheckToken) {
				if (ew_Empty(Token) && CheckToken) // Create token
					Token = ew_CreateToken();
				gsToken = Token; // Save to global variable
			}
		}

		//
		// Page class constructor
		//
		public cUserProjects_list_base() {
			CurrentPage = this;

			// Language object
			if (Language == null)
				Language = new cLanguage();

			// Table object (UserProjects)
			if (UserProjects == null || UserProjects is cUserProjects) {
				UserProjects = this;

				//CurrentTable = this;
			}

			// Initialize URLs
			ExportPrintUrl = PageUrl + "export=print";
			ExportExcelUrl = PageUrl + "export=excel";
			ExportWordUrl = PageUrl + "export=word";
			ExportHtmlUrl = PageUrl + "export=html";
			ExportXmlUrl = PageUrl + "export=xml";
			ExportCsvUrl = PageUrl + "export=csv";
			ExportPdfUrl = PageUrl + "export=pdf";
			InlineAddUrl = PageUrl + "a=add";
			GridAddUrl = PageUrl + "a=gridadd";
			GridEditUrl = PageUrl + "a=gridedit";
			MultiDeleteUrl = "UserProjectsdelete.cshtml";
			MultiUpdateUrl = "UserProjectsupdate.cshtml";

			// Start time
			StartTime = Environment.TickCount;

			// Open connection
			if (Conn == null)
				Conn = new C();

			// List options
			ListOptions = new cListOptions();
			ListOptions.TableVar = TableVar;

			// Export options
			ExportOptions = new cListOptions();
			ExportOptions.Tag = "div";
			ExportOptions.TagClassName = "ewExportOption";

			// Other options
			OtherOptions["addedit"] = new cListOptions();
			OtherOptions["addedit"].Tag = "div";
			OtherOptions["addedit"].TagClassName = "ewAddEditOption";
			OtherOptions["detail"] = new cListOptions();
			OtherOptions["detail"].Tag = "div";
			OtherOptions["detail"].TagClassName = "ewDetailOption";
			OtherOptions["action"] = new cListOptions();
			OtherOptions["action"].Tag = "div";
			OtherOptions["action"].TagClassName = "ewActionOption";
		}

		// 
		//  Page_Init
		//
		public void Page_Init() {
			CurrentAction = (ew_Get("a") != "") ? ew_Get("a") : ew_Post("a_list"); // Set up current action

			// Get grid add count
			int gridaddcnt = ew_ConvertToInt(ew_Get(EW_TABLE_GRID_ADD_ROW_COUNT));
			if (gridaddcnt > 0)
				GridAddRowCount = gridaddcnt;

			// Set up list options
			SetupListOptions();

			// Global Page Loading event
			ew_WebPage.Page_Loading();

			// Page Load event
			Page_Load();

			// Check token
			if (!ValidPost()) {
				ew_Response.Write(Language.Phrase("InvalidPostRequest"));
				Page_Terminate();
				ew_End();
			}

			// Process auto fill
			if (ew_Post("ajax") == "autofill") {
				string results = GetAutoFill(ew_Post("name"), ew_Post("q"));
				if (results != null) {

					// Clean output buffer
					if (!EW_DEBUG_ENABLED)
						ew_Response.Clear();
					ew_Response.Write(results);
					Page_Terminate();
					ew_End();
				}
			}

			// Create Token
			CreateToken();

			// Setup other options
			SetupOtherOptions();

			// Set "checkbox" visible
			if (CustomActions.Count > 0)
				ListOptions["checkbox"].Visible = true;
		}

		//
		// Page_Terminate
		//
		public void Page_Terminate(string url = "") {

			// Page Unload event
			Page_Unload();

			// Global Page Unloaded event
			ew_WebPage.Page_Unloaded();

			// Export
			if (ew_NotEmpty(CustomExport) && CustomExport == Export && EW_EXPORT.ContainsKey(CustomExport)) {
				var sContent = "";
				sContent = Regex.Match(ew_WebPage.Output.ToString(), @"<html>[\s\S]+</html>", RegexOptions.IgnoreCase).Value;
				if (ew_Empty(gsExportFile))
					gsExportFile = TableVar;
				dynamic doc = ew_CreateInstance(EW_EXPORT[CustomExport], new object[] { UserProjects, "" }); // ASPX
				doc.Text.Append(sContent);				
				if (Export == "email") {
				} else {
					doc.Export();
				}		
				ew_DeleteTmpImages(); // Delete temp images
				ew_GCollect(); // ASPX
				ew_End();
			}
			Page_Redirecting(ref url);

			 // Close connection
			if (Conn != null)
				Conn.Close();

			// Gargage collection // ASPX
			ew_GCollect();

			// Go to URL if specified
			if (ew_NotEmpty(url)) {  // ASPX
				if (EW_DEBUG_ENABLED)
					ew_Response.Clear();
				ew_Response.Redirect(ew_MapPath(url, false)); // ASPX
			}

			//ew_End();
		}

		// Class variables
		public cListOptions ListOptions; // List options

		public cListOptions ExportOptions; // Export options

		public cListOptions SearchOptions; // Search options

		public Dictionary<string, cListOptions> OtherOptions = new Dictionary<string, cListOptions>(); // Other options

		public int DisplayRecs = 20; // Number of display records

		public int StartRec;

		public int StopRec;

		public int TotalRecs = 0;

		public int RecRange = 10;

		public dynamic Pager;

		public string DefaultSearchWhere = ""; // Default search WHERE clause

		public string SearchWhere = ""; // Search WHERE clause

		public int RecCnt = 0; // Record count

		public int EditRowCnt;

		public int StartRowCnt = 1;

		//public int RowCnt = 0; // ASPX
		public Dictionary<int, dynamic> Attrs = new Dictionary<int, dynamic>(); // Row attributes and cell attributes

		public object RowIndex = 0; // Row index

		public int KeyCount = 0; // Key count

		public string RowAction = ""; // Row action

		public string RowOldKey = ""; // Row old key (for copy)

		public int RecPerRow = 0;

		public string MultiColumnClass;

		public string MultiColumnEditClass = "col-sm-12";

		public int MultiColumnCnt = 12;

		public int MultiColumnEditCnt = 12;

		public int GridCnt = 0;

		public int ColCnt = 0;		

		public string DbMasterFilter = ""; // Master filter

		public string DbDetailFilter = ""; // Detail filter

		public bool MasterRecordExists;	

		public string MultiSelectKey = "";

		public bool RestoreSearch = false;	

		public int Priv = 0;		

		public ewDataReader Recordset;

		public ewDataReader OldRecordset;

		//
		// Page main
		//
		public void Page_Main() {

			// Search filters
			string sSrchAdvanced = ""; // Advanced search filter
			string sSrchBasic = ""; // Basic search filter
			string sFilter = "";

			// *** perform grid event
			bool bGridInsert = false;
			bool bGridUpdate = false;
			Command = ew_Get("cmd").ToLower();
			if (IsPageRequest) { // Validate request

				// Process custom action first
				ProcessCustomAction();

				// Handle reset command
				ResetCmd();

				// Set up Breadcrumb
				if (ew_Empty(Export))
					SetupBreadcrumb();

				// Hide list options
				if (ew_NotEmpty(Export)) {
					ListOptions.HideAllOptions(new List<string>() {"sequence"});
					ListOptions.UseDropDownButton = false; // Disable drop down button
					ListOptions.UseButtonGroup = false; // Disable button group
				} else if (CurrentAction == "gridadd" || CurrentAction == "gridedit") {
					ListOptions.HideAllOptions();
					ListOptions.UseDropDownButton = false; // Disable drop down button
					ListOptions.UseButtonGroup = false; // Disable button group
				}

				// Hide export options
				if (ew_NotEmpty(Export) || ew_NotEmpty(CurrentAction))
					ExportOptions.HideAllOptions();

				// Hide other options
				if (ew_NotEmpty(Export)) {
					foreach (var kvp in OtherOptions)
						kvp.Value.HideAllOptions();
				}

				// Set up sorting order
				SetUpSortOrder();
			}

			// Restore display records
			if (RecordsPerPage == -1 || RecordsPerPage > 0) {
				DisplayRecs = RecordsPerPage; // Restore from Session
			} else {
				DisplayRecs = 20; // Load default
			}

			// Load Sorting Order
			LoadSortOrder();

			// Build filter
			sFilter = "";
			ew_AddFilter(ref sFilter, DbDetailFilter);
			ew_AddFilter(ref sFilter, SearchWhere);

			// Set up filter in session
			SessionWhere = sFilter;
			CurrentFilter = "";

			// Load record count first
			if (!IsAddOrEdit) // ASPX
				Recordset = LoadRecordset();

			// Search options
			SetupSearchOptions();
		}

		// Build filter for all keys
		public string BuildKeyFilter() {
			string sWrkFilter = "";

			// Update row index and get row key
			int rowindex = 1;
			ObjForm.Index = rowindex;
			string sThisKey = ObjForm.GetValue(FormKeyName);
			while (ew_NotEmpty(sThisKey)) {
				if (SetupKeyValues(sThisKey)) {
					string sFilter = KeyFilter;
					if (ew_NotEmpty(sWrkFilter)) sWrkFilter += " OR "; 
					sWrkFilter += sFilter;
				} else {
					sWrkFilter = "0=1";
					break;
				}

				// Update row index and get row key
				rowindex++; // next row
				ObjForm.Index = rowindex;
				sThisKey = ObjForm.GetValue(FormKeyName);
			}
			return sWrkFilter;
		}

		// Set up key values
		public bool SetupKeyValues(string key) {
			string[] arKeyFlds = key.Split(new char[] {Convert.ToChar(EW_COMPOSITE_KEY_SEPARATOR)});
			if (arKeyFlds.Length >= 2) {
				UserProjects.User_Id.FormValue = arKeyFlds[0];
				UserProjects.Project_Id.FormValue = arKeyFlds[1];
				if (!Information.IsNumeric(UserProjects.Project_Id.FormValue))
					return false;
			}
			return true;
		}

		// Check if empty row
		public bool EmptyRow() {
			return false;
		}

		// Set up sort parameters
		public void SetUpSortOrder() {

			// Check for "order" parameter
			if (ew_NotEmpty(ew_Get("order"))) {
				CurrentOrder = ew_Get("order");
				CurrentOrderType = ew_Get("ordertype");
				UpdateSort(User_Id); // User_Id
				UpdateSort(Project_Id); // Project_Id
				StartRecordNumber = 1; // Reset start position
			}
		}

		// Load sort order parameters
		public void LoadSortOrder() {
			string sOrderBy = SessionOrderBy; // Get Order By from Session
			if (ew_Empty(sOrderBy)) {
				if (ew_NotEmpty(SqlOrderBy)) {
					sOrderBy = SqlOrderBy;
					SessionOrderBy = sOrderBy;
				}
			}
		}

		// Reset command
		// cmd=reset (Reset search parameters)
		// cmd=resetall (Reset search and master/detail parameters)
		// cmd=resetsort (Reset sort parameters)
		public void ResetCmd() {

			// Get reset cmd
			if (Command.ToLower().StartsWith("reset")) {

				// Reset sorting order
				if (ew_SameText(Command, "resetsort")) {
					string sOrderBy = "";
					SessionOrderBy = sOrderBy;
					User_Id.Sort = "";
					Project_Id.Sort = "";
				}

				// Reset start position
				StartRec = 1;
				StartRecordNumber = StartRec;
			}
		}

		// Set up list options
		public void SetupListOptions() {
			cListOption item;

			// Add group option item
			item = ListOptions.Add(ListOptions.GroupOptionName);
			item.Body = "";
			item.OnLeft = false;
			item.Visible = false;

			// "view"
			item = ListOptions.Add("view");
			item.CssStyle = "white-space: nowrap;";
			item.Visible = true;
			item.OnLeft = false;

			// "edit"
			item = ListOptions.Add("edit");
			item.CssStyle = "white-space: nowrap;";
			item.Visible = true;
			item.OnLeft = false;

			// "copy"
			item = ListOptions.Add("copy");
			item.CssStyle = "white-space: nowrap;";
			item.Visible = true;
			item.OnLeft = false;

			// "delete"
			item = ListOptions.Add("delete");
			item.CssStyle = "white-space: nowrap;";
			item.Visible = true;
			item.OnLeft = false;

			// "checkbox"
			item = ListOptions.Add("checkbox");
			item.CssStyle = "white-space: nowrap; text-align: center; vertical-align: middle; margin: 0px;";
			item.Visible = false;
			item.OnLeft = false;
			item.Header = "<input type=\"checkbox\" name=\"key\" id=\"key\" onclick=\"ew_SelectAllKey(this);\">";
			item.ShowInDropDown = false;
			item.ShowInButtonGroup = false;

			// Drop down button for ListOptions
			ListOptions.UseImageAndText = true;
			ListOptions.UseDropDownButton = false;
			ListOptions.DropDownButtonPhrase = Language.Phrase("ButtonListOptions");
			ListOptions.UseButtonGroup = false;
		if (ListOptions.UseButtonGroup && ew_IsMobile())
			ListOptions.UseDropDownButton = true;
			ListOptions.ButtonClass = "btn-sm"; // Class for button group	

			// Call ListOptions_Load event
			ListOptions_Load();
			SetupListOptionsExt();
			item = ListOptions[ListOptions.GroupOptionName];
			item.Visible = ListOptions.GroupOptionVisible;
		}

		// Render list options
		public void RenderListOptions() {
			cListOption oListOpt;
			ListOptions.LoadDefault();
			string links = "", KeyName = "";

			// "view"
			oListOpt = ListOptions["view"];
			if (true)
				oListOpt.Body = "<a class=\"ewRowLink ewView\" title=\"" + ew_HtmlTitle(Language.Phrase("ViewLink")) + "\" data-caption=\"" + ew_HtmlTitle(Language.Phrase("ViewLink")) + "\" href=\"" + ew_HtmlEncode(ViewUrl) + "\">" + Language.Phrase("ViewLink") + "</a>";

			// "edit"
			oListOpt = ListOptions["edit"];
			if (true) {
				oListOpt.Body = "<a class=\"ewRowLink ewEdit\" title=\"" + ew_HtmlTitle(Language.Phrase("EditLink")) + "\" data-caption=\"" + ew_HtmlTitle(Language.Phrase("EditLink")) + "\" href=\"" + ew_HtmlEncode(EditUrl) + "\">" + Language.Phrase("EditLink") + "</a>";
			}

			// "copy"
			oListOpt = ListOptions["copy"];
			if (true) {
				oListOpt.Body = "<a class=\"ewRowLink ewCopy\" title=\"" + ew_HtmlTitle(Language.Phrase("CopyLink")) + "\" data-caption=\"" + ew_HtmlTitle(Language.Phrase("CopyLink")) + "\" href=\"" + ew_HtmlEncode(CopyUrl) + "\">" + Language.Phrase("CopyLink") + "</a>";
			} else {
				oListOpt.Body = "";
			}

			// "delete"
			oListOpt = ListOptions["delete"];
			if (true)
				oListOpt.Body = "<a class=\"ewRowLink ewDelete\"" + "" + " title=\"" + ew_HtmlTitle(Language.Phrase("DeleteLink")) + "\" data-caption=\"" + ew_HtmlTitle(Language.Phrase("DeleteLink")) + "\" href=\"" + ew_HtmlEncode(DeleteUrl) + "\">" + Language.Phrase("DeleteLink") + "</a>";
			else
				oListOpt.Body = "";

			// "checkbox"
			oListOpt = ListOptions["checkbox"];
			oListOpt.Body = "<input type=\"checkbox\" name=\"key_m\" value=\"" + ew_HtmlEncode(User_Id.CurrentValue + EW_COMPOSITE_KEY_SEPARATOR + Project_Id.CurrentValue) + "\" onclick='ew_ClickMultiCheckbox(event, this);'>";
			RenderListOptionsExt();

			// Call ListOptions_Rendered event
			ListOptions_Rendered();
		}

		// Set up other options
		public void SetupOtherOptions() {
			cListOptions option;
			cListOption item;
			var options = OtherOptions;
			option = options["addedit"];

			// Add
			item = option.Add("add");
			item.Body = "<a class=\"ewAddEdit ewAdd\" title=\"" + ew_HtmlTitle(Language.Phrase("Add")) + "\" data-caption=\"" + ew_HtmlTitle(Language.Phrase("AddLink")) + "\" href=\"" + ew_HtmlEncode(AddUrl) + "\">" + Language.Phrase("AddLink") + "</a>";
			item.Visible = (AddUrl != "");
			option = options["action"];

			// Set up options default
			foreach (var kvp in options) {
				var opt = kvp.Value;
				opt.UseImageAndText = true;
				opt.UseDropDownButton = false;
				opt.UseButtonGroup = true;
				opt.ButtonClass = "btn-sm"; // Class for button group
				item = opt.Add(opt.GroupOptionName);
				item.Body = "";
				item.Visible = false;
			}
			options["addedit"].DropDownButtonPhrase = Language.Phrase("ButtonAddEdit");
			options["detail"].DropDownButtonPhrase = Language.Phrase("ButtonDetails");
			options["action"].DropDownButtonPhrase = Language.Phrase("ButtonActions");
		}

		// Render other options
		public void RenderOtherOptions() {
			cListOptions option;
			cListOption item;
			var options = OtherOptions;			
				option = options["action"];
				foreach (KeyValuePair<string, string> action in CustomActions) {

					// Add custom action
					item = option.Add("custom_" + action.Key);
					item.Body = "<a class=\"ewAction ewCustomAction\" href=\"\" onclick=\"ew_SubmitSelected(document.fUserProjectslist, '" + ew_CurrentUrl() + "', null, '" + action.Key + "');return false;\">" + action.Value + "</a>";
				}

				// Hide grid edit, multi-delete and multi-update
				if (TotalRecs <= 0) {
					option = options["addedit"];
					item = option["gridedit"];
					if (item != null) item.Visible = false;
					option = options["action"];
					item = option["multidelete"];
					if (item != null) item.Visible = false;
					item = option["multiupdate"];
					if (item != null) item.Visible = false;
				}
		}

		// Process custom action
		public void ProcessCustomAction() {
			var sFilter = GetKeyFilter();
			var UserAction = ew_Post("useraction");
			if (sFilter != "" && UserAction != "") {
				CurrentFilter = sFilter;
				var sSql = SQL;
				var rsuser = Conn.GetRows(sSql);

				// Call row custom action event
				if (rsuser.Count > 0) {
					Conn.BeginTrans();
					bool Processed = true;
					foreach (var row in rsuser) {
						Processed = Row_CustomAction(UserAction, row);
						if (!Processed) break;
					}
					if (Processed) {
						Conn.CommitTrans(); // Commit the changes
						if (ew_Empty(SuccessMessage))
							SuccessMessage = Language.Phrase("CustomActionCompleted").Replace("%s", UserAction); // Set up success message
					} else {
						Conn.RollbackTrans(); // Rollback changes

						// Set up error message
						if (ew_NotEmpty(SuccessMessage) || ew_NotEmpty(FailureMessage)) {

							// Use the message, do nothing
						} else if (ew_NotEmpty(CancelMessage)) {
							FailureMessage = CancelMessage;
							CancelMessage = "";
						} else {
							FailureMessage = Language.Phrase("CustomActionCancelled").Replace("%s", UserAction);
						}
					}
				}
			}
		}

	// Set up search options
	public void SetupSearchOptions() {
		cListOption item;
		SearchOptions = new cListOptions();
		SearchOptions.Tag = "div";
		SearchOptions.TagClassName = "ewSearchOption";

		// Button group for search
		SearchOptions.UseDropDownButton = false;
		SearchOptions.UseImageAndText = true;
		SearchOptions.UseButtonGroup = true;
		SearchOptions.DropDownButtonPhrase = Language.Phrase("ButtonSearch");

		// Add group option item
		item = SearchOptions.Add(SearchOptions.GroupOptionName);
		item.Body = "";
		item.Visible = false;

		// Hide search options
		if (ew_NotEmpty(Export) || CurrentAction == "gridadd" || CurrentAction == "gridedit")
			SearchOptions.HideAllOptions();
		}

		public void SetupListOptionsExt() {
		}

		public void RenderListOptionsExt() {
		}

		// Set up starting record parameters
		public void SetUpStartRec() {
			int PageNo;

			// Exit if DisplayRecs = 0
			if (DisplayRecs == 0)
				return;
			if (IsPageRequest) { // Validate request

				// Check for a "start" parameter
				if (ew_NotEmpty(ew_Get(EW_TABLE_START_REC)) && Information.IsNumeric(ew_Get(EW_TABLE_START_REC))) {
					StartRec = ew_ConvertToInt(ew_Get(EW_TABLE_START_REC));
					StartRecordNumber = StartRec;
				} else if (ew_NotEmpty(ew_Get(EW_TABLE_PAGE_NO)) && Information.IsNumeric(ew_Get(EW_TABLE_PAGE_NO))) {
					PageNo = ew_ConvertToInt(ew_Get(EW_TABLE_PAGE_NO));
					StartRec = (PageNo - 1) * DisplayRecs + 1;
					if (StartRec <= 0) {
						StartRec = 1;
					} else if (StartRec >= ((TotalRecs - 1) / DisplayRecs) * DisplayRecs + 1) {
						StartRec = ((TotalRecs - 1) / DisplayRecs) * DisplayRecs + 1;
					}
					StartRecordNumber = StartRec;
				}
			}
			StartRec = StartRecordNumber;

			// Check if correct start record counter
			if (StartRec <= 0) {	// Avoid invalid start record counter
				StartRec = 1;	// Reset start record counter
				StartRecordNumber = StartRec;
			} else if (StartRec > TotalRecs) {	// Avoid starting record > total records
				StartRec = ((TotalRecs - 1) / DisplayRecs) * DisplayRecs + 1;	// Point to last page first record
				StartRecordNumber = StartRec;
			} else if ((StartRec - 1) % DisplayRecs != 0) {
				StartRec = ((StartRec - 1) / DisplayRecs) * DisplayRecs + 1;	// Point to page boundary
				StartRecordNumber = StartRec;
			}
		}

		// Load recordset
		public ewDataReader LoadRecordset() {

			// Load list page SQL
			string sSql = SelectSQL;
			if (EW_DEBUG_ENABLED)
				ew_SetDebugMsg(sSql); 

			// Count
			TotalRecs = -1;		
			try {
				string sCntSql = SelectCountSQL;

				// Write SQL for debug
				if (EW_DEBUG_ENABLED)
					ew_SetDebugMsg(sCntSql);
				TotalRecs = Convert.ToInt32(Conn.ExecuteScalar(sCntSql));
			} catch {
				TotalRecs = -1;
			}

			// Load recordset
			var rs = Conn.GetDataReader(sSql);		
			if (TotalRecs < 0 && rs != null && rs.HasRows) {
				TotalRecs = 0;
				using (var rstemp = Conn.OpenDataReader(sSql)) {
					while (rstemp.Read())
						TotalRecs++;
				}
			}

			// Recordset_Selected server event is not supported for ASP.NET
			return rs;
		}

		// Load row based on key values
		public bool LoadRow() {
			string sFilter = KeyFilter;

			// Call Row Selecting event
			Row_Selecting(ref sFilter);

			// Load SQL based on filter
			CurrentFilter = sFilter;
			string sSql = SQL;

			// Write SQL for debug
			if (EW_DEBUG_ENABLED)
				ew_SetDebugMsg(sSql); // Show SQL for debugging
			var res = false;
			try {
				using (var rsrow = Conn.OpenDataReader(sSql)) {
					if (rsrow != null && rsrow.Read()) {				
						LoadRowValues(rsrow);								
						res = true;
					} else {
						return false;
					}
				}
			} catch {
				if (EW_DEBUG_ENABLED)
					throw;
			}
			return res;
		}

		// Load row values from recordset
		public void LoadRowValues(ewDataReader dr) {
			if (dr == null)
				return;
			string sDetailFilter;

			// Call Row Selected event
			var row = Conn.GetRow(dr);
			Row_Selected(ref row);
			User_Id.DbValue = row["User_Id"];
			Project_Id.DbValue = row["Project_Id"];
		}

		// Load DbValue from recordset
		public void LoadDbValues(OrderedDictionary row) {
			if (row == null) return;
			User_Id.SetDbValue(row["User_Id"]);
			Project_Id.SetDbValue(row["Project_Id"]);
		}

		// Load old record
		public bool LoadOldRecord(cConnectionBase cnn = null) {

			// Load key values from Session
			bool bValidKey = true;
			if (ew_NotEmpty(GetKey("User_Id")))
				User_Id.CurrentValue = GetKey("User_Id"); // User_Id
			else
				bValidKey = false;
			if (ew_NotEmpty(GetKey("Project_Id")))
				Project_Id.CurrentValue = GetKey("Project_Id"); // Project_Id
			else
				bValidKey = false;

			// Load old recordset
			if (bValidKey) {
				CurrentFilter = KeyFilter;
				string sSql = SQL;
				try {
					OldRecordset = (cnn != null) ? cnn.OpenDataReader(sSql) : Conn.OpenDataReader(sSql);
					if (OldRecordset != null && OldRecordset.Read())
						LoadRowValues(OldRecordset); // Load row values
					return true;
				} catch { return false; }
			} else {
				OldRecordset = null;
			}
			return bValidKey;
		}

		// Render row values based on field settings
		public void RenderRow() {

			// Call Row_Rendering event
			Row_Rendering();

			// Common render codes for all row types
			// User_Id
			// Project_Id

			if (RowType == EW_ROWTYPE_VIEW) { // View row

				// User_Id
				if (ew_NotEmpty(User_Id.CurrentValue)) {
					sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(User_Id.CurrentValue).Trim(), EW_DATATYPE_STRING);
				sSqlWrk = "SELECT [Id], [FirstName] AS [DispFld], [LastName] AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld] FROM [dbo].[AspNetUsers]";
				sWhereWrk = "";
				sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "User_Id"));
				if (ew_NotEmpty(sLookupTblFilter)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
				}
				if (ew_NotEmpty(sFilterWrk)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
				}

				// Call Lookup selecting
				Lookup_Selecting(User_Id, ref sWhereWrk);
				if (sWhereWrk != "") {
					sSqlWrk += " WHERE " + sWhereWrk;
				}
					odwrk = Conn.GetRow(sSqlWrk);
					if (odwrk != null) {
						User_Id.ViewValue = odwrk["DispFld"];
						User_Id.ViewValue = String.Concat(User_Id.ViewValue, ew_ValueSeparator(1, User_Id), odwrk["Disp2Fld"]);
					} else {
						User_Id.ViewValue = User_Id.CurrentValue;
					}	
				} else {
					User_Id.ViewValue = System.DBNull.Value;
				}

				// Project_Id
				if (ew_NotEmpty(Project_Id.CurrentValue)) {
					sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(Project_Id.CurrentValue).Trim(), EW_DATATYPE_NUMBER);
				sSqlWrk = "SELECT [Id], [Name] AS [DispFld], '' AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld] FROM [dbo].[Projects]";
				sWhereWrk = "";
				sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "Project_Id"));
				if (ew_NotEmpty(sLookupTblFilter)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
				}
				if (ew_NotEmpty(sFilterWrk)) {
					sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
				}

				// Call Lookup selecting
				Lookup_Selecting(Project_Id, ref sWhereWrk);
				if (sWhereWrk != "") {
					sSqlWrk += " WHERE " + sWhereWrk;
				}
					odwrk = Conn.GetRow(sSqlWrk);
					if (odwrk != null) {
						Project_Id.ViewValue = odwrk["DispFld"];
					} else {
						Project_Id.ViewValue = Project_Id.CurrentValue;
					}	
				} else {
					Project_Id.ViewValue = System.DBNull.Value;
				}

				// User_Id
				User_Id.HrefValue = "";
				User_Id.TooltipValue = "";

				// Project_Id
				Project_Id.HrefValue = "";
				Project_Id.TooltipValue = "";
			}

			// Call Row Rendered event
			if (RowType != EW_ROWTYPE_AGGREGATEINIT)
				Row_Rendered();
		}

		// Set up Breadcrumb
		public void SetupBreadcrumb() {
			Breadcrumb = new cBreadcrumb();			
			var url = ew_CurrentUrl();
			url = url.Substring(url.LastIndexOf("/") + 1);
			url = Regex.Replace(url, @"\?cmd=reset(all){0,1}$", ""); // Remove cmd=reset / cmd=resetall
			Breadcrumb.Add("list", TableVar, url, "", TableVar, true);
		}

		// Page Load event
		public virtual void Page_Load() {

			//ew_Write("Page Load");
		}

		// Page Unload event
		public virtual void Page_Unload() {

			//ew_Write("Page Unload");
		}

		// Page Redirecting event
		public virtual void Page_Redirecting(ref string url) {

			//url = newurl;
		}

		// Message Showing event
		// type = ""|"success"|"failure"|"warning"
		public virtual void Message_Showing(ref string msg, string type) {

			// Note: Do not change msg outside the following 4 cases.
			if (type == "success") {

				//msg = "your success message";
			} else if (type == "failure") {

				//msg = "your failure message";
			} else if (type == "warning") {

				//msg = "your warning message";
			} else {

				//msg = "your message";
			}
		}

		// Page_Render event
		public virtual void Page_Render() {

			//ew_Write("Page Render");
		}

		// Page Data Rendering event
		public virtual void Page_DataRendering(ref string header) {

			// Example:
			//header = "your header";

		}

		// Page Data Rendered event
		public virtual void Page_DataRendered(ref string footer) {

			// Example:
			//footer = "your footer";

		}

		// Form Custom Validate event
		public virtual bool Form_CustomValidate(ref string CustomError) {

			//Return error message in CustomError
			return true;
		}

		// ListOptions Load event
		public virtual void ListOptions_Load() {

			// Example: 
			//var opt = ListOptions.Add("new");
			//opt.Header = "xxx";
			//opt.OnLeft = true; // Link on left
			//opt.MoveTo(0); // Move to first column

		}

		// ListOptions Rendered event
		public virtual void ListOptions_Rendered() {

			//Example: 
			//ListOptions["new"].Body = "xxx";

		}

		// Row Custom Action event
		public virtual bool Row_CustomAction(string action, OrderedDictionary row) {

			// Return false to abort
			return true;
		}

		// Page Exporting event
		// ExportDoc = export document object
		public virtual bool Page_Exporting() {

			//ExportDoc.Text = "my header"; // Export header
			//return false; // Return FALSE to skip default export and use Row_Export event

			return true; // Return TRUE to use default export and skip Row_Export event
		}

		// Row Export event
		// ExportDoc = export document object
		public virtual void Row_Export(ewDataReader rs) {

		    // ExportDoc.Text += "my content"; // Build HTML with field value: $rs["MyField"] or $this->MyField->ViewValue
		}

		// Page Exported event
		// ExportDoc = export document object
		public virtual void Page_Exported() {

			//ExportDoc.Text += "my footer"; ' Export footer
			//ew_Write(ExportDoc.Text);

		}
	}
}
