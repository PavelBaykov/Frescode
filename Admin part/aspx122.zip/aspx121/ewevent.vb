<!--##session eventcode##-->
<!--## for (var i = 0; i < arNameSpace.length; i++) { ##-->
Imports <!--##=arNameSpace[i]##-->
<!--## } ##-->

'
' ASP.NET Maker 12 Project Class
'
Partial Public Class <!--##=sProjClassName##-->
	Inherits <!--##=sProjClassName##-->_base

	'
	' Global user code
	'
	<!--##~GetServerEvent("Global","Global Code")##-->
	
	
	'
	' Global events
	'
	<!--##~GetServerEvent("Global","Page_Loading","",true)##-->
	<!--##~GetServerEvent("Global","Page_Rendering")##-->
	<!--##~GetServerEvent("Global","Page_Unloaded","",true)##-->	
	
	'
	' Connection
	'
	Public Class cConnection
		Inherits cConnectionBase
	
		' Constructor
		Public Sub New(ConnStr As String)
			MyBase.New(ConnStr)
		End Sub
		
		' Constructor
		Public Sub New()
			MyBase.New()
		End Sub
	
		<!--##~GetServerEvent("Global","Database_Connecting","",true)##-->
		<!--##~GetServerEvent("Global","Database_Connected","",true)##-->
	End Class
	
	' Execute SQL
	Public Shared Function ew_Execute(Sql As String) As Integer
		Using c = New cConnection()
			Return c.ExecuteNonQuery(Sql)
		End Using
	End Function
	
	' Execute SQL and return first value of first row
	Public Shared Function ew_ExecuteScalar(Sql As String) As Object
		Using c = New cConnection()
			Return c.ExecuteScalar(Sql)
		End Using
	End Function
	
	' Execute SQL and return first value of first row as string
	' for use with As<TValue>, As<TValue>(String, TValue) and Is<TValue>
	Public Shared Function ew_ExecuteValue(Sql As String) As String
		Using c = New cConnection()
			Return Convert.ToString(c.ExecuteScalar(Sql))
		End Using
	End Function
	
	' Execute SQL and return first row as OrderedDictionary
	Public Shared Function ew_ExecuteRow(Sql As String) As OrderedDictionary
		Using c = New cConnection()
			Return c.GetRow(Sql)
		End Using
	End Function
	
	' Execute SQL and return List<OrderedDictionary>
	Public Shared Function ew_ExecuteRows(Sql ) As List(Of OrderedDictionary)
		Using c = New cConnection()
			Return c.GetRows(Sql)
		End Using
	End Function

	' Executes the query, and returns the row(s) as JSON
	Public Shared Function ew_ExecuteJson(Sql As String, Optional FirstOnly As Boolean = True) As String
		Using c = New cConnection()
			If FirstOnly Then
				Dim list = New List(Of OrderedDictionary)()
				list.Add(c.GetRow(Sql))
				Return JsonConvert.SerializeObject(list)
			Else
				Return JsonConvert.SerializeObject(c.GetRows(Sql))
			End If
		End Using
	End Function

	' Execute SQL and return first row
	Public Shared Function ew_ExecuteRecord(Sql As String) As DbDataRecord
		Using c = New cConnection()
			Return c.GetRecord(Sql)
		End Using
	End Function
	
	' Execute SQL and return List<DbDataRecord>
	Public Shared Function ew_ExecuteRecords(Sql As String) As List(Of DbDataRecord)
		Using c = New cConnection()
			Return c.GetRecords(Sql)
		End Using
	End Function
	
	'
	' Advanced Security
	'
	Public Class cAdvancedSecurity
		Inherits cAdvancedSecurityBase
		
		Public Conn As cConnection
	
		Public Sub New()
			MyBase.New(If(TypeOf ew_PageData("Conn") Is cConnection, ew_PageData("Conn"), New cConnection()))
		End Sub		
		
		<!--##~GetServerEvent("Global","UserID_Loading","",true)##-->
		<!--##~GetServerEvent("Global","UserID_Loaded","",true)##-->
		<!--##~GetServerEvent("Global","UserLevel_Loaded","",true)##-->
		<!--##~GetServerEvent("Global","TablePermission_Loading","",true)##-->
		<!--##~GetServerEvent("Global","TablePermission_Loaded","",true)##-->
		<!--##~GetServerEvent("Global","User_CustomValidate","",true)##-->
		<!--##~GetServerEvent("Global","User_Validated","",true)##-->
		<!--##~GetServerEvent("Global","User_PasswordExpired","",true)##-->
	End Class
	
	'
	' Menu
	'
	Public Class cMenu
		Inherits cMenuBase
	
		Public Sub New(MenuId As Object, Optional Mobile As Boolean = False)
			MyBase.New(MenuId, Mobile)
		End Sub
		
		Public Overrides Function Render(Optional ret As Boolean = False) As String
			Dim m = Me
			If IsRoot Then
				Menu_Rendering(m)
			End If
			Return MyBase.Render(ret)
		End Function
		
		<!--##~GetServerEvent("Global","MenuItem_Adding","",true)##-->
		<!--##~GetServerEvent("Global","Menu_Rendering","",false)##-->
	End Class	

End Class
<!--##/session##-->