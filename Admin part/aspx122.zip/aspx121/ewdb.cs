<!--##session ewdb##-->
<!--##
	// Database name
	sDbVar = DB.DBVar;
	if (PROJ.OutputNameLCase)
		sDbVar = sDbVar.toLowerCase();
##-->
	// Database helper class
	public class c<!--##=sDbVar##-->_db<C> : IDisposable
		where C : cConnectionBase, new()
	{
		// Language
		public cLanguage Lang; // ASPX
	
		// Connection
		public cConnectionBase Connection;
	
		// Constructor
		public c<!--##=sDbVar##-->_db(string ConnStr = "", string LangFolder = "", string LangId = "") {
			// Open connection
			if (Connection == null)
				Connect(ConnStr);
			// Set up language object
			if (ew_NotEmpty(LangFolder))
				this.Lang = new cLanguage(LangFolder, LangId);
			else if (Language != null)
				this.Lang = Language;
		}
	
		// Connect to database
		public void Connect(string ConnStr = "") {
			if (ConnStr == "") {
				Connection = new C();
			} else {
				Connection = (cConnectionBase)Activator.CreateInstance(typeof(C), new object[] { ConnStr });
			}
		}
	
		// Execute the query, and return the row(s) as JSON
		public string ExecuteJson(string Sql, bool FirstOnly = true) {
			if (FirstOnly) {
				var row = Connection.GetRow(Sql); 
				return (row != null) ? ew_ArrayToJson(row) : "false";
			} else {
				var ar = Connection.GetRows(Sql); 
				return (ar != null) ? ew_ArrayToJson(ar) : "false";
			}
		}
	
		// Execute UPDATE, INSERT, or DELETE statements
		public int Execute(string Sql) {
			return Connection.ExecuteNonQuery(Sql);
		}
	
		// Execute the query, and return the first column of the first row
		public object ExecuteScalar(string Sql) {
			return Connection.ExecuteScalar(Sql);
		}
	
		// Execute the query, and return the first row as OrderedDictionary
		public OrderedDictionary ExecuteRow(string Sql) {
			return Connection.GetRow(Sql);
		}
		
		// Execute the query, and return the rows as List<OrderedDictionary> // ASPX
		public List<OrderedDictionary> ExecuteRows(string Sql) {
			return Connection.GetRows(Sql);
		}
	
		// Execute the query, and return the datareader
		public ewDataReader ExecuteDataReader(string Sql) { // ASPX
			return Connection.OpenDataReader(Sql);
		}
	
		// Table CSS class name
		public string TableClass = "table table-bordered table-striped ewDbTable";
		
		// Get result in HTML table
		// options(Dictionary<string, object>): 
		// - fieldcaption(bool|Dictionary<string, string>)
		// - horizontal(bool)
		// - tablename(string|List<string>)
		// - tableclass(string)
		public string ExecuteHtml(string Sql, Dictionary<string, object> options = null) {
			if (options == null)
				options = new Dictionary<string, object>();
			var horizontal = options.ContainsKey("horizontal") && Convert.ToBoolean(options["horizontal"]);
			var rs = ExecuteDataReader(Sql);
			if (rs == null || !rs.HasRows || rs.FieldCount < 1)
				return "";
			string html = "", vhtml = "";
			string classname = (options.ContainsKey("tableclass") && ew_NotEmpty(options["tableclass"])) ? Convert.ToString(options["tableclass"]) : TableClass;
			int cnt = 0;
			if (rs.Read()) { // First row
				cnt++;
				// Vertical table
				vhtml = "<table class=\"" + classname + "\"><tbody>";
				for (var i = 0; i < rs.FieldCount; i++) {
					vhtml += "<tr>";
					vhtml += "<td>" + GetFieldCaption(rs.GetName(i), options) + "</td>";
					vhtml += "<td>" + Convert.ToString(rs[i]) + "</td></tr>";
				}
				vhtml += "</tbody></table>";
				// Horizontal table
				html = "<table class=\"" + classname + "\">";
				html += "<thead><tr>";
				for (var i = 0; i < rs.FieldCount; i++)
					html += "<th>" + GetFieldCaption(rs.GetName(i), options) + "</th>";
				html += "</tr></thead>";
				html += "<tbody>";
				html += "<tr>";
				for (var i = 0; i < rs.FieldCount; i++)
					html += "<td>" + Convert.ToString(rs[i]) + "</td>";
				html += "</tr>";						
			}				
			while (rs.Read()) { // Other rows
				cnt++;
				html += "<tr>";					
				for (var i = 0; i < rs.FieldCount; i++)
					html += "<td>" + Convert.ToString(rs[i]) + "</td>";
				html += "</tr>";
			}
			if (html != "")
				html += "</tbody></table>";
			return (cnt > 1 || horizontal) ? html : vhtml;
		}
	
		public string GetFieldCaption(string key, Dictionary<string, object> options) {
			if (options == null)
				return key;
			object tablename = options.ContainsKey("tablename") ? options["tablename"] : null;
			string caption = "";
			bool usecaption = options.ContainsKey("fieldcaption") && options["fieldcaption"] != null;
			if (usecaption) {
				if (ew_IsList(options["fieldcaption"])) {
					caption = ((Dictionary<string, string>)options["fieldcaption"])[key];
				} else if (ew_NotEmpty(Lang)) {
					if (ew_IsList(tablename)) {
						foreach (var tbl in (List<string>)tablename) {
							caption = Lang.FieldPhrase(tbl, key, "FldCaption");
							if (ew_NotEmpty(caption))
								break;
						}
					} else if (ew_NotEmpty(tablename)) {
						caption = Lang.FieldPhrase(Convert.ToString(tablename), key, "FldCaption");
					}
				}
			}
			return (ew_NotEmpty(caption)) ? caption : key;
		}
		
		// Dispose // ASPX
		public void Dispose() {
			Connection.Dispose();
		}
	
	}
<!--##/session##-->
