/*
 ***
 ***  IMPORTANT - DO NOT CHANGE
 ***
 */
 
 
//
// Common variables
//

// Global system variable: bDBMsAccess, bDBMsSql, bDBMySql, bDBOracle, bDBPostgreSql

var sProviderName, sProviderPrefix, sSqlParamSymbol, sLastInsertId, sProviderAssembly;
var ewConnection, ewCommand, ewDataReader, ewTransaction, ewDbType;
var sCodeFile;
var sProjVar = PROJ.ProjVar;
var sProjClassName = ew_ProjClassName();

// Set up .NET database specific parameters
if (bDBMsAccess) {
	sProviderName = "System.Data.OleDb";
	sProviderPrefix = "OleDb";
	sSqlParamSymbol = "?";
	sLastInsertId = "SELECT @@Identity";
	sProviderAssembly = "";
	ewDbType = "System.Data.OleDb.OleDbType";
} else if (bDBMsSql) { // Microsoft SQL Server
  	sProviderName = "System.Data.SqlClient";
	sProviderPrefix = "Sql";
	sSqlParamSymbol = "@"; // Requires name
	sLastInsertId = "SELECT @@Identity";
	sProviderAssembly = "";
	ewDbType = "System.Data.SqlDbType";
} else if (bDBOracle) { // Oracle
  	sProviderName = "System.Data.OracleClient";
	sProviderPrefix = "Oracle";
	sSqlParamSymbol = ":"; // Requires name
	sLastInsertId = "";
	sProviderAssembly = "System.Data.OracleClient, Version=4.0.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089";
	ewDbType = "System.Data.OracleClient.OracleType";
} else if (bDBMySql) { // MySQL // Note: Comment this block out if you use ODBC with MySQL
  	sProviderName = "MySql.Data.MySqlClient";
	sProviderPrefix = "MySql";
	sSqlParamSymbol = "@"; // Requires name
	sLastInsertId = "SELECT LAST_INSERT_ID()";
	sProviderAssembly = "MySql.Data, Version=" + (PROJ.GetV("MySqlDataVersion") || "6.9.5.0") + ", Culture=neutral, PublicKeyToken=c5687fc88969c44d"; // Note: Change version here if necsssary
	ewDbType = "MySql.Data.MySqlClient.MySqlDbType";
} else if (bDBPostgreSql) { // PostgreSQL // Note: Comment this block out if you use ODBC with PostgreSQL
	sProviderName = "Npgsql";
	sProviderPrefix = "Npgsql";
	sSqlParamSymbol = ":"; // Requires name
	sLastInsertId = "";
	sProviderAssembly = "Npgsql, Version=2.2.2.0, Culture=neutral, PublicKeyToken=5d8b90d52f46fda7"; // Note: Change version here if necsssary
	ewDbType = "NpgsqlTypes.NpgsqlDbType";
} else { // Unknown, assume ODBC
	sProviderName = "System.Data.Odbc";
	sProviderPrefix = "Odbc";
	sSqlParamSymbol = "?";
	sLastInsertId = "";
	sProviderAssembly = "";
	ewDbType = "System.Data.Odbc.OdbcType";
}
ewConnection = sProviderPrefix + "Connection";
ewCommand = sProviderPrefix + "Command";
ewDataReader = sProviderPrefix + "DataReader";
ewTransaction = sProviderPrefix + "Transaction";

var dMasterDetail = {};

// Table level variables - set up in aspxcommon-table.*
var gsTblVar;
var gsTblName;
var gbTblListAdd;
var gbTblListEdit;

// Field level variables
var goFlds;
var goFld;
var glFldPageIndex;
var gsFld;
var gsFldQuoteS, gsFldQuoteE;
var gsFldName;
var gsFldVar;
var gsFldParm;
var gsFldObj;

// Field arrays
var arKeyFlds;
var arFlds;
var arAllFlds;

// User level prefix for ASP.NET Report Maker
var pfxUserLevel = ReadReg("HKCU\\Software\\ASPNETReportMaker\\7.0\\Settings\\General\\UserLevelTableNamePrefix");
if (pfxUserLevel == "") pfxUserLevel = ReadReg("HKCU\\Software\\ASPNETReportMaker\\6.0\\Settings\\General\\UserLevelTableNamePrefix");
if (pfxUserLevel == "") pfxUserLevel = "||ASPNETReportMaker||";

//
// Common used functions
//

// Read registry
function ReadReg(RegPath) {
	try {
		var obj = new ActiveXObject("WScript.Shell");
		return obj.RegRead(RegPath);
	} catch(e) {
		return "";
	}
}

// Convert Data
function ConvertData(v, t) {
	try {
		switch (t.toLowerCase()) {
			case "boolean": if (v) return 1; else return 0;
			case "integer": return int(v);
			case "long": return int(v);
			case "single": return float(v);
			case "double": return double(v);
			default: return v;
		}
	} catch(e) {
		return v;
	}
}

// Get field data type (EW_DATATYPE_XXX) 
function GetFieldTypeName(FldTyp) {
	switch (FldTyp) {
		//Case adBigInt, adInteger, adSmallInt, adTinyInt, adSingle, adDouble, adNumeric, adCurrency, adUnsignedTinyInt, adUnsignedSmallInt, adUnsignedInt, adUnsignedBigInt, 139
		case 20:
		case 3:
		case 2:
		case 16:
		case 4:
		case 5:
		case 131:
		case 6:
		case 17:
		case 18:
		case 19:
		case 21:
		case 139:
			return "EW_DATATYPE_NUMBER";
		//Case adDate, adDBDate, adDBTimeStamp, 146
		case 7:
		case 133:
		case 135:
		case 146:
			return "EW_DATATYPE_DATE";
		//Case adDBTime, 145
		case 134:
		case 145:
			return "EW_DATATYPE_TIME";
		//Case adLongVarChar, adLongVarWChar, adChar, adWChar, adVarChar, adVarWChar, 141
		case 201:
		case 203:
		case 129:
		case 130:
		case 200:
		case 202:
		case 141:
			return "EW_DATATYPE_STRING";
		//Case adBoolean
		case 11:
			return "EW_DATATYPE_BOOLEAN";
		//Case adGUID
		case 72:
			return "EW_DATATYPE_GUID";
		//Case adVarBinary, adLongVarBinary
		case 204:
		case 205:
			return "EW_DATATYPE_BLOB";
		default:
			return "EW_DATATYPE_OTHER";
	}
}

// Get return page
function GetReturnPage(p) {
	if (p.substr(0,1) == "_") {
		switch (p.substr(1).toLowerCase()) {
			case "view":
				return "ViewUrl";
			case "edit":
				return "EditUrl";
			case "add":
				return "AddUrl";
			case "copy":
				return "CopyUrl";
			case "delete":
				return "DeleteUrl";
			default:
				var wrk = ew_GetFileNameByCtrlID(p.substr(1));
				return ew_DoubleQuote(wrk, 1);
		}
	} else {
		return p;
	}
}

// Set field name in array
function SetFldObj(ar, idx) {
	ar[idx] = gsFldParm; // FIELD.FldVar
}

// Get field object
function GetFldObj(fldname) {
	FIELD = TABLE.Fields(fldname);
	goFld = goFlds[fldname];
	if (goFld) {
		gsFldParm = goFld.FldParm;
		gsFldVar = goFld.FldVar;
		gsFldName = goFld.FldName;
		glFldPageIndex = goFld.FldPageIndex;
		gsFld = ew_FieldSqlName(goFld);
		gsFldQuoteS = goFld.FldQuoteS;
		gsFldQuoteE = goFld.FldQuoteE;
	} else {
		gsFldParm = FIELD.FldParm;
		gsFldVar = FIELD.FldVar;
		gsFldName = FIELD.FldName;
		glFldPageIndex = FIELD.FldPageIndex;
		gsFld = ew_FieldSqlName(FIELD);
		gsFldQuoteS = FIELD.FldQuoteS;
		gsFldQuoteE = FIELD.FldQuoteE;
	}
	if (CTRL.CtrlID == "info")
		gsFldObj = gsFldParm;
	else
		gsFldObj = gsTblVar + "." + gsFldParm;
	return true;
}

// Get field value
function GetFldVal(fld, fldtype) {
	if (bDBMySql) {
		return fld;
	} else {
		if (ew_GetFieldType(fldtype) == 4) {
			return "((ew_ConvertToBool(" + fld + ")) ? \"1\" : \"0\")";
		//else if (fldtype == 18 || fldtype == 19 || fldtype == 131 || fldtype == 139) {
			//return "ew_Conv(" + fld + ", " + fldtype + ")";
		} else {
			return fld;
		}
	}
}

// Use Add Option page
function UseAddOpt() {
	for (var i = 0, len = goTbls.length; i < len; i++) {
		var TMPTABLE = goTbls[i];
		if (TMPTABLE.TblAddOpt)
			return true;
	}
	return false;
}

// Use Export-to-Email
function UseEmailExport() {
	for (var i = 0, len = goTbls.length; i < len; i++) {
		var TMPTABLE = goTbls[i];
		if (TMPTABLE.TblGen && ((!TMPTABLE.TblUseGlobal && TMPTABLE.TblExportEmail) || PROJ.ExportEmail))
			return true;
	}
	return false;
}

// Return if Export is required
function IsExport() {
	for (var i = 0, len = goTbls.length; i < len; i++) {
		var WRKTABLE = goTbls[i];
		var bTblGen = WRKTABLE.TblGen;
		if (bTblGen) {
			var bUseGlobal = WRKTABLE.TblUseGlobal;
			var bExport = (bUseGlobal) ? PROJ.PrinterFriendly : WRKTABLE.TblPrinterFriendly;
			if (bExport) return true;
			bExport = (bUseGlobal) ? PROJ.ExportHtml : WRKTABLE.TblExportHtml;
			if (bExport) return true;
			bExport = (bUseGlobal) ? PROJ.ExportWord : WRKTABLE.TblExportWord;
			if (bExport) return true;
			bExport = (bUseGlobal) ? PROJ.ExportExcel : WRKTABLE.TblExportExcel;
			if (bExport) return true;
			bExport = (bUseGlobal) ? PROJ.ExportXml : WRKTABLE.TblExportXml;
			if (bExport) return true;
			bExport = (bUseGlobal) ? PROJ.ExportCsv : WRKTABLE.TblExportCsv;
			if (bExport) return true;
			bExport = (bUseGlobal) ? PROJ.ExportEmail : WRKTABLE.TblExportEmail; // P7
			if (bExport) return true;
			bExport = (bUseGlobal) ? PROJ.ExportPDF : WRKTABLE.TblExportPDF; // P8
			if (bExport) return true;
		}
	}
	return false;
}

// Use Tooltip
function UseTooltip() {
	return true;
}

function IsDetailKeyFld(tbl, fld) {
	for (var i = 0, len = goAllMasDets.length; i < len; i++) {
		var MasterDetail = goAllMasDets[i];
		if (MasterDetail.DetailTable == tbl.TblName) {
			for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
				var rel = MasterDetail.Rels[j];
				if (rel.DetailField == fld.FldName)
					return true;
			}
		}
	}
	return false;
}

function IsMasterDetail(master, detail) {
	for (var i = 0, len = goAllMasDets.length; i < len; i++) {
		var MasterDetail = goAllMasDets[i];
		if (MasterDetail.DetailTable == detail && MasterDetail.MasterTable == master)
			return true;
	}
	return false;
}

function IsRelated(master, detail) {
	dMasterDetail[master + "->" + detail] = "";
	for (var i = 0, len = goAllMasDets.length; i < len; i++) {
		var MasterDetail = goAllMasDets[i];
		if (MasterDetail.DetailTable == detail) {
			if (MasterDetail.MasterTable == master) { // master table
				return true;
			} else if (!(master + "->" + MasterDetail.MasterTable in dMasterDetail)) {
				if (IsRelated(master, MasterDetail.MasterTable)) // master table of master table
					return true;
			}
		}
	}
	return false;
}

function IsRequiredField(f) {
	var isRequired;
	var bValidateNotNull = PROJ.GetV("ValidateNotNull");
	isRequired = (((f.FldReq && ew_IsEmpty(f.FldDbDefault) && bValidateNotNull) || f.FldRequired) && ew_IsEmpty(f.FldAutoUpdateValue) && !f.FldAutoIncrement) &&
		(f.FldHtmlTag != "NO" && f.FldHtmlTag != "HIDDEN") &&
		(IsFldList(f) || IsFldAdd(f) || IsFldAddOpt(f) || IsFldRegister(f) ||
		(IsFldEdit(f) && !f.FldHtmlTagReadOnly) ||
		(IsFldUpdate(f) && !f.FldHtmlTagReadOnly && !f.FldIsPrimaryKey))
	// Set register page username/password/email field as required
	if (!isRequired && IsFldRegister(f)) {
		if (f.FldName == PROJ.SecPasswdFld || f.FldName == PROJ.SecLoginIDFld || (PROJ.SecRegisterEmail && f.FldName == PROJ.SecEmailFld))
			isRequired = true;
	}
	return isRequired;
}

function IsValidateText(f) {
	return (ew_IsEmpty(f.FldAutoUpdateValue)) &&
		((f.FldHtmlTag == "TEXT" || f.FldHtmlTag == "PASSWORD") &&
		(!ew_IsFldVirtualLookup(f)) &&
		((IsFldList(f) && !f.FldHtmlTagReadOnly) || IsFldAdd(f) || IsFldAddOpt(f) || IsFldRegister(f) ||
		(IsFldEdit(f) && !f.FldHtmlTagReadOnly) ||
		(IsFldUpdate(f) && !f.FldHtmlTagReadOnly)));
}

function IsValidateFile(f) {
	return (f.FldHtmlTag == "FILE") &&
		((IsFldList(f) && !f.FldHtmlTagReadOnly) || IsFldAdd(f) || IsFldAddOpt(f) || IsFldRegister(f) ||
		(IsFldEdit(f) && !f.FldHtmlTagReadOnly) ||
		(IsFldUpdate(f) && !f.FldHtmlTagReadOnly));
}

function IsValidateSearch(f) {
	return (f.FldHtmlTag == "TEXT" || f.FldHtmlTag == "NO") &&
		(!ew_IsFldVirtualLookup(f)) &&
		(IsFldExtendedSearch(f) || IsFldAdvancedSearch(f)) &&
		(f.FldValidate != "EMAIL");
}

function IsValidateServer(f) {
	if (PROJ.ServerValidate)
		return true;
	else
		return (f.FldValidate == "PASSWORD" || f.FldValidate == "EMAIL" || f.FldValidate == "DATE" || f.FldValidate == "EURODATE" || f.FldValidate == "USDATE" || f.FldValidate == "TIME" || f.FldValidate == "FLOAT" || f.FldValidate == "RANGE" || f.FldValidate == "INTEGER" || f.FldValidate == "USPHONE" || f.FldValidate == "USZIP" || f.FldValidate == "CREDITCARD" || f.FldValidate == "USSSN" || f.FldValidate == "GUID");
}

function IsFldEditCtl(f) {
	return (IsFldList(f) && (gbTblListAdd || gbTblListEdit)) ||
		IsFldEdit(f) || IsFldUpdate(f) || IsFldAdd(f) || IsFldRegister(f);
}

function IsFldList(f) {
	return (f.FldList && (CTRL.CtrlID == "list" || CTRL.CtrlID == "master" || CTRL.CtrlID == "info" || CTRL.CtrlID == "grid" || CTRL.CtrlID == "grid" || CTRL.CtrlID == "preview"));
}

function IsFldReport(f) {
	return (f.FldList && CTRL.CtrlID == "report");
}

function IsFldBasicSearch(f) {
	return (f.FldList && f.FldBasicSearch);
}

function IsFldExtendedSearch(f) {
	return (f.FldList && f.FldExtendedBasicSearch);
}

function IsFldAdvancedSearch(f) {
	return (f.FldSearch && CTRL.CtrlID == "search");
}

function IsFldUpdatable(f) {
	return (((f.FldAttribute & 4) == 4) || ((f.FldAttribute & 8) == 8));
}

function IsFldView(f) {
	return (f.FldView && CTRL.CtrlID == "view");
}

function IsFldAdd(f) {
	return (f.FldAdd && CTRL.CtrlID == "add");
}

function IsFldAddOpt(f) {
	return (f.FldAddOpt && CTRL.CtrlID == "addopt");
}

function IsFldEdit(f) {
	return (f.FldEdit && CTRL.CtrlID == "edit");
}

function IsFldDelete(f) {
	return (f.FldList && CTRL.CtrlID == "delete");
}

function IsFldUpdate(f) {
	return (f.FldMultiUpdate && CTRL.CtrlID == "update");
}

function IsFldRegister(f) {
	return (f.FldRegister && CTRL.CtrlID == "register");
}

function InArray(ar, v) {
	return ew_InArray(v, ar) > -1;
}

function ActivateFieldValue(f) {
	var val;
	switch (ew_GetFieldType(f.FldType)) {
	case 4: // Boolean
		val = "1";
		if (bDBMsAccess)
			val = "true"; // C#
		break;
	case 1: // Numeric
		val = 1;
		break;
	default:
		if (f.NativeDataType == 247) { // ENUM
			if (ew_HasTagValue(f, "Y")) // Assume ENUM(Y,N)
				val = "Y";
			else
				val = "1";
		} else {
			val = "Y";
		}
	}
	return val;
}

function FieldTD_Header(f) {
	var bFldColumnWrap, sFldColumnWidth;
	var sStyle;
	bFldColumnWrap = f.FldColumnWrap;
	sFldColumnWidth = f.FldColumnWidth;
	sStyle = "";
	if (ew_IsNotEmpty(sFldColumnWidth)) {
		sStyle += "width: " + sFldColumnWidth;
		if (!isNaN(sFldColumnWidth)) sStyle += "px";
		sStyle += ";";
	}
	if (!bFldColumnWrap) {
		if (ew_IsNotEmpty(sStyle)) sStyle += " ";
		sStyle += "white-space: nowrap;";
	}
	if (ew_IsNotEmpty(sStyle)) sStyle = " style=\"" + sStyle + "\"";
	return sStyle;
}

function FieldTD_Item(f) {
	return ""; // Set up in RenderRow / RenderListRow ' P7
}

function SqlTableName(t) {
	var name;
	name = ew_QuotedName(t.TblName);
	if (ew_IsNotEmpty(t.TblSchema))
		name = ew_QuotedName(t.TblSchema) + "." + name;
	return name;
}

function BuildCond(cond,opr,newcond) {
	if (ew_IsNotEmpty(newcond)) {
		if (ew_IsNotEmpty(cond)) {
			var wrkcond = cond + " " + opr + " ";
			wrkcond += newcond;
			if (opr.toLowerCase() == "||") wrkcond = "(" + wrkcond + ")";
			return wrkcond;
		} else {
			return newcond;
		}
	} else {
		return cond;
	}
}

function GetProjCssFileName() {
	var fileName = PROJ.ProjVar + ".css";
	if (PROJ.OutputNameLCase)
		fileName = fileName.toLowerCase();
	if (ew_IsNotEmpty(ew_FolderPath("_css")))
		fileName = ew_FolderPath("_css") + "/" + fileName;
	return fileName;
}

function GetImageFolder() {
	if (ew_IsNotEmpty(ew_FolderPath("_images")))
		return ew_FolderPath("_images") + "/";
	else
		return "";
}

function GetClassName(ctrlid) {	
	var name = ew_GetCodeFileNameByCtrlID(ctrlid);
	var pos = name.lastIndexOf(".");
	if (pos > -1)
		name = name.substr(0, pos);
	if (name == ctrlid || name.toLowerCase() == "default")
		name = "_" + name;
	return name; 
}

function IsMsAccess() {
	return bDBMsAccess;
}

function IsMsSQL() {
	return bDBMsSql;
}

function IsMySQL() {
	return bDBMySql;
}

function IsPostgreSQL() {
	return bDBPostgreSql;
}

function IsOracle() {
	return bDBOracle;
}

// Get Oracle service name from connection string
function GetOracleServiceName(ConnStr) {
	var sTag = "Data Source=";
	var sName = "";
	var p1 = ConnStr.indexOf(sTag);
	if (p1 > -1) {
		p1 += sTag.length;
		var p2 = ConnStr.indexOf(";", p1);
		if (p2 > p1) {
			sName = ConnStr.substring(p1, p2 - p1);
		} else {
			sName = ConnStr.substring(p1, ConnStr.length - 1)
		}
	}
	return sName;
}

// Get server event // ASPX
function GetServerEvent(CodeType, ScriptName, ControlID, Override) {
	if (Override && !SYSTEMFUNCTIONS.ServerScriptExist2(CodeType, ScriptName, ControlID))
		return ""; 
	var code = SYSTEMFUNCTIONS.GetServerScript(CodeType, ScriptName, ControlID);
	if (Override) {
		if (PROJ.ProgramLanguage == "C#") {
			code = code.replace(/(public)\s+(\w+)\s+(\w+)\s*\(/, "$1 override $2 $3(");
		} else { // VB
			code = code.replace(/(Public)\s+(\w+)\s+(\w+)\s*\(/, "$1 Overrides $2 $3(");
		}
	}
	return code;
}

// Get virtual server event // ASPX
function GetVirtualEvent(CodeType, ScriptName) {
	var code = PROJ.LoadCodeBase("Server", CodeType, ScriptName, "C#"); // Always C#
	code = code.replace(/(public)\s+(\w+)\s+(\w+)\s*\(/, "$1 virtual $2 $3(");
	return code.replace(/\n/g, "\r\n").replace(/\r\r\n/g, "\r\n").replace(/\r\n/g, "\r\n" + ew_IndentWrk);
}

// Check upload path // ASPX
function CheckUploadPath(path) {
	path = path.replace(/\\/g, "/");
	if (/^~\//.test(path))
		path = path.substr(2);
	return path;
}

// Compatibility
function CompatOldReport() {
	return ew_IsNotEmpty(PROJ.AppRelatedProject) && (PROJ.AppCompatVersion == "" || PROJ.AppCompatVersion <= 7);
}

// Page data [type, name]
var arPageData = [
	["cConnectionBase", "Conn", true],
	["cAdvancedSecurityBase", "Security", true],
	["cFormObj", "ObjForm", true],
	["cLanguage", "Language", true],
	["cBreadcrumb", "Breadcrumb", true],
	["cMenuBase", "RootMenu", true],
	["string", "gsLanguage", true],		
	["bool", "gbSkipHeaderFooter", true],	
	["long", "StartTime", true],		
	["dynamic", "CurrentPage", true],	
	["dynamic", "MasterPage", true],
	["dynamic", "UserTable", true],
	["string", "gsFormError", true],
	["string", "gsSearchError", true],
	["string", "gsMasterReturnUrl", true],
	["string", "gsExport", true],			
	["string", "gsExportFile", true],
	["string", "gsCustomExport", true],
	["string", "gsEmailErrDesc", true],
	["string", "gsDebugMsg", true],	
	["string", "gsToken", true],
	["string", "gsHeaderRowClass", true],
	["string", "gsMenuColumnClass", true],
	["string", "gsSiteTitleClass", true],
	["string[]", "UserAgent", true],
	["List<string>", "gTmpImages = new List<string>()", false],
	["List<OrderedDictionary>", "rswrk", false],
	["List<OrderedDictionary>", "alwrk", false],
	["ewDataReader", "drWrk", false],	
	["string", "jswrk", false],
	["string", "selwrk", false],
	["string[]", "arwrk", false],
	["OrderedDictionary", "odwrk", false],
	["string", "sSqlWrk", false],
	["string", "sWhereWrk", false],
	["string", "sFilterWrk", false],
	["string", "sLookupTblFilter", false],
	["string", "wrkonchange", false],
	["bool", "emptywrk", false]		
];

// Namespaces
var arNameSpace = [
	"System",
	"System.Globalization",
	"System.Collections",
	"System.Collections.Generic",
	"System.Collections.Specialized",
	"System.Web",
	"System.Web.WebPages",
	"System.Web.Helpers",
	"System.Text",
	"System.Text.RegularExpressions",	
	"System.Data",
	"System.Data.Common",
	"System.Xml",
	"System.IO",
	"System.Security.Cryptography",	
	"System.Drawing",
	"System.Drawing.Imaging",
	"System.Drawing.Drawing2D",	
	"System.Reflection",
	"System.Net",
	"System.Net.Mail",
	"System.Net.Mime",
	"System.Linq",
	"System.Dynamic",
	"System.DirectoryServices",
	"System.DirectoryServices.Protocols",
	"Microsoft.VisualBasic",
	"Microsoft.Web.Helpers",
	"WebMatrix.Data",
	"Newtonsoft.Json",
	sProviderName
];
if (IsPostgreSQL()) {
	arNameSpace[arNameSpace.length] = "NpgsqlTypes";
}
arNameSpace[arNameSpace.length] = "ewConnection = " + sProviderName + "." + ewConnection;
arNameSpace[arNameSpace.length] = "ewCommand = " + sProviderName + "." + ewCommand;
arNameSpace[arNameSpace.length] = "ewDataReader = " + sProviderName + "." + ewDataReader;
arNameSpace[arNameSpace.length] = "ewTransaction = " + sProviderName + "." + ewTransaction;
arNameSpace[arNameSpace.length] = "ewDbType = " + ewDbType;

/*
 ***
 ***  IMPORTANT - DO NOT CHANGE
 *** -----------------------------------------
 */
 
 // Uncomment and add more namespaces here
//arNameSpace[arNameSpace.length] = "xxx.xxx";