<!--##session ewglobal##-->
<!--## for (var i = 0; i < arNameSpace.length; i++) { ##-->
using <!--##=arNameSpace[i]##-->;
<!--## } ##-->

//
// ASP.NET Maker 12 Project Class
//
public partial class <!--##=sProjClassName##-->_base : WebPage {

	//
	// Global variables
	//
	
<!--##
	if (bUserProfile)
		arPageData[arPageData.length] = ["cUserProfile", "UserProfile", true];	 
##-->	

<!--## for (var i = 0, len = arPageData.length; i < len; i++) { ##-->
	// <!--##=arPageData[i][1]##-->
	<!--## if (arPageData[i][2]) { ##-->	
	public static <!--##=arPageData[i][0]##--> <!--##=arPageData[i][1]##--> {
		<!--## if (arPageData[i][0] == "bool") { ##-->
		get { return ew_ConvertToBool(ew_PageData["<!--##=arPageData[i][1]##-->"]); }
		<!--## } else if (arPageData[i][0] == "string") { ##-->
		get { return Convert.ToString(ew_PageData["<!--##=arPageData[i][1]##-->"]); }
		<!--## } else { ##-->
		get { return (<!--##=arPageData[i][0]##-->)ew_PageData["<!--##=arPageData[i][1]##-->"]; }
		<!--## } ##-->		
		set { ew_PageData["<!--##=arPageData[i][1]##-->"] = value; }
	}
	<!--## } else { ##-->
	public static <!--##=arPageData[i][0]##--> <!--##=arPageData[i][1]##-->;
	<!--## } ##-->		
<!--## } ##-->

	// CurrentTable // ASPX
	public static dynamic CurrentTable {
		get { return CurrentPage; }
		set { CurrentPage = value; }
	}
	
	// MasterTable // ASPX
	public static dynamic MasterTable {
		get { return MasterPage; }
		set { MasterPage = value; }
	}	
	
	
	<!--##~GetVirtualEvent("Global","Page_Loading")##-->
	<!--##~GetVirtualEvent("Global","Page_Rendering")##-->
	<!--##~GetVirtualEvent("Global","Page_Unloaded")##-->
	
}
<!--##/session##-->
