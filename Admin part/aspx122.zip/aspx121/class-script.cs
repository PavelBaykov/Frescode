<!--##session eventcode##-->
//
// ASP.NET Maker 12 Project Class
//
public partial class <!--##=sProjClassName##--> : <!--##=sProjClassName##-->_base {

<!--##
	if (CTRL.CtrlID.toLowerCase() == "gridcls")
		sPageObj = ew_GetPageObjByCtrlId("grid");
##-->

<!--##include page-class.cs/tablepageclass##-->

}	
<!--##/session##-->