<!--##session ewconfig##-->
<!--##
// Project Name
sProjVar = PROJ.ProjVar;

// Database location
if (bDBMsAccess)
	iCursorLocation = 2; // adUseServer
else
	iCursorLocation = 3; // adUseClient

// Date Separator
sDateSeparator = PROJ.DateSeparator;
if (sDateSeparator == "") sDateSeparator = "/";

// Smtp Server and Port
sSmtpServer = PROJ.SmtpServer;
if (sSmtpServer == "") sSmtpServer = "localhost";
iSmtpServerPort = PROJ.SmtpServerPort;
if (iSmtpServerPort <= 0) iSmtpServerPort = 25;

// Random key
sRandomKey = ew_RandomKey();

// Default Date Format
var DefaultDateFormat;
switch (PROJ.DefaultDateFormat) {
	case 5:
	case 9:
	case 12:
	case 15:
	DefaultDateFormat = "yyyy" + sDateSeparator + "mm" + sDateSeparator + "dd"; break;
	case 6:
	case 10:
	case 13:
	case 16:
	DefaultDateFormat = "mm" + sDateSeparator + "dd" + sDateSeparator + "yyyy"; break;
	case 7:
	case 11:
	case 14:
	case 17:
	DefaultDateFormat = "dd" + sDateSeparator + "mm" + sDateSeparator + "yyyy"; break;
}

var sFilter = "";

var sUploadUrl = ew_GetFileNameByCtrlID("ewupload");
##-->
<!--## for (var i = 0, len = arNameSpace.length; i < len; i++) { ##-->
using <!--##=arNameSpace[i]##-->;
<!--## } ##-->

//
// ASP.NET Maker 12 - Project Configuration
//
public partial class <!--##=sProjClassName##-->_base : WebPage {

	// Debug
	public const bool EW_DEBUG_ENABLED = <!--##=ew_Val(PROJ.GetV("Debug"))##-->; // Set to true for debugging
	public static int EW_OBJECTINFO_DEPTH = 10; // ObjectInfo // ASPX
	public static int EW_OBJECTINFO_ENUMERATION_LENGTH = 1000; // ObjectInfo // ASPX

	// Project
	public const string EW_PROJECT_CLASSNAME = "<!--##=sProjClassName##-->"; // ASPX
	public static string EW_PATH_DELIMITER = Convert.ToString(Path.DirectorySeparatorChar); // Physical path delimiter // ASPX
	public static string EW_ROOT_RELATIVE_PATH = "<!--##=ew_Quote(PROJ.RootRelativePath)##-->"; // Relative path of application root
	public static string EW_RELATIVE_PATH = ""; // Relative path of main script folder	
	public const string EW_DEFAULT_DATE_FORMAT = "<!--##=DefaultDateFormat##-->";
	public const short EW_DEFAULT_DATE_FORMAT_ID = <!--##=PROJ.DefaultDateFormat##-->;
	public const string EW_DATE_SEPARATOR = "<!--##=sDateSeparator##-->";
	public const short EW_UNFORMAT_YEAR = 50; // Unformat year
	public const string EW_PROJECT_NAME = "<!--##=sProjVar##-->"; // Project name
	public const string EW_CONFIG_FILE_FOLDER =  EW_PROJECT_NAME + "<!--##=ew_FolderPath("_security")##-->"; // Config file name
	public const string EW_PROJECT_ID = "<!--##=PROJ.ProjID##-->"; // Project ID (GUID)
	public static string EW_RELATED_PROJECT_ID = "";
	public static string EW_RELATED_LANGUAGE_FOLDER = "";
	public static string EW_RANDOM_KEY = "<!--##=sRandomKey##-->"; // Random key for encryption
	public const string EW_PROJECT_STYLESHEET_FILENAME = "<!--##=GetProjCssFileName()##-->"; // Project stylesheet file name
	public const string EW_CHARSET = "<!--##=PROJ.Charset##-->"; // Project charset
	public const string EW_EMAIL_CHARSET = EW_CHARSET; // Email charset
	public const string EW_EMAIL_KEYWORD_SEPARATOR = "<!--##=PROJ.GetV("EmailKeywordSeparator")##-->"; // Email keyword separator
	public static string EW_COMPOSITE_KEY_SEPARATOR = "<!--##=PROJ.GetV("CompositeKeySeparator")##-->"; // Composite key separator
	public const bool EW_HIGHLIGHT_COMPARE = true; // Case-insensitive
	public const bool EW_USE_DOM_XML = <!--##=ew_Val(PROJ.GetV("UseDomXml"))##-->;
	public const int EW_FONT_SIZE = <!--##=parseInt(PROJ.BodySize) || 14##-->;
	public const string EW_TMP_IMAGE_FONT = "Verdana"; // Font for temp files

	// Database
	public const bool EW_IS_MSACCESS = <!--##=ew_Val(bDBMsAccess)##-->; // Access
	public const bool EW_IS_MSSQL = <!--##=ew_Val(bDBMsSql)##-->; // MS SQL
	public const bool EW_IS_MYSQL = <!--##=ew_Val(bDBMySql)##-->; // MySQL
	public const bool EW_IS_POSTGRESQL = <!--##=ew_Val(bDBPostgreSql)##-->; // PostgreSQL
	public const bool EW_IS_ORACLE = <!--##=ew_Val(bDBOracle)##-->; // Oracle	
	
	public static string EW_DB_CONNECTION_STRING = "";
	public const string EW_DB_PROVIDER_NAME = "<!--##=sProviderName##-->";
  	public const string EW_DB_QUOTE_START = "<!--##=ew_Quote(DB.DBQuoteS)##-->"; 
	public const string EW_DB_QUOTE_END = "<!--##=ew_Quote(DB.DBQuoteE)##-->";	
	public const string EW_DB_SQLPARAM_SYMBOL = "<!--##=sSqlParamSymbol##-->"; // Database SQL parameter symbol
	public const string EW_DB_SCHEMA = "<!--##=ew_Quote(DB.DBSchema)##-->"; // For Oracle	
	
	/**
	 * Password (MD5 and case-sensitivity)
	 * Note: If you enable MD5 password, make sure that the passwords in your
	 * user table are stored as MD5 hash (32-character hexadecimal number) of the
	 * clear text password. If you also use case-insensitive password, convert the
	 * clear text passwords to lower case first before calculating MD5 hash.
	 * Otherwise, existing users will not be able to login. MD5 hash is
	 * irreversible, password will be reset during password recovery.
	 */
	public const bool EW_ENCRYPTED_PASSWORD = <!--##=ew_Val(PROJ.MD5Password)##-->; // Encrypted password	
	public const bool EW_CASE_SENSITIVE_PASSWORD = <!--##=ew_Val(PROJ.CaseSensitivePassword)##-->; // Case Sensitive password
	
	/**
	 * Remove XSS
	 * Note: If you want to allow these keywords, remove them from the following EW_XSS_ARRAY at your own risks.
	*/
	public const bool EW_REMOVE_XSS = <!--##=ew_Val(PROJ.GetV("RemoveXSS"))##-->;
	public static string[] EW_REMOVE_XSS_KEYWORDS = new[] {"javascript", "vbscript", "expression", "<applet", "<meta", "<xml", "<blink", "<link", "<style", "<script", "<embed", "<object", "<iframe", "<frame", "<frameset", "<ilayer", "<layer", "<bgsound", "<title", "<base", "onabort", "onactivate", "onafterprint", "onafterupdate", "onbeforeactivate", "onbeforecopy", "onbeforecut", "onbeforedeactivate", "onbeforeeditfocus", "onbeforepaste", "onbeforeprint", "onbeforeunload", "onbeforeupdate", "onblur", "onbounce", "oncellchange", "onchange", "onclick", "oncontextmenu", "oncontrolselect", "oncopy", "oncut", "ondataavailable", "ondatasetchanged", "ondatasetcomplete", "ondblclick", "ondeactivate", "ondrag", "ondragend", "ondragenter", "ondragleave", "ondragover", "ondragstart", "ondrop", "onerror", "onerrorupdate", "onfilterchange", "onfinish", "onfocus", "onfocusin", "onfocusout", "onhelp", "onkeydown", "onkeypress", "onkeyup", "onlayoutcomplete", "onload", "onlosecapture", "onmousedown", "onmouseenter", "onmouseleave", "onmousemove", "onmouseout", "onmouseover", "onmouseup", "onmousewheel", "onmove", "onmoveend", "onmovestart", "onpaste", "onpropertychange", "onreadystatechange", "onreset", "onresize", "onresizeend", "onresizestart", "onrowenter", "onrowexit", "onrowsdelete", "onrowsinserted", "onscroll", "onselect", "onselectionchange", "onselectstart", "onstart", "onstop", "onsubmit", "onunload"};

	// Check Token
	public static bool EW_CHECK_TOKEN = <!--##=ew_Val(PROJ.GetV("CheckPostToken"))##-->; // Check post token // ASPX

	// Session names	
	public const string EW_SESSION_STATUS = EW_PROJECT_NAME + "_Status"; // Login status	
	public const string EW_SESSION_USER_NAME = EW_SESSION_STATUS + "_UserName";	// User name	
	public const string EW_SESSION_USER_ID = EW_SESSION_STATUS + "_UserID";	// User ID	
	public const string EW_SESSION_USER_PROFILE = EW_SESSION_STATUS + "_UserProfile"; // User Profile
	public const string EW_SESSION_USER_PROFILE_USER_NAME = EW_SESSION_USER_PROFILE + "_UserName";
	public const string EW_SESSION_USER_PROFILE_PASSWORD = EW_SESSION_USER_PROFILE + "_Password";
	public const string EW_SESSION_USER_PROFILE_LOGIN_TYPE = EW_SESSION_USER_PROFILE + "_LoginType";
	public const string EW_SESSION_USER_LEVEL_ID = EW_SESSION_STATUS + "_UserLevel"; // User level ID		
	public const string EW_SESSION_USER_LEVEL = EW_SESSION_STATUS + "_UserLevelValue"; // User level		
	public const string EW_SESSION_PARENT_USER_ID = EW_SESSION_STATUS + "_ParentUserID"; // Parent user ID		
	public const string EW_SESSION_SYS_ADMIN = EW_PROJECT_NAME + "_SysAdmin"; // System admin
	public const string EW_SESSION_PROJECT_ID = EW_PROJECT_NAME + "_ProjectID"; // User Level project ID
	public const string EW_SESSION_AR_USER_LEVEL = EW_PROJECT_NAME + "_arUserLevel"; // User level ArrayList	
	public const string EW_SESSION_AR_USER_LEVEL_PRIV = EW_PROJECT_NAME + "_arUserLevelPriv"; // User level privilege ArrayList		
	public const string EW_SESSION_USER_LEVEL_MSG = EW_PROJECT_NAME + "_UserLevelMessage"; // Security array
	public const string EW_SESSION_SECURITY = EW_PROJECT_NAME + "_Security"; // Security array		
	public const string EW_SESSION_MESSAGE = EW_PROJECT_NAME + "_Message"; // System message	
	public const string EW_SESSION_FAILURE_MESSAGE = EW_PROJECT_NAME + "_Failure_Message"; // System error message
	public const string EW_SESSION_SUCCESS_MESSAGE = EW_PROJECT_NAME + "_Success_Message"; // System message
	public const string EW_SESSION_WARNING_MESSAGE = EW_PROJECT_NAME + "_Warning_Message"; // Warning message
	public const string EW_SESSION_INLINE_MODE = EW_PROJECT_NAME + "_InlineMode"; // Inline mode
	public const string EW_SESSION_BREADCRUMB = EW_PROJECT_NAME + "_Breadcrumb"; // Breadcrumb
	public const string EW_SESSION_TEMP_IMAGES = EW_PROJECT_NAME + "_TempImages"; // Temp images
	
	<!--##
		sLanguageFolder = ew_FolderPath("_language");
		if (ew_IsNotEmpty(sLanguageFolder)) sLanguageFolder += "/";
		sLanguageFiles = PROJ.LanguageFiles;
		sDefaultLanguageFile = PROJ.DefaultLanguageFile;
		if (sLanguageFiles == "") sLanguageFiles = "english.xml";
		if (sDefaultLanguageFile == "") sDefaultLanguageFile = "english.xml";
		bMultiLanguage = PROJ.MultiLanguage;
		if (bMultiLanguage)
			arLanguageFile = sLanguageFiles.split(",");
		else
			arLanguageFile = sDefaultLanguageFile.split(",");
	##-->
	// Language settings
	public const string EW_LANGUAGE_FOLDER = "<!--##=sLanguageFolder##-->";
	public static List<string[]> EW_LANGUAGE_FILE = new List<string[]>() {
	<!--##
		for (var i = 0, len = arLanguageFile.length; i < len; i++) {
			sFile = ew_Dequote(arLanguageFile[i]);
			sLanguageId = LANGUAGE.GetFileId(sFile);
			if (i == 0 || sFile == sDefaultLanguageFile)
				sDefaultLanguageId = sLanguageId;
				sDelimiter = (i < len - 1) ? ", " : "";
	##-->
		new[] {"<!--##=ew_Quote(sLanguageId)##-->", "", "<!--##=ew_Quote(sFile)##-->"}<!--##=sDelimiter##-->	
	<!--##		
		} // Language
	##-->
	};
	public const string EW_LANGUAGE_DEFAULT_ID = "<!--##=sDefaultLanguageId##-->";
	public const string EW_SESSION_LANGUAGE_ID = EW_PROJECT_NAME + "_LanguageId"; // Language ID
	
	// Page Token
	public const string EW_TOKEN_NAME = "token";
	public const string EW_SESSION_TOKEN = EW_PROJECT_NAME + "_Token";

	// Data types
	public const short EW_DATATYPE_NUMBER = 1;
	public const short EW_DATATYPE_DATE = 2;
	public const short EW_DATATYPE_STRING = 3;
	public const short EW_DATATYPE_BOOLEAN = 4;
	public const short EW_DATATYPE_MEMO = 5;
	public const short EW_DATATYPE_BLOB = 6;
	public const short EW_DATATYPE_TIME = 7;
	public const short EW_DATATYPE_GUID = 8;
	public const short EW_DATATYPE_XML = 9;
	public const short EW_DATATYPE_OTHER = 10;
	
	// Row types
	public const short EW_ROWTYPE_VIEW = 1;	// Row type view	
	public const short EW_ROWTYPE_ADD = 2; // Row type add	
	public const short EW_ROWTYPE_EDIT = 3; // Row type edit
	public const short EW_ROWTYPE_SEARCH = 4; // Row type search
	public const short EW_ROWTYPE_MASTER = 5; // Row type master record
	public const short EW_ROWTYPE_AGGREGATEINIT = 6; // Row type aggregate init 
	public const short EW_ROWTYPE_AGGREGATE = 7; // Row type aggregate	

	// Table parameters
	public const string EW_TABLE_PREFIX = "<!--##=pfxUserLevel##-->";	
	public const string EW_TABLE_REC_PER_PAGE = "recperpage"; // Records per page	
	public const string EW_TABLE_START_REC = "start"; // Start record	
	public const string EW_TABLE_PAGE_NO = "pageno"; // Page number	
	public const string EW_TABLE_BASIC_SEARCH = "psearch"; // Basic search keyword		
	public const string EW_TABLE_BASIC_SEARCH_TYPE = "psearchtype"; // Basic search type	
	public const string EW_TABLE_ADVANCED_SEARCH = "advsrch"; // Advanced search	
	public const string EW_TABLE_SEARCH_WHERE = "searchwhere"; // Search where clause	
	public const string EW_TABLE_WHERE = "where"; // Table where
	public const string EW_TABLE_WHERE_LIST = "where_list"; // Table where (list page) 	
	public const string EW_TABLE_ORDER_BY = "orderby"; // Table order by
	public const string EW_TABLE_ORDER_BY_LIST = "orderby_list"; // Table order by (list page) 	
	public const string EW_TABLE_SORT = "sort"; // Table sort	
	public const string EW_TABLE_KEY = "key"; // Table key	
	public const string EW_TABLE_SHOW_MASTER = "showmaster"; // Table show master
	public const string EW_TABLE_SHOW_DETAIL = "showdetail"; // Table show detail	
	public const string EW_TABLE_MASTER_TABLE = "mastertable"; // Master table
	public const string EW_TABLE_DETAIL_TABLE = "detailtable"; // Detail table
	public const string EW_TABLE_RETURN_URL = "return"; // Return URL
	public const string EW_TABLE_EXPORT_RETURN_URL = "exportreturn"; // Export return URL
	public const string EW_TABLE_GRID_ADD_ROW_COUNT = "gridaddcnt"; // Grid add row count
	
	// Audit Trail
	public const bool EW_AUDIT_TRAIL_TO_DATABASE = <!--##=ew_Val(PROJ.GetV("AuditTrailToDB"))##-->; // Write audit trail to DB
<!--##
	var sAuditTrailTable = PROJ.GetV("AuditTrailTable");
	if (DB.Tables.TableExist(sAuditTrailTable))
		sAuditTrailTable = SqlTableName(DB.Tables(sAuditTrailTable));
##-->
	public const string EW_AUDIT_TRAIL_TABLE_NAME = "<!--##=ew_Quote(sAuditTrailTable)##-->"; // Audit trail table name
	public const string EW_AUDIT_TRAIL_FIELD_NAME_DATETIME = "<!--##=PROJ.GetV("AuditTrailFieldDateTime")##-->"; // Audit trail DateTime field name
	public const string EW_AUDIT_TRAIL_FIELD_NAME_SCRIPT = "<!--##=PROJ.GetV("AuditTrailFieldScript")##-->"; // Audit trail Script field name
	public const string EW_AUDIT_TRAIL_FIELD_NAME_USER = "<!--##=PROJ.GetV("AuditTrailFieldUser")##-->"; // Audit trail User field name
	public const string EW_AUDIT_TRAIL_FIELD_NAME_ACTION = "<!--##=PROJ.GetV("AuditTrailFieldAction")##-->"; // Audit trail Action field name
	public const string EW_AUDIT_TRAIL_FIELD_NAME_TABLE = "<!--##=PROJ.GetV("AuditTrailFieldTable")##-->"; // Audit trail Table field name
	public const string EW_AUDIT_TRAIL_FIELD_NAME_FIELD = "<!--##=PROJ.GetV("AuditTrailFieldField")##-->"; // Audit trail Field field name
	public const string EW_AUDIT_TRAIL_FIELD_NAME_KEYVALUE = "<!--##=PROJ.GetV("AuditTrailFieldKeyValue")##-->"; // Audit trail Key Value field name
	public const string EW_AUDIT_TRAIL_FIELD_NAME_OLDVALUE = "<!--##=PROJ.GetV("AuditTrailFieldOldValue")##-->"; // Audit trail Old Value field name
	public const string EW_AUDIT_TRAIL_FIELD_NAME_NEWVALUE = "<!--##=PROJ.GetV("AuditTrailFieldNewValue")##-->"; // Audit trail New Value field name
	
	// Security
	public const string EW_ADMIN_USER_NAME = "<!--##=ew_Quote(PROJ.SecLoginID)##-->"; // Administrator user name	
	public const string EW_ADMIN_PASSWORD = "<!--##=ew_Quote(PROJ.SecPasswd)##-->"; // Administrator password
	public const bool EW_USE_CUSTOM_LOGIN = true; // Use custom login
	
	<!--## if (bDynamicUserLevel) { ##-->
	// Dynamic User Level settings
	// User level definition table/field names
	public const string EW_USER_LEVEL_TABLE = "<!--##=ew_Quote(SqlTableName(DB.Tables(DB.UserLevelTbl)))##-->";
	public const string EW_USER_LEVEL_ID_FIELD = "<!--##=ew_Quote(ew_QuotedName(DB.UserLevelIdFld))##-->";
	public const string EW_USER_LEVEL_NAME_FIELD = "<!--##=ew_Quote(ew_QuotedName(DB.UserLevelNameFld))##-->";
	
	// User Level privileges table/field names
	public const string EW_USER_LEVEL_PRIV_TABLE = "<!--##=ew_Quote(SqlTableName(DB.Tables(DB.UserLevelPrivTbl)))##-->";
	public const string EW_USER_LEVEL_PRIV_TABLE_NAME_FIELD = "<!--##=ew_Quote(ew_QuotedName(DB.UserLevelPrivTblNameFld))##-->";
	public const string EW_USER_LEVEL_PRIV_TABLE_NAME_FIELD_2 = "<!--##=ew_Quote(DB.UserLevelPrivTblNameFld)##-->";
	public const int EW_USER_LEVEL_PRIV_TABLE_NAME_FIELD_SIZE = 255;
	public const string EW_USER_LEVEL_PRIV_USER_LEVEL_ID_FIELD = "<!--##=ew_Quote(ew_QuotedName(DB.UserLevelPrivUserLevelFld))##-->";
	public const string EW_USER_LEVEL_PRIV_PRIV_FIELD = "<!--##=ew_Quote(ew_QuotedName(DB.UserLevelPrivPrivFld))##-->";
	<!--## } ##-->
	
	// User level constants
	public const bool EW_USER_LEVEL_COMPAT = <!--##=ew_Val(!PROJ.GetV("NoUserLevelCompat"))##-->; // Use old user level values
	public const short EW_ALLOW_ADD = 1; // Add		
	public const short EW_ALLOW_DELETE = 2; // Delete			
	public const short EW_ALLOW_EDIT = 4; // Edit				
	public const short EW_ALLOW_LIST = 8; // List
	<!--## if (!PROJ.GetV("NoUserLevelCompat")) { ##-->		
	public const int EW_ALLOW_VIEW = 8; // View (for EW_USER_LEVEL_COMPAT = True)		
	public const int EW_ALLOW_SEARCH = 8; // Search (for EW_USER_LEVEL_COMPAT = True)
	<!--## } else { ##-->
	public const int EW_ALLOW_VIEW = 32; // View (for EW_USER_LEVEL_COMPAT = False)
	public const int EW_ALLOW_SEARCH = 64; // Search (for EW_USER_LEVEL_COMPAT = False)	
	<!--## } ##-->	
	public const short EW_ALLOW_REPORT = 8; // Report		
	public const short EW_ALLOW_ADMIN = 16; // Admin	
	
	// Hierarchical User ID
	public const bool EW_USER_ID_IS_HIERARCHICAL = <!--##=ew_Val(PROJ.GetV("HierarchicalUserID"))##-->; // True to show all level / False to show 1 level
	
	// Use subquery for master/detail
	public const bool EW_USE_SUBQUERY_FOR_MASTER_USER_ID = <!--##=ew_Val(PROJ.GetV("MasterUserIDUseSubquery"))##-->; // True to use subquery / False to skip

<!--##
	var defaultUserIDAllow = ReadReg("HKCU\\Software\\ASPNETMaker\\11.0\\Settings\\General\\DefaultUserIDAllow");
	if (defaultUserIDAllow == "") defaultUserIDAllow = 8 + 32 + 64;
##-->
	public const int EW_USER_ID_ALLOW = <!--##=defaultUserIDAllow##-->;
	
	// User table filters
	<!--##
	if (bUserTable) {
		if (SECTABLE.TblType == "CUSTOMVIEW")
			sUserTable = ew_SQLPart(SECTABLE.TblCustomSQL, "FROM");
		else
			sUserTable = SqlTableName(SECTABLE);
		if (ew_IsNotEmpty(PROJ.SecLoginIDFld)) {
			FIELD = SECTABLE.Fields(PROJ.SecLoginIDFld);
			sFld = ew_FieldSqlName(FIELD);
			sFldQuoteS = FIELD.FldQuoteS;
			sFldQuoteE = FIELD.FldQuoteE;
			sFilter = "(" + sFld + " = " + sFldQuoteS + "%u" + sFldQuoteE + ")";
		} else {
			sFilter = "";
		}
	##-->
	public const string EW_USER_TABLE = "<!--##=ew_Quote(sUserTable)##-->";
	public const string EW_USER_NAME_FILTER = "<!--##=ew_Quote(sFilter)##-->";
	<!--##
		if (ew_IsNotEmpty(DB.SecuUserIDFld)) {
			FIELD = SECTABLE.Fields(DB.SecuUserIDFld);
			sFld = ew_FieldSqlName(FIELD);
			sFldQuoteS = FIELD.FldQuoteS;
			sFldQuoteE = FIELD.FldQuoteE;
			sFilter = "(" + sFld + " = " + sFldQuoteS + "%u" + sFldQuoteE + ")";
		} else {
			sFilter = "";
		}
	##-->
	public const string EW_USER_ID_FILTER = "<!--##=ew_Quote(sFilter)##-->";
	<!--##
		if (ew_IsNotEmpty(PROJ.SecEmailFld)) {
			FIELD = SECTABLE.Fields(PROJ.SecEmailFld);
			sFld = ew_FieldSqlName(FIELD);
			sFldQuoteS = FIELD.FldQuoteS;
			sFldQuoteE = FIELD.FldQuoteE;
			sFilter = "(" + sFld + " = " + sFldQuoteS + "%e" + sFldQuoteE + ")";
		} else {
			sFilter = "";
		}
	##-->
	public const string EW_USER_EMAIL_FILTER = "<!--##=ew_Quote(sFilter)##-->";
	<!--##
		if (PROJ.SecRegisterActivate && ew_IsNotEmpty(PROJ.SecRegisterActivateFld)) {
			FIELD = SECTABLE.Fields(PROJ.SecRegisterActivateFld);
			sFld = ew_FieldSqlName(FIELD);
			sFldQuoteS = FIELD.FldQuoteS;
			sFldQuoteE = FIELD.FldQuoteE;
			sFldValue = ActivateFieldValue(FIELD);
			sFilter = "(" + sFld + " = " + sFldQuoteS + sFldValue + sFldQuoteE + ")";
		} else {
			sFilter = "";
		}
	##-->
	public const string EW_USER_ACTIVATE_FILTER = "<!--##=ew_Quote(sFilter)##-->";
	<!--##
		if (ew_IsNotEmpty(DB.SecUserProfileFld)) {
			FIELD = SECTABLE.Fields(DB.SecUserProfileFld);
			sProfileFld = FIELD.FldName;
	##-->
	public const string EW_USER_PROFILE_FIELD_NAME = "<!--##=sProfileFld##-->";
	<!--##
		}
	}
	##-->
	
	// User Profile Constants
	public const string EW_USER_PROFILE_SESSION_ID = "SessionID";
	public const string EW_USER_PROFILE_LAST_ACCESSED_DATE_TIME = "LastAccessedDateTime";
	public const int EW_USER_PROFILE_CONCURRENT_SESSION_COUNT = <!--##=PROJ.GetV("ConcurrentUserSessionCount")##-->; // Maximum sessions allowed
	public const int EW_USER_PROFILE_SESSION_TIMEOUT = <!--##=PROJ.GetV("UserProfileSessionTimeout")##-->;
	public const string EW_USER_PROFILE_LOGIN_RETRY_COUNT = "LoginRetryCount";
	public const string EW_USER_PROFILE_LAST_BAD_LOGIN_DATE_TIME = "LastBadLoginDateTime";
	public const int EW_USER_PROFILE_MAX_RETRY = <!--##=PROJ.GetV("UserProfileMaxRetry")##-->;
	public const int EW_USER_PROFILE_RETRY_LOCKOUT = <!--##=PROJ.GetV("UserProfileRetryLockout")##-->;
	public const string EW_USER_PROFILE_LAST_PASSWORD_CHANGED_DATE = "LastPasswordChangedDate";
	public const int EW_USER_PROFILE_PASSWORD_EXPIRE = <!--##=PROJ.GetV("UserProfilePasswordExpire")##-->;
	
	// Email
	public const string EW_SMTP_SERVER = "<!--##=sSmtpServer##-->"; // SMTP server	
	public const int EW_SMTP_SERVER_PORT = <!--##=iSmtpServerPort##-->; // SMTP server port
	public const string EW_SMTP_SECURE_OPTION = "<!--##=PROJ.SmtpSecureOption.toLowerCase()##-->";	
	public const string EW_SMTP_SERVER_USERNAME = "<!--##=ew_Quote(PROJ.SMTPServerUsername)##-->"; // SMTP server user name	
	public const string EW_SMTP_SERVER_PASSWORD = "<!--##=ew_Quote(PROJ.SMTPServerPassword)##-->"; // SMTP server password	
	public const string EW_SENDER_EMAIL = "<!--##=PROJ.SecSenderEmail##-->"; // Sender email	
	public const string EW_RECIPIENT_EMAIL = "<!--##=PROJ.RecipientEmail##-->"; // Recipient email
	public const int EW_MAX_EMAIL_RECIPIENT = <!--##=PROJ.GetV("MaxEmailRecipient")##-->;
	public const int EW_MAX_EMAIL_SENT_COUNT = <!--##=PROJ.GetV("MaxEmailSentCount")##-->;
	public const string EW_EXPORT_EMAIL_COUNTER = EW_SESSION_STATUS + "_EmailCounter";
	
	// File upload
	public const string EW_UPLOAD_DEST_PATH = "<!--##=CheckUploadPath(PROJ.UploadPath)##-->"; // Upload destination path	
	public const string EW_UPLOAD_URL = "<!--##=sUploadUrl##-->"; // Upload URL
	public const string EW_UPLOAD_TEMP_FOLDER_PREFIX = "temp__"; // Upload temp folders prefix
	public const int EW_UPLOAD_TEMP_FOLDER_TIME_LIMIT = 1440; // Upload temp folder time limit (minutes)
	public const string EW_UPLOAD_THUMBNAIL_FOLDER = "thumbnail"; // Temporary thumbnail folder
	public const int EW_UPLOAD_THUMBNAIL_WIDTH = <!--##=PROJ.GetV("UploadThumbnailWidth")##-->; // Temporary thumbnail max width
	public const int EW_UPLOAD_THUMBNAIL_HEIGHT = <!--##=PROJ.GetV("UploadThumbnailHeight")##-->; // Temporary thumbnail max height
	public const int EW_MAX_FILE_COUNT = 0; // Max file count
	public const string EW_UPLOAD_ALLOWED_FILE_EXT = "<!--##=PROJ.UploadAllowedFileExt##-->"; // Allowed file extensions
	public const string EW_IMAGE_ALLOWED_FILE_EXT = "gif,jpg,png,bmp"; // Allowed file extensions for images	
	public const int EW_MAX_FILE_SIZE = <!--##=DB.MaxUploadSize##-->; // Max file size	
	public const short EW_THUMBNAIL_DEFAULT_WIDTH = <!--##=PROJ.GetV("ThumbnailDefaultWidth")##-->; // Thumbnail default width
	public const short EW_THUMBNAIL_DEFAULT_HEIGHT = <!--##=PROJ.GetV("ThumbnailDefaultHeight")##-->; // Thumbnail default height
	public const short EW_THUMBNAIL_DEFAULT_QUALITY = -1; // Thumbnail default interpolation
	public const bool EW_UPLOAD_CONVERT_ACCENTED_CHARS = false; // Convert accented chars in upload file name
	public const bool EW_USE_COLORBOX = <!--##=ew_Val(PROJ.GetV("UseColorbox"))##-->; // Use Colorbox
	public const string EW_MULTIPLE_UPLOAD_SEPARATOR = "<!--##=PROJ.GetV("UploadMultipleSeparator")##-->"; // Multiple upload separator
	
	// Audit trail
	public const string EW_AUDIT_TRAIL_PATH = "<!--##=ew_Quote(PROJ.AuditTrailPath)##-->"; // Audit trail path (relative to app root)
	
	// Export records
	public const bool EW_EXPORT_ALL = true; // Export all records
	public const int EW_EXPORT_ALL_TIME_LIMIT = <!--##=PROJ.GetV("ExportAllTimeLimit")##-->; // Export all records time limit
	public const string EW_XML_ENCODING = "utf-8"; // Encoding for Export to XML
	public const bool EW_EXPORT_ORIGINAL_VALUE = <!--##=ew_Val(PROJ.GetV("ExportOriginalValues"))##-->; // True to export original value
	public const bool EW_EXPORT_FIELD_CAPTION = <!--##=ew_Val(PROJ.GetV("ExportFieldCaption"))##-->; // True to export field caption
	public const bool EW_EXPORT_CSS_STYLES = <!--##=ew_Val(PROJ.GetV("ExportCssStyles"))##-->; // True to export css styles
	public const bool EW_EXPORT_MASTER_RECORD = <!--##=ew_Val(PROJ.GetV("ExportMasterRecord"))##-->; // True to export master record
	public const bool EW_EXPORT_MASTER_RECORD_FOR_CSV = <!--##=ew_Val(PROJ.GetV("ExportMasterRecordForCsv"))##-->; // True to export master record for CSV
	public const bool EW_EXPORT_DETAIL_RECORDS = <!--##=ew_Val(PROJ.GetV("ExportDetailRecords"))##-->; // TRUE to export detail records
	public const bool EW_EXPORT_DETAIL_RECORDS_FOR_CSV = <!--##=ew_Val(PROJ.GetV("ExportDetailRecordsForCsv"))##-->; // TRUE to export detail records for CSV
	
	// Export classes
	public static Dictionary<string, string> EW_EXPORT = new Dictionary<string, string>() {
		{"email", "cExportEmail"},
		{"html", "cExportHtml"},
		{"word", "cExportWord"},
		{"excel", "cExportExcel"},
		{"pdf", "cExportPdf"},
		{"csv", "cExportCsv"},
		{"xml", "cExportXml"}
	};
	
	public static Dictionary<string, string> EW_EXPORT_REPORT = new Dictionary<string, string>() {
		{"print", "ExportReportHtml"},
		{"html", "ExportReportHtml"},
		{"word", "ExportReportWord"},
		{"excel", "ExportReportExcel"}
	};
	
	// Mime types // ASPX
	public static Dictionary<string, string> EW_MIME_TYPES = new Dictionary<string, string>() {
		{"pdf", "application/pdf"},
		{"exe", "application/octet-stream"},
		{"zip", "application/zip"},
		{"docx", "application/msword"},
		{"doc", "application/msword"},
		{"xls", "application/vnd.ms-excel"},
		{"xlsx", "application/vnd.ms-excel"},
		{"ppt", "application/vnd.ms-powerpoint"},
		{"pptx", "application/vnd.ms-powerpoint"},
		{"gif", "image/gif"},
		{"png", "image/png"},
		{"jpeg", "image/jpg"},
		{"jpg", "image/jpg"},
		{"mp3", "audio/mpeg"},
		{"wav", "audio/x-wav"},
		{"mpeg", "video/mpeg"},
		{"mpg", "video/mpeg"},
		{"mpe", "video/mpeg"},
		{"mov", "video/quicktime"},
		{"avi", "video/x-msvideo"},
		{"3gp", "video/3gpp"},
		{"css", "text/css"},
		{"jsc", "application/javascript"},
		{"js", "application/javascript"},
		{"asp", "text/html"},
		{"htm", "text/html"},
		{"html", "text/html"}
	};
	
	// Use token in URL (reserved, not used, do NOT change!)
	public const bool EW_USE_TOKEN_IN_URL = false; // Do not use token in URL	
	
	// Use ILIKE for PostgreSql
	public const bool EW_USE_ILIKE_FOR_POSTGRESQL = <!--##=ew_Val(PROJ.GetV("PostgreSqlUseIlike"))##-->;
	
	// Use collation for MySQL
	public const string EW_LIKE_COLLATION_FOR_MYSQL = "<!--##=ew_Quote(PROJ.GetV("MySqlLikeCollation"))##-->";
	
	// Use collation for MsSQL
	public const string EW_LIKE_COLLATION_FOR_MSSQL = "<!--##=ew_Quote(PROJ.GetV("MsSqlLikeCollation"))##-->";
	
	// Null / Not Null values
	public const string EW_NULL_VALUE = "##null##";
	public const string EW_NOT_NULL_VALUE = "##notnull##";
	
	/**
	 * Search multi value option
	 * 1 - no multi value
	 * 2 - AND all multi values
	 * 3 - OR all multi values
	*/
	public const short EW_SEARCH_MULTI_VALUE_OPTION = <!--##=PROJ.GetV("SearchMultiValueOption")##-->;
	
	// Basic search ignore special characters
	public const string EW_BASIC_SEARCH_IGNORE_PATTERN = @"[\?,\.\^\*\(\)\[\]\""]";
	
	// Validate option
	public const bool EW_CLIENT_VALIDATE = <!--##=ew_Val(PROJ.ClientValidate)##-->;	
	public const bool EW_SERVER_VALIDATE = <!--##=ew_Val(PROJ.ServerValidate)##-->;
	
	// Blob field byte count for hash value calculation
	public const int EW_BLOB_FIELD_BYTE_COUNT = <!--##=PROJ.GetV("BlobFieldByteCount")##-->;
	
	// Auto suggest max entries
	public const int EW_AUTO_SUGGEST_MAX_ENTRIES = <!--##=PROJ.GetV("AutoSuggestMaxEntries")##-->;
	
	// Auto fill original value
	public const bool EW_AUTO_FILL_ORIGINAL_VALUE = <!--##=PROJ.GetV("AutoFillOriginalValue")##-->;

	// Checkbox and radio button groups
	public const string EW_ITEM_TEMPLATE_CLASSNAME = "ewTemplate";	
	public const string EW_ITEM_TABLE_CLASSNAME = "ewItemTable";
	
	// Use responsive layout
	public static bool EW_USE_RESPONSIVE_LAYOUT = <!--##=ew_Val(PROJ.GetV("UseResponsiveLayout"))##-->;
	
	// Use css flip
	public const bool EW_CSS_FLIP = <!--##=ew_Val(PROJ.GetV("UseCssFlip"))##-->;
	
	/**
	 * Numeric and monetary formatting options
	 * Note: DO NOT CHANGE THE FOLLOWING DEFAULT_* VARIABLES!
	 * If you want to use custom settings, customize the language file,
	 * set "use_system_locale" to "0" to override and customize the
	 * phrases under the <locale> node for ew_FormatCurrency/Number/Percent functions
	*/
<!--## if (!bMultiLanguage && PROJ.SetLocale && ew_IsNotEmpty(PROJ.Locale)) { ##-->
<!--##
	var sDecimalPoint = ".";
	var sThousandsSep = ",";
	var sCurrencySymbol = "$";
	try {
		var obj = JSON.parse(PROJ.Locale);
		if (obj) {
			if (obj.decimal_point && obj.decimal_point != "")
				sDecimalPoint = obj.decimal_point;
			if (obj.thousands_sep && obj.thousands_sep != "")
				sThousandsSep = obj.thousands_sep;
			if (obj.currency_symbol && obj.currency_symbol != "")
				sCurrencySymbol = obj.currency_symbol;
		}
	} catch(e) {}
##-->
	public static bool EW_USE_SYSTEM_LOCALE = false;
	public static string EW_DECIMAL_POINT = "<!--##=ew_Quote(sDecimalPoint)##-->";
	public static string EW_THOUSANDS_SEP = "<!--##=ew_Quote(sThousandsSep)##-->";
	public static string EW_CURRENCY_SYMBOL = "<!--##=ew_Quote(sCurrencySymbol)##-->";
<!--## } else { ##-->
	public static bool EW_USE_SYSTEM_LOCALE = true;
	public static string EW_DECIMAL_POINT = ".";
	public static string EW_THOUSANDS_SEP = ",";
	public static string EW_CURRENCY_SYMBOL = "$";
<!--## } ##-->
	
	// Cookies
	public static DateTime EW_COOKIE_EXPIRY_TIME = DateTime.Today.AddDays(365);
<!--##/session##-->

<!--##session ewconfigmenu##-->
	// Menu
	public const string EW_MENUBAR_ID = "RootMenu";
	public const string EW_MENUBAR_BRAND = "";
	public const string EW_MENUBAR_BRAND_HYPERLINK = "";
	public const string EW_MENUBAR_CLASSNAME = "";
	//public const string EW_MENUBAR_INNER_CLASSNAME = "";
	public const string EW_MENU_CLASSNAME = "dropdown-menu";
	public const string EW_SUBMENU_CLASSNAME = "dropdown-menu";
	public const string EW_SUBMENU_DROPDOWN_IMAGE = "";
	public const string EW_SUBMENU_DROPDOWN_ICON_CLASSNAME = "";
	public const string EW_MENU_DIVIDER_CLASSNAME = "divider";
	public const string EW_MENU_ITEM_CLASSNAME = "dropdown-submenu";
	public const string EW_SUBMENU_ITEM_CLASSNAME = "dropdown-submenu";
	public const string EW_MENU_ACTIVE_ITEM_CLASS = "active";
	public const string EW_SUBMENU_ACTIVE_ITEM_CLASS = "active";
	public const bool EW_MENU_ROOT_GROUP_TITLE_AS_SUBMENU = false;
	public const bool EW_SHOW_RIGHT_MENU = false;	
<!--##/session##-->

<!--##session ewconfigreportmenu##-->
	// Menu for Report Maker 7
	public const string EWR_MENUBAR_ID = "RootMenu";
	public const string EWR_MENUBAR_BRAND = "";
	public const string EWR_MENUBAR_BRAND_HYPERLINK = "";
	public const string EWR_MENUBAR_CLASSNAME = "";
	public const string EWR_MENUBAR_INNER_CLASSNAME = "";
	public const string EWR_MENU_CLASSNAME = "dropdown-menu";
	public const string EWR_SUBMENU_CLASSNAME = "dropdown-menu";
	public const string EWR_SUBMENU_DROPDOWN_IMAGE = "";
	public const string EWR_MENU_DIVIDER_CLASSNAME = "divider";
	public const string EWR_MENU_ITEM_CLASSNAME = "dropdown-submenu";
	public const string EWR_SUBMENU_ITEM_CLASSNAME = "dropdown-submenu";
	public const string EWR_MENU_ACTIVE_ITEM_CLASS = "disabled";
	public const string EWR_SUBMENU_ACTIVE_ITEM_CLASS = "disabled";
	public const bool EWR_MENU_ROOT_GROUP_TITLE_AS_SUBMENU = false;
<!--##/session##-->

<!--##session ewconfigpdf##-->
	// PDF
	public const string EW_PDF_STYLESHEET_FILENAME = ""; // export PDF CSS styles
<!--##/session##-->	

<!--##session ewconfigresize##-->
	// Image resize
	public const bool EW_RESIZE_ENABLED = false;	
<!--##/session##-->	

<!--##session ewconfigend##-->	
}
<!--##/session##-->