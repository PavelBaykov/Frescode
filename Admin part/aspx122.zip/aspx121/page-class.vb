<!--##session tablepageclass##-->
<!--##
	var id = CTRL.CtrlID.toLowerCase();
	var typ = CTRL.CtrlType.toLowerCase();
	var sPageObjTypes = (id != "master") ? "(Of cConnection, cAdvancedSecurity)" : "";
##-->
	'
	' Page class for <!--##=gsTblName##-->
	'
	<!--## if (id == "master") { ##-->	
	Public Class c<!--##=sPageObj##-->
		Inherits c<!--##=gsTblVar##-->
		
		' Page ID
		Public PageID As String = "master"
		
		' Project ID
		public ProjectID As String = "<!--##=PROJ.ProjID##-->"
	
		' Table name
		public TableName As String = "<!--##=ew_Quote(TABLE.TblName)##-->"
	<!--## } else { ##-->
	Public Class c<!--##=sPageObj##-->(Of C As {cConnection, New}, S As {cAdvancedSecurity, New})
		Inherits c<!--##=sPageObj##-->_base(Of C, S)
	<!--## } ##-->
		<!--##
			var sTblFilter = "";
			if (TABLE.TblType == "REPORT") {
				var SRCTABLE = ew_IsNotEmpty(TABLE.TblRptSrc) ? DB.Tables(TABLE.TblRptSrc) : null;
				if (SRCTABLE)
					sTblFilter = SRCTABLE.TblFilter; 
			} else {
				sTblFilter = TABLE.TblFilter;	
			}		
		##-->		
		<!--## if (ew_IsNotEmpty(sTblFilter)) { ##-->
		' TblFilter
		Public Function Get_TblFilter() As String
			Return <!--##=sTblFilter##-->
		End Function
		<!--## } ##-->
		<!--## if (typ != "report" && ew_IsNotEmpty(TABLE.TblBasicSearchDefault)) { ##-->
		' TblBasicSearchDefault
		Public Function Get_TblBasicSearchDefault() As String
			Return <!--##=TABLE.TblBasicSearchDefault##-->
		End Function
		<!--## } ##-->
		<!--## if (typ != "report" && ew_IsNotEmpty(sAddReturnPage)) { ##-->
		' TblAddReturnPage
		Public Function Get_TblAddReturnPage() As String
			Return <!--##=sAddReturnPage##-->	
		End Function
		<!--## } ##-->
		<!--## if (typ != "report" && ew_IsNotEmpty(sEditReturnPage)) { ##-->
		' TblEditReturnPage
		Public Function Get_TblEditReturnPage() As String
			Return <!--##=sEditReturnPage##-->
		End Function
		<!--## } ##-->
		
		<!--##
		// Custom properties [type, name]
		if (id != "custom") {
		var arProp = ["FldSelectFilter","FldSearchDefault","FldSearchDefault2","FldEditCustomAttributes",
			"FldViewCustomAttributes","FldTagACustomAttributes","FldAutoUpdateValue","FldDefault",
			"FldTagHiddenValue","FldUploadPath","FldServerValidateArgs","FldTagAPrefix","FldTagASuffix"];
		for (var i = 0, len = arAllFlds.length; i < len; i++) {
			if (GetFldObj(arAllFlds[i])) {
				for (var j = 0, l = arProp.length; j < l; j++) {
					var p = arProp[j];
					var value = goFld[p];
					if (ew_IsNotEmpty(value)) {
						if (p == "FldUploadPath") {
							value = CheckUploadPath(value);
						} else if (p == "FldTagAPrefix" || p == "FldTagASuffix") {
							if (value == "None")
								continue;
							value = "\"" + value.replace(/<%=/g, "\" & ").replace(/%>/g, " & \"").replace(/CurrentPage\./g, "").replace(/CurrentTable\./g, "") + "\""; 
						}
		##-->			
		' <!--##=p##--> (<!--##=gsFldParm##-->)
		Public Function Get_<!--##=gsFldParm##-->_<!--##=p##-->() As Object
			Return <!--##=value##-->
		End Function
		<!--##
					}
				}
			}
		}
		}
		##-->
	
		<!--## if (TABLE.TblType != "REPORT") { ##-->
		<!--##~GetServerEvent("Table","Recordset_Selecting","",true)##-->
		<!--##~GetServerEvent("Table","Recordset_SearchValidated","",true)##-->
		<!--##~GetServerEvent("Table","Recordset_Searching","",true)##-->
		<!--##~GetServerEvent("Table","Row_Selecting","",true)##-->
		<!--##~GetServerEvent("Table","Row_Selected","",true)##-->
			<!--## if (id != "master") { // ASPX ##-->
		<!--##~GetServerEvent("Table","Row_Inserting","",true)##-->
		<!--##~GetServerEvent("Table","Row_Inserted","",true)##-->
		<!--##~GetServerEvent("Table","Row_Updating","",true)##-->
		<!--##~GetServerEvent("Table","Row_Updated","",true)##-->
		<!--##~GetServerEvent("Table","Row_UpdateConflict","",true)##-->
		<!--##~GetServerEvent("Table","Row_Deleting","",true)##-->
		<!--##~GetServerEvent("Table","Row_Deleted","",true)##-->
			<!--## } ##-->	
		<!--##~GetServerEvent("Table","Email_Sending","",true)##-->
		<!--##~GetServerEvent("Table","Lookup_Selecting","",true)##-->
		<!--## } ##-->	
		<!--##~GetServerEvent("Table","Row_Rendering","",true)##-->
		<!--##~GetServerEvent("Table","Row_Rendered","",true)##-->
		<!--##~GetServerEvent("Table","UserID_Filtering","",true)##-->
		
		<!--##~GetServerEvent("Table","Page_Load",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Render",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Unload",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Redirecting",id,true)##-->
		<!--##~GetServerEvent("Table","Message_Showing",id,true)##-->
		<!--##~GetServerEvent("Table","Page_DataRendering",id,true)##-->
		<!--##~GetServerEvent("Table","Page_DataRendered",id,true)##-->
		<!--##~GetServerEvent("Table","Form_CustomValidate",id,true)##-->
		<!--## if (id == "list" || id == "preview") { ##-->		
		<!--##~GetServerEvent("Table","ListOptions_Load",id,true)##-->
		<!--##~GetServerEvent("Table","ListOptions_Rendered",id,true)##-->
		<!--## } ##-->
		<!--## if (id == "list") { ##-->
		<!--##~GetServerEvent("Table","Row_CustomAction",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Exporting",id,true)##-->
		<!--##~GetServerEvent("Table","Row_Export",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Exported",id,true)##-->
		<!--## } ##-->
		<!--## if (id == "view" || id == "info") { ##-->		
		<!--##~GetServerEvent("Table","Page_Exporting",id,true)##-->
		<!--##~GetServerEvent("Table","Row_Export",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Exported",id,true)##-->
		<!--## } ##-->		

	End Class
	
	' <!--##=sPageObj##-->	
	Public Shared Property <!--##=sPageObj##--> As c<!--##=sPageObj##--><!--##=sPageObjTypes##--> 
		Get
			Return CType(ew_PageData("<!--##=sPageObj##-->"), c<!--##=sPageObj##--><!--##=sPageObjTypes##-->)
		End Get
		Set(ByVal Value As c<!--##=sPageObj##--><!--##=sPageObjTypes##-->)
			ew_PageData("<!--##=sPageObj##-->") = Value
		End Set
	End Property
	
	<!--## if (id != "master" && id != "gridcls") { ##-->
	' CurrentPage	
	Public Shared Property CurrentPage As c<!--##=sPageObj##--><!--##=sPageObjTypes##--> 
		Get
			Return CType(ew_PageData("CurrentPage"), c<!--##=sPageObj##--><!--##=sPageObjTypes##-->)
		End Get
		Set(ByVal Value As c<!--##=sPageObj##--><!--##=sPageObjTypes##-->)
			ew_PageData("CurrentPage") = Value
		End Set
	End Property

	' CurrentTable	
	Public Shared Property CurrentTable As c<!--##=sPageObj##--><!--##=sPageObjTypes##--> 
		Get
			Return CurrentPage
		End Get
		Set(ByVal Value As c<!--##=sPageObj##--><!--##=sPageObjTypes##-->)
			CurrentPage = Value
		End Set
	End Property
	<!--## } ##-->
<!--##/session##-->

<!--##session otherpageclass##-->
<!--##
	var id = CTRL.CtrlID;
##-->
	'
	' Page class (<!--##=id##-->)
	'
	Public Class c<!--##=sPageObj##-->(Of C As {cConnection, New}, S As {cAdvancedSecurity, New})
		Inherits c<!--##=sPageObj##-->_base(Of C, S)
		
		<!--## if (id == "register" && ew_IsNotEmpty(sRegisterReturnPage)) { ##-->
		' RegisterReturnPage
		Public Function Get_RegisterReturnPage() As String
			Return <!--##=sRegisterReturnPage##-->		
		End Function
		<!--## } ##-->
		
		'
		' Server events
		'
		<!--##~GetServerEvent("Other","Page_Load",id,true)##-->
		<!--##~GetServerEvent("Other","Page_Unload",id,true)##-->
		<!--##~GetServerEvent("Other","Page_Redirecting",id,true)##-->
	<!--## if (ew_InArray(id, ["login", "register", "forgotpwd", "changepwd", "logout"]) > -1) { ##-->
		<!--##~GetServerEvent("Other","Message_Showing",id,true)##-->
	<!--## } ##-->
	<!--## if (ew_InArray(id, ["login", "register", "forgotpwd", "changepwd"]) > -1) { ##-->
		<!--##~GetServerEvent("Other","Page_DataRendered",id,true)##-->
		<!--##~GetServerEvent("Other","Page_DataRendering",id,true)##-->
		<!--##~GetServerEvent("Other","Form_CustomValidate",id,true)##-->
	<!--## } ##-->
	<!--## if (ew_InArray(id, ["register", "forgotpwd", "changepwd"]) > -1) { ##-->
		<!--##~GetServerEvent("Other","Email_Sending",id,true)##-->		
	<!--## } ##-->
	<!--## if (id == "login") { ##-->
		<!--##~GetServerEvent("Other","User_LoggingIn",id,true)##-->
		<!--##~GetServerEvent("Other","User_LoggedIn",id,true)##-->
		<!--##~GetServerEvent("Other","User_LoginError",id,true)##-->		
	<!--## } ##-->
	<!--## if (id == "logout") { ##-->
		<!--##~GetServerEvent("Other","User_LoggingOut",id,true)##-->
		<!--##~GetServerEvent("Other","User_LoggedOut",id,true)##-->		
	<!--## } ##-->
	<!--## if (id == "register") { ##-->
		<!--##~GetServerEvent("Other","User_Registered",id,true)##-->
		<!--##~GetServerEvent("Other","User_Activated",id,true)##-->		
	<!--## } ##-->
	<!--## if (id == "changepwd") { ##-->
		<!--##~GetServerEvent("Other","User_ChangePassword",id,true)##-->			
	<!--## } ##-->
	<!--## if (id == "forgotpwd") { ##-->
		<!--##~GetServerEvent("Other","User_RecoverPassword",id,true)##-->			
	<!--## } ##-->
	End Class
	
	' <!--##=sPageObj##-->
	Public Shared Property <!--##=sPageObj##--> As c<!--##=sPageObj##-->(Of cConnection, cAdvancedSecurity)
		Get
			Return CType(ew_PageData("<!--##=sPageObj##-->"), c<!--##=sPageObj##-->(Of cConnection, cAdvancedSecurity))
		End Get
		Set(ByVal Value As c<!--##=sPageObj##-->(Of cConnection, cAdvancedSecurity))
			ew_PageData("<!--##=sPageObj##-->") = Value
		End Set
	End Property
	
	' CurrentPage	
	Public Shared Property CurrentPage As c<!--##=sPageObj##-->(Of cConnection, cAdvancedSecurity) 
		Get
			Return CType(ew_PageData("CurrentPage"), c<!--##=sPageObj##-->(Of cConnection, cAdvancedSecurity))
		End Get
		Set(ByVal Value As c<!--##=sPageObj##-->(Of cConnection, cAdvancedSecurity))
			ew_PageData("CurrentPage") = Value
		End Set
	End Property
	
	' CurrentTable	
	Public Shared Property CurrentTable As c<!--##=sPageObj##-->(Of cConnection, cAdvancedSecurity) 
		Get
			Return CurrentPage
		End Get
		Set(ByVal Value As c<!--##=sPageObj##-->(Of cConnection, cAdvancedSecurity) )
			CurrentPage = Value
		End Set
	End Property
<!--##/session##-->