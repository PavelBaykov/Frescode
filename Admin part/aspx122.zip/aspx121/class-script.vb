<!--##session eventcode##-->
'
' ASP.NET Maker 12 Project Class
'
Partial Public Class <!--##=sProjClassName##-->
	Inherits <!--##=sProjClassName##-->_base

<!--##
	if (CTRL.CtrlID.toLowerCase() == "gridcls")
		sPageObj = ew_GetPageObjByCtrlId("grid");
##-->

<!--##include page-class.vb/tablepageclass##-->

End Class	
<!--##/session##-->