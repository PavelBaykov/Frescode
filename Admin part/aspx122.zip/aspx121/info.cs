<!--##session infoconfig##-->
<!--##
	// common table variables
	sTblName = TABLE.TblName;

	nFlds = arAllFlds.length;
	nGroups = 0;
	sGroupFldNames = "";
	sGroupFldSrcs = "";
	sGroupFlds = "";
	nOrders = 0;
	sOrdFlds = "";
	sDefaultOrderBy = "";
	sOrderFlds = "";

	bCustomView = false;
	if (TABLE.TblType == "CUSTOMVIEW") {
		bCustomView = true;
	} else if (TABLE.TblType == "REPORT") {
		if (ew_IsNotEmpty(TABLE.TblRptSrc)) {
			WRKTABLE = DB.Tables(TABLE.TblRptSrc);
			if (WRKTABLE.TblType == "CUSTOMVIEW")
				bCustomView = true;
		}
	}

	// Report Level SQL
	if (TABLE.TblType == "REPORT") {

		var SRCTABLE = null;

		if (ew_IsNotEmpty(TABLE.TblRptSrc))
			SRCTABLE = DB.Tables(TABLE.TblRptSrc);

		for (var i = 1; i <= nFlds; i++) {
			for (var j = 0; j < nFlds; j++) {
				goFld = goFlds[arAllFlds[j]];
				
				// Group By
				if (goFld.FldGroupBy == i) { // Matched Group By Sequence
				
					// GroupByFieldCount
					nGroups += 1; // Increment no. of groups
					if (nGroups != i) goFld.FldGroupBy = nGroups; // Adjust Group By Sequence
					
					// GroupByFieldNames
					if (ew_IsNotEmpty(sGroupFldNames)) sGroupFldNames += ",";
					sGroupFldNames += goFld.FldName;
					
					// GroupByFieldSources
					if (ew_IsNotEmpty(sGroupFldSrcs)) sGroupFldSrcs += ",";
					if (bCustomView && ew_IsNotEmpty(goFld.FldSourceName) && goFld.FldSourceName != goFld.FldName) {
						sGroupFldSrcs += goFld.FldSourceName;
						if (goFld.FldAlias) sGroupFldSrcs += " AS " + goFld.FldName;
					} else {
						sGroupFldSrcs += ew_QuotedName(goFld.FldName);
					}
					
					// GroupByFields
					if (ew_IsNotEmpty(sGroupFlds)) sGroupFlds += ",";
					sGroupFlds += ew_FieldSqlName(goFld);
					if (ew_IsNotEmpty(goFld.FldOrder)) sGroupFlds += " " + goFld.FldOrder;
										
				}
				
				// Order By					
				if (goFld.FldOrderBy == i) { // Matched Order By Sequence
								
					// OrderByFieldCount
					nOrders += 1; // Increment no. of orders
					if (nOrders != i) goFld.FldOrderBy = nOrders; // Adjust Order By Sequence
					
					// OrderByFieldSources
					if (ew_IsNotEmpty(sDefaultOrderBy)) sDefaultOrderBy += ",";
					if (bCustomView && ew_IsNotEmpty(goFld.FldSourceName) && goFld.FldSourceName != goFld.FldName)
						sDefaultOrderBy += goFld.FldSourceName;
					else
						sDefaultOrderBy += ew_QuotedName(goFld.FldName);
					sDefaultOrderBy += " " + goFld.FldOrder;
					
				}			
				
			} // j
		} // i

		if (SRCTABLE.TblType == "CUSTOMVIEW") {
			sLimitPart = ew_SQLPart(SRCTABLE.TblCustomSQL, "LIMIT").trim();
			sGroupByPart = ew_SQLPart(TABLE.TblCustomSQL, "GROUP BY").trim();
			sHavingPart = ew_SQLPart(TABLE.TblCustomSQL, "HAVING").trim();
			if (sLimitPart == "" && !(ew_IsNotEmpty(sGroupByPart) && ew_IsNotEmpty(sHavingPart))) { // Allow GROUP BY without HAVING
				sSelectPart = ew_SQLPart(SRCTABLE.TblCustomSQL, "SELECT");
				sFromPart =  ew_SQLPart(SRCTABLE.TblCustomSQL, "FROM");
				sWherePart = "\"" + ew_Quote(ew_SQLPart(SRCTABLE.TblCustomSQL, "WHERE")) + "\"";
				sGroupByPart = ew_SQLPart(SRCTABLE.TblCustomSQL, "GROUP BY");
				sHavingPart = ew_SQLPart(SRCTABLE.TblCustomSQL, "HAVING");
				sOrderByPart = ew_SQLPart(SRCTABLE.TblCustomSQL, "ORDER BY");
				if (ew_IsNotEmpty(sOrderByPart)) {
					if (ew_IsNotEmpty(sDefaultOrderBy)) sDefaultOrderBy += ", ";
					sDefaultOrderBy += sOrderByPart;
				}
			} else {
				sSelectPart = "*";
				sFromPart = "(" + SRCTABLE.TblCustomSQL + ")";
				sWherePart = "";
				sGroupByPart = "";
				sHavingPart = "";
			}
		} else {
			sSelectPart = bDBOracle ? SqlTableName(TABLE) + ".*" : "*";
			sFromPart = SqlTableName(SRCTABLE);
			sWherePart = SRCTABLE.TblFilter.trim();
			sGroupByPart = "";
			sHavingPart = "";
			sLimitPart = "";
		}
		if (sWherePart == "") sWherePart = "\"\""; // Empty String

	// Table Level SQL
	} else {

		for (var i = 1; i <= nFlds; i++) {
			for (var j = 0; j < nFlds; j++) {
				goFld = goFlds[arAllFlds[j]];

				// Order By					
				if (goFld.FldOrderBy == i) { // Matched Order By Sequence

					// OrderByFieldCount
					nOrders += 1; // Increment no. of orders
					if (nOrders != i) goFld.FldOrderBy = nOrders; // Adjust Order By Sequence

					// OrderByFieldNames
					if (ew_IsNotEmpty(sOrderFlds)) sOrderFlds += ",";
					sOrderFlds += goFld.FldName;

					// OrderByFieldSources
					if (ew_IsNotEmpty(sDefaultOrderBy)) sDefaultOrderBy += ",";
					if (bCustomView && ew_IsNotEmpty(goFld.FldSourceName) && goFld.FldSourceName != goFld.FldName)
						sDefaultOrderBy += goFld.FldSourceName;
					else
						sDefaultOrderBy += ew_QuotedName(goFld.FldName);
					sDefaultOrderBy += " " + goFld.FldOrder;
					
				}

			} // j
		} // i

		if (TABLE.TblType == "CUSTOMVIEW") {
			sLimitPart = ew_SQLPart(TABLE.TblCustomSQL, "LIMIT").trim();
			sGroupByPart = ew_SQLPart(TABLE.TblCustomSQL, "GROUP BY").trim();
			sHavingPart = ew_SQLPart(TABLE.TblCustomSQL, "HAVING").trim();
			if (sLimitPart == "" && !(ew_IsNotEmpty(sGroupByPart) && ew_IsNotEmpty(sHavingPart))) { // Allow GROUP BY without HAVING
				sSelectPart = ew_SQLPart(TABLE.TblCustomSQL, "SELECT");
				sFromPart =  ew_SQLPart(TABLE.TblCustomSQL, "FROM");
				sWherePart = "\"" + ew_Quote(ew_SQLPart(TABLE.TblCustomSQL, "WHERE")) + "\"";
				sGroupByPart = ew_SQLPart(TABLE.TblCustomSQL, "GROUP BY");
				sHavingPart = ew_SQLPart(TABLE.TblCustomSQL, "HAVING");
				sOrderByPart = ew_SQLPart(TABLE.TblCustomSQL, "ORDER BY");
				if (ew_IsNotEmpty(sOrderByPart)) {
					if (ew_IsNotEmpty(sDefaultOrderBy)) sDefaultOrderBy += ", ";
					sDefaultOrderBy += sOrderByPart;
				}
			} else {
				sSelectPart = "*";
				sFromPart = "(" + TABLE.TblCustomSQL + ") " + ew_QuotedName("EW_CV_" + TABLE.TblVar);
				sWherePart = "";
				sGroupByPart = "";
				sHavingPart = "";
			}
		//} else if (TABLE.TblType == "VIEW") {
		//	sSelectPart = "*";
		//	if (ew_IsNotEmpty(TABLE.TblSQL)) {
		//		sFromPart = ew_SQLPart(TABLE.TblSQL, "FROM");
		//		if (/\s/.test(sFromPart)) // Safe parsing, contains space => not single table
		//			sFromPart = SqlTableName(TABLE);
		//	} else {
		//		sFromPart = SqlTableName(TABLE);
		//	}
		//	sWherePart = "";
		//	sGroupByPart = "";
		//	sHavingPart = "";
		//	sLimitPart = "";
		} else {
			sSelectPart = bDBOracle ? SqlTableName(TABLE) + ".*" : "*";
			sFromPart = SqlTableName(TABLE);
			sWherePart = "";
			sGroupByPart = "";
			sHavingPart = "";
			sLimitPart = "";
		}
		if (sWherePart == "") sWherePart = "\"\""; // Empty String

	}

	sKeyFilter = "";
	for (var i = 0, len = arKeyFlds.length; i < len; i++) {
		if (GetFldObj(arKeyFlds[i])) {
			if (ew_IsNotEmpty(sKeyFilter)) sKeyFilter += " AND ";
			sKeyFilter += ew_Quote(gsFld) + " = " + gsFldQuoteS + "@" + gsFldParm + "@" + gsFldQuoteE; // quote by @...@
		}
	} // KeyField

	var lPageBreakRecordCount = 0; // PDF page break count
	var sPageOrientation = "portrait"; // PDF page orientation
	var sPageSize = "a4"; // PDF page size
	var sColumnWidths = "";
	var lGridAddRowCount = PROJ.GetV("GridAddRowCount");
	if (lGridAddRowCount <= 0) lGridAddRowCount = 5;
##-->
<!--##/session##-->

<!--##session infoclass##-->
<!--## for (var i = 0; i < arNameSpace.length; i++) { ##-->
using <!--##=arNameSpace[i]##-->;
<!--## } ##-->

//
// ASP.NET Maker 12 Project Class (Table)
//
public partial class <!--##=sProjClassName##-->_base : WebPage {
	
	// <!--##=gsTblVar##-->
	public static c<!--##=gsTblVar##--> <!--##=gsTblVar##--> {
		get { return (c<!--##=gsTblVar##-->)ew_PageData["<!--##=gsTblVar##-->"]; }
		set { ew_PageData["<!--##=gsTblVar##-->"] = value; }
	}

	//
	// Table class for <!--##=sTblName##-->
	//
	<!--## if (TABLE.TblType == "REPORT") { ##-->
	public class c<!--##=gsTblVar##-->: cTableBase {
	<!--## } else { ##-->
	public class c<!--##=gsTblVar##-->: cTable {
	<!--## } ##-->
	
	<!--##
		for (var i = 0, len = arAllFlds.length; i < len; i++) {
			if (GetFldObj(arAllFlds[i])) {
	##-->
		public cField <!--##=gsFldParm##-->;
	<!--##
			}
		} // AllField
	##-->
	
		public int RowCnt = 0; // ASPX
	
		//
		// Table class constructor
		//
		public c<!--##=gsTblVar##-->() {
		
			// Language object // ASPX
			if (Language == null)
				Language = new cLanguage();
	
			TableVar = "<!--##=gsTblVar##-->";
			TableName = "<!--##=ew_Quote(sTblName)##-->";
			TableType = "<!--##=TABLE.TblType##-->";
	
			ExportAll = <!--##=ew_Val(bExportAll)##-->;
			ExportPageBreakCount = <!--##=lPageBreakRecordCount##-->; // Page break per every n record (PDF only)
			ExportPageOrientation = "<!--##=sPageOrientation##-->"; // Page orientation (PDF only)
			ExportPageSize = "<!--##=sPageSize##-->"; // Page size (PDF only)
			ExportColumnWidths = new float[] { <!--##=sColumnWidths##--> }; // Column widths (PDF only) // ASPX
	
		<!--## if (TABLE.TblType != "REPORT") { ##-->
			DetailAdd = <!--##=ew_Val(TABLE.TblDetailAdd)##-->; // Allow detail add
			DetailEdit = <!--##=ew_Val(TABLE.TblDetailEdit)##-->; // Allow detail edit
			DetailView = <!--##=ew_Val(TABLE.TblDetailView)##-->; // Allow detail view
			ShowMultipleDetails = <!--##=ew_Val(TABLE.TblShowMultipleDetails && nDetailTableCount > 1)##-->; // Show multiple details
			GridAddRowCount = <!--##=lGridAddRowCount##-->;
		<!--## } ##-->
	
		<!--## if (TABLE.TblType != "REPORT") { ##-->
			AllowAddDeleteRow = ew_AllowAddDeleteRow(); // Allow add/delete row
		<!--## } ##-->
		
			UserIDAllowSecurity = <!--##=TABLE.TblUserIDAllow##-->; // User ID Allow
			
		<!--## if (TABLE.TblType != "REPORT") { ##-->

			BasicSearch = new cBasicSearch(TableVar);
	
	<!--## if (ew_IsNotEmpty(TABLE.TblBasicSearchDefault)) { ##-->
			BasicSearch.KeywordDefault = Convert.ToString(GetCustomValue("TblBasicSearchDefault")); // ASPX
	<!--## } ##-->
	<!--## if (ew_IsNotEmpty(TABLE.TblBasicSearchTypeDefault)) { ##-->
			BasicSearch.TypeDefault = "<!--##=ew_Quote(TABLE.TblBasicSearchTypeDefault)##-->";
	<!--## } ##-->
	
			<!--## } ##-->
	
	<!--##
		for (var i = 0, len = arAllFlds.length; i < len; i++) {
			if (GetFldObj(arAllFlds[i])) {
				lFldType = goFld.FldType;
				sFldExpression = ew_FieldSqlName(goFld);
				sFldBasicSearchExpression = ew_CastFieldForLike(sFldExpression, lFldType);
				if (goFld.FldFmtType == "Date/Time")
					lFldDateTimeFormat = goFld.FldDtFormat;
				else
					lFldDateTimeFormat = "-1";
				bFldUpload = ew_Val(goFld.FldHtmlTag == "FILE");
				if (ew_IsFldVirtualLookup(goFld)) {
					sFldVirtualExpression = ew_QuotedName(ew_VirtualLookupFldName(goFld));
					FldIsVirtual = "true";
					FldForceSelect = ew_Val(ew_IsFldForceSelect(goFld));
					FldVirtualSearch = ew_Val(!(goFld.FldHtmlTag == "CHECKBOX" || goFld.FldHtmlTag == "SELECT" && goFld.FldSelectMultiple) && goFld.FldVirtualLookupSearch || goFld.FldHtmlTag == "TEXT");
				} else {
					//sFldVirtualExpression = ew_QuotedName(gsFldName)
					sFldVirtualExpression = sFldExpression;
					FldIsVirtual = "false";
					FldForceSelect = "false";
					FldVirtualSearch = "false";
				}
				sFldViewTag = goFld.FldViewTag;
				sFldSrchOpr = goFld.FldSrchOpr;
				sFldSrchOpr2 = goFld.FldSrchOpr2;
				sFldSrchCond = "";
				if (sFldSrchOpr == "USER SELECT") sFldSrchOpr = "=";
				if (sFldSrchOpr2 == "USER SELECT") sFldSrchOpr2 = "=";
				if (sFldSrchOpr == "BETWEEN") {
					sFldSrchCond = "AND";
					sFldSrchOpr2 = "";
				} else if (ew_IsNotEmpty(sFldSrchOpr)) {
					sFldSrchCond = "AND";
				}
	##-->
			// <!--##=gsFldParm##-->
			<!--##=gsFldParm##--> = new cField("<!--##=gsTblVar##-->", "<!--##=ew_Quote(gsTblName)##-->", "<!--##=gsFldVar##-->", "<!--##=ew_Quote(gsFldName)##-->", "<!--##=ew_Quote(sFldExpression)##-->", "<!--##=ew_Quote(sFldBasicSearchExpression)##-->", <!--##=lFldType##-->, <!--##=SYSTEMFUNCTIONS.DbDataType()##-->, <!--##=lFldDateTimeFormat##-->, <!--##=bFldUpload##-->, "<!--##=ew_Quote(sFldVirtualExpression)##-->", <!--##=FldIsVirtual##-->, <!--##=FldForceSelect##-->, <!--##=FldVirtualSearch##-->, "<!--##=ew_Quote(sFldViewTag)##-->");
	<!--## if (SYSTEMFUNCTIONS.IsBoolFld()) { ##-->
			<!--##=gsFldParm##-->.FldDataType = EW_DATATYPE_BOOLEAN;
		<!--## if (ewTrue == "Y") { ##-->
			<!--##=gsFldParm##-->.TrueValue = "Y";
			<!--##=gsFldParm##-->.FalseValue = "N";
		<!--## } else if (ewTrue == "y") { ##-->
			<!--##=gsFldParm##-->.TrueValue = "y";
			<!--##=gsFldParm##-->.FalseValue = "n";
		<!--## } ##-->
	<!--## } ##-->
	<!--##
			if (bDBOracle) {
				sFldTypeName = goFld.FldTypeName.toUpperCase();
				if (sFldTypeName == "BLOB" || sFldTypeName == "CLOB") {
	##-->
			<!--##=gsFldParm##-->.FldBlobType = "<!--##=sFldTypeName##-->";
	<!--##
				}
			}
	##-->
	<!--## if (goFld.FldViewThumbnail) { ##-->
			<!--##=gsFldParm##-->.ImageResize = true;
		<!--##
			quality = "";
			if (quality == "" || isNaN(quality)) {
				quality = "EW_THUMBNAIL_DEFAULT_QUALITY"; // default quality
			} else if (parseInt(quality) <= 0) {
				quality = "EW_THUMBNAIL_DEFAULT_QUALITY"; // default quality
			}
		##-->
			<!--##=gsFldParm##-->.ResizeQuality = <!--##=quality##-->;
	<!--## } ##-->
	<!--## if (ew_IsNotEmpty(goFld.UploadAllowedFileExt)) { ##-->
				<!--##=gsFldParm##-->.UploadAllowedFileExt = "<!--##=goFld.UploadAllowedFileExt##-->";
	<!--## } ##-->
	<!--## if (ew_IsNotEmpty(goFld.UploadMaxFileSize) && isNumber(goFld.UploadMaxFileSize) && goFld.UploadMaxFileSize > 0) { ##-->
				<!--##=gsFldParm##-->.UploadMaxFileSize = <!--##=goFld.UploadMaxFileSize##-->;
	<!--## } ##-->
	<!--## if (goFld.FldUploadMultiple && !ew_IsBinaryField(goFld)) { ##-->
			<!--##=gsFldParm##-->.UploadMultiple = true;
			<!--## if (ew_IsNotEmpty(goFld.UploadMaxFileCount)) { ##-->
				<!--##=gsFldParm##-->.UploadMaxFileCount = <!--##=goFld.UploadMaxFileCount##-->;
			<!--## } ##-->
	<!--## } ##-->
	<!--## if (goFld.FldUseDHTMLEditor) { ##-->
			<!--##=gsFldParm##-->.TruncateMemoRemoveHtml = <!--##=ew_Val(goFld.FldUseDHTMLEditor)##-->;
	<!--## } ##-->
	<!--## if (ew_IsNotEmpty(goFld.FldValidate)) { ##-->
			<!--##=gsFldParm##-->.FldDefaultErrMsg = <!--##=SYSTEMFUNCTIONS.AspDefaultMsg()##-->;
	<!--## } ##-->
	<!--## if (ew_IsNotEmpty(goFld.FldSearchDefault)) { ##-->
			<!--##=gsFldParm##-->.AdvancedSearch.SearchValueDefault = Convert.ToString(GetCustomValue("FldSearchDefault", "<!--##=gsFldParm##-->"));
	<!--## } ##-->
	<!--## if (ew_IsNotEmpty(goFld.FldSearchDefault2)) { ##-->
			<!--##=gsFldParm##-->.AdvancedSearch.SearchValue2Default = Convert.ToString(GetCustomValue("FldSearchDefault2", "<!--##=gsFldParm##-->"));
	<!--## } ##-->
	<!--## if (ew_IsNotEmpty(goFld.FldSearchDefault) || ew_IsNotEmpty(goFld.FldSearchDefault2)) { ##-->
			<!--##=gsFldParm##-->.AdvancedSearch.SearchOperatorDefault = "<!--##=sFldSrchOpr##-->";
			<!--##=gsFldParm##-->.AdvancedSearch.SearchOperator2Default = "<!--##=sFldSrchOpr2##-->";
			<!--##=gsFldParm##-->.AdvancedSearch.SearchConditionDefault = "<!--##=sFldSrchCond##-->";
	<!--## } ##-->
			Fields.Add("<!--##=ew_Quote(gsFldName)##-->", <!--##=gsFldParm##-->);
	<!--##
			}
		} // AllField
	##-->
		}		

		// Invoke method of table class and subclasses // ASPX
		public object Invoke(string name, object[] parameters = null) {
			MethodInfo mi = this.GetType().GetMethod(name);
			if (mi != null)
				return mi.Invoke(this, parameters);
			return null;
		}		
	
		// Get custom property value  // ASPX
		public object GetCustomValue(string PropName, string FldName = "") {
			var name = "Get_";
			if (FldName != "")
				name += FldName + "_";
			name += PropName;			
			return Invoke(name);
		}

<!--##
	if (TABLE.TblType != "REPORT") {
##-->

	<!--##
		if (iSortType == 1) {
	##-->
		// Single column sort
		public void UpdateSort(cField ofld) {
			string sLastSort, sSortField, sThisSort;
			if (CurrentOrder == ofld.FldName) {
				sSortField = ofld.FldExpression;
				sLastSort = ofld.Sort;
				if (CurrentOrderType == "ASC" || CurrentOrderType == "DESC") {
					sThisSort = CurrentOrderType;
				} else {
					sThisSort = (sLastSort == "ASC") ? "DESC" : "ASC"; 
				}
				ofld.Sort = sThisSort;
				SessionOrderBy = sSortField + " " + sThisSort;	// Save to Session
	<!--## if (bTableVirtualLookup) { ##-->
				string sSortFieldList = (ew_NotEmpty(ofld.FldVirtualExpression)) ? ofld.FldVirtualExpression : sSortField;
				SessionOrderByList = sSortFieldList + " " + sThisSort; // Save to Session
	<!--## } ##-->
			} else {
				ofld.Sort = "";
			}
		}
	<!--##
		} else if (iSortType == 2) {
	##-->
		// Multiple column sort
		public void UpdateSort(cField ofld, bool ctrl) {
			string sSortField, sLastSort, sThisSort, sOrderBy;
			if (CurrentOrder == ofld.FldName) {
				sSortField = ofld.FldExpression;
				sLastSort = ofld.Sort;
				if (CurrentOrderType == "ASC" || CurrentOrderType == "DESC") {
					sThisSort = CurrentOrderType;
				} else {
					sThisSort = (sLastSort == "ASC") ? "DESC" : "ASC"; 
				}
				ofld.Sort = sThisSort;
				if (ctrl) {
					sOrderBy = SessionOrderBy;
					if (sOrderBy.Contains(sSortField + " " + sLastSort)) {
						sOrderBy = sOrderBy.Replace(sSortField + " " + sLastSort, sSortField + " " + sThisSort);
					} else {
						if (ew_NotEmpty(sOrderBy)) sOrderBy = sOrderBy + ", "; 
						sOrderBy = sOrderBy + sSortField + " " + sThisSort;
					}
					SessionOrderBy = sOrderBy; // Save to Session
				} else {
					SessionOrderBy = sSortField + " " + sThisSort;	// Save to Session
				}
	<!--## if (bTableVirtualLookup) { ##-->
				string sSortFieldList = (ew_NotEmpty(ofld.FldVirtualExpression)) ? ofld.FldVirtualExpression : sSortField;
				if (ctrl) {
					string sOrderByList = SessionOrderByList;
					if (sOrderByList.Contains(sSortFieldList + " " + sLastSort)) {
						sOrderByList = sOrderByList.Replace(sSortFieldList + " " + sLastSort, sSortFieldList + " " + sThisSort);
					} else {
						if (ew_NotEmpty(sOrderByList)) sOrderByList += ", ";
						sOrderByList += sSortFieldList + " " + sThisSort;
					}
					SessionOrderByList = sOrderByList; // Save to Session
				} else {
					SessionOrderByList = sSortFieldList + " " + sThisSort; // Save to Session
				}
	<!--## } ##-->
			} else {
				if (!ctrl)
					ofld.Sort = ""; 
			}
		}
	<!--##
		}
	##-->

<!--## if (bTableVirtualLookup) { ##-->
		// Session ORDER BY for list page
		public string SessionOrderByList {
			get { return Convert.ToString(ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_ORDER_BY_LIST]); }
			set { ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_ORDER_BY_LIST] = value; }
		}
<!--## } ##-->

<!--##
	}
##-->

<!--##
	if (nMasterTableCount > 0) {
##-->
		// Current master table name
		public string CurrentMasterTable {
			get { return Convert.ToString(ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_MASTER_TABLE]); }
			set { ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_MASTER_TABLE] = value; }
		}

		// Session master where clause
		public string MasterFilter {
			get { // Master filter
				string sMasterFilter = "";
		<!--##
			for (var i = 0, len = arMasterTables.length; i < len; i++) {
				var MasterDetail = goAllMasDets[arMasterTables[i].index];
				MASTERTABLE = DB.Tables(MasterDetail.MasterTable);
				if (MASTERTABLE.TblGen) {
					sMasterTblVar = MASTERTABLE.TblVar;
		##-->
			if (CurrentMasterTable == "<!--##=sMasterTblVar##-->") {
		<!--##
					for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
						FIELD = MASTERTABLE.Fields(MasterDetail.Rels[j].MasterField);
						sMasterFld = ew_FieldSqlName(FIELD);
						sMasterFldTypeName = GetFieldTypeName(FIELD.FldType);
						FIELD = TABLE.Fields(MasterDetail.Rels[j].DetailField);
						sDetailFldParm = FIELD.FldParm;
						if (j >= 1)
							sCond = " AND ";
						else
							sCond = "";
		##-->
				if (ew_NotEmpty(<!--##=sDetailFldParm##-->.SessionValue))
						sMasterFilter += "<!--##=sCond##--><!--##=ew_Quote(sMasterFld)##-->=" + ew_QuotedValue(<!--##=sDetailFldParm##-->.SessionValue, <!--##=sMasterFldTypeName##-->);
				else
					return "";
		<!--##
					} // MasterDetailField
		##-->
			}
		<!--##
				}
			} // MasterDetail
		##-->
				return sMasterFilter;
			}
		}
	
		// Session detail WHERE clause
		public string DetailFilter {
			get { // Detail filter
				string sDetailFilter = "";
		<!--##
			for (var i = 0, len = arMasterTables.length; i < len; i++) {
				var MasterDetail = goAllMasDets[arMasterTables[i].index];
				MASTERTABLE = DB.Tables(MasterDetail.MasterTable);
				if (MASTERTABLE.TblGen) {
					sMasterTblVar = MASTERTABLE.TblVar;
		##-->
				if (CurrentMasterTable == "<!--##=sMasterTblVar##-->") {
		<!--##
					for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
						FIELD = TABLE.Fields(MasterDetail.Rels[j].DetailField);
						sDetailFld = ew_FieldSqlName(FIELD);
						sDetailFldTypeName = GetFieldTypeName(FIELD.FldType);
						sDetailFldParm = FIELD.FldParm;
						if (j >= 1)
							sCond = " AND ";
						else
							sCond = "";
		##-->
					if (ew_NotEmpty(<!--##=sDetailFldParm##-->.SessionValue))
						sDetailFilter += "<!--##=sCond##--><!--##=ew_Quote(sDetailFld)##-->=" + ew_QuotedValue(<!--##=sDetailFldParm##-->.SessionValue, <!--##=sDetailFldTypeName##-->);
					else
						return "";
			<!--##
						} // MasterDetailField
			##-->
				}
			<!--##
					}
				} // MasterDetail
			##-->
				return sDetailFilter;
			}			
		}
	
		<!--##
			for (var i = 0, len = arMasterTables.length; i < len; i++) {
				var MasterDetail = goAllMasDets[arMasterTables[i].index];
				MASTERTABLE = DB.Tables(MasterDetail.MasterTable);
				if (MASTERTABLE.TblGen) {
					sMasterTblVar = MASTERTABLE.TblVar;
					sMasterFilter = "";
					sDetailFilter = "";
					for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
						FIELD = MASTERTABLE.Fields(MasterDetail.Rels[j].MasterField);
						sMasterFld = ew_FieldSqlName(FIELD);
						sMasterFldParm = FIELD.FldParm;
						sMasterFldQuoteS = FIELD.FldQuoteS;
						sMasterFldQuoteE = FIELD.FldQuoteE;
						if (ew_IsNotEmpty(sMasterFilter)) sMasterFilter += " AND ";
						sMasterFilter += sMasterFld + "=" + sMasterFldQuoteS + "@" + sMasterFldParm + "@" + sMasterFldQuoteE;
						FIELD = TABLE.Fields(MasterDetail.Rels[j].DetailField);
						sDetailFld = ew_FieldSqlName(FIELD);
						sDetailFldParm = FIELD.FldParm;
						sDetailFldQuoteS = FIELD.FldQuoteS;
						sDetailFldQuoteE = FIELD.FldQuoteE;
						if (ew_IsNotEmpty(sDetailFilter)) sDetailFilter += " AND ";
						sDetailFilter += sDetailFld + "=" + sDetailFldQuoteS + "@" + sDetailFldParm + "@" + sDetailFldQuoteE;
					} // MasterDetailField
		##-->
		// Master filter
		public string SqlMasterFilter_<!--##=sMasterTblVar##--> {
			get { return "<!--##=ew_Quote(sMasterFilter)##-->"; }
		}
		
		// Detail filter
		public string SqlDetailFilter_<!--##=sMasterTblVar##--> {
			get { return "<!--##=ew_Quote(sDetailFilter)##-->"; }
		}
		<!--##
				}
			} // MasterDetail
		##-->		

	<!--##
		}
	##-->	
	
	<!--##
		if (nDetailTableCount > 0) {
	##-->
		// Current detail table name
		public string CurrentDetailTable {
			get { return Convert.ToString(ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_DETAIL_TABLE]); }
			set { ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_DETAIL_TABLE] = value; }
		}
	
		// Get detail URL
		public string DetailUrl {
			get {
				string sDetailUrl = "";
			<!--##
				for (var i = 0, len = arDetailTables.length; i < len; i++) {
					var MasterDetail = goAllMasDets[arDetailTables[i].index];
					DETAILTABLE = DB.Tables(MasterDetail.DetailTable);
					if (DETAILTABLE.TblGen && DETAILTABLE.TblType != "REPORT") {
						sDetailTblVar = DETAILTABLE.TblVar;
			##-->
				if (CurrentDetailTable == "<!--##=sDetailTblVar##-->") {
					sDetailUrl = <!--##=sDetailTblVar##-->.ListUrl + "?showmaster=" + TableVar;
			<!--##
						for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
							MASTERFIELD = TABLE.Fields(MasterDetail.Rels[j].MasterField);
							sMasterFldParm = MASTERFIELD.FldParm;
							DETAILFIELD = DETAILTABLE.Fields(MasterDetail.Rels[j].DetailField);
							sDetailFldParm = DETAILFIELD.FldParm;
							// Do not use &amp; in URL // ASPX
			##-->
					sDetailUrl += "&fk_<!--##=ew_Quote(sMasterFldParm)##-->=" + ew_UrlEncode(<!--##=sMasterFldParm##-->.CurrentValue);
			<!--##
						} // MasterDetailField
			##-->
				}
			<!--##
					}
				} // MasterDetail
			##-->
				if (ew_Empty(sDetailUrl))
					sDetailUrl = "<!--##=sFnList##-->";
				return sDetailUrl;
			}
		}
	<!--##
		}
	##-->
	
	<!--##
		// Report SQL
		if (TABLE.TblType == "REPORT") {
	
			if (nGroups > 0) {
	
				// Report group level SQL: SELECT DISTINCT [Group-By FIELDS] FROM [TABLE/VIEW] ORDER BY [Group-By FIELDS]	
				sGrpSelectPart = sGroupFldSrcs; // Use Group Fields
				sGrpOrderByPart = sGroupFlds;
	##-->
		// Report group level SQL
		// Select
		private string _SqlGroupSelect = "";
		public string SqlGroupSelect { 
			get { return ew_NotEmpty(_SqlGroupSelect) ? _SqlGroupSelect : "SELECT DISTINCT <!--##=ew_Quote(sGrpSelectPart)##--> FROM <!--##=ew_Quote(sFromPart)##-->"; }
			set { _SqlGroupSelect = value; }
		}
		
		// Where // ASPX
		private string _SqlGroupWhere = "";
		public string SqlGroupWhere {
			<!--## if (SRCTABLE.TblType == "CUSTOMVIEW") { ##-->
			get { return ew_NotEmpty(_SqlGroupWhere) ? _SqlGroupWhere : <!--##=sWherePart##-->; }
			<!--## } else { ##-->
			get { return ew_NotEmpty(_SqlGroupWhere) ? _SqlGroupWhere : Convert.ToString(GetCustomValue("TblFilter")); }
			<!--## } ##-->
			set { _SqlGroupWhere = value; }
		}
		
		// Group By
		private string _SqlGroupGroupBy = "";
		public string SqlGroupGroupBy { 
			get { return ew_NotEmpty(_SqlGroupGroupBy) ? _SqlGroupGroupBy : "<!--##=ew_Quote(sGroupByPart)##-->"; }
			set { _SqlGroupGroupBy = value; }
		}
		
		// Having
		private string _SqlGroupHaving = "";
		public string SqlGroupHaving { 
			get { return ew_NotEmpty(_SqlGroupHaving) ? _SqlGroupHaving : "<!--##=ew_Quote(sHavingPart)##-->"; }
			set { _SqlGroupHaving = value; }
		}
		
		// Order By
		private string _SqlGroupOrderBy = "";
		public string SqlGroupOrderBy { 
			get { return ew_NotEmpty(_SqlGroupOrderBy) ? _SqlGroupOrderBy : "<!--##=ew_Quote(sGrpOrderByPart)##-->"; }
			set { _SqlGroupOrderBy = value; }
		}
	<!--##
			}
	
			// Report Detail Level SQL: SELECT * FROM [TABLE/VIEW] WHERE [Group-By FIELDS] = ... ORDER BY [Order-By FIELDS]
			sDtlOrderByPart = sDefaultOrderBy;
	##-->
		// Report detail level SQL
		// Select
		private string _SqlDetailSelect = "";
		public string SqlDetailSelect { 
			get { return ew_NotEmpty(_SqlDetailSelect) ? _SqlDetailSelect : "SELECT <!--##=ew_Quote(sSelectPart)##--> FROM <!--##=ew_Quote(sFromPart)##-->"; }
			set { _SqlDetailSelect = value; }
		}
		
		// Where // ASPX
		private string _SqlDetailWhere = "";
		public string SqlDetailWhere { 
			<!--## if (SRCTABLE.TblType == "CUSTOMVIEW") { ##-->
			get { return ew_NotEmpty(_SqlDetailWhere) ? _SqlDetailWhere : <!--##=sWherePart##-->; }
			<!--## } else { ##-->
			get { return ew_NotEmpty(_SqlDetailWhere) ? _SqlDetailWhere : Convert.ToString(GetCustomValue("TblFilter")); }
			<!--## } ##-->
			set { _SqlDetailWhere = value; }
		}
		
		// Group By
		private string _SqlDetailGroupBy = "";
		public string SqlDetailGroupBy { 
			get { return ew_NotEmpty(_SqlDetailGroupBy) ? _SqlDetailGroupBy : "<!--##=ew_Quote(sGroupByPart)##-->"; }
			set { _SqlDetailGroupBy = value; }
		}
		
		// Having
		private string _SqlDetailHaving = "";
		public string SqlDetailHaving { 
			get { return ew_NotEmpty(_SqlDetailHaving) ? _SqlDetailHaving : "<!--##=ew_Quote(sHavingPart)##-->"; }
			set { _SqlDetailHaving = value; }
		}
		
		// Order By
		private string _SqlDetailOrderBy = "";
		public string SqlDetailOrderBy { 
			get { return ew_NotEmpty(_SqlDetailOrderBy) ? _SqlDetailOrderBy : "<!--##=ew_Quote(sDtlOrderByPart)##-->"; }
			set { _SqlDetailOrderBy = value; }
		}
	<!--##
		// Table/View SQL
		} else {
	##-->
	
		// Table level SQL
		// FROM
		private string _SqlFrom = "";
		public string SqlFrom {
			get { return ew_NotEmpty(_SqlFrom) ? _SqlFrom : "<!--##=ew_Quote(sFromPart)##-->"; }
			set { _SqlFrom = value; }
		}
		
		// SELECT
		private string _SqlSelect = "";
		public string SqlSelect { // Select
			get { return ew_NotEmpty(_SqlSelect) ? _SqlSelect : "SELECT <!--##=ew_Quote(sSelectPart)##--> FROM " + SqlFrom; }
			set { _SqlSelect = value; }
		}
		
	<!--## if (bTableVirtualLookup) { ##-->
		// SELECT for List page
		private string _SqlSelectList = "";
		public string SqlSelectList { 
			get {
		<!--## if (ew_LanguageCount > 1) { ##-->
				switch (gsLanguage) {
			<!--##
				for (var i = 1; i < ew_LanguageCount; i++) {
			##-->
				case "<!--##=ew_Language[i]##-->":
					return ew_NotEmpty(_SqlSelectList) ? _SqlSelectList : "SELECT * FROM (" +
						"SELECT <!--##=ew_Quote(sSelectPart)##-->, <!--##=arVirtualFieldList[i]##--> FROM <!--##=ew_Quote(sFromPart)##-->" +
						") <!--##=ew_Quote(ew_QuotedName("EW_TMP_TABLE"))##-->";
					break;
		<!--##
				}
		##-->
				default:
					return ew_NotEmpty(_SqlSelectList) ? _SqlSelectList : "SELECT * FROM (" +
						"SELECT <!--##=ew_Quote(sSelectPart)##-->, <!--##=arVirtualFieldList[0]##--> FROM <!--##=ew_Quote(sFromPart)##-->" +
						") <!--##=ew_Quote(ew_QuotedName("EW_TMP_TABLE"))##-->";
					break;
				}
		<!--## } else { ##-->
				return ew_NotEmpty(_SqlSelectList) ? _SqlSelectList : "SELECT * FROM (" +
					"SELECT <!--##=ew_Quote(sSelectPart)##-->, <!--##=arVirtualFieldList[0]##--> FROM <!--##=ew_Quote(sFromPart)##-->" +
					") <!--##=ew_Quote(ew_QuotedName("EW_TMP_TABLE"))##-->";
		<!--## } ##-->				
			}
			set { _SqlSelectList = value; }
		}
	<!--## } ##-->
	
		// WHERE // ASPX
		private string _SqlWhere = "";
		public string SqlWhere {
			get {
				string sWhere = <!--##=sWherePart##-->;
		<!--##
			sTblDefaultFilter = TABLE.TblFilter.trim();
			//if (sTblDefaultFilter == "") sTblDefaultFilter = "\"\""; 
			if (ew_IsNotEmpty(sTblDefaultFilter)) { // ASPX
		##-->
				ew_AddFilter(ref sWhere, Convert.ToString(GetCustomValue("TblFilter")));
		<!--##
			}
		##--> 
				return ew_NotEmpty(_SqlWhere) ? _SqlWhere : sWhere;
			}
			set { _SqlWhere = value; }		
		}
		
		// Group By
		private string _SqlGroupBy = "";
		public string SqlGroupBy {
			get { return ew_NotEmpty(_SqlGroupBy) ? _SqlGroupBy : "<!--##=ew_Quote(sGroupByPart)##-->"; }
			set { _SqlGroupBy = value; }
		}
		
		// Having
		private string _SqlHaving = "";
		public string SqlHaving {
			get { return ew_NotEmpty(_SqlHaving) ? _SqlHaving : "<!--##=ew_Quote(sHavingPart)##-->"; }
			set { _SqlHaving = value; }
		}
		
		// Order By
		private string _SqlOrderBy = "";
		public string SqlOrderBy {
			get { return ew_NotEmpty(_SqlOrderBy) ? _SqlOrderBy : "<!--##=ew_Quote(sDefaultOrderBy)##-->"; }
			set { _SqlOrderBy = value; }
		}
	<!--## } ##-->
	
		// Check if Anonymous User is allowed
	  	public virtual bool AllowAnonymousUser() {
			switch (CurrentPageID()) {
				case "add":
				case "register":
				case "addopt":
					return <!--##=ew_Val(bAnonymousAdd)##-->;
				case "edit":
				case "update":
					return <!--##=ew_Val(bAnonymousEdit)##-->;
				case "delete":
					return <!--##=ew_Val(bAnonymousDelete)##-->;
				case "view":
					return <!--##=ew_Val(bAnonymousView)##-->;
				case "search":
					return <!--##=ew_Val(bAnonymousSearch)##-->;
				default:
					return <!--##=ew_Val(bAnonymousList)##-->;
			}
		}
	
		// Apply User ID filters
		public string ApplyUserIDFilters(string Filter) {
			string sFilter = Filter;
			<!--## if (bTableHasUserIDFld || bMasterTableHasUserIDFld) { ##-->
			if (!AllowAnonymousUser() && ew_NotEmpty(Security.CurrentUserID) && !Security.IsAdmin) { // Non system admin
			<!--##
				if (bTableHasUserIDFld) {
			##-->
				sFilter = AddUserIDFilter(sFilter);
			<!--##
				} else if (bMasterTableHasUserIDFld) {
					for (var i = 0, len = arMasterTables.length; i < len; i++) {
			##-->
				if (CurrentMasterTable == "<!--##=arMasterTables[i].TblVar##-->" || ew_Empty(CurrentMasterTable))
					sFilter = AddDetailUserIDFilter(sFilter, "<!--##=arMasterTables[i].TblVar##-->"); // Add detail User ID filter
			<!--##
					} // MasterTable
				}
			##-->
			}
			<!--## } ##-->
			return sFilter;
		}
	
		// Check if User ID security allows view all
		public bool UserIDAllow(string id = "") {
	
		<!--## if (bTableHasUserIDFld) { ##-->
			int allow = UserIDAllowSecurity;
		<!--## } else { ##-->
			int allow = EW_USER_ID_ALLOW;
		<!--## } ##-->	
			
			switch (id) {
				case "add":
				case "copy":
				case "gridadd":
				case "register":
				case "addopt":
					return ((allow & 1) == 1);
				case "edit":
				case "gridedit":
				case "update":
				case "changepwd":
				case "forgotpwd":
					return ((allow & 4) == 4);
				case "delete":
					return ((allow & 2) == 2);
				case "view":
			<!--## if (PROJ.GetV("NoUserLevelCompat")) { // ##-->
					return ((allow & 32) == 32);
			<!--## } else { ##-->
					return ((allow & 8) == 8);
			<!--## } ##-->
				case "search":
			<!--## if (PROJ.GetV("NoUserLevelCompat")) { // ##-->
					return ((allow & 64) == 64);
			<!--## } else { ##-->
					return ((allow & 8) == 8);
			<!--## } ##-->
				default:
					return ((allow & 8) == 8);
			}
	
		}
	
	<!--##
		// Report SQL
		if (TABLE.TblType == "REPORT") {
	
			if (nGroups > 0) {
	##-->
		// Return report group SQL
		public string GroupSQL {
			get {
				string sFilter = CurrentFilter;
		
			<!--## if (bTableHasUserIDFld || bMasterTableHasUserIDFld) { ##-->
				sFilter = ApplyUserIDFilters(sFilter); // Add User ID filter 
			<!--## } ##-->
		
				string sSort = "";
				return ew_BuildSelectSql(SqlGroupSelect, SqlGroupWhere, SqlGroupGroupBy, SqlGroupHaving, SqlGroupOrderBy, sFilter, sSort);
			}
		}
	<!--##
			}
	##-->
		// Return report detail SQL
		public string DetailSQL {
			get {
				string sFilter = CurrentFilter;
		
			<!--## if (bTableHasUserIDFld || bMasterTableHasUserIDFld) { ##-->
				sFilter = ApplyUserIDFilters(sFilter); // Add User ID filter 
			<!--## } ##-->
		
				string sSort = "";
				return ew_BuildSelectSql(SqlDetailSelect, SqlDetailWhere, SqlDetailGroupBy, SqlDetailHaving, SqlDetailOrderBy, sFilter, sSort);
			}
		}
	<!--##
		// Table/View SQL
		} else {
	##-->
		// Get SQL
		public string GetSQL(string where, string orderby = "") {
			return ew_BuildSelectSql(SqlSelect, SqlWhere, SqlGroupBy, SqlHaving, SqlOrderBy, where, orderby);
		}
		
		// Table SQL
		public string SQL {
			get {
				string sFilter = CurrentFilter;
		
			<!--## if (bTableHasUserIDFld || bMasterTableHasUserIDFld) { ##-->
				sFilter = ApplyUserIDFilters(sFilter); // Add User ID filter
			<!--## } ##-->
		
				string sSort = SessionOrderBy;
				return ew_BuildSelectSql(SqlSelect, SqlWhere, SqlGroupBy, SqlHaving, SqlOrderBy, sFilter, sSort);
			}
		}
	
		// Table SQL with List page filter
		public string SelectSQL {
			get {
				string sSort = "";
				string sFilter = SessionWhere;
				ew_AddFilter(ref sFilter, CurrentFilter);
				Recordset_Selecting(ref sFilter);
	
			<!--## if (bTableHasUserIDFld || bMasterTableHasUserIDFld) { ##-->
				sFilter = ApplyUserIDFilters(sFilter); // Add User ID filter 
			<!--## } ##-->
		
	<!--## if (bTableVirtualLookup) { ##-->
				if (UseVirtualFields()) {
					sSort = SessionOrderByList;
					return ew_BuildSelectSql(SqlSelectList, SqlWhere, SqlGroupBy, SqlHaving, SqlOrderBy, sFilter, sSort);
				} else {
					sSort = SessionOrderBy;
					return ew_BuildSelectSql(SqlSelect, SqlWhere, SqlGroupBy, SqlHaving, SqlOrderBy, sFilter, sSort);
				}
	<!--## } else { ##-->
				sSort = SessionOrderBy;
				return ew_BuildSelectSql(SqlSelect, SqlWhere, SqlGroupBy, SqlHaving, SqlOrderBy, sFilter, sSort);
	<!--## } ##-->
			}
		}
	
		// Get ORDER BY clause
		public string OrderBy {
			get {
		<!--## if (bTableVirtualLookup) { ##-->
				string sSort = (UseVirtualFields()) ? SessionOrderByList : SessionOrderBy;
		<!--## } else { ##-->
				string sSort = SessionOrderBy;
		<!--## } ##-->
				return ew_BuildSelectSql("", "", "", "", SqlOrderBy, "", sSort);
			}
		}
	
	<!--## if (bTableVirtualLookup) { ##-->
		// Check if virtual fields is used in SQL
		private bool UseVirtualFields() {
			string sWhere = (ew_Empty(SessionWhere)) ? "" : SessionWhere;
			string sOrderBy = (ew_Empty(SessionOrderByList)) ? "" : SessionOrderByList;
			if (ew_NotEmpty(sWhere))
				sWhere = " " + sWhere.Replace("(", "").Replace(")", "") + " ";
			if (ew_NotEmpty(sOrderBy))
				sOrderBy = " " + sOrderBy.Replace("(", "").Replace(")", "") + " ";
	<!--##
		bGenBasicSearchChk = true;
		for (var i = 0, len = arAllFlds.length; i < len; i++) {
			if (GetFldObj(arAllFlds[i])) {
				if (ew_IsFldVirtualLookup(goFld)) {
					if (IsFldBasicSearch(goFld) && bGenBasicSearchChk) {
	##-->
			if (ew_NotEmpty(BasicSearch.Keyword))
				return true;
	<!--##
						bGenBasicSearchChk = false;
					}
					if (goFld.FldHtmlTag == "TEXT" || goFld.FldVirtualLookupSearch) {
	##-->
			if (ew_NotEmpty(<!--##=gsFldObj##-->.AdvancedSearch.SearchValue) || ew_NotEmpty(<!--##=gsFldObj##-->.AdvancedSearch.SearchValue2) || sWhere.Contains(" " + <!--##=gsFldObj##-->.FldVirtualExpression + " "))
				return true;
	<!--##
					}
	##-->
			if (sOrderBy.Contains(" " + <!--##=gsFldObj##-->.FldVirtualExpression + " "))
				return true;
	<!--##
				}
			}
		} // AllField
	##-->
			return false;
		}
	<!--## } ##-->
	
		// Return SQL for record count
		public string SelectCountSQL {
			get {			
				if (TableType == "TABLE" || TableType == "VIEW") {
					return "SELECT COUNT(*) FROM" + Regex.Replace(SelectSQL, @"^SELECT\s([\s\S]+)?\*\sFROM", "", RegexOptions.IgnoreCase);
				} else {
					return "SELECT COUNT(*) FROM (" + SelectSQL + ")";
				}				
			}
		}
		
	<!--##
		var sUpdateTable = sFromPart;
		if (TABLE.TblType == "VIEW" && ew_IsNotEmpty(TABLE.TblSQL)) {
			sUpdateTable = ew_SQLPart(TABLE.TblSQL, "FROM");
			if (/\s/.test(sUpdateTable) || /\sAS\s/i.test(ew_SQLPart(TABLE.TblSQL, "SELECT"))) // Safe parsing, FROM contains space => not single table, SELECT contains " AS " => alias
				sUpdateTable = sFromPart;
		}
	##-->	
		// Update Table
		public string UpdateTable = "<!--##=ew_Quote(sUpdateTable)##-->";
		
		// Insert
		public int Insert(OrderedDictionary rs) {
			string names = "";
			string values = "";
			cField fld;
			foreach (DictionaryEntry f in rs) {
				fld = FieldByName((string)f.Key);
				if (fld != null) {
					names += fld.FldExpression + ",";
					values += SqlParameter(ref fld) + ",";
				}
			}
			if (names.EndsWith(",")) names = names.Remove(names.Length - 1); 
			if (values.EndsWith(",")) values = values.Remove(values.Length - 1); 
			if (ew_Empty(names)) return -1;
			string Sql = "INSERT INTO " + UpdateTable + " (" + names + ") VALUES (" + values + ")";
			if (EW_DEBUG_ENABLED)
				ew_SetDebugMsg(Sql);
			var command = Conn.GetCommand(Sql);
			foreach (DictionaryEntry f in rs) {
				fld = FieldByName((string)f.Key);
				if (fld == null)
					continue;
				try {
					command.Parameters.Add(fld.FldVar, fld.FldDbType).Value = ParameterValue(ref fld, f.Value);
				} catch {
					if (EW_DEBUG_ENABLED) throw;
				}
			}
			return command.ExecuteNonQuery();
		}		

		// Update
		public int Update(OrderedDictionary rs, string where = "", OrderedDictionary rsold = null) {
		
			var bCascadeUpdate = false;
			var rscascade = new OrderedDictionary();
		
	<!--##
		if (nDetailTableCount > 0) {
			for (var i = 0, len = arDetailTables.length; i < len; i++) {
				var MasterDetail = goAllMasDets[arDetailTables[i].index];
				if (MasterDetail.CascadeUpdate) { // Cascade update
					OLDTABLE = TABLE; // Save master table
					MASTERTABLE = DB.Tables(TABLE.TblName);
					TABLE = DB.Tables(MasterDetail.DetailTable);
					if (TABLE.TblGen && TABLE.TblType != "REPORT") {
	##-->
			// Cascade Update detail table '<!--##=TABLE.TblName##-->'
			bCascadeUpdate = false;
			rscascade.Clear();
	<!--##
						// Get detail key SQL
						var sDetailKeySQL = "";
						for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
							MASTERFIELD = MASTERTABLE.Fields(MasterDetail.Rels[j].MasterField);
							sMasterFldName = MASTERFIELD.FldName;
							sMasterFldTypeName = GetFieldTypeName(MASTERFIELD.FldType);
							DETAILFIELD = TABLE.Fields(MasterDetail.Rels[j].DetailField);
							sDetailFld = ew_FieldSqlName(DETAILFIELD);
							if (sDetailKeySQL != "") sDetailKeySQL += " + \" AND \" + ";
							sDetailKeySQL += "\"" + ew_Quote(sDetailFld) + " = \" + ew_QuotedValue(rsold[\"" + ew_Quote(sMasterFldName) + "\"], " + sMasterFldTypeName + ")";
						} // MasterDetailField
						for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
							MASTERFIELD = MASTERTABLE.Fields(MasterDetail.Rels[j].MasterField);
							sMasterFldName = MASTERFIELD.FldName;
							DETAILFIELD = TABLE.Fields(MasterDetail.Rels[j].DetailField);
							sDetailFldName = DETAILFIELD.FldName;
							var sCheck = "ew_NotEmpty(rs[\"" + ew_Quote(sMasterFldName) + "\"]) && !ew_SameStr(rsold[\"" + ew_Quote(sMasterFldName) + "\"], rs[\"" + ew_Quote(sMasterFldName) + "\"])";
							var sMasterKeyCheck = sCheck.replace('%f', SQuote(sMasterFldName));
	##-->
			if (rsold != null && (<!--##=sMasterKeyCheck##-->)) {
				bCascadeUpdate = true;
				rscascade.Add("<!--##=ew_Quote(sDetailFldName)##-->", rs["<!--##=ew_Quote(sMasterFldName)##-->"]);				
			}
	<!--##
						} // MasterDetailField
	##-->
			if (bCascadeUpdate) {
				if (<!--##=TABLE.TblVar##--> == null)
					<!--##=TABLE.TblVar##--> = new c<!--##=TABLE.TblVar##-->();		
				<!--##=TABLE.TblVar##-->.Update(rscascade, <!--##=sDetailKeySQL##-->);
			}
	<!--##
					}
					TABLE = OLDTABLE; // Restore master table
				}
			}
		}
	##-->
		
			var values = "";
			foreach (DictionaryEntry f in rs) {
				var fld = FieldByName((string)f.Key);
				if (fld != null)
					values += fld.FldExpression + "=" + SqlParameter(ref fld) + ",";
			}
			if (values.EndsWith(","))
				values = values.Remove(values.Length - 1); 
			if (ew_Empty(values))
				return -1; 
			string Sql = "UPDATE " + UpdateTable + " SET " + values;
			string filter = CurrentFilter;
			ew_AddFilter(ref filter, where);
			if (ew_NotEmpty(filter))
				Sql += " WHERE " + filter;
			if (EW_DEBUG_ENABLED)
				ew_SetDebugMsg(Sql); 
			var command = Conn.GetCommand(Sql);
			foreach (DictionaryEntry f in rs) {
				var fld = FieldByName((string)f.Key);
				if (fld == null)
					continue;
				try {
					command.Parameters.Add(fld.FldVar, fld.FldDbType).Value = ParameterValue(ref fld, f.Value);
				} catch {
					if (EW_DEBUG_ENABLED) throw;
				}
			}
			return command.ExecuteNonQuery();
		}
		
		// Convert to parameter name for use in SQL
		public string SqlParameter(ref cField fld) {
			string sValue = EW_DB_SQLPARAM_SYMBOL;
			if (EW_DB_SQLPARAM_SYMBOL != "?")
				sValue += fld.FldVar;
			return sValue;
		}
		
		// Convert value to object for parameter
		public object ParameterValue(ref cField fld, object value) {
			<!--## if (bUserTable && TABLE.TblName == PROJ.SecTbl) { ##-->
			if (EW_ENCRYPTED_PASSWORD && ew_SameStr(fld.FldName, "<!--##=ew_Quote(PROJ.SecPasswdFld)##-->")) {
				if (EW_CASE_SENSITIVE_PASSWORD) {
					return ew_EncryptPassword(Convert.ToString(value));
				} else {
					return ew_EncryptPassword(Convert.ToString(value).ToLower());
				}
			} else {
				return value;	
			}
			<!--## } else { ##-->
			return value;	
			<!--## } ##-->							
		}
		
		// Delete
		public int Delete(OrderedDictionary rs, string where = "") {
		
	<!--##
		if (nDetailTableCount > 0) {
			for (var i = 0, len = arDetailTables.length; i < len; i++) {
				var MasterDetail = goAllMasDets[arDetailTables[i].index];
				if (MasterDetail.CascadeDelete) { // Cascade delete
					OLDTABLE = TABLE; // Save master table
					MASTERTABLE = DB.Tables(TABLE.TblName);
					TABLE = DB.Tables(MasterDetail.DetailTable);
					if (TABLE.TblGen && TABLE.TblType != "REPORT") {
						// Get detail key SQL
						var sDetailKeySQL = "";
						for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
							MASTERFIELD = MASTERTABLE.Fields(MasterDetail.Rels[j].MasterField);
							sMasterFldName = MASTERFIELD.FldName;
							sMasterFldTypeName = GetFieldTypeName(MASTERFIELD.FldType);
							DETAILFIELD = TABLE.Fields(MasterDetail.Rels[j].DetailField);
							sDetailFld = ew_FieldSqlName(DETAILFIELD);
							if (sDetailKeySQL != "") sDetailKeySQL += " + \" AND \" + ";
							sDetailKeySQL += "\"" + ew_Quote(sDetailFld) + " = \" + ew_QuotedValue(rs[\"" + ew_Quote(sMasterFldName) + "\"], " + sMasterFldTypeName + ")";
						} // MasterDetailField
	##-->
			// Cascade delete detail table '<!--##=MasterDetail.DetailTable##-->'
			if (<!--##=TABLE.TblVar##--> == null)
				<!--##=TABLE.TblVar##--> = new c<!--##=TABLE.TblVar##-->();
			<!--##=TABLE.TblVar##-->.Delete(null, <!--##=sDetailKeySQL##-->);
	<!--##
					}
					TABLE = OLDTABLE; // Restore master table
				}
			}
		}
	##-->
			string Sql = "DELETE FROM " + UpdateTable + " WHERE ";
			string filter = CurrentFilter;
			ew_AddFilter(ref filter, where);
			if (rs != null) {
				cField fld; 
			<!--##
			for (var i = 0, len = arKeyFlds.length; i < len; i++) {
				if (GetFldObj(arKeyFlds[i])) {
			##-->
				fld = FieldByName("<!--##=ew_Quote(gsFldName)##-->");				
				ew_AddFilter(ref filter, fld.FldExpression + "=" + ew_QuotedValue(rs["<!--##=ew_Quote(gsFldName)##-->"], fld.FldDataType));			
			<!--##
				}
			}
			##-->
			}
			if (ew_NotEmpty(filter))
				Sql += filter;
			else
				Sql += "0=1"; // Avoid delete
			if (EW_DEBUG_ENABLED)
				ew_SetDebugMsg(Sql); 
			return Conn.Execute(Sql);
			
		}
	
		// Key filter WHERE clause
		private string SqlKeyFilter {
			get { return "<!--##=sKeyFilter##-->"; }
		}
		
		// Key filter
		public string KeyFilter {
			get {
				string sKeyFilter = SqlKeyFilter;
			<!--##
				var sPrefix = "";
				var sSuffix = "";
				for (var i = 0, len = arKeyFlds.length; i < len; i++) {
					if (GetFldObj(arKeyFlds[i])) {
						if (ew_GetFieldType(goFld.FldType) == 1) { // Numeric
			##-->
				if (!Information.IsNumeric(<!--##=gsFldObj##-->.CurrentValue))
					sKeyFilter = "0=1";	// Invalid key
			<!--##
						}
						if (ew_GetFieldType(goFld.FldType) == 2) { // Date
							sPrefix = "ew_UnformatDateTime(";
							sSuffix = "," + goFld.FldDtFormat + ")";
						} else if (ew_GetFieldType(goFld.FldType) == 5) { // GUID // ASPX
							if (bDBMsAccess) { // Need to add back "{" and "}"
								sPrefix = '"{" + '; // C#
								sSuffix = ' + "}"'; // C#
							}
						} else {
							sPrefix = "";
							sSuffix = "";
						}
			##-->
				sKeyFilter = sKeyFilter.Replace("@<!--##=gsFldParm##-->@", ew_AdjustSql(<!--##=sPrefix##--><!--##=gsFldObj##-->.CurrentValue<!--##=sSuffix##-->)); // Replace key value
			<!--##
					}
				} // KeyField
			##-->
				return sKeyFilter;
			}
		}
	
		// Return URL
		public string ReturnUrl {
			get {
				string name = EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_RETURN_URL;
				// Get referer URL automatically
				if (ew_NotEmpty(ew_ServerVar("HTTP_REFERER")) &&
					ew_ReferPage() != ew_CurrentPage() &&
					ew_ReferPage() != "<!--##=sFnLogin##-->") // Referer not same page or login page
						ew_Session[name] = ew_ServerVar("HTTP_REFERER"); // Save to Session
				if (ew_NotEmpty(ew_Session[name])) {
					return Convert.ToString(ew_Session[name]);
				} else {
					return "<!--##=sFnList##-->";
				}
			}
			set {
				ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_RETURN_URL] = value;
			}
		}
		
		// List URL
		public string ListUrl {
			get { return "<!--##=sFnList##-->"; }
		}
	
		// View URL
		public string ViewUrl {
			get { return KeyUrl("<!--##=sFnView##-->", UrlParm()); }
		}
		
		// View URL
		public string GetViewUrl(string parm = "") {
			if (ew_NotEmpty(parm))
				return KeyUrl("<!--##=sFnView##-->", UrlParm(parm));
			else
				return KeyUrl("<!--##=sFnView##-->", UrlParm(EW_TABLE_SHOW_DETAIL + "="));
		}
		
		// Add URL
		public string AddUrl {
			get {
			<!--## if (bDetailAdd && nDetailTableCount > 0) { ##-->
				return "<!--##=sFnAdd##-->?" + EW_TABLE_SHOW_DETAIL + "=";
			<!--## } else { ##-->
				return "<!--##=sFnAdd##-->";
			<!--## } ##-->
			}
		}
		
		// Add URL
		public string GetAddUrl(string parm = "") {
			if (ew_NotEmpty(parm))
				return "<!--##=sFnAdd##-->?" + UrlParm(parm);
			else
				return "<!--##=sFnAdd##-->";
		}
		
		// Edit URL
		public string EditUrl {
			get {
			<!--## if (bDetailEdit && nDetailTableCount > 0) { ##-->
				return KeyUrl("<!--##=sFnEdit##-->", UrlParm(EW_TABLE_SHOW_DETAIL + "="));
			<!--## } else { ##-->
				return KeyUrl("<!--##=sFnEdit##-->", UrlParm());
			<!--## } ##-->
			}
		}
	
		// Edit URL (with parameter)
		public string GetEditUrl(string parm) {
		<!--## if (bDetailEdit && nDetailTableCount > 0) { ##-->
			if (ew_NotEmpty(parm))
				return KeyUrl("<!--##=sFnEdit##-->", UrlParm(parm));
			else
				return KeyUrl("<!--##=sFnEdit##-->", UrlParm(EW_TABLE_SHOW_DETAIL + "="));
		<!--## } else { ##-->
			return KeyUrl("<!--##=sFnEdit##-->", UrlParm(parm));
		<!--## } ##-->
		}
	
		// Inline edit URL
		public string InlineEditUrl	{
			get { return KeyUrl(ew_CurrentPage(), UrlParm("a=edit")); }
		}
		
		// Copy URL
		public string CopyUrl {
			get {
			<!--## if (bDetailEdit && nDetailTableCount > 0) { ##-->
				return KeyUrl("<!--##=sFnAdd##-->", UrlParm(EW_TABLE_SHOW_DETAIL + "="));
			<!--## } else { ##-->
				return KeyUrl("<!--##=sFnAdd##-->", UrlParm());
			<!--## } ##-->
			}
		}
	
		// Copy URL
		public string GetCopyUrl(string parm = "") {
		<!--## if (bDetailAdd && nDetailTableCount > 0) { ##-->
			if (ew_NotEmpty(parm))
				return KeyUrl("<!--##=sFnAdd##-->", UrlParm(parm));
			else
				return KeyUrl("<!--##=sFnAdd##-->", UrlParm(EW_TABLE_SHOW_DETAIL + "="));
		<!--## } else { ##-->
			return KeyUrl("<!--##=sFnAdd##-->", UrlParm(parm));
		<!--## } ##-->
		}		
	
		// Inline copy URL
		public string InlineCopyUrl	{
			get { return KeyUrl(ew_CurrentPage(), UrlParm("a=copy")); }
		}
		
		// Delete URL
		public string DeleteUrl	{
			get { return KeyUrl("<!--##=sFnDelete##-->", UrlParm()); }
		}
	
		// Add key value to URL
		public string KeyUrl(string url, string parm = "") {
			string sUrl = url + "?";
			if (ew_NotEmpty(parm)) sUrl += parm + "&"; 
	<!--##
		for (var i = 0, len = arKeyFlds.length; i < len; i++) {
			if (GetFldObj(arKeyFlds[i])) {
				var sFldKeyVal = gsFldParm + ".CurrentValue";
				var sDateCheck = "";
				if (ew_GetFieldType(goFld.FldType) == 2) { // DateTime fields
					if (ew_InArray(goFld.FldDtFormat, [5, 6, 7]) > -1) { // Format As Date
						sFldKeyVal = "ew_UrlEncode(Convert.ToDateTime(" + sFldKeyVal + ").ToString(\"yyyy'/'MM'/'dd\"))";
					} else { // Format As DateTime
						sFldKeyVal = "ew_UrlEncode(Convert.ToDateTime(" + sFldKeyVal + ").ToString(\"yyyy'/'MM'/'dd' 'HH':'mm':'ss\"))";
					}
				} else if (ew_GetFieldType(goFld.FldType) == 7) { // Time fields
					sFldKeyVal = "ew_UrlEncode(Convert.ToDateTime(" + sFldKeyVal + ").ToString(\"HH':'mm':'ss\"))";
				} else if (ew_GetFieldType(goFld.FldType) != 1) {
					sFldKeyVal = "ew_UrlEncode(Convert.ToString(" + sFldKeyVal + "))";
				}
				sConcat = "";
				if (i > 0) sConcat = "&";
				if (goFld.FldHtmlTag == "FILE" && !ew_IsBinaryField(goFld)) { // Upload to folder (P501)
	##-->
			if (!ew_Empty(<!--##=gsFldParm##-->.Upload.DbValue)) {
				sUrl += "<!--##=sConcat##--><!--##=gsFldParm##-->=" + ew_UrlEncode(<!--##=gsFldParm##-->.Upload.DbValue);
	<!--##
				} else if (ew_InArray(ew_GetFieldType(FIELD.FldType), [2, 7]) > -1) {
	##-->
			if (!Convert.IsDBNull(<!--##=gsFldParm##-->.CurrentValue) && Information.IsDate(<!--##=gsFldParm##-->.CurrentValue)) {
				sUrl += "<!--##=sConcat##--><!--##=gsFldParm##-->=" + <!--##=sFldKeyVal##-->;
	<!--##
				} else {
	##-->
			if (!Convert.IsDBNull(<!--##=gsFldParm##-->.CurrentValue)) {
				sUrl += "<!--##=sConcat##--><!--##=gsFldParm##-->=" + <!--##=sFldKeyVal##-->;				
	<!--##
				}
	##-->				
			} else {
				return "javascript:alert(ewLanguage.Phrase('InvalidRecord'));";
			}
	<!--##
			}
		} // KeyField
	##-->
			return sUrl;
		}
		
		// Sort URL
		public string SortUrl(cField fld) {
	<!--## if (iSortType == 0) { ##-->
			return "";
	<!--## } else { ##-->
			if (ew_NotEmpty(CurrentAction) || ew_NotEmpty(Export) || 
		<!--## if (bDBMySql || bDBPostgreSql) { ##-->
				(new List<int>() {128, 204, 205}).Contains(fld.FldType)) { // Unsortable data type
		<!--## } else { ##-->
				(new List<int>() {141, 201, 203, 128, 204, 205}).Contains(fld.FldType)) { // Unsortable data type
		<!--## } ##-->
				return "";
			} else if (fld.Sortable) { 
				string sUrlParm = UrlParm("order=" + ew_UrlEncode(fld.FldName) + "&amp;ordertype=" + fld.ReverseSort());
				return ew_CurrentPage() + "?" + sUrlParm;
			}
			return "";
	<!--## } ##-->
		}
		
		// Get record keys
		public ArrayList GetRecordKeys() {
			var arKeys = new ArrayList();
			if (ew_Form["key_m"] != null) { // Key in form
				arKeys.AddRange(ew_Form.GetValues("key_m"));
		<!--## if (nKeyCount > 1) { ##-->
				for (int i = 0; i < arKeys.Count; i++)
					arKeys[i] = Convert.ToString(arKeys[i]).Split(new[] { Convert.ToChar(EW_COMPOSITE_KEY_SEPARATOR) });
		<!--## } ##-->
			} else if (ew_QueryString["key_m"] != null) {
				arKeys.AddRange(ew_QueryString.GetValues("key_m"));
		<!--## if (nKeyCount > 1) { ##-->
				for (int i = 0; i < arKeys.Count; i++)
					arKeys[i] = Convert.ToString(arKeys[i]).Split(new[] { Convert.ToChar(EW_COMPOSITE_KEY_SEPARATOR) });
		<!--## } ##-->
			} else if (ew_QueryString.Count > 0) {
			<!--## if (nKeyCount > 1) { ##-->
				var keys = new string[<!--##=nKeyCount##-->]; // C#
			<!--## } else { ##-->
				var keys = "";
			<!--## } ##-->
		<!--##
			for (var i = 0, len = arKeyFlds.length; i < len; i++) {
				if (GetFldObj(arKeyFlds[i])) {
		##-->
		<!--## if (nKeyCount > 1) { ##-->
				keys[<!--##=i##-->] = ew_Get("<!--##=gsFldParm##-->");
		<!--## } else { ##-->
				keys = ew_Get("<!--##=gsFldParm##-->"); // <!--##=gsFldParm##-->
		<!--## } ##-->
		<!--##
				}
			} // KeyField
		##-->
				arKeys.Add(keys);
				//return arKeys; // do not return yet, so the values will also be checked by the following code
			}
			// check keys
			var ar = new ArrayList();
			// Check keys
			foreach (var keys in arKeys) {
		<!--## if (nKeyCount > 1) { ##-->
				if (!Information.IsArray(keys) || ((string[])keys).Length != <!--##=nKeyCount##-->)
					continue; // Just skip so other keys will still work
		<!--## } ##-->
		<!--##
			for (var i = 0, len = arKeyFlds.length; i < len; i++) {
				if (GetFldObj(arKeyFlds[i])) {
					bNumericKey = (ew_GetFieldType(goFld.FldType) == 1);
					if (bNumericKey) {
		##-->
		<!--## if (nKeyCount > 1) { ##-->
				if (!Information.IsNumeric(((string[])keys)[<!--##=i##-->])) // <!--##=gsFldParm##-->
		<!--## } else { ##-->
				if (!Information.IsNumeric(keys))
		<!--## } ##-->
					continue;
		<!--##
					}
				}
			} // KeyField
		##-->
				ar.Add(keys);
			}
			return ar;
		}
	
		// Get key filter
		public string GetKeyFilter() {
			ArrayList arKeys = GetRecordKeys();
			string sKeyFilter = "";
			foreach (var keys in arKeys) {
				if (ew_NotEmpty(sKeyFilter))
					sKeyFilter += " OR ";
		<!--##
			for (var i = 0, len = arKeyFlds.length; i < len; i++) {
				if (GetFldObj(arKeyFlds[i])) {
					if (nKeyCount > 1)
						keystr = "((string[])keys)[" + i + "]";
					else
						keystr = "keys";
		##-->
				<!--##=gsFldParm##-->.CurrentValue = <!--##=keystr##-->;
		<!--##
				}
			} // KeyField
		##-->
				sKeyFilter += "(" + KeyFilter + ")";
			}
			return sKeyFilter;
		}
	
		// Load rows based on filter
		public ewDataReader LoadRs(string sFilter, cConnectionBase cnn = null) {
			// Set up filter (SQL WHERE clause) and get return SQL
			string sSql = GetSQL(sFilter);
			try {
				var rs = (cnn != null) ? cnn.OpenDataReader(sSql) : Conn.OpenDataReader(sSql); // ASPX
				if (rs != null) {
					if (rs.HasRows)
						return rs;
					rs.Close();
					rs.Dispose();
				}
			} catch {}
			return null;
		}
		
		// Load record count based on filter
		public int LoadRecordCount(string sFilter) {
			// Set up filter (SQL WHERE clause) and get return SQL
			string sSql = GetSQL(sFilter);
			string sSqlCnt = "SELECT COUNT(*) FROM" + ((TableType == "TABLE" || TableType == "VIEW") ? Regex.Replace(sSql, @"^SELECT\s([\s\S]+)?\*\sFROM", "", RegexOptions.IgnoreCase) : " (" + sSql + ")");
			// Try count SQL first
			try {
				return Convert.ToInt32(Conn.ExecuteScalar(sSqlCnt));
			} catch {}
			// Loop datareader to get count
			try {
				int Cnt = 0;
				using (ewDataReader rs = Conn.OpenDataReader(sSql)) {					
					while (rs.Read())
						Cnt++;
				}
				return Cnt;
			} catch {
				return 0;
			}
		}
	<!--##
		} // table/view
	##-->
		
		<!--## if (TABLE.TblType != "REPORT") { ##-->
	
		// Load row values from recordset
		public void LoadListRowValues(ewDataReader rs) {
		<!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
					if (ew_GetFieldType(goFld.FldType) == 4) { // Boolean Fields
		##-->
			<!--##=gsFldParm##-->.DbValue = ew_ConvertToBool(rs["<!--##=ew_Quote(gsFldName)##-->"]) ? "1" : "0";
		<!--##
					} else if (goFld.FldHtmlTag == "FILE") {
		##-->
			<!--##=gsFldParm##-->.Upload.DbValue = rs["<!--##=ew_Quote(gsFldName)##-->"];
		<!--##
					} else {
		##-->
			<!--##=gsFldParm##-->.DbValue = rs["<!--##=ew_Quote(gsFldName)##-->"];
		<!--##
					}
				}
			} // AllField
		##-->
		}
	
		// Render list row values
		public void RenderListRow() {
			
		<!--## if (TABLE.TblType != "REPORT" && SYSTEMFUNCTIONS.ServerScriptExist("Table","Row_Rendering")) { ##-->
			// Call Row Rendering event
			Row_Rendering();
		<!--## } ##-->
		
	   // Common render codes
	   <!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
	   ##-->
			// <!--##=gsFldParm##-->
			<!--##~SYSTEMFUNCTIONS.ScriptCommon()##-->
	   <!--##
				}
			} // AllField
	   ##-->
	
		<!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
		##-->
			// <!--##=gsFldParm##-->
			<!--##~SYSTEMFUNCTIONS.ScriptView()##-->
		<!--##
				}
			} // AllField
		##-->
	
		<!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
		##-->
			// <!--##=gsFldParm##-->
			<!--##~SYSTEMFUNCTIONS.ScriptViewRefer()##-->
		<!--##
				}
			} // AllField
		##-->
		
		<!--## if (TABLE.TblType != "REPORT" && SYSTEMFUNCTIONS.ServerScriptExist("Table","Row_Rendered")) { ##-->
			// Call Row Rendered event
			Row_Rendered();
		<!--## } ##-->
	
		}
		
		// Render edit row values
		public void RenderEditRow() {
		
		<!--## if (TABLE.TblType != "REPORT" && SYSTEMFUNCTIONS.ServerScriptExist("Table","Row_Rendering")) { ##-->
			// Call Row Rendering event
				Row_Rendering();
		<!--## } ##-->
	
		<!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
		##-->
		// <!--##=gsFldName##-->
		<!--##~SYSTEMFUNCTIONS.ScriptEdit()##-->
		<!--##
				}
			} // AllField
		##-->
	
		<!--## if (TABLE.TblType != "REPORT" && SYSTEMFUNCTIONS.ServerScriptExist("Table","Row_Rendered")) { ##-->
			// Call Row Rendered event
				Row_Rendered();
		<!--## } ##-->

		}

		// Aggregate list row values
		public void AggregateListRowValues() {
		<!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
					if (goFld.FldAggregate == "COUNT" || goFld.FldAggregate == "AVERAGE") {
		##-->
				<!--##=gsFldObj##-->.Count++; // Increment count
		<!--##
					}
					if (goFld.FldAggregate == "AVERAGE" || goFld.FldAggregate == "TOTAL") {
		##-->
				if (Information.IsNumeric(<!--##=gsFldObj##-->.CurrentValue))
					<!--##=gsFldObj##-->.Total += ew_ConvertToDouble(<!--##=gsFldObj##-->.CurrentValue); // Accumulate total
		<!--##
					}
				}
			} // AllField
		##-->
		}
	
		// Aggregate list row (for rendering)
		public void AggregateListRow() {
	
		<!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
					if (ew_IsNotEmpty(goFld.FldAggregate)) {
		##-->
				<!--##~SYSTEMFUNCTIONS.ScriptAggregate()##-->
		<!--##
					}
				}
			} //AllField
		##-->  
		<!--## if (TABLE.TblType != "REPORT" && SYSTEMFUNCTIONS.ServerScriptExist("Table","Row_Rendered")) { ##-->
			// Call Row Rendered event
			Row_Rendered();
		<!--## } ##-->
	
		}
		
		public dynamic ExportDoc;
	
		// Export data in HTML/CSV/Word/Excel/Email/PDF format
		public void ExportDocument(dynamic Doc, ewDataReader Recordset, int StartRec, int StopRec, string ExportPageType = "") {	
		
			if (Recordset == null || Doc == null)
				return;
	
			if (!Doc.ExportCustom) {
				// Write header
				Doc.ExportTableHeader();
				if (Doc.Horizontal) { // Horizontal format, write header
					Doc.BeginExportRow();
	
					if (ExportPageType == "view") {
	
		<!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
					if (goFld.FldView) {
		##-->
						if (<!--##=gsFldObj##-->.Exportable) Doc.ExportCaption(ref <!--##=gsFldObj##-->);
		<!--##
					}
				}
			} // AllField
		##-->
	
					} else {
	
		<!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
					if (goFld.FldExport) {
		##-->
						if (<!--##=gsFldObj##-->.Exportable) Doc.ExportCaption(ref <!--##=gsFldObj##-->);
		<!--##
					}
				}
			} // AllField
		##-->
	
					}
	
					Doc.EndExportRow();
	
				}
			}	
			
			// Move to first record
			int RecCnt = StartRec - 1;
			for (int i = 1; i <= StartRec - 1; i++)
				Recordset.Read();	
			
			while (Recordset.Read() && RecCnt < StopRec) {
				RecCnt++;
				if (RecCnt >= StartRec) {
					int RowCnt = RecCnt - StartRec + 1;
	
					// Page break
					if (ExportPageBreakCount > 0) {
						if (RowCnt > 1 && (RowCnt - 1) % ExportPageBreakCount == 0)
							Doc.ExportPageBreak();
					}
	
					LoadListRowValues(Recordset);
	
			<!--## if (SYSTEMFUNCTIONS.IsAggregate()) { ##-->
					AggregateListRowValues(); // Aggregate row values
			<!--## } ##-->
	
					// Render row
					RowType = EW_ROWTYPE_VIEW; // Render view
					ResetAttrs();
					RenderListRow();
	
					if (!Doc.ExportCustom) {
						Doc.BeginExportRow(RowCnt); // Allow CSS styles if enabled
	
						if (ExportPageType == "view") {
	
		<!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
					if (goFld.FldView) {
		##-->
							if (<!--##=gsFldObj##-->.Exportable) Doc.ExportField(ref <!--##=gsFldObj##-->);
		<!--##
					}
				}
			} // AllField
		##-->
	
						} else {
	
		<!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
					if (goFld.FldExport) {
		##-->
							if (<!--##=gsFldObj##-->.Exportable) Doc.ExportField(ref <!--##=gsFldObj##-->);
		<!--##
					}
				}
			} // AllField
		##-->
	
						}
	
						Doc.EndExportRow();
					}
				}

	<!--## if (SYSTEMFUNCTIONS.ServerScriptExist(sCtrlType,"Row_Export")) { ##-->
			// Call Row Export server event
			if (Doc.ExportCustom)
				Row_Export(Recordset);
	<!--## } ##-->	
			}
			
			<!--## if (SYSTEMFUNCTIONS.IsAggregate()) { ##-->
			// Export aggregates (horizontal format only)
			if (Doc.Horizontal) {
				RowType = EW_ROWTYPE_AGGREGATE;
				ResetAttrs();
				AggregateListRow();
				if (!Doc.ExportCustom) {
					Doc.BeginExportRow(-1);
		<!--##
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
					if (goFld.FldExport) {
		##-->
					Doc.ExportAggregate(ref <!--##=gsFldObj##-->, "<!--##=ew_Quote(goFld.FldAggregate)##-->");
		<!--##
					}
				}
			} // AllField
		##-->
					Doc.EndExportRow();
				}
			}	
			<!--## } ##-->
			
			if (!Doc.ExportCustom) {
				Doc.ExportTableFooter();
			}
		}
	
		<!--## } ##-->
	
	<!--##
		if (bTableHasUserIDFld) {
			if (GetFldObj(TABLE.TblUserIDFld)) {
				sTblUserIDFldName = gsFld;
			}
	##-->
	
		<!--##
			if (TABLE.TblName == SECTABLE.TblName) {
	
				if (GetFldObj(DB.SecuUserIDFld)) {
					sFldDataType = GetFieldTypeName(goFld.FldType);
					sUserIDFldName = gsFld;
				}
	
				if (bParentUserID) {
					if (GetFldObj(DB.SecuParentUserIDFld)) {
						sParentUserIDFldName = gsFld;
					}
				}
	
				if (SECTABLE.TblType == "CUSTOMVIEW")
					sFromPart = ew_SQLPart(SECTABLE.TblCustomSQL, "FROM");
				else
					sFromPart = SqlTableName(SECTABLE);
		##-->

		// User ID filter
		public string UserIDFilter(object userid) {
			string sUserIDFilter = "<!--##=ew_Quote(sUserIDFldName)##--> = " + ew_QuotedValue(userid, <!--##=sFldDataType##-->);
		<!--## if (bParentUserID) { ##-->
			string sParentUserIDFilter = "<!--##=ew_Quote(sUserIDFldName)##--> IN (SELECT <!--##=ew_Quote(sUserIDFldName)##--> FROM <!--##=ew_Quote(sFromPart)##--> WHERE <!--##=ew_Quote(sParentUserIDFldName)##--> = " + ew_QuotedValue(userid, <!--##=sFldDataType##-->) + ")";
			sUserIDFilter = "(" + sUserIDFilter + ") OR (" + sParentUserIDFilter + ")";
		<!--## } ##-->
			return sUserIDFilter;
		}
			
		<!--##
			}
		##-->
		
		// Add User ID filter
		public string AddUserIDFilter(string sFilter = "") {
			string sFilterWrk = "";
			var id = (CurrentPageID() == "list") ? CurrentAction : CurrentPageID();
			if (!UserIDAllow(id) && !Security.IsAdmin) {
				sFilterWrk = Security.UserIDList();
				if (ew_NotEmpty(sFilterWrk))
					sFilterWrk = "<!--##=ew_Quote(sTableUserIDFld)##--> IN (" + sFilterWrk + ")";
				ew_AddFilter(ref sFilterWrk, sFilter);
			}
		<!--## if (SYSTEMFUNCTIONS.ServerScriptExist("Table","UserID_Filtering")) { ##-->
			// Call User ID Filtering event
			UserID_Filtering(ref sFilterWrk);
		<!--## } ##-->
		
			ew_AddFilter(ref sFilter, sFilterWrk);
			return sFilter;
		}	
	
		<!--##
			if (bParentUserID && PROJ.SecTbl == TABLE.TblName) { // User table with parent user id
		##-->
		
		// Add Parent User ID filter
		public string AddParentUserIDFilter(string sFilter, object userid) {
			if (!Security.IsAdmin) {
				string sFilterWrk = Security.ParentUserIDList(userid);
				if (ew_NotEmpty(sFilterWrk))
					sFilterWrk = "<!--##=ew_Quote(sTableUserIDFld)##--> IN (" + sFilterWrk + ")";
				ew_AddFilter(ref sFilterWrk, sFilter);
				return sFilterWrk;
			} else {
				return sFilter;
			}
			
		}
	
		<!--##
			}
		##-->
		
		// User ID subquery
		public string GetUserIDSubquery(cField fld, cField masterfld) {
			string sWrk = "";			
			string sSql = "SELECT " + masterfld.FldExpression + " FROM <!--##=ew_Quote(sFromPart)##-->";
			string sFilter = AddUserIDFilter();
			if (ew_NotEmpty(sFilter))
				sSql += " WHERE " + sFilter;
	
			// Use subquery
			if (EW_USE_SUBQUERY_FOR_MASTER_USER_ID) {	// Use subquery
				sWrk = sSql;
			} else { // List all values
				using (var rsuser = Conn.OpenDataReader(sSql)) {
					if (rsuser != null) {
						while (rsuser.Read()) {
							if (ew_NotEmpty(sWrk)) sWrk += ","; 
							sWrk += ew_QuotedValue(rsuser[0], masterfld.FldDataType);
						}
						rsuser.Close();				
					}
				}
			}
			if (ew_NotEmpty(sWrk))
				sWrk = fld.FldExpression + " IN (" + sWrk + ")";
			return sWrk;
		}
	<!--##
		}
	##-->
	
	<!--##
		if (bMasterTableHasUserIDFld) {
	##-->
	
		// Add master User ID filter
		public string AddMasterUserIDFilter(string sFilter, string sCurrentMasterTable) {
			string sFilterWrk = sFilter;
		<!--##
			for (var i = 0, len = arMasterTables.length; i < len; i++) {
				var MasterDetail = goAllMasDets[arMasterTables[i].index];
				MASTERTABLE = DB.Tables(MasterDetail.MasterTable);
				if (MASTERTABLE.TblGen) {
					if (bUserID && ew_IsNotEmpty(MASTERTABLE.TblUserIDFld)) {
						sMasterTblVar = MASTERTABLE.TblVar;
						if (sMasterTblVar == TABLE.TblVar) { // master = detail
		##-->
			if (sCurrentMasterTable == "<!--##=sMasterTblVar##-->" && ew_NotEmpty(CurrentMasterTable)) {
		<!--##
						} else {
		##-->
			if (sCurrentMasterTable == "<!--##=sMasterTblVar##-->") {
		<!--##
						}
		##-->
				sFilterWrk = <!--##=sMasterTblVar##-->.AddUserIDFilter(sFilterWrk);
			}
		<!--##
					}
				}
			} // MasterDetail
		##-->
			return sFilterWrk;
		}
	
		// Add detail User ID filter
		public string AddDetailUserIDFilter(string sFilter, string sCurrentMasterTable) {
			string sFilterWrk = sFilter;
			string sSubqueryWrk = "";			
		<!--##
			for (var i = 0, len = arMasterTables.length; i < len; i++) {
				var MasterDetail = goAllMasDets[arMasterTables[i].index];
				MASTERTABLE = DB.Tables(MasterDetail.MasterTable);
				if (MASTERTABLE.TblGen) {
					if (bUserID && ew_IsNotEmpty(MASTERTABLE.TblUserIDFld)) {
						sMasterTblVar = MASTERTABLE.TblVar;
						if (sMasterTblVar == TABLE.TblVar) { // master = detail
		##-->
			if (sCurrentMasterTable == "<!--##=sMasterTblVar##-->" && ew_NotEmpty(CurrentMasterTable)) {
		<!--##
						} else {
		##-->
			if (sCurrentMasterTable == "<!--##=sMasterTblVar##-->") {
		<!--##
						}
						for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
							MASTERFIELD = MASTERTABLE.Fields(MasterDetail.Rels[j].MasterField);
							sMasterFldParm = MASTERFIELD.FldParm;
							DETAILFIELD = TABLE.Fields(MasterDetail.Rels[j].DetailField);
							sDetailFldParm = DETAILFIELD.FldParm;
		##-->
				if (!<!--##=sMasterTblVar##-->.UserIDAllow()) {
					sSubqueryWrk = <!--##=sMasterTblVar##-->.GetUserIDSubquery(<!--##=sDetailFldParm##-->, <!--##=sMasterTblVar##-->.<!--##=sMasterFldParm##-->);
					ew_AddFilter(ref sFilterWrk, sSubqueryWrk);
				}
		<!--##
						} // MasterDetailField
		##-->
			}
		<!--##
					}
				}
			} // MasterDetail
		##-->
			return sFilterWrk;
		}
	<!--##
		}
	##-->
	
		<!--## if (TABLE.TblType != "REPORT") { ##-->
		// Get auto fill value
		public string GetAutoFill(string id, string val) {
			var rsarr = new List<OrderedDictionary>();
			
			int rowcnt = 0;

		<!--##
			for (var i = 0, wrklen = arAllFlds.length; i < wrklen; i++) {
				if (GetFldObj(arAllFlds[i])) {
					if (goFld.FldAutoFill && ew_IsNotEmpty(goFld.FldAutoFillSourceFields) && ew_IsNotEmpty(goFld.FldAutoFillTargetFields) &&
						ew_IsNotEmpty(goFld.FldTagLnkTbl) && ew_IsNotEmpty(goFld.FldTagLnkFld)) {
						var LINKTABLE = DB.Tables.Item(goFld.FldTagLnkTbl);
						if (!LINKTABLE) continue;
						var sCtrlID = CTRL.CtrlID;
						var iFldCnt = -1;
						var arFields = [];
						var sFldVarList = "";
						var arSourceFlds = goFld.FldAutoFillSourceFields.split("||");
						var arTargetFlds = goFld.FldAutoFillTargetFields.split("||");
						for (var j = 0, cnt = arSourceFlds.length; j < cnt; j++) {
							iFldCnt += 1;
							ew_AddSelectField(arFields, LINKTABLE, arSourceFlds[j], ew_LanguageCount, "FIELD" + iFldCnt); // Fill field
						}
						// Build SQL
						var WRKFLD = LINKTABLE.Fields.Item(goFld.FldTagLnkFld);
						if (!WRKFLD) continue;
						var sFilterFld = ew_Quote(ew_FieldSqlName(WRKFLD));
						var sFilterQuoteS = WRKFLD.FldQuoteS;
						var sFilterQuoteE = WRKFLD.FldQuoteE;
						var sFilter = "(" + sFilterFld + " = " + sFilterQuoteS + "\" + ew_AdjustSql(val) + \"" + sFilterQuoteE + ")";
		##-->
			if (Regex.IsMatch(id, @"^x(\d)*_<!--##=gsFldParm##-->$")) {
				<!--##~SYSTEMFUNCTIONS.LookupSql(false, arFields, sFilter, "", true, "", true)##-->
				using (var rs = Conn.OpenDataReader(sSqlWrk)) {
					while (rs != null && rs.Read()) {							
						var ar = new OrderedDictionary();
		<!--##
						for (var j = 0, len = arTargetFlds.length; j < len; j++) {
							var TARGETFLD = goTblFlds.Fields[arTargetFlds[j]];
							sTargetFldParm = TARGETFLD.FldParm;
		##-->
						<!--##=sTargetFldParm##-->.DbValue = rs["FIELD<!--##=j##-->"];
		<!--##
						}
						
		##-->
						RowType = EW_ROWTYPE_EDIT;
						RenderEditRow();
		<!--##
						var tmpFld = goFld; // Save field object
						for (var j = 0, len = arTargetFlds.length; j < len; j++) {
							goFld = goTblFlds.Fields[arTargetFlds[j]];
							sTargetFldParm = goFld.FldParm;
							if (SYSTEMFUNCTIONS.IsBoolFld()) {
		##-->
						ar.Add(<!--##=j##-->, ew_ConvertToBool(<!--##=sTargetFldParm##-->.CurrentValue) ? "<!--##=ewTrue##-->" : "<!--##=ewFalse##-->");
		<!--##
							} else if (ew_InArray(goFld.FldHtmlTag, ["SELECT", "RADIO", "CHECKBOX", "HIDDEN"]) > -1) {
		##-->
						ar.Add(<!--##=j##-->, <!--##=sTargetFldParm##-->.CurrentValue);
		<!--##
							} else {
		##-->
						ar.Add(<!--##=j##-->, (<!--##=sTargetFldParm##-->.AutoFillOriginalValue) ? <!--##=sTargetFldParm##-->.CurrentValue : <!--##=sTargetFldParm##-->.EditValue);
		<!--##
							}
						}
						goFld = tmpFld; // Restore field object
		##-->
						rowcnt++;
						rsarr.Add(ar);
					}
				}
			}
		<!--##
					}
				}
			}
		##-->

			// Output (using ew_Response) // ASPX
			if (ew_IsList(rsarr) && rowcnt > 0) {				 
				foreach (OrderedDictionary row in rsarr) {
					for (var i = 0; i < row.Count; i++) {
						var str = Convert.ToString(row[i]);
						if (ew_Empty(ew_Post("keepHTML")))
							str = ew_RemoveHtml(str);
						if (str.Contains("\r") || str.Contains("\n")) {
							if (ew_NotEmpty(ew_Post("keepCRLF"))) {
								str = str.Replace("\r", "\\r").Replace("\n", "\\n");
							} else {
								str = str.Replace("\r", " ").Replace("\n", " ");
							}
						}
						row[i] = str;
					}				
				}
				return ew_ArrayToJson(rsarr);		
			} else {
				return "false";
			}

		}
		<!--## } ##-->

		<!--## if (TABLE.TblType != "REPORT") { ##-->
		// Table level events
		<!--##~GetVirtualEvent("Table","Recordset_Selecting")##-->		
		<!--##~GetVirtualEvent("Table","Recordset_SearchValidated")##-->
		<!--##~GetVirtualEvent("Table","Recordset_Searching")##-->
		<!--##~GetVirtualEvent("Table","Row_Selecting")##-->
		<!--##~GetVirtualEvent("Table","Row_Selected")##-->
		<!--##~GetVirtualEvent("Table","Row_Inserting")##-->
		<!--##~GetVirtualEvent("Table","Row_Inserted")##-->
		<!--##~GetVirtualEvent("Table","Row_Updating")##-->
		<!--##~GetVirtualEvent("Table","Row_Updated")##-->
		<!--##~GetVirtualEvent("Table","Row_UpdateConflict")##-->
		<!--##~GetVirtualEvent("Table","Row_Export")##-->
		<!--##~GetVirtualEvent("Table","Page_Exporting")##-->
		<!--##~GetVirtualEvent("Table","Page_Exported")##-->
		<!--##~GetVirtualEvent("Table","Grid_Inserting")##-->
		<!--##~GetVirtualEvent("Table","Grid_Inserted")##-->
		<!--##~GetVirtualEvent("Table","Grid_Updating")##-->
		<!--##~GetVirtualEvent("Table","Grid_Updated")##-->
		<!--##~GetVirtualEvent("Table","Row_Deleting")##-->
		<!--##~GetVirtualEvent("Table","Row_Deleted")##-->
		<!--##~GetVirtualEvent("Table","Email_Sending")##-->
		<!--##~GetVirtualEvent("Table","Lookup_Selecting")##-->
		<!--## } ##-->
	
		<!--##~GetVirtualEvent("Table","Row_Rendering")##-->
		<!--##~GetVirtualEvent("Table","Row_Rendered")##-->
		<!--##~GetVirtualEvent("Table","UserID_Filtering")##-->
	}
}
<!--##/session##-->