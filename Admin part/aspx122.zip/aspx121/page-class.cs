<!--##session tablepageclass##-->
<!--##
	var id = CTRL.CtrlID.toLowerCase();
	var typ = CTRL.CtrlType.toLowerCase();
	var sPageObjTypes = (id != "master") ? "<cConnection, cAdvancedSecurity>" : "";
##-->
	//
	// Page class for <!--##=gsTblName##-->
	//
	<!--## if (id == "master") { ##-->	
	public class c<!--##=sPageObj##--> : c<!--##=gsTblVar##-->
	{
		// Page ID
		public string PageID = "master";
		
		// Project ID
		public string ProjectID = "<!--##=PROJ.ProjID##-->";
	
		// Table name
		public string TableName = "<!--##=ew_Quote(TABLE.TblName)##-->";
	<!--## } else { ##-->
	public class c<!--##=sPageObj##--><C, S> : c<!--##=sPageObj##-->_base<C, S>
		where C : cConnection, new()
		where S : cAdvancedSecurity, new()
	{
	<!--## } ##-->
		<!--##
			var sTblFilter = "";
			if (TABLE.TblType == "REPORT") {
				var SRCTABLE = ew_IsNotEmpty(TABLE.TblRptSrc) ? DB.Tables(TABLE.TblRptSrc) : null;
				if (SRCTABLE)
					sTblFilter = SRCTABLE.TblFilter; 
			} else {
				sTblFilter = TABLE.TblFilter;	
			}
		##-->		
		<!--## if (ew_IsNotEmpty(sTblFilter)) { ##-->
		// TblFilter
		public string Get_TblFilter() {
			return <!--##=sTblFilter##-->;
		}
		<!--## } ##-->
		<!--## if (typ != "report" && ew_IsNotEmpty(TABLE.TblBasicSearchDefault)) { ##-->
		// TblBasicSearchDefault
		public string Get_TblBasicSearchDefault() {
			return <!--##=TABLE.TblBasicSearchDefault##-->;		
		}
		<!--## } ##-->
		<!--## if (typ != "report" && ew_IsNotEmpty(sAddReturnPage)) { ##-->
		// TblAddReturnPage
		public string Get_TblAddReturnPage() {
			return <!--##=sAddReturnPage##-->;		
		}
		<!--## } ##-->
		<!--## if (typ != "report" && ew_IsNotEmpty(sEditReturnPage)) { ##-->
		// TblEditReturnPage
		public string Get_TblEditReturnPage() {
			return <!--##=sEditReturnPage##-->;		
		}
		<!--## } ##-->
		
		<!--##
		// Custom properties [type, name]
		if (id != "custom") {
			var arProp = ["FldSelectFilter","FldSearchDefault","FldSearchDefault2","FldEditCustomAttributes",
				"FldViewCustomAttributes","FldTagACustomAttributes","FldAutoUpdateValue","FldDefault",
				"FldTagHiddenValue","FldUploadPath","FldServerValidateArgs","FldTagAPrefix","FldTagASuffix"];		
			for (var i = 0, len = arAllFlds.length; i < len; i++) {
				if (GetFldObj(arAllFlds[i])) {
					for (var j = 0, l = arProp.length; j < l; j++) {
						var p = arProp[j];
						var value = goFld[p];
						if (ew_IsNotEmpty(value)) {
							if (p == "FldUploadPath") {
								value = CheckUploadPath(value);
							} else if (p == "FldTagAPrefix" || p == "FldTagASuffix") {
								if (value == "None")
									continue;
								value = "\"" + value.replace(/<%=/g, "\" + ").replace(/%>/g, " + \"").replace(/CurrentPage\./g, "").replace(/CurrentTable\./g, "") + "\""; 
							}			
		##-->			
		// <!--##=p##--> (<!--##=gsFldParm##-->)
		public object Get_<!--##=gsFldParm##-->_<!--##=p##-->() {
			return <!--##=value##-->;
		}
		<!--##
						}
					}
				}
			}
		}
		##-->
	
		<!--## if (TABLE.TblType != "REPORT") { ##-->
		<!--##~GetServerEvent("Table","Recordset_Selecting","",true)##-->		
		<!--##~GetServerEvent("Table","Recordset_SearchValidated","",true)##-->
		<!--##~GetServerEvent("Table","Recordset_Searching","",true)##-->
		<!--##~GetServerEvent("Table","Row_Selecting","",true)##-->
		<!--##~GetServerEvent("Table","Row_Selected","",true)##-->
			<!--## if (id != "master") { // ASPX ##-->
		<!--##~GetServerEvent("Table","Row_Inserting","",true)##-->
		<!--##~GetServerEvent("Table","Row_Inserted","",true)##-->
		<!--##~GetServerEvent("Table","Row_Updating","",true)##-->
		<!--##~GetServerEvent("Table","Row_Updated","",true)##-->
		<!--##~GetServerEvent("Table","Row_UpdateConflict","",true)##-->
		<!--##~GetServerEvent("Table","Row_Deleting","",true)##-->
		<!--##~GetServerEvent("Table","Row_Deleted","",true)##-->
			<!--## } ##-->	
		<!--##~GetServerEvent("Table","Email_Sending","",true)##-->
		<!--##~GetServerEvent("Table","Lookup_Selecting","",true)##-->
		<!--## } ##-->	
		<!--##~GetServerEvent("Table","Row_Rendering","",true)##-->
		<!--##~GetServerEvent("Table","Row_Rendered","",true)##-->
		<!--##~GetServerEvent("Table","UserID_Filtering","",true)##-->
		
		<!--##~GetServerEvent("Table","Page_Load",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Render",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Unload",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Redirecting",id,true)##-->
		<!--##~GetServerEvent("Table","Message_Showing",id,true)##-->
		<!--##~GetServerEvent("Table","Page_DataRendering",id,true)##-->
		<!--##~GetServerEvent("Table","Page_DataRendered",id,true)##-->
		<!--##~GetServerEvent("Table","Form_CustomValidate",id,true)##-->	
		<!--## if (id == "list" || id == "preview") { ##-->		
		<!--##~GetServerEvent("Table","ListOptions_Load",id,true)##-->
		<!--##~GetServerEvent("Table","ListOptions_Rendered",id,true)##-->
		<!--## } ##-->
		<!--## if (id == "list") { ##-->
		<!--##~GetServerEvent("Table","Row_CustomAction",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Exporting",id,true)##-->
		<!--##~GetServerEvent("Table","Row_Export",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Exported",id,true)##-->
		<!--## } ##-->
		<!--## if (id == "view" || id == "info") { ##-->		
		<!--##~GetServerEvent("Table","Page_Exporting",id,true)##-->
		<!--##~GetServerEvent("Table","Row_Export",id,true)##-->
		<!--##~GetServerEvent("Table","Page_Exported",id,true)##-->
		<!--## } ##-->
			

	}
	
	// <!--##=sPageObj##-->	
	public static c<!--##=sPageObj##--><!--##=sPageObjTypes##--> <!--##=sPageObj##--> {
		get { return (c<!--##=sPageObj##--><!--##=sPageObjTypes##-->)ew_PageData["<!--##=sPageObj##-->"]; }
		set { ew_PageData["<!--##=sPageObj##-->"] = value; }
	}
	
	<!--## if (id != "master" && id != "gridcls") { ##-->
	// CurrentPage
	public static c<!--##=sPageObj##--><!--##=sPageObjTypes##--> CurrentPage {
		get { return (c<!--##=sPageObj##--><!--##=sPageObjTypes##-->)ew_PageData["CurrentPage"]; }
		set { ew_PageData["CurrentPage"] = value; }
	}

	// CurrentTable
	public static c<!--##=sPageObj##--><!--##=sPageObjTypes##--> CurrentTable {
		get { return CurrentPage; }
		set { CurrentPage = value; }
	}
	<!--## } ##-->
<!--##/session##-->

<!--##session otherpageclass##-->
<!--##
	var id = CTRL.CtrlID;
##-->
	//
	// Page class (<!--##=id##-->)
	//
	public class c<!--##=sPageObj##--><C, S> : c<!--##=sPageObj##-->_base<C, S>
		where C : cConnection, new()
		where S : cAdvancedSecurity, new()
	{
		<!--## if (id == "register" && ew_IsNotEmpty(sRegisterReturnPage)) { ##-->
		// RegisterReturnPage
		public string Get_RegisterReturnPage() {
			return <!--##=sRegisterReturnPage##-->;		
		}
		<!--## } ##-->
	
		//
		// Server events
		//
		<!--##~GetServerEvent("Other","Page_Load",id,true)##-->
		<!--##~GetServerEvent("Other","Page_Unload",id,true)##-->
		<!--##~GetServerEvent("Other","Page_Redirecting",id,true)##-->
	<!--## if (ew_InArray(id, ["login", "register", "forgotpwd", "changepwd", "logout"]) > -1) { ##-->		
		<!--##~GetServerEvent("Other","Message_Showing",id,true)##-->
	<!--## } ##-->
	<!--## if (ew_InArray(id, ["login", "register", "forgotpwd", "changepwd"]) > -1) { ##-->		
		<!--##~GetServerEvent("Other","Page_DataRendered",id,true)##-->
		<!--##~GetServerEvent("Other","Page_DataRendering",id,true)##-->
		<!--##~GetServerEvent("Other","Form_CustomValidate",id,true)##-->
	<!--## } ##-->
	<!--## if (ew_InArray(id, ["register", "forgotpwd", "changepwd"]) > -1) { ##-->
		<!--##~GetServerEvent("Other","Email_Sending",id,true)##-->		
	<!--## } ##-->
	<!--## if (id == "login") { ##-->
		<!--##~GetServerEvent("Other","User_LoggingIn",id,true)##-->
		<!--##~GetServerEvent("Other","User_LoggedIn",id,true)##-->
		<!--##~GetServerEvent("Other","User_LoginError",id,true)##-->		
	<!--## } ##-->
	<!--## if (id == "logout") { ##-->
		<!--##~GetServerEvent("Other","User_LoggingOut",id,true)##-->
		<!--##~GetServerEvent("Other","User_LoggedOut",id,true)##-->		
	<!--## } ##-->
	<!--## if (id == "register") { ##-->
		<!--##~GetServerEvent("Other","User_Registered",id,true)##-->
		<!--##~GetServerEvent("Other","User_Activated",id,true)##-->		
	<!--## } ##-->
	<!--## if (id == "changepwd") { ##-->
		<!--##~GetServerEvent("Other","User_ChangePassword",id,true)##-->			
	<!--## } ##-->
	<!--## if (id == "forgotpwd") { ##-->
		<!--##~GetServerEvent("Other","User_RecoverPassword",id,true)##-->			
	<!--## } ##-->
	}
	
	// <!--##=sPageObj##-->
	public static c<!--##=sPageObj##--><cConnection, cAdvancedSecurity> <!--##=sPageObj##--> {
		get { return (c<!--##=sPageObj##--><cConnection, cAdvancedSecurity>)ew_PageData["<!--##=sPageObj##-->"]; }
		set { ew_PageData["<!--##=sPageObj##-->"] = value; }
	}
	
	// CurrentPage
	public static c<!--##=sPageObj##--><cConnection, cAdvancedSecurity> CurrentPage {
		get { return (c<!--##=sPageObj##--><cConnection, cAdvancedSecurity>)ew_PageData["CurrentPage"]; }
		set { ew_PageData["CurrentPage"] = value; }
	}

	// CurrentTable
	public static c<!--##=sPageObj##--><cConnection, cAdvancedSecurity> CurrentTable {
		get { return CurrentPage; }
		set { CurrentPage = value; }
	}
<!--##/session##-->