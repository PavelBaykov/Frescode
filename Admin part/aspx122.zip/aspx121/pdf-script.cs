<!--##session pdfclass##-->
	//
	// Class for export to PDF
	//
	public class cExportPdf: cExportBase {
	
		// Constructor
		public cExportPdf(cTable tbl, string style): base(tbl, style) {}
	
		// Export
		public override void Export() {
			ew_Write(Text);
		}
	
	}
<!--##/session##-->