<!--##session js_local_begin##-->
<script type="text/javascript">
// Page object
var <!--##=sPageObj##--> = new ew_Page("<!--##=sPageObj##-->");
<!--##=sPageObj##-->.PageID = "<!--##=CTRL.CtrlID##-->"; // Page ID
var EW_PAGE_ID = <!--##=sPageObj##-->.PageID; // For backward compatibility

<!--##
	// Submit form
	sId = CTRL.CtrlID.toLowerCase();
##-->

// Form object
var <!--##=sFormName##--> = new ew_Form("<!--##=sFormName##-->");

<!--## if (sId == "list" || sId == "grid") { ##-->
<!--##=sFormName##-->.FormKeyCountName = '@<!--##=sPageObj##-->.FormKeyCountName';
<!--## } ##-->

<!--##
	if (((bInlineEdit || bInlineAdd || bInlineCopy || bGridEdit || bGridAdd) && sId == "list") ||
	sId == "grid" || sId == "add" || sId == "edit" || sId == "update" || sId == "register" || sId == "addopt") {
##-->
// Validate form
<!--##=sFormName##-->.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	this.PostAutoSuggest();	
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	
	<!--## if (sId == "update") { ##-->
	if (!ew_UpdateSelected(fobj)) {
		alert(ewLanguage.Phrase("NoFieldSelected"));
		return false;
	}
	<!--## } ##-->
	
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";

	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
	<!--##
		if ((sId == "list" && bGridAdd) || sId == "grid") {
	##-->
		var checkrow = (gridinsert) ? !this.EmptyRow(infix) : true;
		if (checkrow) {
			addcnt++;
	<!--##
		}

		for (var i = 0; i < nFldCount; i++) {
			if (GetFldObj(arFlds[i])) {

				// Required field
				if (IsRequiredField(goFld)) {
	##-->
		<!--##~SYSTEMFUNCTIONS.JsReqValidator()##-->
	<!--##
				}

				// Text validation
				if (IsValidateText(goFld)) {
	##-->
		<!--##~SYSTEMFUNCTIONS.JsValidator()##-->
	<!--##
				}
			}
		} // Field

		if (TABLE.TblName == DB.UserLevelTbl && bDynamicUserLevel) {
			sUserLevelIDFldVar = goTblFlds.Fields[DB.UserLevelIdFld].FldVar;
			sUserLevelNameFldVar = goTblFlds.Fields[DB.UserLevelNameFld].FldVar;
	##-->
		var elId = fobj.elements["x" + infix + "<!--##=sUserLevelIDFldVar.substr(1)##-->"];
		var elName = fobj.elements["x" + infix + "<!--##=sUserLevelNameFldVar.substr(1)##-->"];
		if (elId && elName) {
			elId.value = $.trim(elId.value);
			elName.value = $.trim(elName.value);
			if (elId && !ew_CheckInteger(elId.value))
				return this.OnError(elId, ewLanguage.Phrase("UserLevelIDInteger"));
			var level = parseInt(elId.value, 10);
			if (level == 0) {
				if (!ew_SameText(elName.value, "default"))
					return this.OnError(elName, ewLanguage.Phrase("UserLevelDefaultName"));
			} else if (level == -1) {
				if (!ew_SameText(elName.value, "administrator"))
					return this.OnError(elName, ewLanguage.Phrase("UserLevelAdministratorName"));
			} else if (level < -1) {
				return this.OnError(elId, ewLanguage.Phrase("UserLevelIDIncorrect"));
			} else if (level > 0) { 
				if (ew_SameText(elName.value, "administrator") || ew_SameText(elName.value, "default"))
					return this.OnError(elName, ewLanguage.Phrase("UserLevelNameIncorrect"));
			}
		}
	<!--##
		}

		if (SYSTEMFUNCTIONS.ClientScriptExist(sCtrlType, "Form_CustomValidate")) {
	##-->
		// Set up row object
		ew_ElementsToRow(fobj);
		
		// Fire Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
	<!--##
		}

		if ((sId == "list" && bGridAdd) || sId == "grid") {
	##-->
		} // End Grid Add checking
	<!--##
		}
	##--> 
	}

	<!--## if (sId == "add" || sId == "edit" || sId == "register") { // ASPX ##-->
<!--## if (PROJ.ProgramLanguage == "C#") { // ASPX ##-->
<!--##include captcha-script.cshtml/aspxcaptcha_js##-->
<!--## } else { ##-->
<!--##include captcha-script.vbhtml/aspxcaptcha_js##-->
<!--## } ##-->
	<!--## } ##-->

	<!--##
		if (sId == "list" && bGridAdd) {
	##-->
	if (gridinsert && addcnt == 0) { // No row added
		alert(ewLanguage.Phrase("NoAddRecord"));
		return false;
	}
	<!--##
		}
	##-->

	<!--##
		if (sId == "add" || sId == "edit") {
	##-->
	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ewForms[val])
			if (!ewForms[val].Validate())
				return false;
	}
	<!--##
		}
	##-->

	return true;
}

<!--##
	}
##-->

<!--##
	if ((sId == "list" && bGridAdd) || sId == "grid") {
##-->
// Check empty row
<!--##=sFormName##-->.EmptyRow = function(infix) {
	var fobj = this.Form;
	<!--##
		for (var i = 0; i < nFldCount; i++) {
			if (GetFldObj(arFlds[i])) {
				if (!goFld.FldAutoIncrement && ew_IsEmpty(goFld.FldAutoUpdateValue)) {
					var sFieldType = (SYSTEMFUNCTIONS.IsBoolFld()) ? "true" : "false";
	##-->
	if (ew_ValueChanged(fobj, infix, "<!--##=ew_AddSquareBrackets(gsFldParm, goFld)##-->", <!--##=sFieldType##-->)) return false;
	<!--##				
				}
			}
		}
	##-->
	return true;
}
<!--##
	}
##-->

<!--## if (SYSTEMFUNCTIONS.ClientScriptExist(sCtrlType, "Form_CustomValidate")) { ##-->
// Form_CustomValidate event
<!--##=sFormName##-->.Form_CustomValidate = <!--##~SYSTEMFUNCTIONS.GetClientScript(sCtrlType, "Form_CustomValidate")##-->
<!--## } ##-->

// Use JavaScript validation or not
<!--## if (PROJ.ProgramLanguage == "C#") { // ASPX ##-->
<!--##=sFormName##-->.ValidateRequired = @((EW_CLIENT_VALIDATE) ? "true" : "false");
<!--## } else { ##-->
<!--##=sFormName##-->.ValidateRequired = @(If(EW_CLIENT_VALIDATE, "true", "false"));
<!--## } ##-->

<!--##
	if (SYSTEMFUNCTIONS.IsMultiPage()) {
##-->
// Multi-Page properties
<!--##=sFormName##-->.MultiPage = new ew_MultiPage("<!--##=sFormName##-->",
	<!--##
		// Multi-Page elements
		var arEl = [];
		for (var i = 0; i < nFldCount; i++) {
			if (GetFldObj(arFlds[i])) {				
				if (goFld.FldHtmlTag != "HIDDEN" && ew_IsEmpty(goFld.FldAutoUpdateValue)) {
					arEl[arEl.length] = [gsFldVar, glFldPageIndex];
					if (CTRL.CtrlID == "register" && TABLE.TblName == PROJ.SecTbl && goFld.FldName == PROJ.SecPasswdFld) {
						gsFldVar = "c_" + gsFldParm;
						arEl[arEl.length] = [gsFldVar, glFldPageIndex];
					}
				}
			}
		}
	##-->
	<!--##=JSON.stringify(arEl)##-->
);
<!--##
	}
##-->


// Dynamic selection lists
<!--##
	for (var i = 0; i < nFldCount; i++) {
		if (GetFldObj(arFlds[i])) {
			if (goFld.FldIsLookup) {
##-->
<!--##=sFormName##-->.Lists["<!--##=ew_AddSquareBrackets(gsFldVar, goFld)##-->"] = <!--##=SYSTEMFUNCTIONS.SelectionList(sId)##-->;
<!--##
			}
		}
	}
##-->

// Form object for search
<!--## if ((bBasicSearch || bExtendedBasicSearch || bAdvancedSearch) && sId == "list") { ##-->
var <!--##=sFormNameSearch##--> = new ew_Form("<!--##=sFormNameSearch##-->");
<!--## } ##-->

<!--## if (sId == "search" || (bExtendedBasicSearch && sId == "list")) { ##-->

// Validate function for search
<!--##=sFormNameSearch##-->.Validate = function(fobj) {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	fobj = fobj || this.Form;
	this.PostAutoSuggest();
	var infix = "";
	<!--##
		for (var i = 0; i < nAllFldCount; i++) {
			if (GetFldObj(arAllFlds[i])) {
				if (IsValidateSearch(goFld)) {
	##-->
	<!--##~SYSTEMFUNCTIONS.JsValidator()##-->
	<!--##
				}
			}
		}

		if (SYSTEMFUNCTIONS.ClientScriptExist(sCtrlType, "Form_CustomValidate")) {
	##-->
	// Set up row object
	ew_ElementsToRow(fobj);
		
	// Fire Form_CustomValidate event
	if (!this.Form_CustomValidate(fobj))
		return false;
	<!--##
		}
	##-->
	return true;
}
<!--## } ##-->

<!--##
	if (bExtendedBasicSearch && sId == "list") {
##-->

<!--## if (SYSTEMFUNCTIONS.ClientScriptExist(sCtrlType, "Form_CustomValidate")) { ##-->
// Form_CustomValidate event
<!--##=sFormNameSearch##-->.Form_CustomValidate = <!--##~SYSTEMFUNCTIONS.GetClientScript(sCtrlType, "Form_CustomValidate")##-->
<!--## } ##-->

// Use JavaScript validation or not
<!--## if (PROJ.ProgramLanguage == "C#") { // ASPX ##-->
<!--##=sFormNameSearch##-->.ValidateRequired = @((EW_CLIENT_VALIDATE) ? "true" : "false");
<!--## } else { ##-->
<!--##=sFormNameSearch##-->.ValidateRequired = @(If(EW_CLIENT_VALIDATE, "true", "false"));
<!--## } ##-->

// Dynamic selection lists
<!--##
	for (var i = 0; i < nAllFldCount; i++) {
		if (GetFldObj(arAllFlds[i]) && IsFldExtendedSearch(goFld)) {
			if (goFld.FldGenerate && goFld.FldSelectType == "Table" &&
				ew_IsNotEmpty(goFld.FldTagLnkTbl) && ew_IsNotEmpty(goFld.FldTagLnkFld) && ew_IsNotEmpty(goFld.FldTagLnkDisplay) &&
				ew_InArray(goFld.FldHtmlTag, ["TEXT", "SELECT", "RADIO", "CHECKBOX"]) > -1) {
##-->
<!--##=sFormNameSearch##-->.Lists["<!--##=ew_AddSquareBrackets(gsFldVar, goFld)##-->"] = <!--##=SYSTEMFUNCTIONS.SelectionList("extbs")##-->;
<!--##
			}
		}
	}
##-->

<!--##
	}
##-->

<!--## if ((bBasicSearch || bExtendedBasicSearch || bAdvancedSearch) && sId == "list" && PROJ.GetV("SearchPanelCollapsed") && !bShowBlankListPage) { ##-->
// Init search panel as collapsed
if (<!--##=sFormNameSearch##-->) <!--##=sFormNameSearch##-->.InitSearchPanel = true;
<!--## } ##-->

<!--##/session##-->


<!--##session js_local_end##-->
</script>
<!--##/session##-->
