<!--##session eventcode##-->
<!--## for (var i = 0; i < arNameSpace.length; i++) { ##-->
using <!--##=arNameSpace[i]##-->;
<!--## } ##-->

//
// ASP.NET Maker 12 Project Class
//
public partial class <!--##=sProjClassName##--> : <!--##=sProjClassName##-->_base {

	//
	// Global user code
	//
	<!--##~GetServerEvent("Global","Global Code")##-->
	
	
	//
	// Global events
	//
	<!--##~GetServerEvent("Global","Page_Loading","",true)##-->
	<!--##~GetServerEvent("Global","Page_Rendering")##-->
	<!--##~GetServerEvent("Global","Page_Unloaded","",true)##-->	
	
	//
	// Connection
	//
	public class cConnection : cConnectionBase {
	
		// Constructor
		public cConnection(string ConnStr) : base(ConnStr)
		{
		}
		
		// Constructor
		public cConnection() : base()
		{	
		}
	
		<!--##~GetServerEvent("Global","Database_Connecting","",true)##-->
		<!--##~GetServerEvent("Global","Database_Connected","",true)##-->
	}
	
	// Execute SQL
	public static int ew_Execute(string Sql)
	{
		using (var c = new cConnection()) { 
			return c.ExecuteNonQuery(Sql);
		}
	}
	
	// Execute SQL and return first value of first row
	public static object ew_ExecuteScalar(string Sql)
	{
		using (var c = new cConnection()) {
			return c.ExecuteScalar(Sql);
		}
	}
	
	// Execute SQL and return first value of first row as string
	// for use with As<TValue>, As<TValue>(String, TValue) and Is<TValue>
	public static string ew_ExecuteValue(string Sql)
	{
		using (var c = new cConnection()) {
			return Convert.ToString(c.ExecuteScalar(Sql));
		}
	}
	
	// Execute SQL and return first row as OrderedDictionary
	public static OrderedDictionary ew_ExecuteRow(string Sql)
	{
		using (var c = new cConnection()) {
			return c.GetRow(Sql);
		}
	}
	
	// Execute SQL and return List<OrderedDictionary>
	public static List<OrderedDictionary> ew_ExecuteRows(string Sql)
	{
		using (var c = new cConnection()) {
			return c.GetRows(Sql);
		}
	}
	
	// Executes the query, and returns the row(s) as JSON
	public static string ew_ExecuteJson(string Sql, bool FirstOnly = true)
	{
		using (var c = new cConnection()) {
			if (FirstOnly) {
				var list = new List<OrderedDictionary>();
				list.Add(c.GetRow(Sql));
				return JsonConvert.SerializeObject(list);
			} else {
				return JsonConvert.SerializeObject(c.GetRows(Sql));
			}
		}
	}
	
	// Execute SQL and return first row
	public static DbDataRecord ew_ExecuteRecord(string Sql)
	{
		using (var c = new cConnection()) {
			return c.GetRecord(Sql);
		}
	}
	
	// Execute SQL and return List<DbDataRecord>
	public static List<DbDataRecord> ew_ExecuteRecords(string Sql)
	{
		using (var c = new cConnection()) {
			return c.GetRecords(Sql);
		}
	}	
	
	//
	// Advanced Security
	//
	public class cAdvancedSecurity : cAdvancedSecurityBase {
	
		public cConnection Conn;
	
		public cAdvancedSecurity() : base((ew_PageData["Conn"] is cConnection) ? (cConnection)ew_PageData["Conn"] : new cConnection()) {		
		}
			
		<!--##~GetServerEvent("Global","UserID_Loading","",true)##-->
		<!--##~GetServerEvent("Global","UserID_Loaded","",true)##-->
		<!--##~GetServerEvent("Global","UserLevel_Loaded","",true)##-->
		<!--##~GetServerEvent("Global","TablePermission_Loading","",true)##-->
		<!--##~GetServerEvent("Global","TablePermission_Loaded","",true)##-->
		<!--##~GetServerEvent("Global","User_CustomValidate","",true)##-->
		<!--##~GetServerEvent("Global","User_Validated","",true)##-->
		<!--##~GetServerEvent("Global","User_PasswordExpired","",true)##-->
	}
	
	//
	// Menu
	//
	public class cMenu : cMenuBase {
	
		public cMenu(object MenuId, bool Mobile = false) : base(MenuId, Mobile) {
		}
		
		public override string Render(bool ret = false) {
			var m = this;
			if (IsRoot)
				Menu_Rendering(ref m);
			return base.Render(ret);
		}
		
		<!--##~GetServerEvent("Global","MenuItem_Adding","",true)##-->
		<!--##~GetServerEvent("Global","Menu_Rendering","",false)##-->
	}	

}	
<!--##/session##-->