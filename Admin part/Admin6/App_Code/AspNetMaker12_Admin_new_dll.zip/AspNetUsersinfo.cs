using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET Maker 12 Project Class (Table)
//
public partial class AspNetMaker12_Admin_new_base : WebPage {

	// AspNetUsers
	public static cAspNetUsers AspNetUsers {
		get { return (cAspNetUsers)ew_PageData["AspNetUsers"]; }
		set { ew_PageData["AspNetUsers"] = value; }
	}

	//
	// Table class for AspNetUsers
	//
	public class cAspNetUsers: cTable {

		public cField Id;

		public cField FirstName;

		public cField LastName;

		public cField UserRole;

		public cField DateCreated;

		public cField zEmail;

		public cField EmailConfirmed;

		public cField PasswordHash;

		public cField SecurityStamp;

		public cField PhoneNumber;

		public cField PhoneNumberConfirmed;

		public cField TwoFactorEnabled;

		public cField LockoutEndDateUtc;

		public cField LockoutEnabled;

		public cField AccessFailedCount;

		public cField UserName;

		public cField CreatedBy_Id;

		public cField Customer_Id;

		public int RowCnt = 0; // ASPX

		//
		// Table class constructor
		//
		public cAspNetUsers() {

			// Language object // ASPX
			if (Language == null)
				Language = new cLanguage();
			TableVar = "AspNetUsers";
			TableName = "AspNetUsers";
			TableType = "TABLE";
			ExportAll = true;
			ExportPageBreakCount = 0; // Page break per every n record (PDF only)
			ExportPageOrientation = "portrait"; // Page orientation (PDF only)
			ExportPageSize = "a4"; // Page size (PDF only)
			ExportColumnWidths = new float[] {  }; // Column widths (PDF only) // ASPX
			DetailAdd = false; // Allow detail add
			DetailEdit = false; // Allow detail edit
			DetailView = false; // Allow detail view
			ShowMultipleDetails = false; // Show multiple details
			GridAddRowCount = 5;
			AllowAddDeleteRow = ew_AllowAddDeleteRow(); // Allow add/delete row
			UserIDAllowSecurity = 0; // User ID Allow
			BasicSearch = new cBasicSearch(TableVar);

			// Id
			Id = new cField("AspNetUsers", "AspNetUsers", "x_Id", "Id", "[Id]", "[Id]", 202, SqlDbType.NVarChar, -1, false, "[Id]", false, false, false, "FORMATTED TEXT");
			Fields.Add("Id", Id);

			// FirstName
			FirstName = new cField("AspNetUsers", "AspNetUsers", "x_FirstName", "FirstName", "[FirstName]", "[FirstName]", 203, SqlDbType.NText, -1, false, "[FirstName]", false, false, false, "FORMATTED TEXT");
			Fields.Add("FirstName", FirstName);

			// LastName
			LastName = new cField("AspNetUsers", "AspNetUsers", "x_LastName", "LastName", "[LastName]", "[LastName]", 203, SqlDbType.NText, -1, false, "[LastName]", false, false, false, "FORMATTED TEXT");
			Fields.Add("LastName", LastName);

			// UserRole
			UserRole = new cField("AspNetUsers", "AspNetUsers", "x_UserRole", "UserRole", "[UserRole]", "CAST([UserRole] AS NVARCHAR)", 3, SqlDbType.Int, -1, false, "[UserRole]", false, false, false, "FORMATTED TEXT");
			UserRole.FldDefaultErrMsg = Language.Phrase("IncorrectInteger");
			Fields.Add("UserRole", UserRole);

			// DateCreated
			DateCreated = new cField("AspNetUsers", "AspNetUsers", "x_DateCreated", "DateCreated", "[DateCreated]", "", 135, SqlDbType.DateTime, -1, false, "[DateCreated]", false, false, false, "FORMATTED TEXT");
			Fields.Add("DateCreated", DateCreated);

			// zEmail
			zEmail = new cField("AspNetUsers", "AspNetUsers", "x_zEmail", "Email", "[Email]", "[Email]", 202, SqlDbType.NVarChar, -1, false, "[Email]", false, false, false, "FORMATTED TEXT");
			Fields.Add("Email", zEmail);

			// EmailConfirmed
			EmailConfirmed = new cField("AspNetUsers", "AspNetUsers", "x_EmailConfirmed", "EmailConfirmed", "[EmailConfirmed]", "[EmailConfirmed]", 11, SqlDbType.Bit, -1, false, "[EmailConfirmed]", false, false, false, "FORMATTED TEXT");
			EmailConfirmed.FldDataType = EW_DATATYPE_BOOLEAN;
			Fields.Add("EmailConfirmed", EmailConfirmed);

			// PasswordHash
			PasswordHash = new cField("AspNetUsers", "AspNetUsers", "x_PasswordHash", "PasswordHash", "[PasswordHash]", "[PasswordHash]", 203, SqlDbType.NText, -1, false, "[PasswordHash]", false, false, false, "FORMATTED TEXT");
			Fields.Add("PasswordHash", PasswordHash);

			// SecurityStamp
			SecurityStamp = new cField("AspNetUsers", "AspNetUsers", "x_SecurityStamp", "SecurityStamp", "[SecurityStamp]", "[SecurityStamp]", 203, SqlDbType.NText, -1, false, "[SecurityStamp]", false, false, false, "FORMATTED TEXT");
			Fields.Add("SecurityStamp", SecurityStamp);

			// PhoneNumber
			PhoneNumber = new cField("AspNetUsers", "AspNetUsers", "x_PhoneNumber", "PhoneNumber", "[PhoneNumber]", "[PhoneNumber]", 203, SqlDbType.NText, -1, false, "[PhoneNumber]", false, false, false, "FORMATTED TEXT");
			Fields.Add("PhoneNumber", PhoneNumber);

			// PhoneNumberConfirmed
			PhoneNumberConfirmed = new cField("AspNetUsers", "AspNetUsers", "x_PhoneNumberConfirmed", "PhoneNumberConfirmed", "[PhoneNumberConfirmed]", "[PhoneNumberConfirmed]", 11, SqlDbType.Bit, -1, false, "[PhoneNumberConfirmed]", false, false, false, "FORMATTED TEXT");
			PhoneNumberConfirmed.FldDataType = EW_DATATYPE_BOOLEAN;
			Fields.Add("PhoneNumberConfirmed", PhoneNumberConfirmed);

			// TwoFactorEnabled
			TwoFactorEnabled = new cField("AspNetUsers", "AspNetUsers", "x_TwoFactorEnabled", "TwoFactorEnabled", "[TwoFactorEnabled]", "[TwoFactorEnabled]", 11, SqlDbType.Bit, -1, false, "[TwoFactorEnabled]", false, false, false, "FORMATTED TEXT");
			TwoFactorEnabled.FldDataType = EW_DATATYPE_BOOLEAN;
			Fields.Add("TwoFactorEnabled", TwoFactorEnabled);

			// LockoutEndDateUtc
			LockoutEndDateUtc = new cField("AspNetUsers", "AspNetUsers", "x_LockoutEndDateUtc", "LockoutEndDateUtc", "[LockoutEndDateUtc]", "", 135, SqlDbType.DateTime, -1, false, "[LockoutEndDateUtc]", false, false, false, "FORMATTED TEXT");
			Fields.Add("LockoutEndDateUtc", LockoutEndDateUtc);

			// LockoutEnabled
			LockoutEnabled = new cField("AspNetUsers", "AspNetUsers", "x_LockoutEnabled", "LockoutEnabled", "[LockoutEnabled]", "[LockoutEnabled]", 11, SqlDbType.Bit, -1, false, "[LockoutEnabled]", false, false, false, "FORMATTED TEXT");
			LockoutEnabled.FldDataType = EW_DATATYPE_BOOLEAN;
			Fields.Add("LockoutEnabled", LockoutEnabled);

			// AccessFailedCount
			AccessFailedCount = new cField("AspNetUsers", "AspNetUsers", "x_AccessFailedCount", "AccessFailedCount", "[AccessFailedCount]", "CAST([AccessFailedCount] AS NVARCHAR)", 3, SqlDbType.Int, -1, false, "[AccessFailedCount]", false, false, false, "FORMATTED TEXT");
			AccessFailedCount.FldDefaultErrMsg = Language.Phrase("IncorrectInteger");
			Fields.Add("AccessFailedCount", AccessFailedCount);

			// UserName
			UserName = new cField("AspNetUsers", "AspNetUsers", "x_UserName", "UserName", "[UserName]", "[UserName]", 202, SqlDbType.NVarChar, -1, false, "[UserName]", false, false, false, "FORMATTED TEXT");
			Fields.Add("UserName", UserName);

			// CreatedBy_Id
			CreatedBy_Id = new cField("AspNetUsers", "AspNetUsers", "x_CreatedBy_Id", "CreatedBy_Id", "[CreatedBy_Id]", "[CreatedBy_Id]", 202, SqlDbType.NVarChar, -1, false, "[CreatedBy_Id]", false, false, false, "FORMATTED TEXT");
			Fields.Add("CreatedBy_Id", CreatedBy_Id);

			// Customer_Id
			Customer_Id = new cField("AspNetUsers", "AspNetUsers", "x_Customer_Id", "Customer_Id", "[Customer_Id]", "CAST([Customer_Id] AS NVARCHAR)", 3, SqlDbType.Int, -1, false, "[Customer_Id]", false, false, false, "FORMATTED TEXT");
			Customer_Id.FldDefaultErrMsg = Language.Phrase("IncorrectInteger");
			Fields.Add("Customer_Id", Customer_Id);
		}		

		// Invoke method of table class and subclasses // ASPX
		public object Invoke(string name, object[] parameters = null) {
			MethodInfo mi = this.GetType().GetMethod(name);
			if (mi != null)
				return mi.Invoke(this, parameters);
			return null;
		}		

		// Get custom property value  // ASPX
		public object GetCustomValue(string PropName, string FldName = "") {
			var name = "Get_";
			if (FldName != "")
				name += FldName + "_";
			name += PropName;			
			return Invoke(name);
		}

		// Single column sort
		public void UpdateSort(cField ofld) {
			string sLastSort, sSortField, sThisSort;
			if (CurrentOrder == ofld.FldName) {
				sSortField = ofld.FldExpression;
				sLastSort = ofld.Sort;
				if (CurrentOrderType == "ASC" || CurrentOrderType == "DESC") {
					sThisSort = CurrentOrderType;
				} else {
					sThisSort = (sLastSort == "ASC") ? "DESC" : "ASC"; 
				}
				ofld.Sort = sThisSort;
				SessionOrderBy = sSortField + " " + sThisSort;	// Save to Session
			} else {
				ofld.Sort = "";
			}
		}

		// Table level SQL
		// FROM
		private string _SqlFrom = "";

		public string SqlFrom {
			get { return ew_NotEmpty(_SqlFrom) ? _SqlFrom : "[dbo].[AspNetUsers]"; }
			set { _SqlFrom = value; }
		}

		// SELECT
		private string _SqlSelect = "";

		public string SqlSelect { // Select
			get { return ew_NotEmpty(_SqlSelect) ? _SqlSelect : "SELECT * FROM " + SqlFrom; }
			set { _SqlSelect = value; }
		}

		// WHERE // ASPX
		private string _SqlWhere = "";

		public string SqlWhere {
			get {
				string sWhere = "";
				return ew_NotEmpty(_SqlWhere) ? _SqlWhere : sWhere;
			}
			set { _SqlWhere = value; }		
		}

		// Group By
		private string _SqlGroupBy = "";

		public string SqlGroupBy {
			get { return ew_NotEmpty(_SqlGroupBy) ? _SqlGroupBy : ""; }
			set { _SqlGroupBy = value; }
		}

		// Having
		private string _SqlHaving = "";

		public string SqlHaving {
			get { return ew_NotEmpty(_SqlHaving) ? _SqlHaving : ""; }
			set { _SqlHaving = value; }
		}

		// Order By
		private string _SqlOrderBy = "";

		public string SqlOrderBy {
			get { return ew_NotEmpty(_SqlOrderBy) ? _SqlOrderBy : ""; }
			set { _SqlOrderBy = value; }
		}

		// Check if Anonymous User is allowed
	  	public virtual bool AllowAnonymousUser() {
			switch (CurrentPageID()) {
				case "add":
				case "register":
				case "addopt":
					return false;
				case "edit":
				case "update":
					return false;
				case "delete":
					return false;
				case "view":
					return false;
				case "search":
					return false;
				default:
					return false;
			}
		}

		// Apply User ID filters
		public string ApplyUserIDFilters(string Filter) {
			string sFilter = Filter;
			return sFilter;
		}

		// Check if User ID security allows view all
		public bool UserIDAllow(string id = "") {
			int allow = EW_USER_ID_ALLOW;
			switch (id) {
				case "add":
				case "copy":
				case "gridadd":
				case "register":
				case "addopt":
					return ((allow & 1) == 1);
				case "edit":
				case "gridedit":
				case "update":
				case "changepwd":
				case "forgotpwd":
					return ((allow & 4) == 4);
				case "delete":
					return ((allow & 2) == 2);
				case "view":
					return ((allow & 32) == 32);
				case "search":
					return ((allow & 64) == 64);
				default:
					return ((allow & 8) == 8);
			}
		}

		// Get SQL
		public string GetSQL(string where, string orderby = "") {
			return ew_BuildSelectSql(SqlSelect, SqlWhere, SqlGroupBy, SqlHaving, SqlOrderBy, where, orderby);
		}

		// Table SQL
		public string SQL {
			get {
				string sFilter = CurrentFilter;
				string sSort = SessionOrderBy;
				return ew_BuildSelectSql(SqlSelect, SqlWhere, SqlGroupBy, SqlHaving, SqlOrderBy, sFilter, sSort);
			}
		}

		// Table SQL with List page filter
		public string SelectSQL {
			get {
				string sSort = "";
				string sFilter = SessionWhere;
				ew_AddFilter(ref sFilter, CurrentFilter);
				Recordset_Selecting(ref sFilter);
				sSort = SessionOrderBy;
				return ew_BuildSelectSql(SqlSelect, SqlWhere, SqlGroupBy, SqlHaving, SqlOrderBy, sFilter, sSort);
			}
		}

		// Get ORDER BY clause
		public string OrderBy {
			get {
				string sSort = SessionOrderBy;
				return ew_BuildSelectSql("", "", "", "", SqlOrderBy, "", sSort);
			}
		}

		// Return SQL for record count
		public string SelectCountSQL {
			get {			
				if (TableType == "TABLE" || TableType == "VIEW") {
					return "SELECT COUNT(*) FROM" + Regex.Replace(SelectSQL, @"^SELECT\s([\s\S]+)?\*\sFROM", "", RegexOptions.IgnoreCase);
				} else {
					return "SELECT COUNT(*) FROM (" + SelectSQL + ")";
				}				
			}
		}

		// Update Table
		public string UpdateTable = "[dbo].[AspNetUsers]";

		// Insert
		public int Insert(OrderedDictionary rs) {
			string names = "";
			string values = "";
			cField fld;
			foreach (DictionaryEntry f in rs) {
				fld = FieldByName((string)f.Key);
				if (fld != null) {
					names += fld.FldExpression + ",";
					values += SqlParameter(ref fld) + ",";
				}
			}
			if (names.EndsWith(",")) names = names.Remove(names.Length - 1); 
			if (values.EndsWith(",")) values = values.Remove(values.Length - 1); 
			if (ew_Empty(names)) return -1;
			string Sql = "INSERT INTO " + UpdateTable + " (" + names + ") VALUES (" + values + ")";
			if (EW_DEBUG_ENABLED)
				ew_SetDebugMsg(Sql);
			var command = Conn.GetCommand(Sql);
			foreach (DictionaryEntry f in rs) {
				fld = FieldByName((string)f.Key);
				if (fld == null)
					continue;
				try {
					command.Parameters.Add(fld.FldVar, fld.FldDbType).Value = ParameterValue(ref fld, f.Value);
				} catch {
					if (EW_DEBUG_ENABLED) throw;
				}
			}
			return command.ExecuteNonQuery();
		}		

		// Update
		public int Update(OrderedDictionary rs, string where = "", OrderedDictionary rsold = null) {
			var bCascadeUpdate = false;
			var rscascade = new OrderedDictionary();
			var values = "";
			foreach (DictionaryEntry f in rs) {
				var fld = FieldByName((string)f.Key);
				if (fld != null)
					values += fld.FldExpression + "=" + SqlParameter(ref fld) + ",";
			}
			if (values.EndsWith(","))
				values = values.Remove(values.Length - 1); 
			if (ew_Empty(values))
				return -1; 
			string Sql = "UPDATE " + UpdateTable + " SET " + values;
			string filter = CurrentFilter;
			ew_AddFilter(ref filter, where);
			if (ew_NotEmpty(filter))
				Sql += " WHERE " + filter;
			if (EW_DEBUG_ENABLED)
				ew_SetDebugMsg(Sql); 
			var command = Conn.GetCommand(Sql);
			foreach (DictionaryEntry f in rs) {
				var fld = FieldByName((string)f.Key);
				if (fld == null)
					continue;
				try {
					command.Parameters.Add(fld.FldVar, fld.FldDbType).Value = ParameterValue(ref fld, f.Value);
				} catch {
					if (EW_DEBUG_ENABLED) throw;
				}
			}
			return command.ExecuteNonQuery();
		}

		// Convert to parameter name for use in SQL
		public string SqlParameter(ref cField fld) {
			string sValue = EW_DB_SQLPARAM_SYMBOL;
			if (EW_DB_SQLPARAM_SYMBOL != "?")
				sValue += fld.FldVar;
			return sValue;
		}

		// Convert value to object for parameter
		public object ParameterValue(ref cField fld, object value) {
			return value;	
		}

		// Delete
		public int Delete(OrderedDictionary rs, string where = "") {
			string Sql = "DELETE FROM " + UpdateTable + " WHERE ";
			string filter = CurrentFilter;
			ew_AddFilter(ref filter, where);
			if (rs != null) {
				cField fld; 
				fld = FieldByName("Id");				
				ew_AddFilter(ref filter, fld.FldExpression + "=" + ew_QuotedValue(rs["Id"], fld.FldDataType));			
			}
			if (ew_NotEmpty(filter))
				Sql += filter;
			else
				Sql += "0=1"; // Avoid delete
			if (EW_DEBUG_ENABLED)
				ew_SetDebugMsg(Sql); 
			return Conn.Execute(Sql);
		}

		// Key filter WHERE clause
		private string SqlKeyFilter {
			get { return "[Id] = '@Id@'"; }
		}

		// Key filter
		public string KeyFilter {
			get {
				string sKeyFilter = SqlKeyFilter;
				sKeyFilter = sKeyFilter.Replace("@Id@", ew_AdjustSql(Id.CurrentValue)); // Replace key value
				return sKeyFilter;
			}
		}

		// Return URL
		public string ReturnUrl {
			get {
				string name = EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_RETURN_URL;

				// Get referer URL automatically
				if (ew_NotEmpty(ew_ServerVar("HTTP_REFERER")) &&
					ew_ReferPage() != ew_CurrentPage() &&
					ew_ReferPage() != "login.cshtml") // Referer not same page or login page
						ew_Session[name] = ew_ServerVar("HTTP_REFERER"); // Save to Session
				if (ew_NotEmpty(ew_Session[name])) {
					return Convert.ToString(ew_Session[name]);
				} else {
					return "AspNetUserslist.cshtml";
				}
			}
			set {
				ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_RETURN_URL] = value;
			}
		}

		// List URL
		public string ListUrl {
			get { return "AspNetUserslist.cshtml"; }
		}

		// View URL
		public string ViewUrl {
			get { return KeyUrl("AspNetUsersview.cshtml", UrlParm()); }
		}

		// View URL
		public string GetViewUrl(string parm = "") {
			if (ew_NotEmpty(parm))
				return KeyUrl("AspNetUsersview.cshtml", UrlParm(parm));
			else
				return KeyUrl("AspNetUsersview.cshtml", UrlParm(EW_TABLE_SHOW_DETAIL + "="));
		}

		// Add URL
		public string AddUrl {
			get {
				return "AspNetUsersadd.cshtml";
			}
		}

		// Add URL
		public string GetAddUrl(string parm = "") {
			if (ew_NotEmpty(parm))
				return "AspNetUsersadd.cshtml?" + UrlParm(parm);
			else
				return "AspNetUsersadd.cshtml";
		}

		// Edit URL
		public string EditUrl {
			get {
				return KeyUrl("AspNetUsersedit.cshtml", UrlParm());
			}
		}

		// Edit URL (with parameter)
		public string GetEditUrl(string parm) {
			return KeyUrl("AspNetUsersedit.cshtml", UrlParm(parm));
		}

		// Inline edit URL
		public string InlineEditUrl	{
			get { return KeyUrl(ew_CurrentPage(), UrlParm("a=edit")); }
		}

		// Copy URL
		public string CopyUrl {
			get {
				return KeyUrl("AspNetUsersadd.cshtml", UrlParm());
			}
		}

		// Copy URL
		public string GetCopyUrl(string parm = "") {
			return KeyUrl("AspNetUsersadd.cshtml", UrlParm(parm));
		}		

		// Inline copy URL
		public string InlineCopyUrl	{
			get { return KeyUrl(ew_CurrentPage(), UrlParm("a=copy")); }
		}

		// Delete URL
		public string DeleteUrl	{
			get { return KeyUrl("AspNetUsersdelete.cshtml", UrlParm()); }
		}

		// Add key value to URL
		public string KeyUrl(string url, string parm = "") {
			string sUrl = url + "?";
			if (ew_NotEmpty(parm)) sUrl += parm + "&"; 
			if (!Convert.IsDBNull(Id.CurrentValue)) {
				sUrl += "Id=" + ew_UrlEncode(Convert.ToString(Id.CurrentValue));				
			} else {
				return "javascript:alert(ewLanguage.Phrase('InvalidRecord'));";
			}
			return sUrl;
		}

		// Sort URL
		public string SortUrl(cField fld) {
			if (ew_NotEmpty(CurrentAction) || ew_NotEmpty(Export) || 
				(new List<int>() {141, 201, 203, 128, 204, 205}).Contains(fld.FldType)) { // Unsortable data type
				return "";
			} else if (fld.Sortable) { 
				string sUrlParm = UrlParm("order=" + ew_UrlEncode(fld.FldName) + "&amp;ordertype=" + fld.ReverseSort());
				return ew_CurrentPage() + "?" + sUrlParm;
			}
			return "";
		}

		// Get record keys
		public ArrayList GetRecordKeys() {
			var arKeys = new ArrayList();
			if (ew_Form["key_m"] != null) { // Key in form
				arKeys.AddRange(ew_Form.GetValues("key_m"));
			} else if (ew_QueryString["key_m"] != null) {
				arKeys.AddRange(ew_QueryString.GetValues("key_m"));
			} else if (ew_QueryString.Count > 0) {
				var keys = "";
				keys = ew_Get("Id"); // Id
				arKeys.Add(keys);

				//return arKeys; // do not return yet, so the values will also be checked by the following code
			}

			// check keys
			var ar = new ArrayList();

			// Check keys
			foreach (var keys in arKeys) {
				ar.Add(keys);
			}
			return ar;
		}

		// Get key filter
		public string GetKeyFilter() {
			ArrayList arKeys = GetRecordKeys();
			string sKeyFilter = "";
			foreach (var keys in arKeys) {
				if (ew_NotEmpty(sKeyFilter))
					sKeyFilter += " OR ";
				Id.CurrentValue = keys;
				sKeyFilter += "(" + KeyFilter + ")";
			}
			return sKeyFilter;
		}

		// Load rows based on filter
		public ewDataReader LoadRs(string sFilter, cConnectionBase cnn = null) {

			// Set up filter (SQL WHERE clause) and get return SQL
			string sSql = GetSQL(sFilter);
			try {
				var rs = (cnn != null) ? cnn.OpenDataReader(sSql) : Conn.OpenDataReader(sSql); // ASPX
				if (rs != null) {
					if (rs.HasRows)
						return rs;
					rs.Close();
					rs.Dispose();
				}
			} catch {}
			return null;
		}

		// Load record count based on filter
		public int LoadRecordCount(string sFilter) {

			// Set up filter (SQL WHERE clause) and get return SQL
			string sSql = GetSQL(sFilter);
			string sSqlCnt = "SELECT COUNT(*) FROM" + ((TableType == "TABLE" || TableType == "VIEW") ? Regex.Replace(sSql, @"^SELECT\s([\s\S]+)?\*\sFROM", "", RegexOptions.IgnoreCase) : " (" + sSql + ")");

			// Try count SQL first
			try {
				return Convert.ToInt32(Conn.ExecuteScalar(sSqlCnt));
			} catch {}

			// Loop datareader to get count
			try {
				int Cnt = 0;
				using (ewDataReader rs = Conn.OpenDataReader(sSql)) {					
					while (rs.Read())
						Cnt++;
				}
				return Cnt;
			} catch {
				return 0;
			}
		}

		// Load row values from recordset
		public void LoadListRowValues(ewDataReader rs) {
			Id.DbValue = rs["Id"];
			FirstName.DbValue = rs["FirstName"];
			LastName.DbValue = rs["LastName"];
			UserRole.DbValue = rs["UserRole"];
			DateCreated.DbValue = rs["DateCreated"];
			zEmail.DbValue = rs["Email"];
			EmailConfirmed.DbValue = ew_ConvertToBool(rs["EmailConfirmed"]) ? "1" : "0";
			PasswordHash.DbValue = rs["PasswordHash"];
			SecurityStamp.DbValue = rs["SecurityStamp"];
			PhoneNumber.DbValue = rs["PhoneNumber"];
			PhoneNumberConfirmed.DbValue = ew_ConvertToBool(rs["PhoneNumberConfirmed"]) ? "1" : "0";
			TwoFactorEnabled.DbValue = ew_ConvertToBool(rs["TwoFactorEnabled"]) ? "1" : "0";
			LockoutEndDateUtc.DbValue = rs["LockoutEndDateUtc"];
			LockoutEnabled.DbValue = ew_ConvertToBool(rs["LockoutEnabled"]) ? "1" : "0";
			AccessFailedCount.DbValue = rs["AccessFailedCount"];
			UserName.DbValue = rs["UserName"];
			CreatedBy_Id.DbValue = rs["CreatedBy_Id"];
			Customer_Id.DbValue = rs["Customer_Id"];
		}

		// Render list row values
		public void RenderListRow() {

			// Call Row Rendering event
			Row_Rendering();

	   // Common render codes
			// Id

			Id.CellCssStyle = "white-space: nowrap;";

			// FirstName
			// LastName
			// UserRole
			// DateCreated

			DateCreated.CellCssStyle = "white-space: nowrap;";

			// zEmail
			// EmailConfirmed

			EmailConfirmed.CellCssStyle = "white-space: nowrap;";

			// PasswordHash
			PasswordHash.CellCssStyle = "white-space: nowrap;";

			// SecurityStamp
			SecurityStamp.CellCssStyle = "white-space: nowrap;";

			// PhoneNumber
			PhoneNumber.CellCssStyle = "white-space: nowrap;";

			// PhoneNumberConfirmed
			PhoneNumberConfirmed.CellCssStyle = "white-space: nowrap;";

			// TwoFactorEnabled
			TwoFactorEnabled.CellCssStyle = "white-space: nowrap;";

			// LockoutEndDateUtc
			LockoutEndDateUtc.CellCssStyle = "white-space: nowrap;";

			// LockoutEnabled
			LockoutEnabled.CellCssStyle = "white-space: nowrap;";

			// AccessFailedCount
			AccessFailedCount.CellCssStyle = "white-space: nowrap;";

			// UserName
			UserName.CellCssStyle = "white-space: nowrap;";

			// CreatedBy_Id
			CreatedBy_Id.CellCssStyle = "white-space: nowrap;";

			// Customer_Id
			// Id

			Id.ViewValue = Id.CurrentValue;

			// FirstName
			FirstName.ViewValue = FirstName.CurrentValue;

			// LastName
			LastName.ViewValue = LastName.CurrentValue;

			// UserRole
			UserRole.ViewValue = UserRole.CurrentValue;

			// DateCreated
			DateCreated.ViewValue = DateCreated.CurrentValue;

			// zEmail
			zEmail.ViewValue = zEmail.CurrentValue;

			// EmailConfirmed
			if (ew_ConvertToBool(EmailConfirmed.CurrentValue)) {
				EmailConfirmed.ViewValue = (EmailConfirmed.FldTagCaption(1) != "") ? EmailConfirmed.FldTagCaption(1) : "Yes";
			} else {
				EmailConfirmed.ViewValue = (EmailConfirmed.FldTagCaption(2) != "") ? EmailConfirmed.FldTagCaption(2) : "No";
			}

			// PasswordHash
			PasswordHash.ViewValue = PasswordHash.CurrentValue;

			// SecurityStamp
			SecurityStamp.ViewValue = SecurityStamp.CurrentValue;

			// PhoneNumber
			PhoneNumber.ViewValue = PhoneNumber.CurrentValue;

			// PhoneNumberConfirmed
			if (ew_ConvertToBool(PhoneNumberConfirmed.CurrentValue)) {
				PhoneNumberConfirmed.ViewValue = (PhoneNumberConfirmed.FldTagCaption(1) != "") ? PhoneNumberConfirmed.FldTagCaption(1) : "Yes";
			} else {
				PhoneNumberConfirmed.ViewValue = (PhoneNumberConfirmed.FldTagCaption(2) != "") ? PhoneNumberConfirmed.FldTagCaption(2) : "No";
			}

			// TwoFactorEnabled
			if (ew_ConvertToBool(TwoFactorEnabled.CurrentValue)) {
				TwoFactorEnabled.ViewValue = (TwoFactorEnabled.FldTagCaption(1) != "") ? TwoFactorEnabled.FldTagCaption(1) : "Yes";
			} else {
				TwoFactorEnabled.ViewValue = (TwoFactorEnabled.FldTagCaption(2) != "") ? TwoFactorEnabled.FldTagCaption(2) : "No";
			}

			// LockoutEndDateUtc
			LockoutEndDateUtc.ViewValue = LockoutEndDateUtc.CurrentValue;

			// LockoutEnabled
			if (ew_ConvertToBool(LockoutEnabled.CurrentValue)) {
				LockoutEnabled.ViewValue = (LockoutEnabled.FldTagCaption(1) != "") ? LockoutEnabled.FldTagCaption(1) : "Yes";
			} else {
				LockoutEnabled.ViewValue = (LockoutEnabled.FldTagCaption(2) != "") ? LockoutEnabled.FldTagCaption(2) : "No";
			}

			// AccessFailedCount
			AccessFailedCount.ViewValue = AccessFailedCount.CurrentValue;

			// UserName
			UserName.ViewValue = UserName.CurrentValue;

			// CreatedBy_Id
			CreatedBy_Id.ViewValue = CreatedBy_Id.CurrentValue;

			// Customer_Id
			if (ew_NotEmpty(Customer_Id.CurrentValue)) {
				sFilterWrk = "[Id]" + ew_SearchString("=", Convert.ToString(Customer_Id.CurrentValue).Trim(), EW_DATATYPE_NUMBER);
			sSqlWrk = "SELECT [Id], [Id] AS [DispFld], '' AS [Disp2Fld], '' AS [Disp3Fld], '' AS [Disp4Fld] FROM [dbo].[Customers]";
			sWhereWrk = "";
			sLookupTblFilter = Convert.ToString(GetCustomValue("FldSelectFilter", "Customer_Id"));
			if (ew_NotEmpty(sLookupTblFilter)) {
				sWhereWrk = ew_JoinFilter(sWhereWrk, sLookupTblFilter);
			}
			if (ew_NotEmpty(sFilterWrk)) {
				sWhereWrk = ew_JoinFilter(sWhereWrk, sFilterWrk);
			}

			// Call Lookup selecting
			Lookup_Selecting(Customer_Id, ref sWhereWrk);
			if (sWhereWrk != "") {
				sSqlWrk += " WHERE " + sWhereWrk;
			}
				odwrk = Conn.GetRow(sSqlWrk);
				if (odwrk != null) {
					Customer_Id.ViewValue = odwrk["DispFld"];
				} else {
					Customer_Id.ViewValue = Customer_Id.CurrentValue;
				}	
			} else {
				Customer_Id.ViewValue = System.DBNull.Value;
			}

			// Id
			Id.HrefValue = "";
			Id.TooltipValue = "";

			// FirstName
			FirstName.HrefValue = "";
			FirstName.TooltipValue = "";

			// LastName
			LastName.HrefValue = "";
			LastName.TooltipValue = "";

			// UserRole
			UserRole.HrefValue = "";
			UserRole.TooltipValue = "";

			// DateCreated
			DateCreated.HrefValue = "";
			DateCreated.TooltipValue = "";

			// zEmail
			zEmail.HrefValue = "";
			zEmail.TooltipValue = "";

			// EmailConfirmed
			EmailConfirmed.HrefValue = "";
			EmailConfirmed.TooltipValue = "";

			// PasswordHash
			PasswordHash.HrefValue = "";
			PasswordHash.TooltipValue = "";

			// SecurityStamp
			SecurityStamp.HrefValue = "";
			SecurityStamp.TooltipValue = "";

			// PhoneNumber
			PhoneNumber.HrefValue = "";
			PhoneNumber.TooltipValue = "";

			// PhoneNumberConfirmed
			PhoneNumberConfirmed.HrefValue = "";
			PhoneNumberConfirmed.TooltipValue = "";

			// TwoFactorEnabled
			TwoFactorEnabled.HrefValue = "";
			TwoFactorEnabled.TooltipValue = "";

			// LockoutEndDateUtc
			LockoutEndDateUtc.HrefValue = "";
			LockoutEndDateUtc.TooltipValue = "";

			// LockoutEnabled
			LockoutEnabled.HrefValue = "";
			LockoutEnabled.TooltipValue = "";

			// AccessFailedCount
			AccessFailedCount.HrefValue = "";
			AccessFailedCount.TooltipValue = "";

			// UserName
			UserName.HrefValue = "";
			UserName.TooltipValue = "";

			// CreatedBy_Id
			CreatedBy_Id.HrefValue = "";
			CreatedBy_Id.TooltipValue = "";

			// Customer_Id
			Customer_Id.HrefValue = "";
			Customer_Id.TooltipValue = "";

			// Call Row Rendered event
			Row_Rendered();
		}

		// Render edit row values
		public void RenderEditRow() {

			// Call Row Rendering event
				Row_Rendering();

		// Id
		Id.EditAttrs["class"] = "form-control";
		Id.EditValue = Id.CurrentValue;

		// FirstName
		FirstName.EditAttrs["class"] = "form-control";
		FirstName.EditValue = FirstName.CurrentValue; // ASPX
		FirstName.PlaceHolder = ew_RemoveHtml(FirstName.FldCaption);

		// LastName
		LastName.EditAttrs["class"] = "form-control";
		LastName.EditValue = LastName.CurrentValue; // ASPX
		LastName.PlaceHolder = ew_RemoveHtml(LastName.FldCaption);

		// UserRole
		UserRole.EditAttrs["class"] = "form-control";
		UserRole.EditValue = UserRole.CurrentValue; // ASPX
		UserRole.PlaceHolder = ew_RemoveHtml(UserRole.FldCaption);

		// DateCreated
		DateCreated.EditAttrs["class"] = "form-control";
		DateCreated.EditValue = DateCreated.CurrentValue; // ASPX
		DateCreated.PlaceHolder = ew_RemoveHtml(DateCreated.FldCaption);

		// Email
		zEmail.EditAttrs["class"] = "form-control";
		zEmail.EditValue = zEmail.CurrentValue; // ASPX
		zEmail.PlaceHolder = ew_RemoveHtml(zEmail.FldCaption);

		// EmailConfirmed
		alwrk = new List<OrderedDictionary>();
		alwrk.Add(new OrderedDictionary() {
			{0, EmailConfirmed.FldTagValue(1)}, 
			{1, (ew_NotEmpty(EmailConfirmed.FldTagCaption(1))) ? EmailConfirmed.FldTagCaption(1) : EmailConfirmed.FldTagValue(1)}
		});
		alwrk.Add(new OrderedDictionary() {
			{0, EmailConfirmed.FldTagValue(2)}, 
			{1, (ew_NotEmpty(EmailConfirmed.FldTagCaption(2))) ? EmailConfirmed.FldTagCaption(2) : EmailConfirmed.FldTagValue(2)}
		});
		EmailConfirmed.EditValue = alwrk;

		// PasswordHash
		PasswordHash.EditAttrs["class"] = "form-control";
		PasswordHash.EditValue = PasswordHash.CurrentValue; // ASPX
		PasswordHash.PlaceHolder = ew_RemoveHtml(PasswordHash.FldCaption);

		// SecurityStamp
		SecurityStamp.EditAttrs["class"] = "form-control";
		SecurityStamp.EditValue = SecurityStamp.CurrentValue; // ASPX
		SecurityStamp.PlaceHolder = ew_RemoveHtml(SecurityStamp.FldCaption);

		// PhoneNumber
		PhoneNumber.EditAttrs["class"] = "form-control";
		PhoneNumber.EditValue = PhoneNumber.CurrentValue; // ASPX
		PhoneNumber.PlaceHolder = ew_RemoveHtml(PhoneNumber.FldCaption);

		// PhoneNumberConfirmed
		alwrk = new List<OrderedDictionary>();
		alwrk.Add(new OrderedDictionary() {
			{0, PhoneNumberConfirmed.FldTagValue(1)}, 
			{1, (ew_NotEmpty(PhoneNumberConfirmed.FldTagCaption(1))) ? PhoneNumberConfirmed.FldTagCaption(1) : PhoneNumberConfirmed.FldTagValue(1)}
		});
		alwrk.Add(new OrderedDictionary() {
			{0, PhoneNumberConfirmed.FldTagValue(2)}, 
			{1, (ew_NotEmpty(PhoneNumberConfirmed.FldTagCaption(2))) ? PhoneNumberConfirmed.FldTagCaption(2) : PhoneNumberConfirmed.FldTagValue(2)}
		});
		PhoneNumberConfirmed.EditValue = alwrk;

		// TwoFactorEnabled
		alwrk = new List<OrderedDictionary>();
		alwrk.Add(new OrderedDictionary() {
			{0, TwoFactorEnabled.FldTagValue(1)}, 
			{1, (ew_NotEmpty(TwoFactorEnabled.FldTagCaption(1))) ? TwoFactorEnabled.FldTagCaption(1) : TwoFactorEnabled.FldTagValue(1)}
		});
		alwrk.Add(new OrderedDictionary() {
			{0, TwoFactorEnabled.FldTagValue(2)}, 
			{1, (ew_NotEmpty(TwoFactorEnabled.FldTagCaption(2))) ? TwoFactorEnabled.FldTagCaption(2) : TwoFactorEnabled.FldTagValue(2)}
		});
		TwoFactorEnabled.EditValue = alwrk;

		// LockoutEndDateUtc
		LockoutEndDateUtc.EditAttrs["class"] = "form-control";
		LockoutEndDateUtc.EditValue = LockoutEndDateUtc.CurrentValue; // ASPX
		LockoutEndDateUtc.PlaceHolder = ew_RemoveHtml(LockoutEndDateUtc.FldCaption);

		// LockoutEnabled
		alwrk = new List<OrderedDictionary>();
		alwrk.Add(new OrderedDictionary() {
			{0, LockoutEnabled.FldTagValue(1)}, 
			{1, (ew_NotEmpty(LockoutEnabled.FldTagCaption(1))) ? LockoutEnabled.FldTagCaption(1) : LockoutEnabled.FldTagValue(1)}
		});
		alwrk.Add(new OrderedDictionary() {
			{0, LockoutEnabled.FldTagValue(2)}, 
			{1, (ew_NotEmpty(LockoutEnabled.FldTagCaption(2))) ? LockoutEnabled.FldTagCaption(2) : LockoutEnabled.FldTagValue(2)}
		});
		LockoutEnabled.EditValue = alwrk;

		// AccessFailedCount
		AccessFailedCount.EditAttrs["class"] = "form-control";
		AccessFailedCount.EditValue = AccessFailedCount.CurrentValue; // ASPX
		AccessFailedCount.PlaceHolder = ew_RemoveHtml(AccessFailedCount.FldCaption);

		// UserName
		UserName.EditAttrs["class"] = "form-control";
		UserName.EditValue = UserName.CurrentValue; // ASPX
		UserName.PlaceHolder = ew_RemoveHtml(UserName.FldCaption);

		// CreatedBy_Id
		CreatedBy_Id.EditAttrs["class"] = "form-control";
		CreatedBy_Id.EditValue = CreatedBy_Id.CurrentValue; // ASPX
		CreatedBy_Id.PlaceHolder = ew_RemoveHtml(CreatedBy_Id.FldCaption);

		// Customer_Id
		Customer_Id.EditAttrs["class"] = "form-control";

			// Call Row Rendered event
				Row_Rendered();
		}

		// Aggregate list row values
		public void AggregateListRowValues() {
		}

		// Aggregate list row (for rendering)
		public void AggregateListRow() {

			// Call Row Rendered event
			Row_Rendered();
		}

		public dynamic ExportDoc;

		// Export data in HTML/CSV/Word/Excel/Email/PDF format
		public void ExportDocument(dynamic Doc, ewDataReader Recordset, int StartRec, int StopRec, string ExportPageType = "") {	
			if (Recordset == null || Doc == null)
				return;
			if (!Doc.ExportCustom) {

				// Write header
				Doc.ExportTableHeader();
				if (Doc.Horizontal) { // Horizontal format, write header
					Doc.BeginExportRow();
					if (ExportPageType == "view") {
						if (FirstName.Exportable) Doc.ExportCaption(ref FirstName);
						if (LastName.Exportable) Doc.ExportCaption(ref LastName);
						if (UserRole.Exportable) Doc.ExportCaption(ref UserRole);
						if (DateCreated.Exportable) Doc.ExportCaption(ref DateCreated);
						if (zEmail.Exportable) Doc.ExportCaption(ref zEmail);
						if (PasswordHash.Exportable) Doc.ExportCaption(ref PasswordHash);
						if (Customer_Id.Exportable) Doc.ExportCaption(ref Customer_Id);
					} else {
						if (FirstName.Exportable) Doc.ExportCaption(ref FirstName);
						if (LastName.Exportable) Doc.ExportCaption(ref LastName);
						if (UserRole.Exportable) Doc.ExportCaption(ref UserRole);
						if (Customer_Id.Exportable) Doc.ExportCaption(ref Customer_Id);
					}
					Doc.EndExportRow();
				}
			}	

			// Move to first record
			int RecCnt = StartRec - 1;
			for (int i = 1; i <= StartRec - 1; i++)
				Recordset.Read();	
			while (Recordset.Read() && RecCnt < StopRec) {
				RecCnt++;
				if (RecCnt >= StartRec) {
					int RowCnt = RecCnt - StartRec + 1;

					// Page break
					if (ExportPageBreakCount > 0) {
						if (RowCnt > 1 && (RowCnt - 1) % ExportPageBreakCount == 0)
							Doc.ExportPageBreak();
					}
					LoadListRowValues(Recordset);

					// Render row
					RowType = EW_ROWTYPE_VIEW; // Render view
					ResetAttrs();
					RenderListRow();
					if (!Doc.ExportCustom) {
						Doc.BeginExportRow(RowCnt); // Allow CSS styles if enabled
						if (ExportPageType == "view") {
							if (FirstName.Exportable) Doc.ExportField(ref FirstName);
							if (LastName.Exportable) Doc.ExportField(ref LastName);
							if (UserRole.Exportable) Doc.ExportField(ref UserRole);
							if (DateCreated.Exportable) Doc.ExportField(ref DateCreated);
							if (zEmail.Exportable) Doc.ExportField(ref zEmail);
							if (PasswordHash.Exportable) Doc.ExportField(ref PasswordHash);
							if (Customer_Id.Exportable) Doc.ExportField(ref Customer_Id);
						} else {
							if (FirstName.Exportable) Doc.ExportField(ref FirstName);
							if (LastName.Exportable) Doc.ExportField(ref LastName);
							if (UserRole.Exportable) Doc.ExportField(ref UserRole);
							if (Customer_Id.Exportable) Doc.ExportField(ref Customer_Id);
						}
						Doc.EndExportRow();
					}
				}

			// Call Row Export server event
			if (Doc.ExportCustom)
				Row_Export(Recordset);
			}
			if (!Doc.ExportCustom) {
				Doc.ExportTableFooter();
			}
		}

		// Get auto fill value
		public string GetAutoFill(string id, string val) {
			var rsarr = new List<OrderedDictionary>();
			int rowcnt = 0;

			// Output (using ew_Response) // ASPX
			if (ew_IsList(rsarr) && rowcnt > 0) {				 
				foreach (OrderedDictionary row in rsarr) {
					for (var i = 0; i < row.Count; i++) {
						var str = Convert.ToString(row[i]);
						if (ew_Empty(ew_Post("keepHTML")))
							str = ew_RemoveHtml(str);
						if (str.Contains("\r") || str.Contains("\n")) {
							if (ew_NotEmpty(ew_Post("keepCRLF"))) {
								str = str.Replace("\r", "\\r").Replace("\n", "\\n");
							} else {
								str = str.Replace("\r", " ").Replace("\n", " ");
							}
						}
						row[i] = str;
					}				
				}
				return ew_ArrayToJson(rsarr);		
			} else {
				return "false";
			}
		}

		// Table level events
		// Recordset Selecting event
		public virtual void Recordset_Selecting(ref string filter) { 

			// Enter your code here	
		}

		// Recordset Search Validated event
		public virtual void Recordset_SearchValidated() {

			// Enter your code here
		}

		// Recordset Searching event
		public virtual void Recordset_Searching(ref string filter) {

			// Enter your code here
		}

		// Row_Selecting event
		public virtual void Row_Selecting(ref string filter) {

			// Enter your code here	
		}

		// Row Selected event
		public virtual void Row_Selected(ref OrderedDictionary od) {

			//ew_Write("Row Selected");
		}

		// Row Inserting event
		public virtual bool Row_Inserting(OrderedDictionary rsold, ref OrderedDictionary rsnew) {

			// Enter your code here
			// To cancel, set return value to False and error message to CancelMessage

			return true;
		}

		// Row Inserted event
		public virtual void Row_Inserted(OrderedDictionary rsold, OrderedDictionary rsnew) {

			//ew_Write("Row Inserted");
		}

		// Row Updating event
		public virtual bool Row_Updating(OrderedDictionary rsold, ref OrderedDictionary rsnew) {

			// Enter your code here
			// To cancel, set return value to False and error message to CancelMessage

			return true;
		}

		// Row Updated event
		public virtual void Row_Updated(OrderedDictionary rsold, OrderedDictionary rsnew) {

			// ew_Write("Row Updated");
		}

		// Row Update Conflict event
		public virtual bool Row_UpdateConflict(OrderedDictionary rsold, ref OrderedDictionary rsnew) {

			// Enter your code here
			// To ignore conflict, set return value to false

			return true;
		}

		// Row Export event
		// ExportDoc = export document object
		public virtual void Row_Export(ewDataReader rs) {

		    // ExportDoc.Text += "my content"; // Build HTML with field value: $rs["MyField"] or $this->MyField->ViewValue
		}

		// Page Exporting event
		// ExportDoc = export document object
		public virtual bool Page_Exporting() {

			//ExportDoc.Text = "my header"; // Export header
			//return false; // Return FALSE to skip default export and use Row_Export event

			return true; // Return TRUE to use default export and skip Row_Export event
		}

		// Page Exported event
		// ExportDoc = export document object
		public virtual void Page_Exported() {

			//ExportDoc.Text += "my footer"; ' Export footer
			//ew_Write(ExportDoc.Text);

		}

		// Grid Inserting event
		public virtual bool Grid_Inserting() {

			// Enter your code here
			// To reject grid insert, set return value to FALSE

			return true;
		}

		// Grid Inserted event
		public virtual void Grid_Inserted(List<OrderedDictionary> rsnew) {

			//ew_Write("Grid Inserted");
		}

		// Grid Updating event
		public virtual bool Grid_Updating(List<OrderedDictionary> rsold) {

			// Enter your code here
			// To reject grid update, set return value to FALSE

			return true;
		}

		// Grid Updated event
		public virtual void Grid_Updated(List<OrderedDictionary> rsold, List<OrderedDictionary> rsnew) {

			//ew_Write("Grid Updated");
		}

		// Recordset Deleting event
		public virtual bool Row_Deleting(OrderedDictionary rs) {

			// Enter your code here
			// To cancel, set return value to False and error message to CancelMessage

			return true;
		}

		// Recordset Deleted event
		public virtual void Row_Deleted(OrderedDictionary rs) {

			//ew_Write("Row Deleted");
		}

		// Email Sending event
		public virtual bool Email_Sending(ref cEmail Email, dynamic Args) {

			//ew_End(Email);
			return true;
		}

		// Lookup Selecting event
		public virtual void Lookup_Selecting(cField fld, ref string filter) {

			// Enter your code here
		}

		// Row Rendering event
		public virtual void Row_Rendering() {

			// Enter your code here	
		}

		// Row Rendered event
		public virtual void Row_Rendered() {

			//ew_VarPrint(<FieldName>); // View field properties
		}

		// User ID Filtering event
		public virtual void UserID_Filtering(ref string filter) {

			// Enter your code here
		}
	}
}
