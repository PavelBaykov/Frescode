using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET Maker 12 Project Class
//
public partial class AspNetMaker12_Admin_new_base : WebPage {

	//
	// Global variables
	//
	// Conn
	public static cConnectionBase Conn {
		get { return (cConnectionBase)ew_PageData["Conn"]; }
		set { ew_PageData["Conn"] = value; }
	}

	// Security
	public static cAdvancedSecurityBase Security {
		get { return (cAdvancedSecurityBase)ew_PageData["Security"]; }
		set { ew_PageData["Security"] = value; }
	}

	// ObjForm
	public static cFormObj ObjForm {
		get { return (cFormObj)ew_PageData["ObjForm"]; }
		set { ew_PageData["ObjForm"] = value; }
	}

	// Language
	public static cLanguage Language {
		get { return (cLanguage)ew_PageData["Language"]; }
		set { ew_PageData["Language"] = value; }
	}

	// Breadcrumb
	public static cBreadcrumb Breadcrumb {
		get { return (cBreadcrumb)ew_PageData["Breadcrumb"]; }
		set { ew_PageData["Breadcrumb"] = value; }
	}

	// RootMenu
	public static cMenuBase RootMenu {
		get { return (cMenuBase)ew_PageData["RootMenu"]; }
		set { ew_PageData["RootMenu"] = value; }
	}

	// gsLanguage
	public static string gsLanguage {
		get { return Convert.ToString(ew_PageData["gsLanguage"]); }
		set { ew_PageData["gsLanguage"] = value; }
	}

	// gbSkipHeaderFooter
	public static bool gbSkipHeaderFooter {
		get { return ew_ConvertToBool(ew_PageData["gbSkipHeaderFooter"]); }
		set { ew_PageData["gbSkipHeaderFooter"] = value; }
	}

	// StartTime
	public static long StartTime {
		get { return (long)ew_PageData["StartTime"]; }
		set { ew_PageData["StartTime"] = value; }
	}

	// CurrentPage
	public static dynamic CurrentPage {
		get { return (dynamic)ew_PageData["CurrentPage"]; }
		set { ew_PageData["CurrentPage"] = value; }
	}

	// MasterPage
	public static dynamic MasterPage {
		get { return (dynamic)ew_PageData["MasterPage"]; }
		set { ew_PageData["MasterPage"] = value; }
	}

	// UserTable
	public static dynamic UserTable {
		get { return (dynamic)ew_PageData["UserTable"]; }
		set { ew_PageData["UserTable"] = value; }
	}

	// gsFormError
	public static string gsFormError {
		get { return Convert.ToString(ew_PageData["gsFormError"]); }
		set { ew_PageData["gsFormError"] = value; }
	}

	// gsSearchError
	public static string gsSearchError {
		get { return Convert.ToString(ew_PageData["gsSearchError"]); }
		set { ew_PageData["gsSearchError"] = value; }
	}

	// gsMasterReturnUrl
	public static string gsMasterReturnUrl {
		get { return Convert.ToString(ew_PageData["gsMasterReturnUrl"]); }
		set { ew_PageData["gsMasterReturnUrl"] = value; }
	}

	// gsExport
	public static string gsExport {
		get { return Convert.ToString(ew_PageData["gsExport"]); }
		set { ew_PageData["gsExport"] = value; }
	}

	// gsExportFile
	public static string gsExportFile {
		get { return Convert.ToString(ew_PageData["gsExportFile"]); }
		set { ew_PageData["gsExportFile"] = value; }
	}

	// gsCustomExport
	public static string gsCustomExport {
		get { return Convert.ToString(ew_PageData["gsCustomExport"]); }
		set { ew_PageData["gsCustomExport"] = value; }
	}

	// gsEmailErrDesc
	public static string gsEmailErrDesc {
		get { return Convert.ToString(ew_PageData["gsEmailErrDesc"]); }
		set { ew_PageData["gsEmailErrDesc"] = value; }
	}

	// gsDebugMsg
	public static string gsDebugMsg {
		get { return Convert.ToString(ew_PageData["gsDebugMsg"]); }
		set { ew_PageData["gsDebugMsg"] = value; }
	}

	// gsToken
	public static string gsToken {
		get { return Convert.ToString(ew_PageData["gsToken"]); }
		set { ew_PageData["gsToken"] = value; }
	}

	// gsHeaderRowClass
	public static string gsHeaderRowClass {
		get { return Convert.ToString(ew_PageData["gsHeaderRowClass"]); }
		set { ew_PageData["gsHeaderRowClass"] = value; }
	}

	// gsMenuColumnClass
	public static string gsMenuColumnClass {
		get { return Convert.ToString(ew_PageData["gsMenuColumnClass"]); }
		set { ew_PageData["gsMenuColumnClass"] = value; }
	}

	// gsSiteTitleClass
	public static string gsSiteTitleClass {
		get { return Convert.ToString(ew_PageData["gsSiteTitleClass"]); }
		set { ew_PageData["gsSiteTitleClass"] = value; }
	}

	// UserAgent
	public static string[] UserAgent {
		get { return (string[])ew_PageData["UserAgent"]; }
		set { ew_PageData["UserAgent"] = value; }
	}

	// gTmpImages = new List<string>()
	public static List<string> gTmpImages = new List<string>();

	// rswrk
	public static List<OrderedDictionary> rswrk;

	// alwrk
	public static List<OrderedDictionary> alwrk;

	// drWrk
	public static ewDataReader drWrk;

	// jswrk
	public static string jswrk;

	// selwrk
	public static string selwrk;

	// arwrk
	public static string[] arwrk;

	// odwrk
	public static OrderedDictionary odwrk;

	// sSqlWrk
	public static string sSqlWrk;

	// sWhereWrk
	public static string sWhereWrk;

	// sFilterWrk
	public static string sFilterWrk;

	// sLookupTblFilter
	public static string sLookupTblFilter;

	// wrkonchange
	public static string wrkonchange;

	// emptywrk
	public static bool emptywrk;

	// CurrentTable // ASPX
	public static dynamic CurrentTable {
		get { return CurrentPage; }
		set { CurrentPage = value; }
	}

	// MasterTable // ASPX
	public static dynamic MasterTable {
		get { return MasterPage; }
		set { MasterPage = value; }
	}	

	// Page Loading event
	public virtual void Page_Loading() {

		//ew_Write("Page Loading");
	}

	// Page Rendering event
	public virtual void Page_Rendering() {

		//ew_Write("Page Rendering");
	}

	// Page Unloaded event
	public virtual void Page_Unloaded() {

		//ew_Write("Page Unloaded");
	}
}
