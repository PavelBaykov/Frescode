using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET Maker 12 Project Class
// (C)2015 e.World Technology Ltd. All rights reserved.
//
public partial class AspNetMaker12_Admin_new_base : WebPage {

	// Execute method
	public override void Execute() {
	}	

	// Current page
	public static AspNetMaker12_Admin_new_base ew_WebPage {
		get { return (AspNetMaker12_Admin_new_base)WebPageContext.Current.Page; }
	}	

	// Current HttpContext
	public static HttpContextWrapper ew_HttpContext {
		get {
			return new HttpContextWrapper(HttpContext.Current); 
		}
	}

	// Current WebPage
	public static WebPage ew_Page {
		get { return (WebPage)WebPageContext.Current.Page; }
	}		

	// Page data class
	public class cPageData
	{

		private Dictionary<string, object> _data = new Dictionary<string, object>(); 

		public object this[string key] {
			get {
				return (_data.ContainsKey(key)) ? _data[key] : null;
			}
			set {
				if (_data.ContainsKey(key)) {
					_data[key] = value;
				} else {
					_data.Add(key, value);
				}		
			}
		}
	}

	// Page data
	public static cPageData ew_PageData {
		get {
			var key = "__PageData"; 
			if (!ew_Page.PageData.ContainsKey(key))
				ew_Page.PageData[key] = new cPageData();
			return ew_Page.PageData[key];
		}		
	}

	// Request
	public static HttpRequestBase ew_Request {
		get {
			if (WebPageContext.Current != null) { 
				return ew_Page.Request;
			} else {
				return ew_HttpContext.Request;
			}
		}
	}

	// Response
	public static HttpResponseBase ew_Response {
		get {
			if (WebPageContext.Current != null) {
				return ew_Page.Response;
			} else {
				return ew_HttpContext.Response;
			}
		}
	}

	// Server
	public static HttpServerUtilityBase ew_Server {
		get {
			if (WebPageContext.Current != null) { 
				return ew_Page.Server;
			} else {
				return ew_HttpContext.Server;
			}
		}
	}

	// Session
	public static HttpSessionStateBase ew_Session {
		get {
			if (WebPageContext.Current != null) { 
				return ew_Page.Session;
			} else {
				return ew_HttpContext.Session;
			}
		}
	}

	// Form
	public static NameValueCollection ew_Form {
		get { return ew_Page.Request.Unvalidated().Form; }
	}

	// QueryString
	public static NameValueCollection ew_QueryString {
		get { return ew_Page.Request.Unvalidated().QueryString; }
	}

	// Files
	public static HttpFileCollectionBase ew_Files {
		get { return ew_Page.Request.Files; }
	}	

	// IsPost
	public static bool IsPost {
		get { return ew_Page.IsPost; }
	}

	// Compare object as string
	public static bool ew_SameStr(object v1, object v2)
	{
		return string.Equals(Convert.ToString(v1).Trim(), Convert.ToString(v2).Trim());
	}

	// Compare object as string (case insensitive)
	public static bool ew_SameText(object v1, object v2)
	{
		return string.Equals(Convert.ToString(v1).Trim().ToUpperInvariant(), Convert.ToString(v2).Trim().ToUpperInvariant());
	}

	// Compare object as integer
	public static bool ew_SameInt(object v1, object v2)
	{
		try {
			return (Convert.ToInt32(v1) == Convert.ToInt32(v2));
		} catch {
			return false;
		}
	}

	// Compare object as specified type
    public static bool ew_Same<T>(object v1, object v2)
    {
        try {
			return EqualityComparer<T>.Default.Equals(Convert.ToString(v1).Trim().As<T>(), Convert.ToString(v2).Trim().As<T>());
		} catch {
			return false;
		}
    }

	// Compare file name without extension // ASPX
	public static bool ew_SameFileName(string v1, string v2)
	{
		return string.Equals(Path.GetFileNameWithoutExtension(v1), Path.GetFileNameWithoutExtension(v2));
	}

	// Check if empty string
	public static bool ew_Empty(object value)
	{
		return string.Equals(Convert.ToString(value).Trim(), string.Empty);
	}

	// Check if not empty string
	public static bool ew_NotEmpty(object value)
	{
		return !ew_Empty(value);
	}

	// Convert object to integer
	public static int ew_ConvertToInt(object value)
	{
		try {
			return Convert.ToInt32(value);
		} catch {
			return 0;
		}
	}

	// Convert object to integer
	public static long ew_ConvertToInt64(object value)
	{
		try {
			return Convert.ToInt64(value);
		} catch {
			return 0;
		}
	}

	// Convert object to double
	public static double ew_ConvertToDouble(object value)
	{
		try {
			return Convert.ToDouble(value);
		} catch {
			return 0;
		}
	}

	// Convert object to bool
	public static bool ew_ConvertToBool(object value)
	{
		try {
			if (Information.IsNumeric(value)) {
				return ew_ConvertToInt(value) != 0;
			} else if (value is string) { // ***
				return ew_SameText(value, "y") || ew_SameText(value, "t");
			} else {
				return Convert.ToBoolean(value);
			}
		} catch {
			return false;
		}
	}

	// Convert input value to boolean value for SQL paramater // ASPX //***
	public static object ew_ConvertToBool(object Value, string TrueValue, string FalseValue)
	{
		var res = Value;
		if (!ew_SameStr(Value, TrueValue) && !ew_SameStr(Value, FalseValue))
			res = ew_NotEmpty(Value) ? TrueValue : FalseValue;
		if (Information.IsNumeric(res)) // Convert to int so it can be converted to bool if necessary
			res = ew_ConvertToInt(res);
		return res;
	}

	// Prepend CSS class name // ASPX
	public static string ew_PrependClass(string attr, string classname) {
		classname = classname.Trim();
		if (ew_NotEmpty(classname)) {
			attr = attr.Trim();
			if (ew_NotEmpty(attr))
				attr = " " + attr;
			attr = classname + attr;
		}
		return attr;
	}

	// Append CSS class name // ASPX
	public static string ew_AppendClass(string attr, string classname) {
		classname = classname.Trim();
		if (ew_NotEmpty(classname)) {
			attr = attr.Trim();
			if (ew_NotEmpty(attr))
				attr += " ";
			attr += classname;			
		}
		return attr;
	}

	// Add message
	public static void ew_AddMessage(ref string msg, string newmsg) {
		if (ew_NotEmpty(newmsg)) {
			if (ew_NotEmpty(msg))
				msg += "<br>";
			msg += newmsg;
		}
	}

	// Join messages by "<br>" and return the combined message // ASPX
	public static string ew_JoinMessage(string msg, string newmsg) {
		if (ew_NotEmpty(newmsg)) {
			if (ew_NotEmpty(msg))
				msg += "<br>";
			msg += newmsg;
		}
		return msg;
	}

	// Add filter
	public static void ew_AddFilter(ref string filter, string newfilter) {
		if (ew_Empty(newfilter))
			return;
		if (ew_NotEmpty(filter)) {
			filter = "(" + filter + ") AND (" + newfilter + ")";
		} else {
			filter = newfilter;
		}
	}

	// Join filters by "AND" and return the combined filter
	public static string ew_JoinFilter(string filter, string newfilter) {
		if (ew_Empty(newfilter))
			return filter;
		if (ew_NotEmpty(filter)) {
			filter = "(" + filter + ") AND (" + newfilter + ")";
		} else {
			filter = newfilter;
		}
		return filter;
	}

	// Get user IP
	public static string ew_CurrentUserIP()
	{
        string ipaddr = "";
        string host = ew_ServerVar("REMOTE_ADDR");
        if (ew_NotEmpty(host))
            ipaddr = ew_GetIP4Address(host);
        if (ew_Empty(ipaddr)) {
            host = ew_Request.UserHostAddress;
			if (ew_NotEmpty(host))
				ipaddr = ew_GetIP4Address(host);
		}
		if (ew_Empty(ipaddr)) {
            host = Dns.GetHostName();
			if (ew_NotEmpty(host))
				ipaddr = ew_GetIP4Address(host);
		}        
        return ipaddr;
	}

    // Get IPv4 Address
	public static string ew_GetIP4Address(string host)
    {
        string ipaddr = String.Empty;
		try {
	        foreach (IPAddress IPA in Dns.GetHostAddresses(host)) {
	            if (IPA.AddressFamily.ToString() == "InterNetwork") {
	                ipaddr = IPA.ToString();
	                break;
	            }
	        }
		} catch {}
        return ipaddr;
    }

	// Get current date in default date format
	public static string ew_CurrentDate(int namedformat)
	{
		string DT;
		if (ew_Contains(namedformat, new int[] {5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17})) {
			if (ew_Contains(namedformat, new int[] {5, 9, 12, 15})) {
				DT = ew_FormatDateTime(DateTime.Today, 5);
			} else if (ew_Contains(namedformat, new int[] {6, 10, 13, 16})) {
				DT = ew_FormatDateTime(DateTime.Today, 6);
			} else {
				DT = ew_FormatDateTime(DateTime.Today, 7);
			}
			return DT;
		} else {
			return ew_FormatDateTime(DateTime.Today, 5);
		}
	}

	public static string ew_CurrentDate()
	{
		return ew_CurrentDate(-1);
	}

	// Get current time in hh:mm:ss format
	public static string ew_CurrentTime() {
		DateTime DT;
		DT = DateTime.Now;
		return DT.ToString("HH':'mm':'ss");
	}

	// Get current date in default date format with
	// Current time in hh:mm:ss format
	public static string ew_CurrentDateTime(int namedformat) {
		string DT;
		if (ew_Contains(namedformat, new int[] {5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17})) {
			if (ew_Contains(namedformat, new int[] {5, 9, 12, 15})) {
				DT = ew_FormatDateTime(DateTime.Now, 9);
			} else if (ew_Contains(namedformat, new int[] {6, 10, 13, 16})) {
				DT = ew_FormatDateTime(DateTime.Now, 10);
			} else {
				DT = ew_FormatDateTime(DateTime.Now, 11);
			}
			return DT;
		} else {
			return ew_FormatDateTime(DateTime.Now, 9);
		}		
	}

	// Get current date in default date format with
	// Current time in hh:mm:ss format
	public static string ew_CurrentDateTime() {
		return ew_CurrentDateTime(-1);	
	}

	// Remove XSS
	public static string ew_RemoveXSS(object val)
	{

		// Handle null value
		if (val == null)
			return null;

		// Remove all non-printable characters. CR(0a) and LF(0b) and TAB(9) are allowed 
		// This prevents some character re-spacing such as <java\0script> 
		// Note that you have to handle splits with \n, \r, and \t later since they *are* allowed in some inputs

		Regex regEx = new Regex("([\\x00-\\x08][\\x0b-\\x0c][\\x0e-\\x20])", RegexOptions.IgnoreCase);

		// Create regular expression.
		val = regEx.Replace(Convert.ToString(val), "");

		// Straight replacements, the user should never need these since they're normal characters 
		// This prevents like <IMG SRC=&#X40&#X61&#X76&#X61&#X73&#X63&#X72&#X69&#X70&#X74&#X3A&#X61&#X6C&#X65&#X72&#X74&#X28&#X27&#X58&#X53&#X53&#X27&#X29> 

		var search = "abcdefghijklmnopqrstuvwxyz";
		search += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		search += "1234567890!@#$%^&*()";
		search += "~`\";:?+/={}[]-_|'\\";
		for (int i = 0; i <= search.Length - 1; i++) {

			// ;? matches the ;, which is optional 
			// 0{0,7} matches any padded zeros, which are optional and go up to 8 chars 
			// &#x0040 @ search for the hex values

			regEx = new Regex("(&#[x|X]0{0,8}" + Conversion.Hex(Strings.Asc(search[i])) + ";?)");

			// With a ;
			val = regEx.Replace(Convert.ToString(val), Convert.ToString(search[i]));

			// &#00064 @ 0{0,7} matches '0' zero to seven times
			regEx = new Regex("(&#0{0,8}" + Strings.Asc(search[i]) + ";?)");

			// With a ;
			val = regEx.Replace(Convert.ToString(val), Convert.ToString(search[i]));
		}

		// Now the only remaining whitespace attacks are \t, \n, and \r
		bool Found = true;
		string val_before, pattern, replacement;

		// Keep replacing as long as the previous round replaced something 
		while (Found) {
			val_before = Convert.ToString(val);
			for (int i = 0; i <= EW_REMOVE_XSS_KEYWORDS.GetUpperBound(0); i++) {
				pattern = "";
				for (int j = 0; j <= EW_REMOVE_XSS_KEYWORDS[i].Length - 1; j++) {
					if (j > 0) {
						pattern = pattern + "(";
						pattern = pattern + "(&#[x|X]0{0,8}([9][a][b]);?)?";
						pattern = pattern + "|(&#0{0,8}([9][10][13]);?)?";
						pattern = pattern + ")?";
					}
					pattern = pattern + EW_REMOVE_XSS_KEYWORDS[i][j];
				}
				replacement = EW_REMOVE_XSS_KEYWORDS[i].Substring(0, 2) + "<x>" + EW_REMOVE_XSS_KEYWORDS[i].Substring(2);

				// Add in <> to nerf the tag
				regEx = new Regex(pattern);
				val = regEx.Replace(Convert.ToString(val), replacement);

				// Filter out the hex tags
				if (ew_SameStr(val_before, val)) {

					// No replacements were made, so exit the loop
					Found = false;
				}
			}
		}
		return Convert.ToString(val);
	}

	// Check token
	public static bool ew_CheckToken(string t) {
		var timeout = ew_Session.Timeout;
		if (timeout <= 0)
			timeout = 20;
		return (DateTime.Now.Ticks - ew_ConvertToInt64(ew_Decrypt(t))) < timeout * 60 * Math.Pow(10, 7);
	}

	// Create token
	public static string ew_CreateToken() {
		return ew_Encrypt(DateTime.Now.Ticks);
	}

	// Highlight keywords
	public static string ew_Highlight(string name, object src, string bkw, string bkwtype, string akw = "", string akw2 = "")
	{
		string outstr = "";
		if (ew_NotEmpty(src) && (ew_NotEmpty(bkw) || ew_NotEmpty(akw) || ew_NotEmpty(akw2))) {
			string kw = "", kwstr = "";
			int x = 0, y = 0, xx = 0;
			var srcstr = Convert.ToString(src);
			var yy = srcstr.IndexOf("<", xx);
			if (yy < 0) yy = srcstr.Length; 
			while (yy >= 0) {
				if (yy > xx) {
					var wrksrc = srcstr.Substring(xx, yy - xx);
					kwstr = bkw.Trim();					
					List<string> kwlist;
					if (bkw.Length > 0 && bkwtype.Length == 0) { // Check for exact phase
						kwlist = new List<string>() {kwstr}; // Use single array element
					} else {
						while (kwstr.Contains("  "))
							kwstr = kwstr.Replace("  ", " ");	
						kwlist = new List<string>(kwstr.Split(new char[] {' '}));
					}
					if (ew_NotEmpty(akw))
						kwlist.Add(akw.Trim());
					if (ew_NotEmpty(akw2))
						kwlist.Add(akw2.Trim());
					x = 0;
					ew_GetKeyword(wrksrc, kwlist, x, ref y, ref kw);
					while (y >= 0) {
						outstr += wrksrc.Substring(x, y - x) + "<span class=\"" + name + " ewHighlightSearch\">" + wrksrc.Substring(y, kw.Length) + "</span>";
						x = y + kw.Length;
						ew_GetKeyword(wrksrc, kwlist, x, ref y, ref kw);
					}
					outstr += wrksrc.Substring(x);
					xx += wrksrc.Length;
				}
				if (xx < srcstr.Length) {
					yy = srcstr.IndexOf(">", xx);
					if (yy >= 0) {
						outstr += srcstr.Substring(xx, yy - xx + 1);
						xx = yy + 1;
						yy = srcstr.IndexOf("<", xx);
						if (yy < 0) yy = srcstr.Length; 
					} else {
						outstr += srcstr.Substring(xx);
						yy = -1;
					}
				} else {
					yy = -1;
				}
			}
		} else {
			outstr = Convert.ToString(src);
		}
		return outstr;
	}

	// Get keyword
	public static void ew_GetKeyword(string src, List<string> kwlist, int x, ref int y, ref string kw)
	{
		int wrky, thisy = -1;
		string thiskw = "";
		foreach (var wrkkw in kwlist) {
			if (ew_NotEmpty(wrkkw)) {
				if (EW_HIGHLIGHT_COMPARE) {	// Case-insensitive
					wrky = src.IndexOf(wrkkw, x, StringComparison.InvariantCultureIgnoreCase);
				} else {
					wrky = src.IndexOf(wrkkw, x);
				}
				if (wrky > -1) {
					if (thisy == -1) {
						thisy = wrky;
						thiskw = wrkkw;
					} else if (wrky < thisy) {
						thisy = wrky;
						thiskw = wrkkw;
					}
				}
			}
		}
		y = thisy;
		kw = thiskw;
	}

	//
	// Security shortcut functions
	//
	// Get current user name
	public static string CurrentUserName()
	{
		return Convert.ToString(ew_Session[EW_SESSION_USER_NAME]);
	}

	// Get current user ID
	public static string CurrentUserID()
	{
		return Convert.ToString(ew_Session[EW_SESSION_USER_ID]);
	}

	// Get current parent user ID
	public static string CurrentParentUserID()
	{
		return Convert.ToString(ew_Session[EW_SESSION_PARENT_USER_ID]);
	}

	// Get current user level
	public static int CurrentUserLevel()
	{
		return Convert.ToInt32(ew_Session[EW_SESSION_USER_LEVEL_ID]);
	}

	// Get current page ID
	public static string CurrentPageID()
	{
		return (CurrentPage != null) ? CurrentPage.PageID : "";
	}	

	// Check if user password expired
	public static bool IsPasswordExpired()
	{
		return ew_SameStr(ew_Session[EW_SESSION_STATUS], "passwordexpired");
	}

	// Check if user is logging in (after changing password)
	public static bool IsLoggingIn()
	{
		return ew_SameStr(ew_Session[EW_SESSION_STATUS], "loggingin");
	}	

	// Is Logged In
	public static bool IsLoggedIn()
	{
		return ew_SameStr(ew_Session[EW_SESSION_STATUS], "login");
	}

	// Is System Admin
	public static bool IsSysAdmin()
	{
		return ew_ConvertToInt(ew_Session[EW_SESSION_SYS_ADMIN]) == 1;
	}

	// Is Admin
	public static bool IsAdmin()
	{
		return IsSysAdmin() || (Security != null && Security.IsAdmin);
	}

	// Current master table object
	public static dynamic CurrentMasterTable {
		get {
			if (CurrentPage != null) {
				string MasterTableName = CurrentPage.CurrentMasterTable;
				if (ew_NotEmpty(MasterTableName) && ew_PageData[MasterTableName] != null)
					return (dynamic)ew_PageData[MasterTableName];
			}
			return null;
		}
	}	

	// Get current project ID
	public static string CurrentProjectID() {
		if (CurrentPage != null)
			return CurrentPage.ProjectID;
		return EW_PROJECT_ID;
	}

	// Get WebMatrix.Data.Database (Note: Does not work with Npgsql)
	public static Database ew_Database() {
		return Database.OpenConnectionString(EW_DB_CONNECTION_STRING, EW_DB_PROVIDER_NAME);
	}

	// Get IEnumerable<Object> using WebMatrix.Data.Database.Query
	public static IEnumerable<Object> ew_Query(string commandText, params Object[] parameters) {
		var db = ew_Database();
		return (db != null) ? db.Query(commandText, parameters) : null;
	}

	// Encrypt
	public static string ew_Encrypt(object Data, string Key)
	{	
		if (ew_Empty(Data))
			return "";
		byte[] Results = {};
		try {
			System.Text.UTF8Encoding UTF8 = new System.Text.UTF8Encoding();
			MD5CryptoServiceProvider HashProvider = new MD5CryptoServiceProvider();
			byte[] TDESKey = HashProvider.ComputeHash(UTF8.GetBytes(Key));
			TripleDESCryptoServiceProvider TDESAlgorithm = new TripleDESCryptoServiceProvider();
			TDESAlgorithm.Key = TDESKey;
			TDESAlgorithm.Mode = CipherMode.ECB;
			TDESAlgorithm.Padding = PaddingMode.PKCS7;		
			try {
				byte[] DataToEncrypt = UTF8.GetBytes(Convert.ToString(Data));
				ICryptoTransform Encryptor = TDESAlgorithm.CreateEncryptor();
				Results = Encryptor.TransformFinalBlock(DataToEncrypt, 0, DataToEncrypt.Length);
			} finally {                
				TDESAlgorithm.Clear();
				HashProvider.Clear();
			}
		} catch {}
		return Convert.ToBase64String(Results).Replace("+", "_2B").Replace("/", "_2F").Replace("=", "_2E");		
	}

	// Encrypt
	public static string ew_Encrypt(object Data)
	{
		return ew_Encrypt(Data, EW_RANDOM_KEY); 	
	}

	// Decrypt
	public static string ew_Decrypt(object Data, string Key)
	{
		if (ew_Empty(Data))
			return "";
		byte[] Results = {};
		System.Text.UTF8Encoding UTF8 = new System.Text.UTF8Encoding();
		try {			
			MD5CryptoServiceProvider HashProvider = new MD5CryptoServiceProvider();
			byte[] TDESKey = HashProvider.ComputeHash(UTF8.GetBytes(Key));
			TripleDESCryptoServiceProvider TDESAlgorithm = new TripleDESCryptoServiceProvider();
			TDESAlgorithm.Key = TDESKey;
			TDESAlgorithm.Mode = CipherMode.ECB;
			TDESAlgorithm.Padding = PaddingMode.PKCS7;
			string sData = Convert.ToString(Data).Replace("_2B", "+").Replace("_2F", "/").Replace("_2E", "=");		
			try {
				byte[] DataToDecrypt = Convert.FromBase64String(sData);
				ICryptoTransform Decryptor = TDESAlgorithm.CreateDecryptor();
				Results = Decryptor.TransformFinalBlock(DataToDecrypt, 0, DataToDecrypt.Length);
			} finally {
				TDESAlgorithm.Clear();
				HashProvider.Clear();
			}
		} catch {}
		return UTF8.GetString(Results);
	}

	// Decrypt
	public static string ew_Decrypt(object Data)
	{
		return ew_Decrypt(Data, EW_RANDOM_KEY);
	}	

	// Save binary to file
	public static bool ew_SaveFile(string folder, string fn, ref byte[] filedata)
	{
		if (ew_CreateFolder(folder)) {
			try {
				File.WriteAllBytes(ew_IncludeTrailingDelimiter(folder, true) + fn, filedata);				
				return true;
			} catch {
				if (EW_DEBUG_ENABLED) throw; 
				return false;
			}
		}
		return false;
	}

	// Get image content type
	public static string ew_GetImageContentType(string fn)
	{	
		string ext = Path.GetExtension(fn).Replace(".", "").ToLower();
		if (ext == "gif") { // gif
			return "image/gif";
		} else if (ext == "jpg" || ext == "jpeg" || ext == "jpe") { // jpg
			return "image/jpeg";
		} else if (ext == "png") { // png
			return "image/png";
		} else {
			return "image/bmp";
		}
	}

	// Read global debug message
	public static string ew_DebugMsg() {
		var msg = Regex.Replace(gsDebugMsg, @"^<br>\n", "");
		gsDebugMsg = "";
		return (ew_NotEmpty(msg)) ? "<div class=\"alert alert-info ewAlert\">" + msg + "</div>" : "";
	}

	// Write global debug message
	public static void ew_SetDebugMsg(string v) {
		var msg = gsDebugMsg;
		ew_AddMessage(ref msg, v);
		gsDebugMsg = msg;
	}	

	//
	//  Language class
	//
	public class cLanguage : IDisposable
	{

		public string LanguageId;

		public XmlDocument objDOM;

		public StringDictionary Col; // Note: key is case-insensitive.

		public string LanguageFolder = EW_RELATIVE_PATH + EW_LANGUAGE_FOLDER; // ASPX	

		// Constructor
		public cLanguage(string langfolder = "", string langid = "")
		{
			if (ew_NotEmpty(langfolder))
				LanguageFolder = langfolder;

			// Set up file list
			LoadFileList();

			// Set up language id
			if (ew_NotEmpty(langid)) { // Set up language id
				LanguageId = langid;
				ew_Session[EW_SESSION_LANGUAGE_ID] = LanguageId;
			} else if (ew_NotEmpty(ew_Get("language"))) {
				LanguageId = ew_Get("language");
				ew_Session[EW_SESSION_LANGUAGE_ID] = LanguageId;
			} else if (ew_NotEmpty(ew_Session[EW_SESSION_LANGUAGE_ID])) {
				LanguageId = Convert.ToString(ew_Session[EW_SESSION_LANGUAGE_ID]);
			} else {
				LanguageId = EW_LANGUAGE_DEFAULT_ID;
			}
			gsLanguage = LanguageId;
			Load(LanguageId);
		}

		// Terminate
		public void Dispose()
		{
			objDOM = null;
		}

		// Load language file list
		private void LoadFileList()
		{
			if (ew_IsList(EW_LANGUAGE_FILE)) {
				for (int i = 0; i < EW_LANGUAGE_FILE.Count; i++)
					EW_LANGUAGE_FILE[i][1] = LoadFileDesc(ew_MapPath(LanguageFolder + EW_LANGUAGE_FILE[i][2])); // ASPX
			}
		}

		// Load language file description
		private string LoadFileDesc(string File)
		{
			var xmlr = new XmlTextReader(File);
			xmlr.WhitespaceHandling = WhitespaceHandling.None;
			try {
				while (!xmlr.EOF) {
					xmlr.Read();
					if (xmlr.IsStartElement() && xmlr.Name == "ew-language")
						return xmlr.GetAttribute("desc");
				}
			} finally {
				xmlr.Close();
			}
			return "";
		}

		// Load language file
		private void Load(string id)
		{
			string sFileName = GetFileName(id);
			if (ew_Empty(sFileName))
				sFileName = GetFileName(EW_LANGUAGE_DEFAULT_ID);
			if (ew_Empty(sFileName)) return; 
			if (EW_USE_DOM_XML) {
				objDOM = new XmlDocument();
				objDOM.Load(sFileName);
			} else {
				if (ew_Session[EW_PROJECT_NAME + "_" + sFileName] != null) {
					Col = (StringDictionary)ew_Session[EW_PROJECT_NAME + "_" + sFileName];
				} else {
					Col = new StringDictionary();
					XmlToCollection(sFileName);
					ew_Session[EW_PROJECT_NAME + "_" + sFileName] = Col;
				}
			}

			// Set up locale / currency format for language
			if (LocalePhrase("use_system_locale") == "0") {
				EW_USE_SYSTEM_LOCALE = false;
				EW_DECIMAL_POINT = LocalePhrase("decimal_point");
				EW_THOUSANDS_SEP = LocalePhrase("thousands_sep");
				EW_CURRENCY_SYMBOL = LocalePhrase("currency_symbol");
			}		
		}

		// Convert XML to Collection
		private void XmlToCollection(string File)
		{
			string Key = "/";
			var OldKey = new List<string>();
			int Index;
			var xmlr = new XmlTextReader(File);
			xmlr.WhitespaceHandling = WhitespaceHandling.None;
			try {
				while (!xmlr.EOF) {
					xmlr.Read();
					string Name = xmlr.Name;
					string Id = xmlr.GetAttribute("id");
					if (Name == "ew-language")
						continue; 
					switch (xmlr.NodeType) {
						case XmlNodeType.Element:
							if (xmlr.IsStartElement() && !xmlr.IsEmptyElement) {
								OldKey.Add(Key);
								Key += Name + "/";
								if (Id != null)
									Key += Id + "/"; 
							}
							if (Id != null && xmlr.IsEmptyElement) { // phrase
								Id = Name + "/" + Id;
								Col[Key + Id + "/imageurl"] = (xmlr.GetAttribute("imageurl") != null) ? xmlr.GetAttribute("imageurl") : "";
								Col[Key + Id + "/imagewidth"] = (xmlr.GetAttribute("imagewidth") != null) ? xmlr.GetAttribute("imagewidth") : "";
								Col[Key + Id + "/imageheight"] = (xmlr.GetAttribute("imageheight") != null) ? xmlr.GetAttribute("imageheight") : "";
								Col[Key + Id + "/class"] = (xmlr.GetAttribute("class") != null) ? xmlr.GetAttribute("class") : "";
								if (xmlr.GetAttribute("client") == "1")
									Id += "/1"; 
								Col[Key + Id] = xmlr.GetAttribute("value");
							}
							break;
						case XmlNodeType.EndElement:
							Key = OldKey.Last();
							OldKey.RemoveAt(OldKey.Count - 1);								
							break;
					}
				}
			} finally {
				xmlr.Close();
			}
		}

		// Get language file name
		private string GetFileName(string Id)
		{
			if (ew_IsList(EW_LANGUAGE_FILE)) {
				foreach (string[] langfile in EW_LANGUAGE_FILE) {
					if (langfile[0] == Id)
						return ew_MapPath(LanguageFolder + langfile[2]);
				}
			}
			return "";
		}

		// Get node attribute
		private string GetNodeAtt(XmlNode Node, string Att)
		{
			if (Node != null) {
				return ((XmlElement)Node).GetAttribute(Att);
			} else {
				return "";
			}
		}

		// Set node attribute
		private void SetNodeAtt(XmlNode Node, string Att, string Value)
		{
			if (Node != null)
				((XmlElement)Node).SetAttribute(Att, Value);
		}

		// Get phrase
		public string LocalePhrase(string Id)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//locale/phrase[@id='" + Id + "']"), "value");
			} else {
				if (Col.ContainsKey("/locale/phrase/" + Id)) {
					return Col["/locale/phrase/" + Id];
				} else if (Col.ContainsKey("/locale/phrase/" + Id + "/1")) {
					return Col["/locale/phrase/" + Id + "/1"];
				} else {
					return "";
				}
			}
		}

		// Set locale phrase
		public void SetLocalePhrase(string Id, string Value)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//locale/phrase[@id='" + Id + "']"), "value", Value);
			} else {
				if (Col.ContainsKey("/locale/phrase/" + Id)) {
					Col["/locale/phrase/" + Id] = Value;
				} else if (Col.ContainsKey("/locale/phrase/" + Id + "/1")) {
					Col["/locale/phrase/" + Id + "/1"] = Value;
				}
			}
		}

		// Get phrase
		private string _Phrase(string Id, string attr)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//global/phrase[@id='" + Id + "']"), attr);
			} else {
				Id = (attr == "value") ? Id : Id + "/" + attr;
				if (Col.ContainsKey("/global/phrase/" + Id)) {
					return Col["/global/phrase/" + Id];
				} else if (Col.ContainsKey("/global/phrase/" + Id + "/1")) {
					return Col["/global/phrase/" + Id + "/1"];
				} else {
					return "";
				}
			}
		}			

		// Get phrase
		public string Phrase(string Id, bool UseText = false)
		{	
			var ImageUrl = _Phrase(Id, "imageurl");
			var ImageWidth = _Phrase(Id, "imagewidth");
			var ImageHeight = _Phrase(Id, "imageheight");
			var ImageClass = _Phrase(Id, "class");
			var Text = _Phrase(Id, "value");
			if (!UseText && ImageClass != "") {
				return "<span data-phrase=\"" + Id + "\" class=\"" + ImageClass + "\" data-caption=\"" + ew_HtmlEncode(Text) + "\"></span>";
			} else if (!UseText && ImageUrl != "") {
				var style = (ImageWidth != "") ? " width: " + ImageWidth + "px;" : "";
				style += (ImageHeight != "") ? " height: " + ImageHeight + "px;" : "";
				return "<img data-phrase=\"" + Id + "\" src=\"" + ew_HtmlEncode(ImageUrl) + "\" style=\"" + style.Trim() + "\" alt=\"" + ew_HtmlEncode(Text) + "\" title=\"" + ew_HtmlEncode(Text) + "\">";
			} else {
				return Text;
			}
		}

		// Set phrase
		public void SetPhrase(string Id, string Value)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//global/phrase[@id='" + Id + "']"), "value", Value);
			} else {
				if (Col.ContainsKey("/global/phrase/" + Id)) {
					Col["/global/phrase/" + Id] = Value;
				} else if (Col.ContainsKey("/global/phrase/" + Id + "/1")) {
					Col["/global/phrase/" + Id + "/1"] = Value;
				}
			}
		}

		// Get project phrase
		public string ProjectPhrase(string Id)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//project/phrase[@id='" + Id + "']"), "value");
			} else {
				Id = "/project/phrase/" + Id; 
				return Col.ContainsKey(Id) ? Col[Id] : "";
			}
		}

		// Set project phrase
		public void SetProjectPhrase(string Id, string Value)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//project/phrase[@id='" + Id + "']"), "value", Value);
			} else {
				Col["/project/phrase/" + Id] = Value;
			}
		}

		// Get menu phrase
		public string MenuPhrase(string MenuId, string Id)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//project/menu[@id='" + MenuId.ToLower() + "']/phrase[@id='" + Id + "']"), "value");
			} else {
				Id = "/project/menu/" + MenuId.ToLower() + "/phrase/" + Id;
				return Col.ContainsKey(Id) ? Col[Id] : "";
			}
		}

		// Set menu phrase
		public void SetMenuPhrase(string MenuId, string Id, string Value)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//project/menu[@id='" + MenuId.ToLower() + "']/phrase[@id='" + Id + "']"), "value", Value);
			} else {
				Col["/project/menu/" + MenuId.ToLower() + "/phrase/" + Id] = Value;
			}
		}

		// Get table phrase
		public string TablePhrase(string TblVar, string Id)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//project/table[@id='" + TblVar.ToLower() + "']/phrase[@id='" + Id + "']"), "value");
			} else {
				return Col["/project/table/" + TblVar.ToLower() + "/phrase/" + Id];
			}
		}

		// Set table phrase
		public void SetTablePhrase(string TblVar, string Id, string Value)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//project/table[@id='" + TblVar.ToLower() + "']/phrase[@id='" + Id + "']"), "value", Value);
			} else {
				Col["/project/table/" + TblVar.ToLower() + "/phrase/" + Id] = Value;
			}
		}

		// Get field phrase
		public string FieldPhrase(string TblVar, string FldVar, string Id)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//project/table[@id='" + TblVar.ToLower() + "']/field[@id='" + FldVar.ToLower() + "']/phrase[@id='" + Id + "']"), "value");
			} else {
				Id = "/project/table/" + TblVar.ToLower() + "/field/" + FldVar.ToLower() + "/phrase/" + Id;
				return Col.ContainsKey(Id) ? Col[Id] : "";
			}
		}

		// Set field phrase
		public void SetFieldPhrase(string TblVar, string FldVar, string Id, string Value)
		{
			Id = Id.ToLower();
			if (EW_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//project/table[@id='" + TblVar.ToLower() + "']/field[@id='" + FldVar.ToLower() + "']/phrase[@id='" + Id + "']"), "value", Value);	
			} else {
				Col["/project/table/" + TblVar.ToLower() + "/field/" + FldVar.ToLower() + "/phrase/" + Id] = Value;
			}
		}

		// Output XML as JSON
		public string XmlToJSON(string XPath)
		{
			XmlNodeList NodeList = objDOM.SelectNodes(XPath);
			string Str = "{";
			foreach (XmlNode Node in NodeList) {
				string Id = GetNodeAtt(Node, "id");
				string Value = GetNodeAtt(Node, "value");
				Str += "\"" + ew_JsEncode2(Id) + "\":\"" + ew_JsEncode2(Value) + "\",";
			}
			if (Str.EndsWith(","))
				Str = Str.Substring(0, Str.Length - 1); 
			Str += "}\r\n";
			return Str;
		}

		// Output collection as JSON
		public string CollectionToJSON(string Prefix, string Suffix)
		{
			string Id;
			int Pos;
			string Str = "{";
			foreach (string Name in Col.Keys) {
				if (Name.StartsWith(Prefix)) {
					if (ew_NotEmpty(Suffix) && Name.EndsWith(Suffix)) {
						Pos = Name.LastIndexOf(Suffix);
						Id = Name.Substring(Prefix.Length, Pos - Prefix.Length);
					} else {
						Id = Name.Substring(Prefix.Length);
					}
					Str += "\"" + ew_JsEncode2(Id) + "\":\"" + ew_JsEncode2(Col[Name]) + "\",";
				}
			}
			if (Str.EndsWith(","))
				Str = Str.Substring(0, Str.Length - 1); 
			Str += "}\r\n";
			return Str;
		}

		// Output all phrases as JSON
		public string AllToJSON()
		{
			if (EW_USE_DOM_XML) {
				return "var ewLanguage = new ew_Language(" + XmlToJSON("//global/phrase") + ");";
			} else {
				return "var ewLanguage = new ew_Language(" + CollectionToJSON("/global/phrase/", "") + ");";
			}
		}

		// Output client phrases as JSON
		public string ToJSON()
		{
			if (EW_USE_DOM_XML) {
				return "var ewLanguage = new ew_Language(" + XmlToJSON("//global/phrase[@client='1']") + ");";
			} else {
				return "var ewLanguage = new ew_Language(" + CollectionToJSON("/global/phrase/", "/1") + ");";
			}
		}

		// Output language selection form
		public string SelectionForm() {
			string form = "";
			int cnt = EW_LANGUAGE_FILE.Count;
			if (cnt > 1) {
				for (int i = 0; i < cnt; i++) {
					string langid = EW_LANGUAGE_FILE[i][0];
					string langphrase = EW_LANGUAGE_FILE[i][1];
					string selected = (langid == gsLanguage) ? " selected=\"selected\"" : "";
					string phrase = Phrase(langid);
					if (phrase == "") // Use description for button
						phrase = langphrase;
					form += "<option value=\"" + langid + "\"" + selected + ">" + phrase + "</option>";
				}
			}
			if (form != "")
				form = "<div class=\"ewLanguageOption\"><select class=\"form-control\" id=\"ewLanguage\" name=\"ewLanguage\" onchange=\"ew_SetLanguage(this);\">" + form + "</select></div>";
			return form;
		}
	}

	//
	//  XML document class
	//
	public class cXMLDocument : IDisposable
	{

		public string Encoding = "";
		string RootTagName = "table";
		string SubTblName = "";
		string RowTagName = "row";
		XmlDocument XmlDoc;
		XmlElement XmlTbl;
		XmlElement XmlSubTbl;
		XmlElement XmlRow;
		XmlElement XmlFld;

		// Constructor
		public cXMLDocument()
		{
			XmlDoc = new XmlDocument();
		}

		public XmlDocument Load(string phyfile) {
			if (File.Exists(phyfile)) {
				XmlDoc.Load(phyfile);
				return XmlDoc;
			}
			return null;
		}

		public XmlElement DocumentElement {
			get {
				return (XmlDoc != null) ? XmlDoc.DocumentElement : null;
			}
		}

		public string GetAttribute(ref XmlElement element, string name) {
			return (element != null) ? element.GetAttribute(name) : "";
		}

		public void SetAttribute(ref XmlElement element, string name, string value) {
			if (element != null)
				element.SetAttribute(name, value);
	    }

		public XmlElement SelectSingleNode(string query) {
			var node = XmlDoc.SelectSingleNode(query);
			return (node != null) ? (XmlElement)node : null;
		}

		public XmlNodeList SelectNodes(string query) {
			return XmlDoc.SelectNodes(query);
		}

		// Add root
		public void AddRoot(string rootname)
		{
			RootTagName = ew_XmlTagName(rootname);
			XmlTbl = XmlDoc.CreateElement(RootTagName);
			XmlDoc.AppendChild(XmlTbl);
		}

		// Add row
		public void AddRow(string tablename = "", string rowname = "")
		{
			if (ew_NotEmpty(rowname))
				RowTagName = ew_XmlTagName(rowname);
			XmlRow = XmlDoc.CreateElement(RowTagName);
			if (ew_Empty(tablename)) {
				if (XmlTbl != null)
					XmlTbl.AppendChild(XmlRow);
			} else {
				if (ew_Empty(SubTblName) || !ew_SameStr(SubTblName, tablename)) {
					SubTblName = ew_XmlTagName(tablename);
					XmlSubTbl = XmlDoc.CreateElement(SubTblName);
					XmlTbl.AppendChild(XmlSubTbl);
				}
				if (XmlSubTbl != null)
					XmlSubTbl.AppendChild(XmlRow);
			}
		}

		// Add row by name
		public void AddRowEx(string Name)
		{
			XmlRow = XmlDoc.CreateElement(Name);
			XmlTbl.AppendChild(XmlRow);
		}

		// Add field
		public void AddField(string name, object value)
		{
			XmlFld = XmlDoc.CreateElement(ew_XmlTagName(name));
			XmlRow.AppendChild(XmlFld);
			XmlFld.AppendChild(XmlDoc.CreateTextNode(Convert.ToString(value)));
		}

		// XML
		public string XML()
		{
			return XmlDoc.OuterXml;
		}

		// Output
		public void Output()
		{
			ew_Response.Clear(); 
			ew_Response.ContentType = "text/xml";
			string PI = "<?xml version=\"1.0\"";
			if (ew_NotEmpty(Encoding))
				PI += " encoding=\"" + Encoding + "\"";
			PI += " ?>";
			ew_Write(PI + XmlDoc.OuterXml);
		}

		// Output XML for debug
		public void Print()
		{
			ew_Response.Clear(); 
			ew_Response.ContentType = "text/plain";
			ew_Write(ew_HtmlEncode(XmlDoc.OuterXml));
		}

		// Terminate
		public void Dispose()
		{
			XmlFld = null;
			XmlRow = null;
			XmlTbl = null;
			XmlDoc = null;
		}
	}

	//
	// Email class
	//
	public class cEmail
	{

		public string Sender = ""; // Sender		

		public string Recipient = ""; // Recipient		

		public string Cc = ""; // Cc		

		public string Bcc = ""; // Bcc		

		public string Subject = ""; // Subject		

		public string Format = ""; // Format		

		public string Content = ""; // Content

		//public string AttachmentContent = ""; // Attachement content
		//public string AttachmentFileName = ""; // Attachment file name
		public List<string> Attachments = new List<string>(); // Attachments

		public List<string> EmbeddedImages = new List<string>(); // Embedded image

		public string Charset = ""; // Charset

		public string SendErrNumber = ""; // Send error number

		public string SendErrDescription = ""; // Send error description

		public bool EnableSsl = ew_SameText(EW_SMTP_SECURE_OPTION, "SSL"); // Send secure option

		public System.Net.Mail.SmtpClient Mailer = null;

		// Load email from template
		public void Load(string fn)
		{
			string sWrk = ew_LoadTxt(fn);

			// Load text file content
			sWrk = sWrk.Replace("\r\n", "\n");

			// Convert to Lf
			sWrk = sWrk.Replace("\r", "\n");

			// Convert to Lf
			if (ew_NotEmpty(sWrk)) {
				int i = sWrk.IndexOf("\n" + "\n");

				// Locate header and mail content
				if (i > 0) {
					string sHeader = sWrk.Substring(0, i + 1);
					Content = sWrk.Substring(i + 2);
					string[] arrHeader = sHeader.Split(new char[] {'\n'});
					for (int j = 0; j <= arrHeader.GetUpperBound(0); j++) {
						i = arrHeader[j].IndexOf(":");
						if (i > 0) {
							string sName = arrHeader[j].Substring(0, i).Trim();
							string sValue = arrHeader[j].Substring(i + 1).Trim();
							switch (sName.ToLower()) {
								case "subject":
									Subject = sValue;
									break;
								case "from":
									Sender = sValue;
									break;
								case "to":
									Recipient = sValue;
									break;
								case "cc":
									Cc = sValue;
									break;
								case "bcc":
									Bcc = sValue;
									break;
								case "format":
									Format = sValue;
									break;
							}
						}
					}
				}
			}
		}

		// Replace sender
		public void ReplaceSender(string ASender)
		{
			Sender = Sender.Replace("<!--$From-->", ASender);
		}

		// Replace recipient
		public void ReplaceRecipient(string ARecipient)
		{
			Recipient = Recipient.Replace("<!--$To-->", ARecipient);
		}

		// Add cc email
		public void AddCc(string ACc)
		{
			if (ew_NotEmpty(ACc)) {
				if (ew_NotEmpty(Cc)) Cc = Cc + ";"; 
				Cc = Cc + ACc;
			}
		}

		// Add bcc email
		public void AddBcc(string ABcc)
		{
			if (ew_NotEmpty(ABcc)) {
				if (ew_NotEmpty(Bcc)) Bcc = Bcc + ";"; 
				Bcc = Bcc + ABcc;
			}
		}

		// Replace subject
		public void ReplaceSubject(string ASubject)
		{
			Subject = Subject.Replace("<!--$Subject-->", ASubject);
		}

		// Replace content
		public void ReplaceContent(string Find, string ReplaceWith)
		{
			Content = Content.Replace(Find, ReplaceWith);
		}

		// Method to add embedded image
		public void AddEmbeddedImage(string image) {
			if (ew_NotEmpty(image))
				EmbeddedImages.Add(image);
		}

		// Method to add attachment
		public void AddAttachment(string filename) {
			if (ew_NotEmpty(filename))
				Attachments.Add(filename);
		}

		// Send email
		public bool Send()
		{
			bool bSend = ew_SendEmail(Sender, Recipient, Cc, Bcc, Subject, Content, Format, Charset, EnableSsl, Attachments, EmbeddedImages, Mailer);
			if (!bSend)
				SendErrDescription = gsEmailErrDesc; // Send error description
			return bSend;
		}
	}

	//
	// Class for Pager item
	//
	public class cPagerItem
	{

		public string Text;

		public int Start;

		public bool Enabled;

		// Constructor
		public cPagerItem(int AStart, string AText, bool AEnabled)
		{
			Text = AText;
			Start = AStart;
			Enabled = AEnabled;
		}

		// Constructor
		public cPagerItem()
		{

			// Do nothing
		}
	}

	//
	// Class for PrevNext pager
	//
	public class cPager
	{

		public cPagerItem NextButton;

		public cPagerItem FirstButton;

		public cPagerItem PrevButton;

		public cPagerItem LastButton;

		public int PageSize;		

		public int FromIndex;

		public int ToIndex;

		public int RecordCount;

		public bool Visible;
	}

	//
	// Class for Numeric pager
	//
	public class cNumericPager : cPager
	{

		public List<cPagerItem> Items = new List<cPagerItem>();

		public int Range;

		public int ButtonCount = 0;

		// Constructor
		public cNumericPager(int AFromIndex, int APageSize, int ARecordCount, int ARange)
		{
			FromIndex = AFromIndex;
			PageSize = APageSize;
			RecordCount = ARecordCount;
			Range = ARange;
			FirstButton = new cPagerItem();
			PrevButton = new cPagerItem();
			NextButton = new cPagerItem();
			LastButton = new cPagerItem();
			Visible = true;
			Init();
		}

		// Init pager
		public void Init()
		{
			if (FromIndex > RecordCount) FromIndex = RecordCount; 
			ToIndex = FromIndex + PageSize - 1;
			if (ToIndex > RecordCount) ToIndex = RecordCount; 
			SetupNumericPager();

			// Update button count
			if (FirstButton.Enabled) ButtonCount++;
            if (PrevButton.Enabled) ButtonCount++;
            if (NextButton.Enabled) ButtonCount++;
            if (LastButton.Enabled) ButtonCount++; 
		}

		// Add pager item
		private void AddPagerItem(int StartIndex, string Text, bool Enabled)
		{
			Items.Add(new cPagerItem(StartIndex, Text, Enabled));
		}

		// Setup pager items
		private void SetupNumericPager()
		{
			bool HasPrev;
			bool NoNext;
			int dy2;
			int dx2;
			int y;
			int x;
			int dx1;
			int dy1;
			int ny;
			int TempIndex;
			if (RecordCount > PageSize) {
				NoNext = (RecordCount < (FromIndex + PageSize));
				HasPrev = (FromIndex > 1);

				// First Button
				TempIndex = 1;
				FirstButton.Start = TempIndex;
				FirstButton.Enabled = (FromIndex > TempIndex);

				// Prev Button
				TempIndex = FromIndex - PageSize;
				if (TempIndex < 1) TempIndex = 1; 
				PrevButton.Start = TempIndex;
				PrevButton.Enabled = HasPrev;

				// Page links
				if (HasPrev | !NoNext) {
					x = 1;
					y = 1;
					dx1 = ((FromIndex - 1) / (PageSize * Range)) * PageSize * Range + 1;
					dy1 = ((FromIndex - 1) / (PageSize * Range)) * Range + 1;
					if ((dx1 + PageSize * Range - 1) > RecordCount) {
						dx2 = (RecordCount / PageSize) * PageSize + 1;
						dy2 = (RecordCount / PageSize) + 1;
					} else {
						dx2 = dx1 + PageSize * Range - 1;
						dy2 = dy1 + Range - 1;
					}
					while (x <= RecordCount) {
						if (x >= dx1 & x <= dx2) {
							AddPagerItem(x, Convert.ToString(y), FromIndex != x);
							x = x + PageSize;
							y = y + 1;
						}
else if (x >= (dx1 - PageSize * Range) & x <= (dx2 + PageSize * Range)) {
							if (x + Range * PageSize < RecordCount) {
								AddPagerItem(x, y + "-" + (y + Range - 1), true);
							} else {
								ny = (RecordCount - 1) / PageSize + 1;
								if (ny == y) {
									AddPagerItem(x, Convert.ToString(y), true);
								} else {
									AddPagerItem(x, y + "-" + ny, true);
								}
							}
							x = x + Range * PageSize;
							y = y + Range;
						} else {
							x = x + Range * PageSize;
							y = y + Range;
						}
					}
				}

				// Next Button
				NextButton.Start = FromIndex + PageSize;
				TempIndex = FromIndex + PageSize;
				NextButton.Start = TempIndex;
				NextButton.Enabled = !NoNext;

				// Last Button
				TempIndex = ((RecordCount - 1) / PageSize) * PageSize + 1;
				LastButton.Start = TempIndex;
				LastButton.Enabled = (FromIndex < TempIndex);
			}
		}
	}

	//
	// Class for PrevNext pager
	//
	public class cPrevNextPager : cPager
	{

		public int PageCount;

		public int CurrentPage;

		// Constructor
		public cPrevNextPager(int AFromIndex, int APageSize, int ARecordCount)
		{
			FromIndex = AFromIndex;
			PageSize = APageSize;
			RecordCount = ARecordCount;
			FirstButton = new cPagerItem();
			PrevButton = new cPagerItem();
			NextButton = new cPagerItem();
			LastButton = new cPagerItem();
			Visible = true;
			Init();
		}

		// Method to init pager
		public void Init()
		{
			int TempIndex;
			if (PageSize > 0) {
				CurrentPage = (FromIndex - 1) / PageSize + 1;
				PageCount = (RecordCount - 1) / PageSize + 1;
				if (FromIndex > RecordCount) FromIndex = RecordCount; 
				ToIndex = FromIndex + PageSize - 1;
				if (ToIndex > RecordCount) ToIndex = RecordCount; 

				// First Button
				TempIndex = 1;
				FirstButton.Start = TempIndex;
				FirstButton.Enabled = (TempIndex != FromIndex);

				// Prev Button
				TempIndex = FromIndex - PageSize;
				if (TempIndex < 1) TempIndex = 1; 
				PrevButton.Start = TempIndex;
				PrevButton.Enabled = (TempIndex != FromIndex);

				// Next Button
				TempIndex = FromIndex + PageSize;
				if (TempIndex > RecordCount) TempIndex = FromIndex; 
				NextButton.Start = TempIndex;
				NextButton.Enabled = (TempIndex != FromIndex);

				// Last Button
				TempIndex = ((RecordCount - 1) / PageSize) * PageSize + 1;
				LastButton.Start = TempIndex;
				LastButton.Enabled = (TempIndex != FromIndex);
			}
		}
	}

	//
	// Breadcrumb class
	//
	public class cBreadcrumbLink { // ASPX

		public string Id;

		public string Title;

		public string Url;

		public string Cls;

		public string TableVar;

		public bool IsCurrent;

		// Constructor
		public cBreadcrumbLink(string aid, string atitle, string aurl, string acls, string atablevar = "", bool acurrent = false) {
			Set(aid, atitle, aurl, acls, atablevar, acurrent);
		}		

		// Set properties
		public void Set(string aid, string atitle, string aurl, string acls, string atablevar = "", bool acurrent = false) {
			Id = aid;
			Title = atitle;
			Url = aurl;
			Cls = acls;
			TableVar = atablevar;
			IsCurrent = acurrent;
		}
	}	

	public class cBreadcrumb {

		public List<cBreadcrumbLink> Links = new List<cBreadcrumbLink>();

		public List<cBreadcrumbLink> SessionLinks = new List<cBreadcrumbLink>();

		public bool Visible = true;

		// Constructor
		public cBreadcrumb() {
			Links.Add(new cBreadcrumbLink("home", "HomePage", "default.cshtml", "ewHome")); // Home
		}

		// Check if an item exists
		public bool Exists(string pageid, string table, string pageurl) {
			foreach (var Link in Links) {
				if (pageid == Link.Id && table == Link.TableVar && pageurl == Link.Url)
					return true;
			}
			return false;
		}

		// Add breadcrumb
		public void Add(string pageid, string pagetitle, string pageurl, string pageurlclass = "", string table = "", bool current = false) {

			// Load session links
			LoadSession();

			// Get list of master tables
			List<string> mastertable = new List<string>();
			if (ew_NotEmpty(table)) {
				var tablevar = table;
				while (ew_NotEmpty(ew_Session[EW_PROJECT_NAME + "_" + tablevar + "_" + EW_TABLE_MASTER_TABLE])) {
					tablevar = Convert.ToString(ew_Session[EW_PROJECT_NAME + "_" + tablevar + "_" + EW_TABLE_MASTER_TABLE]);
					if (mastertable.Contains(tablevar))
						break;
					mastertable.Add(tablevar);
				}
			}

			// Add master links first
			foreach (var Link in SessionLinks) {
				if (mastertable.Contains(Link.TableVar) && Link.Id == "list") {
					if (Link.Url == pageurl)
						break;
					if (!Exists(Link.Id, Link.TableVar, Link.Url)) // ASPX
						Links.Add(new cBreadcrumbLink(Link.Id, Link.Title, Link.Url, Link.Cls, Link.TableVar, false));
				}
			}			

			// Add this link
			if (!Exists(pageid, table, pageurl))
				Links.Add(new cBreadcrumbLink(pageid, pagetitle, pageurl, pageurlclass, table, current));

			// Save session links
			SaveSession();
		}

		// Save links to Session
		public void SaveSession() {
			ew_Session[EW_SESSION_BREADCRUMB] = Links;
		}

		// Load links from Session
		public void LoadSession() {
			if (ew_IsList(ew_Session[EW_SESSION_BREADCRUMB]) && ew_Session[EW_SESSION_BREADCRUMB] is List<cBreadcrumbLink>)
				SessionLinks = (List<cBreadcrumbLink>)ew_Session[EW_SESSION_BREADCRUMB];
		}

		// Load language phrase
		public string LanguagePhrase(string title, string table, bool current) {
			var wrktitle = (title == table) ? Language.TablePhrase(title, "TblCaption") : Language.Phrase(title);
			if (current)
				wrktitle = "<span id=\"ewPageCaption\">" + wrktitle + "</span>";
			return wrktitle;
		}

		// Render
		public void Render() {
			if (!Visible)
				return;
			var nav = "<ul class=\"breadcrumb\">";			
			for (var i = 0; i < Links.Count; i++) {
				var Link = Links[i];
				var url = Link.Url;
				if (i < Links.Count - 1) {
					nav += "<li>";
				} else {
					nav += "<li class=\"active\">";
					url = ""; // No need to show url for current page
				}
				var text = LanguagePhrase(Link.Title, Link.TableVar, Link.IsCurrent);
				var title = ew_HtmlTitle(text);
				if (ew_NotEmpty(url)) {
					nav += "<a href=\"" + ew_GetUrl(url) + "\"";
					if (ew_NotEmpty(title) && title != text)
						nav += " title=\"" + ew_HtmlEncode(title) + "\"";
					if (Link.Cls != "")
						nav += " class=\"" + Link.Cls + "\"";
					nav += ">" + text + "</a>";
				} else {
					nav += text;
				}	
				nav += "</li>";
			}
			nav += "</ul>";
			ew_Write(nav);
		}
	}

	//
	// Table classes
	//
	// Common class for table and report
	public class cTableBase {

		public string TableVar = "";

		public string TableName = "";

		public string TableType = "";

		private string _TableCaption = "";	

		public bool Visible = true;	

		public Dictionary<string, cField> Fields = new Dictionary<string, cField>();	

		public bool UseTokenInUrl = EW_USE_TOKEN_IN_URL;

		public string Export = ""; // Export

		public string CustomExport = ""; // Custom export

		public bool ExportAll;

		public int ExportPageBreakCount; // Page break per every n record (PDF only)

		public string ExportPageOrientation; // Page orientation (PDF only)

		public string ExportPageSize; // Page size (PDF only)

		public float[] ExportColumnWidths; // Column widths (PDF only) // ASPX

		public bool SendEmail; // Send email

		public string TableCustomInnerHtml = ""; // Custom inner HTML	

		public cBasicSearch BasicSearch; // Basic search

		public string CurrentFilter = ""; // Current filter

		public string CurrentOrder = ""; // Current order

		public string CurrentOrderType = ""; // Current order type	

		public int RowType; // Row type

		public string CssClass = ""; // CSS class

		public string CssStyle = ""; // CSS style

		public Dictionary<string, object> RowAttrs = new Dictionary<string, object>(); // ASPX

		public Dictionary<int, string> PgCaption = new Dictionary<int, string>();				

		public string CurrentAction = ""; // Current action

		public string LastAction = ""; // Last action

		public int UserIDAllowSecurity = 0; // User ID Allow

		public string Command = "";

		// Reset attributes for table object
		public void ResetAttrs() {
			CssClass = "";
			CssStyle = "";
	    	RowAttrs.Clear();
			foreach (var kvp in Fields)
				kvp.Value.ResetAttrs();
		}

		// Setup field titles
		public void SetupFieldTitles() {
			foreach (KeyValuePair<string, cField> kvp in Fields) {
				cField fld = kvp.Value;
				if (ew_NotEmpty(fld.FldTitle)) {	
					fld.EditAttrs["data-toggle"] = "tooltip";
					fld.EditAttrs["title"] = ew_HtmlEncode(fld.FldTitle);
				}
			}
		}

		// Get form values (for validation)
		public Dictionary<string, string> GetFormValues() {
			var values = new Dictionary<string, string>();
			foreach (KeyValuePair<string, cField> kvp in Fields) {
				cField fld = kvp.Value;
				values.Add(fld.FldName, fld.FormValue);
			}
			return values;
		}		

		// Get field values
		public Dictionary<string, object> GetFieldValues(string name) {
			var values = new Dictionary<string, object>();
			foreach (KeyValuePair<string, cField> kvp in Fields) {
				cField fld = kvp.Value;
				PropertyInfo pi = fld.GetType().GetProperty(name); // Property
				if (pi != null) {
					values.Add(fld.FldName, pi.GetValue(fld, null));
					continue;
				}					
				FieldInfo fi = fld.GetType().GetField(name); // Field
				if (fi != null) {
					values.Add(fld.FldName, fi.GetValue(fld));
					continue;
				}	
				values.Add(fld.FldName, null);
			}
			return values;
		}

		// Table caption
		public string TableCaption {
			get {
				if (ew_NotEmpty(_TableCaption))
					return _TableCaption;
				else
					return Language.TablePhrase(TableVar, "TblCaption");
			}
			set { _TableCaption = value; }
		}		

		// Set page caption
		public void SetPageCaption(int Page, string v) {
			PgCaption[Page] = v;
		}

		// Page caption
		public string PageCaption(int Page) {
			string Caption = "";
			if (PgCaption.ContainsKey(Page))
				Caption = PgCaption[Page];
			if (ew_NotEmpty(Caption)) {
				return Caption;
			} else {
				Caption = Language.TablePhrase(TableVar, "TblPageCaption" + Convert.ToString(Page));
				if (ew_Empty(Caption))
					Caption = "Page " + Convert.ToString(Page);
				return Caption;
			}
		}

		// Add URL parameter
		public string UrlParm(string parm = "") {
			string result = (UseTokenInUrl) ? "t=" + TableVar : "";
			if (ew_NotEmpty(parm)) {
				if (ew_NotEmpty(result))
					result += "&";
				result += parm;
			}
			return result;
		}

		// Row Styles
		public string RowStyles {
			get {
				string sAtt = "";
				string sStyle = CssStyle;
				if (RowAttrs.ContainsKey("style") && ew_NotEmpty(RowAttrs["style"]))
					sStyle += " " + RowAttrs["style"];
				string sClass = CssClass;
				if (RowAttrs.ContainsKey("class") && ew_NotEmpty(RowAttrs["class"]))
					sClass += " " + RowAttrs["class"];
				if (ew_NotEmpty(sStyle))
					sAtt += " style=\"" + sStyle.Trim() + "\"";
				if (ew_NotEmpty(sClass))
					sAtt += " class=\"" + sClass.Trim() + "\"";
				return sAtt;
			}
		}

		// Row Attribute
		public string RowAttributes {
			get {
				string sAtt = RowStyles;
				if (ew_Empty(Export)) {
					foreach (KeyValuePair<string, object> Attr in RowAttrs) {
						if (!ew_SameText(Attr.Key, "style") && !ew_SameText(Attr.Key, "class") && ew_NotEmpty(Attr.Value))
							sAtt += " " + Attr.Key + "=\"" + Convert.ToString(Attr.Value).Trim() + "\"";
					}
				}
				return sAtt;
			}
		}

		// Get field object by name
		public cField FieldByName(string Name) {
			if (Fields.ContainsKey(Name))
				return Fields[Name];			
			return null;
		}	
	}

	// class for table
	public class cTable : cTableBase {

		public string CurrentMode = ""; // Current mode

		public string UpdateConflict; // Update conflict

		public string EventName = ""; // Event name

		public bool EventCancelled; // Event cancelled

		public string CancelMessage = ""; // Cancel message

		public bool AllowAddDeleteRow = true; // Allow add/delete row

		public bool ValidateKey = true; // Validate key	

		public bool DetailAdd; // Allow detail add

		public bool DetailEdit; // Allow detail edit	

		public bool DetailView; // Allow detail view

		public bool ShowMultipleDetails; // Show multiple details

		public int GridAddRowCount;

		public Dictionary<string, string> CustomActions = new Dictionary<string, string>(); // Custom actions

		public int Priv = 0;

		// Check current action
		// Add
		public bool IsAdd {
			get { return CurrentAction == "add"; }
		}

		// Copy
		public bool IsCopy {
			get { return CurrentAction == "copy" || CurrentAction == "C"; }
		}

		// Edit
		public bool IsEdit {
			get { return CurrentAction == "edit"; }
		}

		// Delete
		public bool IsDelete {
			get { return CurrentAction == "D"; }
		}

		// Confirm
		public bool IsConfirm {
			get { return CurrentAction == "F"; }
		}

		// Overwrite
		public bool IsOverwrite {
			get { return CurrentAction == "overwrite"; }
		}

		// Cancel
		public bool IsCancel {
			get { return CurrentAction == "cancel"; }
		}

		// Grid add
		public bool IsGridAdd {
			get { return CurrentAction == "gridadd"; }
		}

		// Grid edit
		public bool IsGridEdit {
			get { return CurrentAction == "gridedit"; }
		}

		// Add/Copy/Edit/GridAdd/GridEdit
		public bool IsAddOrEdit {
			get { return IsAdd || IsCopy || IsEdit || IsGridAdd || IsGridEdit; }
		}

		// Insert
		public bool IsInsert {
			get { return CurrentAction == "insert" || CurrentAction == "A"; }
		}

		// Update
		public bool IsUpdate {
			get { return CurrentAction == "update" || CurrentAction == "U"; }
		}

		// Grid update
		public bool IsGridUpdate {
			get { return CurrentAction == "gridupdate"; }
		}

		// Grid insert
		public bool IsGridInsert {
			get { return CurrentAction == "gridinsert"; }
		}

		// Grid overwrite
		public bool IsGridOverwrite {
			get { return CurrentAction == "gridoverwrite"; }
		}

		// Check last action
		// Cancelled
		public bool IsCanceled {
			get { return LastAction == "cancel" && CurrentAction == ""; }
		}

		// Inline inserted
		public bool IsInlineInserted {
			get { return LastAction == "insert" && CurrentAction == ""; }
		}

		// Inline updated
		public bool IsInlineUpdated {
			get { return LastAction == "update" && CurrentAction == ""; }
		}

		// Grid updated
		public bool IsGridUpdated {
			get { return LastAction == "gridupdate" && CurrentAction == ""; }
		}

		// Grid inserted
		public bool IsGridInserted {
			get { return LastAction == "gridinsert" && CurrentAction == ""; }
		}

		// Inserted or Updated
	    public bool IsInsertedOrUpdated {
	        get { return IsInlineInserted || IsInlineUpdated || IsGridUpdated || IsGridInserted; }
	    }

		// Export Return Page
		public string ExportReturnUrl {
			get {
				if (ew_NotEmpty(ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_EXPORT_RETURN_URL])) {
					return Convert.ToString(ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_EXPORT_RETURN_URL]);
				} else {
					return ew_CurrentPage();
				}
			}
			set { ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_EXPORT_RETURN_URL] = value; }
		}

		// Records per page
		public int RecordsPerPage {
			get { return Convert.ToInt32(ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_REC_PER_PAGE]); }
			set { ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_REC_PER_PAGE] = value; }
		}

		// Start record number
		public int StartRecordNumber {
			get { return Convert.ToInt32(ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_START_REC]); }
			set { ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_START_REC] = value; }
		}		

		// Search Highlight Name
		public string HighlightName {
			get { return TableVar + "_Highlight"; }
		}

		// Search WHERE clause		
		public string SessionSearchWhere {
			get { return Convert.ToString(ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_SEARCH_WHERE]); }
			set { ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_SEARCH_WHERE] = value; }
		}		

		// Session WHERE Clause
		public string SessionWhere {
			get { return Convert.ToString(ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_WHERE]); }
			set { ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_WHERE] = value; }
		}

		// Session ORDER BY
		public string SessionOrderBy {
			get { return Convert.ToString(ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_ORDER_BY]); }
			set { ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_ORDER_BY] = value; }
		}

		// Session key
		public object GetKey(string fld) {
			return ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_KEY + "_" + fld];
		}

		public void SetKey(string fld, object v) {
			ew_Session[EW_PROJECT_NAME + "_" + TableVar + "_" + EW_TABLE_KEY + "_" + fld] = v;
		}	
	}

	//
	//  Field class
	//
	public class cField	{

		public string TblName; 

		public string TblVar; // Table var

		public string FldName; // Field name

		public string FldVar; // Field variable name

		public string FldExpression; // Field expression (used in SQL)

		public string FldBasicSearchExpression; // Field expression (used in basic search SQL)

		public bool FldIsVirtual; // Virtual field

		public string FldVirtualExpression; // Virtual field expression (used in ListSQL)

		public bool FldForceSelection; // Autosuggest force selection

		public bool FldVirtualSearch; // Search as virtual field

		public object VirtualValue; // Virtual field value

		public object TooltipValue; // Field tooltip value

		public int TooltipWidth = 0; // Field tooltip width

		public int FldType; // Field type (ADO data type)

		public ewDbType FldDbType; // Field type (.NET data type)

		public int FldDataType; // Field type (ASP.NET Maker data type)

		public string FldBlobType; // For Oracle only

		public bool Visible = true; // Visible

		public string FldViewTag = ""; // View Tag

		public bool FldIsDetailKey = false; // Field is detail key

		public int FldDateTimeFormat; // Date time format

		public string CssStyle = ""; // CSS style

		public string CssClass = ""; // CSS class

		public string ImageAlt = ""; // Image alt

		public int ImageWidth = 0; // Image width

		public int ImageHeight = 0; // Image height

		public bool ImageResize = false; // Image resize

		public int ResizeQuality = 100; // Resize quality

		public bool IsBlobImage = false; // Is blob image

		public string ViewCustomAttributes = "";

		public string EditCustomAttributes = "";

		public string CellCustomAttributes = "";

		public string LinkCustomAttributes = ""; // Link custom attributes

		public string CustomMsg = ""; // Custom message

		public string CellCssClass = ""; // Cell CSS class

		public string CellCssStyle = ""; // Cell CSS style

		public string MultiUpdate = ""; // Multi update

		public object OldValue; // Old Value

		public object ConfirmValue; // Confirm Value

		public object CurrentValue; // Current value

		public object ViewValue; // View value

		public object EditValue; // Edit value

		public object EditValue2; // Edit value 2 (search)

		public object HrefValue; // Href value

		public object HrefValue2;

		public Dictionary<string, string> CellAttrs = new Dictionary<string, string>(); // Cell attributes

		public Dictionary<string, string> EditAttrs = new Dictionary<string, string>(); // Edit Attributes

		public Dictionary<string, string> ViewAttrs = new Dictionary<string, string>(); // View Attributes

		public Dictionary<string, string> LinkAttrs = new Dictionary<string, string>(); // Link custom attributes

		private string m_FormValue; // Form value

		private string m_QueryStringValue; // QueryString value

		private object m_DbValue; // Database value		

		public bool Disabled; // Disabled

		public bool ReadOnly; // ReadOnly		

		public bool TruncateMemoRemoveHtml; // Remove Html from Memo field

		public string FldDefaultErrMsg;

		public bool Sortable = true; 

		public int Count = 0; // Count		

		public double Total = 0; // Total

		public string TrueValue = "1";

		public string FalseValue = "0";		

		public cAdvancedSearch AdvancedSearch; // Advanced Search Object		

		public cUpload Upload; // Upload Object

		public string UploadPath = EW_UPLOAD_DEST_PATH; // Upload path

		public string OldUploadPath = EW_UPLOAD_DEST_PATH; // Old upload path (for deleting old image)

		public string UploadAllowedFileExt = EW_UPLOAD_ALLOWED_FILE_EXT; // Allowed file extensions

		public int UploadMaxFileSize = EW_MAX_FILE_SIZE; // Upload max file size

		public int UploadMaxFileCount = EW_MAX_FILE_COUNT; // Upload max file count

		public bool UploadMultiple = false; // Multiple Upload

		public bool UseColorbox = EW_USE_COLORBOX; // Use Colorbox

		public object DisplayValueSeparator = ", "; // String or String[]

		public bool Exportable = true;

		public string PlaceHolder = "";	

		public bool AutoFillOriginalValue = EW_AUTO_FILL_ORIGINAL_VALUE;

		public string ReqErrMsg;	

		// Create new field object
		//public cField(string atblvar, string atblname, string afldvar, string afldname, string afldexpression, string afldbsexp, int afldtype, ewDbType aflddbtype, int aflddatatype, int aflddtformat, bool aforceselect, string afldviewtag)
		public cField(string atblvar, string atblname, string afldvar, string afldname, string afldexp, string afldbsexp, int afldtype, ewDbType aflddbtype, int aflddtfmt, bool aupload, string afldvirtualexp, bool afldvirtual, bool aforceselect, bool afldvirtualsrch, string afldviewtag = "")
		{
			TblVar = atblvar;
			TblName = atblname; 
			FldVar = afldvar;
			FldName = afldname;
			FldExpression = afldexp;
			FldBasicSearchExpression = afldbsexp;
			FldType = afldtype;
			FldDbType = aflddbtype;
			FldDataType = ew_FieldDataType(afldtype);
			FldDateTimeFormat = aflddtfmt;
			AdvancedSearch = new cAdvancedSearch(TblVar, FldVar);
			if (aupload) {
				Upload = new cUpload(TblVar, FldVar);
				Upload.UploadMultiple = UploadMultiple;
			}
			FldVirtualExpression = afldvirtualexp;
			FldIsVirtual = afldvirtual;
			FldForceSelection = aforceselect;
			FldVirtualSearch = afldvirtualsrch;
			FldViewTag = afldviewtag;
			if (ew_QueryString[afldvar] != null)
				SetQueryStringValue(ew_Get(afldvar), false);
			if (ew_Form[afldvar] != null)
				SetFormValue(ew_Post(afldvar), false);
			ReqErrMsg = Language.Phrase("EnterRequiredField");	
		}

		private string Caption = "";		

		public string FldCaption { // Field caption
			get { 
				if (ew_NotEmpty(Caption))
					return Caption;
				else
					return Language.FieldPhrase(TblVar, FldVar.Substring(2), "FldCaption");
			}
			set {
				Caption = value;
			}
		}

		public string FldTitle { // Field title
			get { return Language.FieldPhrase(TblVar, FldVar.Substring(2), "FldTitle"); }
		}

		public string FldAlt { // Field alt
			get { return Language.FieldPhrase(TblVar, FldVar.Substring(2), "FldAlt"); }
		}

		public string FldErrMsg { // Field err msg
			get {
				string sFldErrMsg = Language.FieldPhrase(TblVar, FldVar.Substring(2), "FldErrMsg");
				if (ew_Empty(sFldErrMsg))
					sFldErrMsg = FldDefaultErrMsg + " - " + FldCaption; 
				return sFldErrMsg;
			}
		}

		// Field tag value
		public string FldTagValue(int i) {
			return Language.FieldPhrase(TblVar, FldVar.Substring(2), "FldTagValue" + Convert.ToString(i));
		}

		// Field tag caption
		public string FldTagCaption(int i) {
			return Language.FieldPhrase(TblVar, FldVar.Substring(2), "FldTagCaption" + Convert.ToString(i));
		}		

		// Reset attributes for field object
		public void ResetAttrs() {
			CssStyle = "";
			CssClass = "";
			CellCssStyle = "";
			CellCssClass = "";
			CellAttrs.Clear();
			EditAttrs.Clear();
			ViewAttrs.Clear();
			LinkAttrs.Clear();
		}		

		// View Attributes
		public string ViewAttributes {
			get {
				string sAtt = "", sStyle = "", sClass = CssClass;
				if (FldViewTag == "IMAGE" && ImageWidth > 0 && (!ImageResize || (ImageResize && ImageHeight <= 0)))
					sStyle += "width: " + ImageWidth + "px; ";
				if (FldViewTag == "IMAGE" && ImageHeight > 0 && (!ImageResize || (ImageResize && ImageWidth <= 0)))
					sStyle += "height: " + ImageHeight + "px; ";
				sStyle += CssStyle.Trim();		
				if (ViewAttrs.ContainsKey("style") && ew_NotEmpty(ViewAttrs["style"])) {
					if (!sStyle.EndsWith(";")) sStyle += ";";
					sStyle += " " + ViewAttrs["style"].Trim();
				}
				if (ViewAttrs.ContainsKey("class") && ew_NotEmpty(ViewAttrs["class"]))
					sClass += " " + ViewAttrs["class"];
				if (ew_NotEmpty(sStyle))
					sAtt += " style=\"" + sStyle.Trim() + "\"";
				if (ew_NotEmpty(sClass))
					sAtt += " class=\"" + sClass.Trim() + "\"";				
				if (ew_NotEmpty(ImageAlt))
					sAtt += " alt=\"" + ImageAlt.Trim() + "\"";				
				foreach (KeyValuePair<string, string> Attr in ViewAttrs) {
					if (!ew_SameText(Attr.Key, "style") && !ew_SameText(Attr.Key, "class") && ew_NotEmpty(Attr.Value))
						sAtt += " " + Convert.ToString(Attr.Key) + "=\"" + Convert.ToString(Attr.Value).Trim() + "\"";
				}				
				if (ew_NotEmpty(ViewCustomAttributes))
					sAtt += " " + ViewCustomAttributes.Trim();
				return sAtt;
			}
		}

		// Edit Attributes
		public string EditAttributes {
			get {
				string sAtt = "";
				string sStyle = CssStyle;
				string sClass = CssClass;
				if (EditAttrs.ContainsKey("style") && ew_NotEmpty(EditAttrs["style"]))
					sStyle += " " + EditAttrs["style"];
				if (EditAttrs.ContainsKey("class") && ew_NotEmpty(EditAttrs["class"]))
					sClass += " " + EditAttrs["class"];
				if (ew_NotEmpty(sStyle))
					sAtt += " style=\"" + sStyle.Trim() + "\"";
				if (ew_NotEmpty(sClass))
					sAtt += " class=\"" + sClass.Trim() + "\"";
				if (Disabled)
					EditAttrs["disabled"] = "disabled";
				if (ReadOnly) // For TEXT/PASSWORD/TEXTAREA only
					EditAttrs["readonly"] = "readonly";
				foreach (KeyValuePair<string, string> Attr in EditAttrs) {
					if (!ew_SameText(Attr.Key, "style") && !ew_SameText(Attr.Key, "class") && ew_NotEmpty(Attr.Value))
						sAtt += " " + Convert.ToString(Attr.Key) + "=\"" + Convert.ToString(Attr.Value).Trim() + "\"";
				}				
				if (ew_NotEmpty(EditCustomAttributes))
					sAtt += " " + EditCustomAttributes.Trim();				
				return sAtt;
			}
		}

		// Link attributes
		public string LinkAttributes {
			get {
				string sAtt = "";
				string sHref = Convert.ToString(HrefValue).Trim();
				foreach (KeyValuePair<string, string> Attr in LinkAttrs) {
					if (ew_NotEmpty(Attr.Value)) {
						if (ew_SameText(Attr.Key, "href"))
							sHref += " " + Convert.ToString(Attr.Value).Trim();
						else
							sAtt += " " + Convert.ToString(Attr.Key) + "=\"" + Convert.ToString(Attr.Value).Trim() + "\"";
					}
				}
				if (ew_NotEmpty(sHref))
					sAtt += " href=\"" + sHref.Trim() + "\"";
				if (ew_NotEmpty(LinkCustomAttributes))
					sAtt += " " + LinkCustomAttributes.Trim();
				return sAtt;
			}
		}	

		// Cell Styles
		public string CellStyles {
			get {
				string sAtt = "";
				string sStyle = CellCssStyle;
				string sClass = CellCssClass;
				if (CellAttrs.ContainsKey("style") && ew_NotEmpty(CellAttrs["style"]))
					sStyle += " " + CellAttrs["style"];
				if (CellAttrs.ContainsKey("class") && ew_NotEmpty(CellAttrs["class"]))
					sClass += " " + CellAttrs["class"];
				if (ew_NotEmpty(sStyle))
					sAtt += " style=\"" + sStyle.Trim() + "\"";
				if (ew_NotEmpty(sClass))
					sAtt += " class=\"" + sClass.Trim() + "\"";
				return sAtt;
			}
		}

		// Cell Attributes
		public string CellAttributes {
			get {
				string sAtt = CellStyles;
				foreach (KeyValuePair<string, string> Attr in CellAttrs) {
					if (!ew_SameText(Attr.Key, "style") && !ew_SameText(Attr.Key, "class") && ew_NotEmpty(Attr.Value))
						sAtt += " " + Convert.ToString(Attr.Key) + "=\"" + Convert.ToString(Attr.Value).Trim() + "\"";
				}
				if (ew_NotEmpty(CellCustomAttributes))
					sAtt += " " + CellCustomAttributes.Trim(); // Cell custom attributes
				return sAtt;
			}
		}

		// Sort Attributes
		public string Sort {
			get { return Convert.ToString(ew_Session[EW_PROJECT_NAME + "_" + TblVar + "_" + EW_TABLE_SORT + "_" + FldVar]); }
			set {
				if (ew_Session[EW_PROJECT_NAME + "_" + TblVar + "_" + EW_TABLE_SORT + "_" + FldVar] != value) {
					ew_Session[EW_PROJECT_NAME + "_" + TblVar + "_" + EW_TABLE_SORT + "_" + FldVar] = value;
				}
			}
		}

		// List View value
		public string ListViewValue {
			get {
				if (ew_Empty(ViewValue)) {
					return "&nbsp;";
				} else {
					string Result = Convert.ToString(ViewValue);
					string Result2 = Regex.Replace(Result, "<[^img][^>]*>" , String.Empty); // Remove all except non-empty image tag
					return (Result2.Trim().Equals(String.Empty)) ? "&nbsp;" : Result;	
				}
			}
		}

		public bool ExportOriginalValue = EW_EXPORT_ORIGINAL_VALUE; // Export original value			

		// Export Caption
		public string ExportCaption {
			get {
				if (EW_EXPORT_FIELD_CAPTION) {
					return FldCaption;
				} else {
					return FldName;
				}
			}
		}

		// Export Value
		public string ExportValue {
			get {
				return (ExportOriginalValue) ? Convert.ToString(CurrentValue) : Convert.ToString(ViewValue);
			}
		}

		// Get temp image
		public string GetTempImage() {
			if (FldDataType == EW_DATATYPE_BLOB) {
				if (!Convert.IsDBNull(Upload.DbValue)) { // ASPX
					byte[] wrkdata = (byte[])Upload.DbValue;			
					if (ImageResize) {
						int wrkwidth = ImageWidth;
						int wrkheight = ImageHeight;
						ew_ResizeBinary(ref wrkdata, ref wrkwidth, ref wrkheight, ResizeQuality);
					}
					return ew_TmpImage(wrkdata);
				}
			} else {
				string wrkfile = Convert.ToString(Upload.DbValue);
				if (ew_Empty(wrkfile))
					wrkfile = Convert.ToString(CurrentValue);
				if (ew_NotEmpty(wrkfile)) {
					if (!UploadMultiple) {
						string imagefn = ew_UploadPathEx(true, UploadPath) + wrkfile;
						if (ImageResize) {
							int wrkwidth = ImageWidth;
							int wrkheight = ImageHeight;
							byte[] wrkdata = ew_ResizeFileToBinary(imagefn, ref wrkwidth, ref wrkheight, ResizeQuality);
							return ew_TmpImage(wrkdata);
						} else {
							return ew_TmpFile(imagefn);
						}
					 } else {
						var tmpfiles = wrkfile.Split(new char[] {Convert.ToChar(EW_MULTIPLE_UPLOAD_SEPARATOR)});
						var tmpimage = "";
						foreach (var tmpfile in tmpfiles) {
							if (ew_NotEmpty(tmpfile)) {
								string imagefn = ew_UploadPathEx(true, UploadPath) + wrkfile;
								if (ImageResize) {
									int wrkwidth = ImageWidth;
									int wrkheight = ImageHeight;
									byte[] wrkdata = ew_ResizeFileToBinary(imagefn, ref wrkwidth, ref wrkheight, ResizeQuality);
									if (ew_NotEmpty(tmpimage))
										tmpimage += ",";
									tmpimage += ew_TmpImage(wrkdata);
								} else {
									if (ew_NotEmpty(tmpimage))
										tmpimage += ",";
									tmpimage += ew_ConvertFullUrl(UploadPath + tmpfile);
								}
							}
						}
						return tmpimage;
					}
				}
			}
			return "";
		}

		// Form value
		public void SetFormValue(object value, bool current = true) {
			m_FormValue = Convert.ToString(value);
			if (current)
				CurrentValue = m_FormValue;
		}		

		public string FormValue {
			get { return m_FormValue; }
			set {
				m_FormValue = value;
				CurrentValue = m_FormValue;
			}
		}

		// QueryString value
		public void SetQueryStringValue(object value, bool current = true) {
			m_QueryStringValue = Convert.ToString(value);
			if (current)
				CurrentValue = m_QueryStringValue;
		}

		public string QueryStringValue {
			get { return m_QueryStringValue; }
			set {
				m_QueryStringValue = value;
				CurrentValue = m_QueryStringValue;
			}
		}

		// DbValue
		public void SetDbValue(object value, bool current = false) {
			m_DbValue = value;
			if (current)
				CurrentValue = m_DbValue;
		}

		public object DbValue {
			get { return m_DbValue; }
			set {
				m_DbValue = value;
				CurrentValue = m_DbValue;
			}
		}

		// Session Value
		public object SessionValue {
			get { return ew_Session[EW_PROJECT_NAME + "_" + TblVar + "_" + FldVar + "_SessionValue"]; }
			set { ew_Session[EW_PROJECT_NAME + "_" + TblVar + "_" + FldVar + "_SessionValue"] = value; }
		}

		public string ReverseSort()
		{
			return (Sort == "ASC") ? "DESC" : "ASC";
		}

		// Advanced search
		public string UrlParameterName(string name)
		{
			string fldparm = FldVar.Substring(2);
			if (ew_SameText(name, "SearchValue")) {
				fldparm = "x_" + fldparm;
			} else if (ew_SameText(name, "SearchOperator")) {
				fldparm = "z_" + fldparm;
			} else if (ew_SameText(name, "SearchCondition")) {
				fldparm = "v_" + fldparm;
			} else if (ew_SameText(name, "SearchValue2")) {
				fldparm = "y_" + fldparm;
			} else if (ew_SameText(name, "SearchOperator2")) {
				fldparm = "w_" + fldparm;
			}
			return fldparm;
		}

		// Set up database value
		public void SetDbValue(ref OrderedDictionary rs, object value, object def, bool skip)
		{
			bool bSkipUpdate = (skip || !Visible || Disabled);
			if (bSkipUpdate)
				return;
			switch (FldType) {
				case 2:
				case 3:
				case 16:
				case 17:
				case 18:
				case 19:
				case 20:
				case 21:

					// Int
					if (Information.IsNumeric(Convert.ToString(value))) {
						m_DbValue = ew_Conv(value, FldType);
					} else {
						m_DbValue = def;
					}
					break;
				case 5:
				case 6:
				case 14:
				case 131:

					// Double
					value = ew_StrToFloat(value);
					if (Information.IsNumeric(Convert.ToString(value))) {
						m_DbValue = ew_Conv(value, FldType);
					} else {
						m_DbValue = def;
					}
					break;
				case 4:

					// Single
					value = ew_StrToFloat(value);
					if (Information.IsNumeric(Convert.ToString(value))) {
						m_DbValue = ew_Conv(value, FldType);
					} else {
						m_DbValue = def;
					}
					break;
				case 7:
				case 133:
				case 134:
				case 135:

					// Date
					if (Information.IsDate(value)) {
						m_DbValue = Convert.ToDateTime(value);
					} else {
						m_DbValue = def;
					}
					break;
				case 145: // Time
					if (Information.IsDate(value)) {
						m_DbValue = DateTime.Parse(Convert.ToString(value)).TimeOfDay;
					} else {
						m_DbValue = def;
					}
					break;
				case 146: // DateTimeOffset
					if (Information.IsDate(value)) {
						m_DbValue = DateTimeOffset.Parse(Convert.ToString(value));
					} else {
						m_DbValue = def;
					}
					break;
				case 201:
				case 203:
				case 129:
				case 130:
				case 200:
				case 202:	// String
					if (EW_REMOVE_XSS) {
						m_DbValue = ew_RemoveXSS(Convert.ToString(value));
					} else {
						m_DbValue = Convert.ToString(value);
					} 
					if (Convert.ToString(m_DbValue) == "") m_DbValue = def; 
					break;
				case 141: // Xml
					if (ew_NotEmpty(value)) {
						m_DbValue = value;
					} else {
						m_DbValue = def;
					}
					break;
				case 128:
				case 204:
				case 205:

					// Binary
					if (Convert.IsDBNull(value)) {
						m_DbValue = def;
					} else {
						m_DbValue = value;
					}
					break;
				case 72:

					// GUID
					if (ew_NotEmpty(value) && ew_CheckGUID(Convert.ToString(value).Trim())) {
						m_DbValue = value;
					} else {
						m_DbValue = def;
					}
					break;
				default:
					m_DbValue = value;
					break;
			}
			rs[FldName] = m_DbValue; 
		}
	}

	//
	//  List option collection class
	//	
	public class cListOptions
	{

		public List<cListOption> Items = new List<cListOption>();

		public string CustomItem = "";

		public string Tag = "td";

		public string TagClassName = "";

		public string TableVar = "";

		public string RowCnt = "";

		public string ScriptType = "block";

		public string ScriptId = "";

		public string ScriptClassName = "";

		public string JavaScript = "";

		public int RowSpan = 1;

		public bool UseDropDownButton = false;

		public bool UseButtonGroup = false;

		public string ButtonClass = "";

		public string GroupOptionName = "button";

		public string DropDownButtonPhrase = "";

		public bool UseImageAndText = false;

		// Check visible
		public bool Visible
		{
			get {
				foreach (var item in Items) {
					if (item.Visible)
						return true;
				}
				return false;
			}
		}

		// Check group option visible
		public bool GroupOptionVisible
		{
			get {
				var cnt = 0;
				foreach (var item in Items) {
					if (item.Name != GroupOptionName && 
						((item.Visible && item.ShowInDropDown && UseDropDownButton) ||
						(item.Visible && item.ShowInButtonGroup && UseButtonGroup))) {
							cnt++;
						if (UseDropDownButton && cnt > 1)
							return true;
						else if (UseButtonGroup)
							return true;
					}
				}
				return false;
			}
		}

		// Add and return a new option
		public cListOption Add(string Name)
		{
			cListOption item = new cListOption(Name);
			item.Parent = this;
			Items.Add(item);
			return item;
		}

		// Load default settings
		public void LoadDefault()
		{
			CustomItem = "";
			foreach (var item in Items)
				item.Body = "";
		}

		// Hide all options
		public void HideAllOptions(List<string> List = null)
		{
			foreach (var item in Items)
				if (List == null || !List.Contains(item.Name))
					item.Visible = false;
		}

		// Show all options
		public void ShowAllOptions()
		{
			foreach (var item in Items)
				item.Visible = true;
		}

		// Get item by name (predefined names: view/edit/copy/delete/detail_<DetailTable>/userpermission/checkbox)
		public cListOption GetItem(string name)
		{
			return Items.Find(delegate(cListOption item) {
                return (item.Name == name);
            });
		}

		// Get item position
		public int ItemPos(string name) {
			var pos = 0;
			foreach (var item in Items) {
				if (item.Name == name)
					return pos;
				pos++;
			}
			return -1;
		}

		// Get item by name
		public cListOption this[string name] {
			get {
				return GetItem(name);
			}
		}

		// Get item by index
		public cListOption this[int index] {
			get {
				return Items[index];
			}
		}

		// Get item index by name (predefined names: view/edit/copy/delete/detail_<DetailTable>/userpermission/checkbox)
		public int GetItemIndex(string name)
		{
			return Items.FindIndex(delegate(cListOption item) {
                return (item.Name == name);
            });
		}		

		// Move item to position
		public void MoveItem(string Name, int Pos)
		{	
			int newpos = Pos;
			if (newpos < 0) // If negative, count from the end
				newpos = Items.Count + newpos;
			if (newpos < 0) {
				newpos = 0;
			} else if (newpos >= Items.Count) {
				newpos = Items.Count - 1;
			}
			var CurItem = GetItem(Name);
			int oldpos = GetItemIndex(Name);
			if (oldpos > -1 && newpos != oldpos) {
				Items.RemoveAt(oldpos); // Remove old item
				if (oldpos < newpos)
					newpos--; // Adjust new position
				Items.Insert(newpos, CurItem); // Insert new item
			}
		}

		// Render list options
		public void Render(string aPart, string aPos = "", object aRowCnt = null, string aScriptType = "block", string aScriptId = "", string aScriptClassName = "") {
			var groupitem = GetItem(GroupOptionName);
			if (ew_Empty(CustomItem) && groupitem != null && ShowPos(groupitem.OnLeft, aPos)) {
				if (UseDropDownButton) { // Render dropdown
					var buttonvalue = "";
					int cnt = 0;
					foreach (var item in Items) {
						if (item.Name != GroupOptionName && item.Visible && item.ShowInDropDown) {
							buttonvalue += item.Body;
							cnt++;
						}
					}
					if (cnt <= 1) {
						UseDropDownButton = false; // No need to use drop down button
					} else {
						groupitem.Body = RenderDropDownButton(buttonvalue, aPos);
						groupitem.Visible = true;
					}
				}
				if (!UseDropDownButton && UseButtonGroup) { // Render button group
					var visible = false;
					var buttongroups = new Dictionary<string, string>();
					foreach (var item in Items) {
						if (item.Name != GroupOptionName && item.Visible && item.ShowInButtonGroup && ew_NotEmpty(item.Body)) {
							visible = true;
							var buttonvalue = (UseImageAndText) ? item.GetImageAndText(item.Body) : item.Body;
							if (!buttongroups.ContainsKey(item.ButtonGroupName))
								buttongroups[item.ButtonGroupName] = "";
							buttongroups[item.ButtonGroupName] += buttonvalue;
						}
					}
					groupitem.Body = "";
					foreach (KeyValuePair<string, string> kvp in buttongroups)
						groupitem.Body += RenderButtonGroup(kvp.Value);
					if (visible)
						groupitem.Visible = true;
				}
			}
			if (ew_NotEmpty(aScriptId)) {
				RenderEx(aPart, aPos, aRowCnt, "block", aScriptId, aScriptClassName); // Original block for ew_ShowTemplates
				RenderEx(aPart, aPos, aRowCnt, "blocknotd", aScriptId);
				RenderEx(aPart, aPos, aRowCnt, "single", aScriptId);
			} else {
				RenderEx(aPart, aPos, aRowCnt, aScriptType, aScriptId, aScriptClassName);
			}
		}

		// Render list options
		public void RenderEx(string aPart, string aPos = "", object aRowCnt = null, string aScriptType = "block", string aScriptId = "", string aScriptClassName = "") {
			RowCnt = Convert.ToString(aRowCnt);
			ScriptType = aScriptType;
			ScriptId = aScriptId;
			ScriptClassName = aScriptClassName;
			JavaScript = "";
			if (ew_NotEmpty(ScriptId)) {
				Tag = (ScriptType == "block") ? "td" : "span";
				if (ScriptType == "block") {
					if (aPart == "header")
						ew_Write("<script id=\"tpoh_" + ScriptId + "\" class=\"" + ScriptClassName + "\" type=\"text/html\">");
					else if (aPart == "body")
						ew_Write("<script id=\"tpob" + RowCnt + "_" + ScriptId + "\" class=\"" + ScriptClassName + "\" type=\"text/html\">");
					else if (aPart == "footer")
						ew_Write("<script id=\"tpof_" + ScriptId + "\" class=\"" + ScriptClassName + "\" type=\"text/html\">");
				} else if (aScriptType == "blocknotd") {
					if (aPart == "header")
						ew_Write("<script id=\"tpo2h_" + ScriptId + "\" class=\"" + ScriptClassName + "\" type=\"text/html\">");
					else if (aPart == "body")
						ew_Write("<script id=\"tpo2b" + RowCnt + "_" + ScriptId + "\" class=\"" + ScriptClassName + "\" type=\"text/html\">");
					else if (aPart == "footer")
						ew_Write("<script id=\"tpo2f_" + ScriptId + "\" class=\"" + ScriptClassName + "\" type=\"text/html\">");
					ew_Write("<span>");
				}
			} else {
				Tag = (ew_NotEmpty(aPos) && aPos != "bottom") ? "td" : "div";
			}
			if (ew_NotEmpty(CustomItem)) {
				cListOption opt = null;
				int cnt = 0;
				foreach (var item in Items) {
					if (ShowItem(item, ScriptId, aPos))
						cnt++;
					if (item.Name == CustomItem)
						opt = item;
				}
				var bUseButtonGroup = UseButtonGroup; // Backup options
				var bUseImageAndText = UseImageAndText;
				UseButtonGroup = true; // Show button group for custom item
				UseImageAndText = true; // Use image and text for custom item
				if (opt != null && cnt > 0) {
					if (ew_NotEmpty(ScriptId) || ShowPos(opt.OnLeft, aPos)) {
						ew_Write(opt.Render(aPart, cnt));
					} else {
						ew_Write(opt.Render("", cnt));
					}
				}
				UseButtonGroup = bUseButtonGroup; // Restore options
				UseImageAndText = bUseImageAndText;
			} else {
				foreach (var item in Items) {
					if (ShowItem(item, ScriptId, aPos))
						ew_Write(item.Render(aPart, 1));
				}
			}
			if ((aScriptType == "block" || aScriptType == "blocknotd") && ew_NotEmpty(aScriptId)) {
				if (aScriptType == "blocknotd")
					ew_Write("</span>");
				ew_Write("</script>");
				if (ew_NotEmpty(JavaScript))
					ew_Write(JavaScript);
			}
		}

		// Show item
		private bool ShowItem(cListOption item, string ScriptId, string Pos)
		{
			var show = item.Visible && (ew_NotEmpty(ScriptId) || ShowPos(item.OnLeft, Pos));
			if (show)
				if (UseDropDownButton)
					show = (item.Name == GroupOptionName || !item.ShowInDropDown);
				else if (UseButtonGroup)
					show = (item.Name == GroupOptionName || !item.ShowInButtonGroup);
			return show;
		}		

		// Show position
		private bool ShowPos(bool OnLeft, string Pos)
		{
			return (OnLeft && Pos == "left") || (!OnLeft && Pos == "right") || Pos == "" || Pos == "bottom";
		}

		// Concat options and return concatenated HTML
		// pattern - regular expression pattern for matching the option names, e.g. "^detail_"
		public string Concat(string pattern, string separator = "") {
			var ar = new List<string>();
			foreach (var item in Items) {
				if (Regex.IsMatch(item.Name, pattern) && ew_NotEmpty(item.Body))
					ar.Add(item.Body);
			}
			return String.Join(separator, ar);
		}

		// Merge options to the first option and return it
		// pattern - regular expression pattern for matching the option names, e.g. "^detail_"
		public cListOption Merge(string pattern, string separator = "") {
			cListOption first = null;
			foreach (var item in Items) {
				if (Regex.IsMatch(item.Name, pattern)) {
					if (first == null) {
						first = item;
						first.Body = Concat(pattern, separator);
					} else {
						item.Visible = false;
					}
				}
			}
			return first;
		}

		// Get button group link
		public string RenderButtonGroup(string body) {		

			// Get all inputs
			// format: <input type="hidden" ...>

			var inputs = new List<string>();
			foreach (Match match in Regex.Matches(body, @"<input\s+type=['""]hidden['""]\s+([^>]*)>", RegexOptions.IgnoreCase)) {
				body = body.Replace(match.Value, ""); 
				inputs.Add(match.Value);
			}

			// Get all buttons
			// format: <div class="btn-group">...</div>

			var btns = new List<string>();
			foreach (Match match in Regex.Matches(body, @"<div\s+class\s*=\s*['""]btn-group['""]([^>]*)>([\s\S]*?)</div\s*>", RegexOptions.IgnoreCase)) {
				body = body.Replace(match.Value, ""); 
				btns.Add(match.Value);
			}
			var links = "";

			// Get all links/buttons
			// format: <a ...>...</a> / <button ...>...</button>

			foreach (Match match in Regex.Matches(body, @"<(a|button)([^>]*)>([\s\S]*?)</(a|button)\s*>", RegexOptions.IgnoreCase)) {
				string tag = match.Groups[1].Value, cls = "", attrs = "";
				var m = Regex.Match(match.Groups[2].Value, @"\s+class\s*=\s*['""]([\s\S]*?)['""]", RegexOptions.IgnoreCase);
				if (m.Success) { // Match class="class"
					cls = m.Groups[1].Value;
                    attrs = match.Groups[2].Value.Replace(m.Value, "");
				} else {
					attrs = match.Groups[2].Value;
				}
				var caption = match.Groups[3].Value;
				if (!cls.Contains("btn btn-default"))
					cls = ew_PrependClass(cls, "btn btn-default"); // Prepend button classes
				if (ew_NotEmpty(ButtonClass))
					cls = ew_AppendClass(cls, ButtonClass); // Append button classes
				attrs = " class=\"" + cls + "\" " + attrs;
 				var link = "<" + tag + attrs + ">" + caption + "</" + tag + ">";
				links += link;
			}	
			var btngroup = "";
			if (ew_NotEmpty(links))
				btngroup = "<div class=\"btn-group ewButtonGroup\">" + links + "</div>";				
			foreach (var btn in btns)
				btngroup += btn;
			foreach (var input in inputs)
				btngroup += input;
			return btngroup;
		}

		// Render drop down button
		public string RenderDropDownButton(string body, string pos) {

			// Get all inputs
			// format: <input type="hidden" ...>

			var inputs = new List<string>();
			foreach (Match match in Regex.Matches(body, @"<input\s+type=['""]hidden['""]\s+([^>]*)>", RegexOptions.IgnoreCase)) {
				body = body.Replace(match.Value, ""); 
				inputs.Add(match.Value);
			}

			// Remove <div class="hide ewPreview">...</div>
			var previewlinks = "";
			foreach (Match match in Regex.Matches(body, @"<div\s+class\s*=\s*['""]hide\s+ewPreview['""]>([\s\S]*?)(<div([^>]*)>([\s\S]*?)</div\s*>)+([\s\S]*?)</div\s*>", RegexOptions.IgnoreCase)) {
				body = body.Replace(match.Value, "");
				previewlinks += match.Value;
			}

			// Remove toggle button first <button ... data-toggle="dropdown">...</button>
			foreach (Match match in Regex.Matches(body, @"<button\s+([\s\S]*?)data-toggle\s*=\s*['""]dropdown['""]\s*>([\s\S]*?)<\/button\s*>", RegexOptions.IgnoreCase)) {
				body = body.Replace(match.Value, "");
			}

			// Get all links/buttons <a ...>...</a> / <button ...>...</button>
			var matches = Regex.Matches(body, @"<(a|button)([^>]*)>([\s\S]*?)</(a|button)\s*>", RegexOptions.IgnoreCase);
			if (matches.Count == 0)
				return "";
			string links = "", submenulink = "", submenulinks = "";
			var submenu = false;
			foreach (Match match in matches) {
				string tag = match.Groups[1].Value, action = "", caption = "", cls = "", attrs = "";
				var actionmatches = Regex.Match(match.Value, @"\s+data-action\s*=\s*['""]([\s\S]*?)['""]", RegexOptions.IgnoreCase); 
				if (actionmatches.Success) // Match data-action='action'
					action = actionmatches.Groups[1].Value;
				var submatches = Regex.Match(match.Groups[2].Value, @"\s+class\s*=\s*['""]([\s\S]*?)['""]", RegexOptions.IgnoreCase);
				if (submatches.Success) { // Match class='class'
					cls = Regex.Replace(submatches.Groups[1].Value, @"btn[\S]*\s+", "", RegexOptions.IgnoreCase);
					attrs = match.Groups[2].Value.Replace(submatches.Value, "");
				} else {
					attrs = match.Groups[2].Value;
				}
				attrs = Regex.Replace(attrs, @"\s+title\s*=\s*['""]([\s\S]*?)['""]", "", RegexOptions.IgnoreCase); // Remove title='title'
				submatches = Regex.Match(attrs, @"\s+data-caption\s*=\s*['""]([\s\S]*?)['""]", RegexOptions.IgnoreCase);
				if (submatches.Success) // Match data-caption='caption'
					caption = submatches.Groups[1].Value;
				attrs = " class=\"" + cls + "\" " + attrs;
				if (ew_SameText(tag, "button")) // Add href for button
					attrs += " href=\"javascript:void(0);\"";
				if (UseImageAndText) { // Image and text
					var submatch = Regex.Match(match.Groups[3].Value, @"<img([^>]*)>", RegexOptions.IgnoreCase); // <img> tag
					if (submatch.Success)
						caption = submatch.Value + "&nbsp;&nbsp;" + caption;
					submatch = Regex.Match(match.Groups[3].Value, @"<span([^>]*)>([\s\S]*?)<\/span\s*>", RegexOptions.IgnoreCase); // <span class='class'></span> tag
					if (submatch.Success)
						if (Regex.IsMatch(submatch.Groups[1].Value, @"\s+class\s*=\s*['""]([\s\S]*?)['""]", RegexOptions.IgnoreCase)) // Match class='class'
							caption = submatch.Value + "&nbsp;&nbsp;" + caption;
				}
				if (ew_Empty(caption))
					caption = match.Groups[3].Value;				
				string link = "<a" + attrs + ">" + caption + "</a>";
				if (action == "list") { // Start new submenu
					if (submenu) { // End previous submenu
						if (ew_NotEmpty(submenulinks)) { // Set up submenu
							links += "<li class=\"dropdown-submenu\">" + submenulink + "<ul class=\"dropdown-menu\">" + submenulinks + "</ul></li>";
						} else {
							links += "<li>" + submenulink + "</li>";
						}
					}
					submenu = true;
					submenulink = link;
					submenulinks = "";
				} else {
					if (ew_Empty(action) && submenu) { // End previous submenu
						if (ew_NotEmpty(submenulinks)) { // Set up submenu
							links += "<li class=\"dropdown-submenu\">" + submenulink + "<ul class=\"dropdown-menu\">" + submenulinks + "</ul></li>";
						} else {
							links += "<li>" + submenulink + "</li>";
						}
						submenu = false;
					}
					if (submenu)
						submenulinks += "<li>" + link + "</li>";
					else
						links += "<li>" + link + "</li>";
				}
			}
			var btndropdown = "";
			if (ew_NotEmpty(links)) {
				if (submenu) { // End previous submenu
					if (ew_NotEmpty(submenulinks)) { // Set up submenu
						links += "<li class=\"dropdown-submenu\">" + submenulink + "<ul class=\"dropdown-menu\">" + submenulinks + "</ul></li>";
					} else {
						links += "<li>" + submenulink + "</li>";
					}
				}
				var btnclass = "dropdown-toggle btn btn-default";
				if (ew_NotEmpty(ButtonClass))
					btnclass = ew_AppendClass(btnclass, ButtonClass);
				var buttontitle = ew_HtmlTitle(DropDownButtonPhrase);
				buttontitle = (DropDownButtonPhrase != buttontitle) ? " title=\"" + buttontitle + "\"" : "";
				var button = "<button class=\"" + btnclass + "\"" + buttontitle + " data-toggle=\"dropdown\">" + DropDownButtonPhrase + " <b class=\"caret\"></b></button><ul class=\"dropdown-menu ewMenu\">" + links + "</ul>";				
				if (pos == "bottom") // Use dropup
					btndropdown = "<div class=\"btn-group dropup ewButtonGroup\">" + button + "</div>";
				else
					btndropdown = "<div class=\"btn-group ewButtonGroup\">" + button + "</div>";
			}
			foreach (var input in inputs)
				btndropdown += input;
			btndropdown += previewlinks;	
			return btndropdown;
		}

		// Hide detail items for dropdown
		public void HideDetailItemsForDropDown() {
			var showdtl = false;
			if (UseDropDownButton) {
				foreach (var item in Items) {
					if (item.Name != GroupOptionName && item.Visible && item.ShowInDropDown && !item.Name.StartsWith("detail_")) {
						showdtl = true;
						break;
					}
				}
			}
			if (!showdtl) {
				foreach (var item in Items) {
					if (item.Name.StartsWith("detail_"))
						item.Visible = false;
				}
			}
		}
	}

	//
	//  List option class
	//	
	public class cListOption
	{

		public string Name = "";

		public bool OnLeft = false;

		public string CssStyle = "";

		public string CssClass = "";

		public bool Visible = true;

		public string Header = "";

		public string Body = "";

		public string Footer = "";

		public string Tag = "td";

		public string Separator = "";

		public cListOptions Parent;

		public bool ShowInButtonGroup = true;

		public bool ShowInDropDown = true;

		public string ButtonGroupName = "_default";

		// Constructor
		public cListOption(string aName)
		{
			Name = aName;
		}

		// Move
		public void MoveTo(int Pos) {
			Parent.MoveItem(Name, Pos);
		}

		// Render
		public string Render(string Part, int ColSpan = 1) {
			var tagclass = Parent.TagClassName;
			var value = "";
			if (Part == "header") {
				if (tagclass == "") tagclass = "ewListOptionHeader";
				value = Header;
			} else if (Part == "body") {
				if (tagclass == "") tagclass = "ewListOptionBody";
				if (Parent.Tag != "td")
					tagclass = ew_AppendClass(tagclass, "ewListOptionSeparator");
				value = Body;
			} else if (Part == "footer") {
				if (tagclass == "") tagclass = "ewListOptionFooter";
				value = Footer;
			} else {
				value = Part;
			}
			if (ew_Empty(value) && Parent.Tag == "span" && ew_Empty(Parent.ScriptId))
				return "";
			var res = (ew_NotEmpty(value)) ? value : "&nbsp;";
			tagclass = ew_AppendClass(tagclass, CssClass);
			var attrs = new Dictionary<string, string>() {{"class", tagclass}, {"style", CssStyle}, {"data-name", Name}}; // ***
			if (ew_SameText(Parent.Tag, "td") && Parent.RowSpan > 1)
				attrs["rowspan"] = Convert.ToString(Parent.RowSpan);
			if (ew_SameText(Parent.Tag, "td") && ColSpan > 1)
				attrs["colspan"] = Convert.ToString(ColSpan);
			var name = Parent.TableVar + "_" + Name;
			if (Name != Parent.GroupOptionName) {
				if (!(new List<string>() {"checkbox", "rowcnt"}).Contains(Name)) {
					if (Parent.UseImageAndText)
						res = GetImageAndText(res);
					if (Parent.UseButtonGroup && ShowInButtonGroup) {
						res = Parent.RenderButtonGroup(res);
						if (OnLeft && ew_SameText(Parent.Tag, "td") && ColSpan > 1)
							res = "<div style=\"text-align: right\">" + res + "</div>";
					}
				}
				if (Part == "header")
					res = "<span id=\"elh_" + name + "\" class=\"" + name + "\">" + res + "</span>";
				else if (Part == "body")
					res = "<span id=\"el" + Parent.RowCnt + "_" + name + "\" class=\"" + name + "\">" + res + "</span>";
				else if (Part == "footer")
					res = "<span id=\"elf_" + name + "\" class=\"" + name + "\">" + res + "</span>";
			}

			// remove string tag = (Parent.Tag == "td" && Part == "header") ? "th" : Parent.Tag;
			var tag = (Parent.Tag == "td" && Part == "header") ? "th" : Parent.Tag;
			if (Parent.UseButtonGroup && ShowInButtonGroup)
				attrs["style"] += "white-space: nowrap;";
			res = ew_HtmlElement(tag, attrs, res);
			if (ew_NotEmpty(Parent.ScriptId)) {
				var js = ew_ExtractScript(ref res, Parent.ScriptClassName + "_js");
				if (Parent.ScriptType == "single") {
					if (Part == "header")
						res = "<script id=\"tpoh_" + Parent.ScriptId + "_" + Name + "\" type=\"text/html\">" + res + "</script>";
					else if (Part == "body")
						res = "<script id=\"tpob" + Parent.RowCnt + "_" + Parent.ScriptId + "_" + Name + "\" type=\"text/html\">" + res + "</script>";
					else if (Part == "footer")
						res = "<script id=\"tpof_" + Parent.ScriptId + "_" + Name + "\" type=\"text/html\">" + res + "</script>";
				}
				if (ew_NotEmpty(js))
					if (Parent.ScriptType == "single")
						res += js;
					else
						Parent.JavaScript += js;
			}
			return res;
		}

		// Get image and text link
		public string GetImageAndText(string body) {
			foreach (Match match in Regex.Matches(body, @"<a([^>]*)>([\s\S]*?)</a\s*>", RegexOptions.IgnoreCase)) {
				var submatch = Regex.Match(match.Groups[1].Value, @"\s+data-caption\s*=\s*['""]([\s\S]*?)['""]", RegexOptions.IgnoreCase);
				if (submatch.Success) { // Match data-caption='caption'
					var caption = submatch.Groups[1].Value;
					if (Regex.Match(match.Groups[2].Value, @"<img([^>]*)>", RegexOptions.IgnoreCase).Success) // Image and text
						body = body.Replace(match.Groups[2].Value, match.Groups[2].Value + "&nbsp;&nbsp;" + caption);
				}
			}
			return body;
		}
	}

	//
	// CSS parser
	//
	public class cCssParser
	{

		public Dictionary<string, Dictionary<string, string>> css;

		// Constructor
		public cCssParser()
		{
			css = new Dictionary<string, Dictionary<string, string>>();
		}

		// Clear all styles
		public void Clear()
		{
			foreach (KeyValuePair<string, Dictionary<string, string>> kvp in css)
				kvp.Value.Clear();
			css.Clear();
		}

		// add a section
		public void Add(string key, string codestr)
		{
			key = key.ToLower().Trim();
			if (key == "")
				return;
			codestr = codestr.ToLower();
			if (!css.ContainsKey(key))
				css[key] = new Dictionary<string, string>();
			string[] codes = codestr.Split(new char[] { ';' });
			if (codes.Length > 0)
			{
				foreach (string code in codes)
				{
					string sCode = code.ToLower();
					string[] arCode = code.Split(new char[] { ':' });
					string codekey = arCode[0];
					string codevalue = "";
					if (arCode.Length > 1)
						codevalue = arCode[1];
					if (codekey.Length > 0)
					{
						css[key][codekey.Trim()] = codevalue.Trim();
					}
				}
			}
		}

		// explode a string into two
		private void Explode(string str, char sep, ref string str1, ref string str2)
		{
			string[] ar = str.Split(new char[] { sep });
			str1 = ar[0];
			if (ar.Length > 1)
				str2 = ar[1];
		}

		// Get a style
		public string Get(string key, string property)
		{
			key = key.ToLower();

			property = property.ToLower();
			string tag = "", subtag = "", cls = "", id = "";
			Explode(key, ':', ref tag, ref subtag);
			Explode(tag, '.', ref tag, ref cls);
			Explode(tag, '#', ref tag, ref id);
			string result = "";
			foreach (KeyValuePair<string, Dictionary<string, string>> kvp in css)
			{
				string _tag = kvp.Key;
				Dictionary<string, string> value = kvp.Value;
				string _subtag = "", _cls = "", _id = "";
				Explode(_tag, ':', ref _tag, ref _subtag);
				Explode(_tag, '.', ref _tag, ref _cls);
				Explode(_tag, '#', ref _tag, ref _id);
				bool tagmatch = (tag == _tag || _tag.Length == 0);
				bool subtagmatch = (subtag == _subtag || _subtag.Length == 0);
				bool classmatch = (cls == _cls || _cls.Length == 0);
				bool idmatch = (id == _id);
				if (tagmatch && subtagmatch && classmatch && idmatch)
				{
					string temp = _tag;
					if (temp.Length > 0 && _cls.Length > 0)
					{
						temp += "." + _cls;
					}
					else if (temp.Length == 0)
					{
						temp = "." + _cls;
					}
					if (temp.Length > 0 && _subtag.Length > 0)
					{
						temp += ":" + _subtag;
					}
					else if (temp.Length == 0)
					{
						temp = ":" + _subtag;
					}
					if (css[temp].ContainsKey(property))
						result = css[temp][property];
				}
			}
			return result;
		}

		// Get section as dictionary
		public Dictionary<string, string> GetSection(string key)
		{
			key = key.ToLower();
			string tag = "", subtag = "", cls = "", id = "";
			Explode(key, ':', ref tag, ref subtag);
			Explode(tag, '.', ref tag, ref cls);
			Explode(tag, '#', ref tag, ref id);
			Dictionary<string, string> result = new Dictionary<string, string>();
			foreach (KeyValuePair<string, Dictionary<string, string>> kvp in css)
			{
				string _tag = kvp.Key;
				Dictionary<string, string> value = kvp.Value;
				string _subtag = "", _cls = "", _id = "";
				Explode(_tag, ':', ref _tag, ref _subtag);
				Explode(_tag, '.', ref _tag, ref _cls);
				Explode(_tag, '#', ref _tag, ref _id);
				bool tagmatch = (tag == _tag || _tag.Length == 0);
				bool subtagmatch = (subtag == _subtag || _subtag.Length == 0);
				bool classmatch = (cls == _cls || _cls.Length == 0);
				bool idmatch = (id == _id);
				if (tagmatch && subtagmatch && classmatch && idmatch)
				{
					string temp = _tag;
					if (temp.Length > 0 && _cls.Length > 0)
					{
						temp += "." + _cls;
					}
					else if (temp.Length == 0)
					{
						temp = "." + _cls;
					}
					if (temp.Length > 0 && _subtag.Length > 0)
					{
						temp += ":" + _subtag;
					}
					else if (temp.Length == 0)
					{
						temp = ":" + _subtag;
					}
					foreach (KeyValuePair<string, string> kv in css[temp])
					{
						result[kv.Key] = kv.Value;
					}
				}
			}
			return result;
		}

		// Get section as string
		public string GetSectionString(string key)
		{
			Dictionary<string, string> dict = GetSection(key);
			string result = "";
			foreach (KeyValuePair<string, string> kv in dict)
				result += kv.Key + ":" + kv.Value + ";"; // no spaces
			return result;
		}

		// Parse string
		public bool ParseStr(string str)
		{
			Clear();

			// Remove comments
			str = Regex.Replace(str, @"\/\*(.*)?\*\/", "");

			// Parse the csscode
			string[] parts = str.Split(new char[] { '}' });
			if (parts.Length > 0)
			{
				foreach (string part in parts)
				{
					string keystr = "", codestr = "";
					Explode(part, '{', ref keystr, ref codestr);
					string[] keys = keystr.Split(new char[] { ',' });
					if (keys.Length > 0)
					{
						foreach (string akey in keys)
						{
							string key = akey;
							if (key.Length > 0)
							{
								key = key.Replace("\n", "");
								key = key.Replace("\\", "");
								Add(key, codestr.Trim());
							}
						}
					}
				}
			}
			return (css.Count > 0);
		}

		// Parse a stylesheet
		public bool ParseFile(string filename)
		{
			Clear();
			if (File.Exists(filename))
			{
				return ParseStr(File.ReadAllText(filename));
			}
			else
			{
				return false;
			}
		}

		// Get CSS string
		public string GetCSS()
		{
			string result = "";
			foreach (KeyValuePair<string, Dictionary<string, string>> kvp in css)
			{
				result += kvp.Key + " {\n";
				foreach (KeyValuePair<string, string> kv in kvp.Value)
				{
					result += "  " + kv.Key + ": " + kv.Value + ";\n";
				}
				result += "}\n\n";
			}
			return result;
		}
	}

	//
	// Connection object
	//
	public class cConnectionBase : IDisposable
	{

		public string ConnectionString = EW_DB_CONNECTION_STRING;

		public ewConnection Conn;		

		public ewTransaction Trans;

		private ewConnection _Conn; 

		private List<ewCommand> _Command = new List<ewCommand>(); 

		private List<ewDataReader> _DataReader = new List<ewDataReader>();

		// Constructor
		public cConnectionBase(string ConnStr)
		{
			ConnectionString = ConnStr;
			Conn = OpenConnection();		
		}

		// Constructor
		public cConnectionBase()
        {
			EW_DB_CONNECTION_STRING = "Persist Security Info=False;Data Source=localhost\\SQLEXPRESS;Initial Catalog=Frescode;Trusted_Connection=Yes";
			ConnectionString = EW_DB_CONNECTION_STRING;
			Conn = OpenConnection();
		}

		// Execute SQL for the main connection
		public int Execute(string Sql)
		{			
			using (var cmd = GetCommand(Sql)) {
				var res = cmd.ExecuteNonQuery();
				return res;
			}			
		}

		// Execute SQL for a specified connection
		public int Execute(string Sql, ewConnection Cnn)
		{			
			using (var cmd = new ewCommand(Sql, Cnn)) {
				return cmd.ExecuteNonQuery();
			}			
		}		

		// Execute SQL
		public int ExecuteNonQuery(string Sql)
		{			
			using (var cmd = OpenCommand(Sql)) { // Use new connection
				return cmd.ExecuteNonQuery();
			}		
		}

		// Execute SQL and return first value of first row
		public object ExecuteScalar(string Sql, bool Primary = false)
		{
			if (Primary) {
				using (var cmd = GetCommand(Sql)) { // Use main connection
					return cmd.ExecuteScalar();
				}	
			} else {
				using (var cmd = OpenCommand(Sql)) { // Use new connection
					return cmd.ExecuteScalar();
				}
			}
		}		

		// Get last insert ID
		public object GetLastInsertId()
		{
			using (var cmd = GetCommand("SELECT @@Identity")) { // Use main connection
				return cmd.ExecuteScalar();
			}			
			return System.DBNull.Value;
		}

		// Get data reader
		public ewDataReader GetDataReader(string Sql)
		{
			try {
				var cmd = GetCommand(Sql);  // Use main connection
				return cmd.ExecuteReader();
			} catch {
				if (EW_DEBUG_ENABLED)
					throw; 
				return null;
			}
		}

		// Get a new connection
		public ewConnection OpenConnection()
		{
			Database_Connecting(ref ConnectionString); 
			var c = new ewConnection(ConnectionString);			
			c.Open();
			if (EW_DEFAULT_DATE_FORMAT_ID > 0) // ASPX
        		Execute("SET DATEFORMAT ymd", c);
			Database_Connected(c);
			return c; 
		}

		// Get command
		public ewCommand GetCommand(string Sql)
		{
			var Cmd = new ewCommand(Sql, Conn);
			if (Trans != null)
				Cmd.Transaction = Trans; 
			return Cmd;
		}		

		// Get a new command
		public ewCommand OpenCommand(string Sql)
		{ 
			try {
				if (_Conn == null)
					_Conn = OpenConnection(); // Use secondary connection							
				var cmd = new ewCommand(Sql, _Conn);					
				_Command.Add(cmd);							
				return cmd;
			} catch {
				if (EW_DEBUG_ENABLED)
					throw; 
				return null;
			}
		}

		// Get a new data reader
		public ewDataReader OpenDataReader(string Sql)
		{ 
			try {
				var cmd = OpenCommand(Sql); // Use secondary connection					
				var r = cmd.ExecuteReader();
				_DataReader.Add(r);			
				return r;
			} catch {
				if (EW_DEBUG_ENABLED)
					throw; 
				return null;
			}
		}

		// Get a row as OrderedDictionary from data reader
		public OrderedDictionary GetRow(ewDataReader dr)
		{
			if (dr != null) {
				var od = new OrderedDictionary();
				for (int i = 0; i < dr.FieldCount; i++) {
					try {
						if (ew_NotEmpty(dr.GetName(i))) {
							od[dr.GetName(i)] = dr[i];
						} else {
							od[Convert.ToString(i)] = dr[i]; // Convert index to string as key
						}
					} catch {}
				}
				return od;
			}
			return null;
		}

		// Get a row as OrderedDictionary by SQL
		public OrderedDictionary GetRow(string Sql)
		{
			using (var dr = OpenDataReader(Sql)) {			
				if (dr != null && dr.Read())
					return GetRow(dr);				
			}
			return null;			
		}

		// Get a row as string[] from data reader
		public string[] GetRow2(ewDataReader dr)
		{
			if (dr != null && dr.FieldCount > 0) {
				var ar = new string[dr.FieldCount];
				for (int i = 0; i < dr.FieldCount; i++)
					ar[i] = Convert.ToString(dr[i]);
				return ar;
			}
			return null;
		}		

		// Get rows as List<OrderedDictionary>
		public List<OrderedDictionary> GetRows(ewDataReader dr)
		{
			if (dr != null) {		
				var rows = new List<OrderedDictionary>();
				while (dr.Read())
					rows.Add(GetRow(dr));
				dr.Close();
				dr.Dispose();
				return rows;
			}
			return null;
		}

		// Get rows as List<OrderedDictionary> by SQL
		public List<OrderedDictionary> GetRows(string Sql)
		{
			var dr = OpenDataReader(Sql);
			return GetRows(dr);			
		}

		// Get rows as List<string[]> by SQL
		public List<string[]> GetRows2(string Sql)
		{
			using (var dr = OpenDataReader(Sql)) {
				if (dr != null) {		
					var rows = new List<string[]>();
					while (dr.Read())
						rows.Add(GetRow2(dr));
					return rows;
				}
			}
			return null;			
		}

		// Get rows as List<OrderedDictionary> by SQL with main connection
        public List<OrderedDictionary> GetRows3(string Sql)
        {
            var dr = GetDataReader(Sql);
            return GetRows(dr);
        }		

		// Get rows as List<DbDataRecord> by SQL
		public List<DbDataRecord> GetRecords(string Sql)
		{
			using (var dr = OpenDataReader(Sql)) {
				if (dr != null) {				
					var list = new List<DbDataRecord>();		
					foreach (DbDataRecord record in dr)
						list.Add(record);
					return list;
				}
			}
			return null;
		}

		// Get first row as DbDataRecord by SQL
		public DbDataRecord GetRecord(string Sql)
		{
			using (var dr = OpenDataReader(Sql)) {
				if (dr != null) {
					foreach (DbDataRecord r in dr)
		               return r;  
				}
			}
			return null;			
		}		

		// Get count (by dataset)
		public int GetCount(string Sql)
		{
			int cnt = 0;
			using (var dr = OpenDataReader(Sql)) {			
				if (dr != null) {
					while (dr.Read())
						cnt++;
				}
			}
			return cnt;			
		}

		// Begin transaction
		public void BeginTrans()
		{
			try {
				Trans = Conn.BeginTransaction(IsolationLevel.ReadUncommitted);
			} catch {
				if (EW_DEBUG_ENABLED)
					throw; 
			}
		}

		// Commit transaction
		public void CommitTrans()
		{
			try {
				if (Trans != null)
					Trans.Commit();
			} catch {
				if (EW_DEBUG_ENABLED)
					throw; 
			} 
		}

		// Rollback transaction
		public void RollbackTrans()
		{
			try {
				if (Trans != null)
					Trans.Rollback();
			} catch {
				if (EW_DEBUG_ENABLED)
					throw; 
			} 
		}

		// Concat // ASPX
		public string Concat(params string[] list) {
			if (EW_IS_MSACCESS) {
				return String.Join(" & ", list);
			} else if (EW_IS_MSSQL) { 
				return String.Join(" + ", list);			
			} else if (EW_IS_ORACLE || EW_IS_POSTGRESQL) {
				return String.Join(" || ", list);
			} else { // MySQL/ODBC 
				return "CONCAT(" + String.Join(", ", list) + ")";
			}
		}

		// Dispose
		public void Dispose()
		{
			if (Trans != null)
				Trans.Dispose(); 
			Conn.Close();
			Conn.Dispose();
			foreach (ewDataReader dr in _DataReader) {
				if (dr != null) {
					dr.Close();
					dr.Dispose();
				}
			}
			foreach (ewCommand cmd in _Command) {
				if (cmd != null)
					cmd.Dispose();
			}
			if (_Conn != null) {
				_Conn.Close();
				_Conn.Dispose();
			}
		}

		// Close
		public void Close()
		{
			Dispose();
		}

		// Database Connecting event
		public virtual void Database_Connecting(ref string Connstr) {

			//ew_Write("Database Connecting");
		}

		// Database Connected event
		public virtual void Database_Connected(ewConnection Cnn) {

			//Execute("Your SQL", Cnn);
		}
	}		

	// Resize binary to thumbnail
	public static bool ew_ResizeBinary(ref byte[] filedata, ref int width, ref int height, int interpolation = -1)
	{
		return true; // No resize
	}

	// Resize file to thumbnail file
	public static bool ew_ResizeFile(string fn, string tn, ref int width, ref int height, int interpolation = -1)
	{
		try {
			if (File.Exists(fn)) {
				File.Copy(fn, tn); // Copy only, no resize
				return true;
			}
			return false;
		} catch {
			if (EW_DEBUG_ENABLED) throw; 
			return false;
		}
	}

	// Resize file to binary
	public static byte[] ew_ResizeFileToBinary(string fn, ref int width, ref int height, int interpolation = -1)
	{
		try {
			if (File.Exists(fn)) {
				WebImage img = new WebImage(fn);
				return img.GetBytes(); // No resize
			}
			return null;
		} catch {
			if (EW_DEBUG_ENABLED) throw; 
			return null;
		}
	}

	//
	// Basic Search class
	//
	public class cBasicSearch {

		public string TblVar = "";		

		public string KeywordDefault = "";

		public string TypeDefault = "";

		private string _Prefix = "";

		// Constructor
		public cBasicSearch(string tblvar) {
			TblVar = tblvar;
			_Prefix = EW_PROJECT_NAME + "_" + tblvar + "_";
		}

		// Session variable name
		public string GetSessionName(string suffix) {
			return _Prefix + suffix;
		}

		// Load default
		public void LoadDefault() {
			Keyword = KeywordDefault;
			Type = TypeDefault;
		}

		// Unset session
		public void UnsetSession() {
			ew_Session.Remove(GetSessionName(EW_TABLE_BASIC_SEARCH_TYPE));
			ew_Session.Remove(GetSessionName(EW_TABLE_BASIC_SEARCH));
		}

		// Isset session
		public bool IssetSession {
			get { return ew_Session[GetSessionName(EW_TABLE_BASIC_SEARCH)] != null; }
		}

		// Get Keyword
		public string Keyword {
			get { return Convert.ToString(ew_Session[GetSessionName(EW_TABLE_BASIC_SEARCH)]); }
			set { ew_Session[GetSessionName(EW_TABLE_BASIC_SEARCH)] = value; }
		}

		// Type
		public string Type {
			get { return Convert.ToString(ew_Session[GetSessionName(EW_TABLE_BASIC_SEARCH_TYPE)]); } 
			set { ew_Session[GetSessionName(EW_TABLE_BASIC_SEARCH_TYPE)] = value; }
		}

		public string TypeName() {
			string typ = Type;
			switch (typ) {
				case "=": return Language.Phrase("QuickSearchExact");
				case "AND": return Language.Phrase("QuickSearchAll");
				case "OR": return Language.Phrase("QuickSearchAny");
				default: return Language.Phrase("QuickSearchAuto");
			}
		}

		public string TypeNameShort() {
			string typ = Type;
			string typname;
			switch (typ) {
				case "=": typname = Language.Phrase("QuickSearchExactShort"); break;
				case "AND": typname = Language.Phrase("QuickSearchAllShort"); break;
				case "OR": typname = Language.Phrase("QuickSearchAnyShort"); break;
				default: typname = Language.Phrase("QuickSearchAutoShort"); break;
			}
			if (ew_NotEmpty(typname)) typname += "&nbsp;";
			return typname;
		}

		public void Save() {
			ew_Session[GetSessionName(EW_TABLE_BASIC_SEARCH)] = Keyword;
			ew_Session[GetSessionName(EW_TABLE_BASIC_SEARCH_TYPE)] = Type;
		}

		public void Load() {

			// Blank
		}
	}

	//
	//  Advanced Search class
	//
	public class cAdvancedSearch
	{

		public string TblVar = "";

		public string FldVar = "";

		public string SearchValue = null; // Search value		

		public string SearchOperator = "="; // Search operator		

		public string SearchCondition = "AND"; // Search condition		

		public string SearchValue2 = null; // Search value 2		

		public string SearchOperator2 = "="; // Search operator 2

		public string SearchValueDefault = null; // Search value default

		public string SearchOperatorDefault = ""; // Search operator default

		public string SearchConditionDefault = ""; // Search condition default

		public string SearchValue2Default = null; // Search value 2 default

		public string SearchOperator2Default = ""; // Search operator 2 default

		private string _Prefix = "";

		private string _Suffix = "";

		// Constructor
		public cAdvancedSearch(string tblvar, string fldvar) {
			TblVar = tblvar;
			FldVar = fldvar;
			_Prefix = EW_PROJECT_NAME + "_" + tblvar + "_" + EW_TABLE_ADVANCED_SEARCH + "_";
			_Suffix = "_" + fldvar.Substring(2);
		}

		// Session variable name
		public string GetSessionName(string infix) {
			return _Prefix + infix + _Suffix;
		}

		// Unset session
		public void UnsetSession() {
			ew_Session.Remove(GetSessionName("x"));
			ew_Session.Remove(GetSessionName("z"));
			ew_Session.Remove(GetSessionName("v"));
			ew_Session.Remove(GetSessionName("y"));
			ew_Session.Remove(GetSessionName("w"));
		}

		// Isset session
		public bool IssetSession {
			get { return ew_Session[GetSessionName("x")] != null || ew_Session[GetSessionName("y")] != null; }
		}

		// Save to session
		public void Save() {			
			if (!ew_SameStr(ew_Session[GetSessionName("x")], SearchValue))
				ew_Session[GetSessionName("x")] = SearchValue;
			if (!ew_SameStr(ew_Session[GetSessionName("y")], SearchValue2))
				ew_Session[GetSessionName("y")] = SearchValue2;
			if (!ew_SameStr(ew_Session[GetSessionName("z")], SearchOperator))
				ew_Session[GetSessionName("z")] = SearchOperator;
			if (!ew_SameStr(ew_Session[GetSessionName("v")], SearchCondition))
				ew_Session[GetSessionName("v")] = SearchCondition;
			if (!ew_SameStr(ew_Session[GetSessionName("w")], SearchOperator2))
				ew_Session[GetSessionName("w")] = SearchOperator2;
		}

		// Load from session
		public void Load() {
			SearchValue = Convert.ToString(ew_Session[GetSessionName("x")]);
			SearchOperator = Convert.ToString(ew_Session[GetSessionName("z")]);
			SearchCondition = Convert.ToString(ew_Session[GetSessionName("v")]);
			SearchValue2 = Convert.ToString(ew_Session[GetSessionName("y")]);
			SearchOperator2 = Convert.ToString(ew_Session[GetSessionName("w")]);
		}

		// Get value
		public string GetValue(string infix) {
			return Convert.ToString(ew_Session[GetSessionName(infix)]);
		}

		// Load default values
		public void LoadDefault() {
			if (ew_NotEmpty(SearchValueDefault)) SearchValue = SearchValueDefault;
			if (ew_NotEmpty(SearchOperatorDefault)) SearchOperator = SearchOperatorDefault;
			if (ew_NotEmpty(SearchConditionDefault)) SearchCondition = SearchConditionDefault;
			if (ew_NotEmpty(SearchValue2Default)) SearchValue2 = SearchValue2Default;
			if (ew_NotEmpty(SearchOperator2Default)) SearchOperator2 = SearchOperator2Default;
		}
	}

	//
	//  Upload class
	//
	public class cUpload
	{

		public int Index = -1; // Index to handle multiple form elements

		public string TblVar; // Table variable

		public string FldVar; // Field variable

		public object DbValue = System.DBNull.Value; // Value from database // ASPX

		public string Message = ""; // Error message

		public object Value; // Upload value

		public string FileName = ""; // Upload file name

		public long FileSize; // Upload file size

		public string ContentType = ""; // File content type

		public int ImageWidth = -1; // Image width

		public int ImageHeight = -1; // Image height

		public bool UploadMultiple = false; // Multiple upload

		public bool KeepFile = true; // Keep old file

		// Contructor
		public cUpload(string ATblVar, string AFldVar)
		{
			TblVar = ATblVar;
			FldVar = AFldVar;
		}

		public bool IsEmpty {
			get {
				return DbValue == System.DBNull.Value;
			}	
		}

		// Check the file type of the uploaded file
		private bool UploadAllowedFileExt(string FileName)
		{
			return ew_CheckFileType(FileName);
		}

		// Get upload file
		public bool UploadFile()
		{
			try {				
				Value = System.DBNull.Value; // Reset first
				Message = ""; // Reset first
				var fldvar = (Index < 0) ? FldVar : FldVar.Substring(0, 1) + Index + FldVar.Substring(1);
				var wrkvar = "fn_" + fldvar;
				FileName = ew_Post(wrkvar); // Get file name
				wrkvar = "fa_" + fldvar;
				KeepFile = ew_Post(wrkvar) == "1"; // Check if keep old file
				if (!KeepFile && ew_NotEmpty(FileName) && !UploadMultiple) {
					var f = ew_UploadTempPath(fldvar) + EW_PATH_DELIMITER + FileName;
					var fi = new FileInfo(f);
					if (fi.Exists) {
						Value = File.ReadAllBytes(f);
						FileSize = fi.Length;
						ContentType = ew_ContentType(((byte[])Value).Take(11), f);
						try {
							System.Drawing.Image img = System.Drawing.Image.FromFile(f);
							ImageWidth = Convert.ToInt32(img.PhysicalDimension.Width);
							ImageHeight = Convert.ToInt32(img.PhysicalDimension.Height);
						} catch {}
					}
				}
				return true;
			} catch (Exception e) {
				Message = e.Message;
				return false;
			}
		}

		// Resize image
		public bool Resize(int Width, int Height, int Interpolation)
		{
			bool result = false;
			if (!Convert.IsDBNull(Value)) {
				int wrkWidth = Width;
				int wrkHeight = Height;
				byte[] data = (byte[])Value;
				result = ew_ResizeBinary(ref data, ref wrkWidth, ref wrkHeight, Interpolation);
				if (result) {
					Value = data;
					if (wrkWidth > 0 && wrkHeight > 0) {
						ImageWidth = wrkWidth;
						ImageHeight = wrkHeight;
					}
					FileSize = data.Length;
				}
			}
			return result;
		}

		// Save uploaded data to file (Path relative to application root)
		public bool SaveToFile(string Path, string NewFileName, bool Overwrite, int Idx = -1)
		{
			if (!Convert.IsDBNull(Value)) {
				Path = ew_UploadPathEx(true, Path);
				if (ew_Empty(NewFileName)) NewFileName = FileName; 
				byte[] data = (byte[])Value;
				if (!Overwrite)
					NewFileName = ew_UploadFileNameEx(Path, NewFileName);				
				return ew_SaveFile(Path, NewFileName, ref data);
			} else if (Idx >= 0) { // Use file from upload temp folder
				var ar = FileName.Split(new char[] { Convert.ToChar(EW_MULTIPLE_UPLOAD_SEPARATOR) });
				if (Idx < ar.Length) {
					var fn = ar[Idx];
					var fldvar = (Index < 0) ? FldVar : FldVar.Substring(0, 1) + Index + FldVar.Substring(1);
					var OldFile = ew_UploadTempPath(fldvar) + EW_PATH_DELIMITER + fn;
					if (File.Exists(OldFile)) {
						if (!Overwrite)
							NewFileName = ew_UploadFileNameEx(Path, NewFileName);
						return ew_CopyFile(Path, NewFileName, OldFile, Overwrite); // ASPX
					}
				}
			}
			return false;
		}

		// Resize and save uploaded data to file (Path relative to application root)
		public bool ResizeAndSaveToFile(int Width, int Height, int Interpolation, string Path, string NewFileName, bool Overwrite, int Idx = -1)
		{
			var bResult = false;
			if (!Convert.IsDBNull(Value)) {

				// Save old values
				var OldValue = Value;				
				var OldWidth = ImageWidth;
				var OldHeight = ImageHeight;
				var OldFileSize = FileSize;
				try {
					Resize(Width, Height, Interpolation);
					bResult = SaveToFile(Path, NewFileName, Overwrite);
				} finally { // Restore old values
					Value = OldValue;					
					ImageWidth = OldWidth;
					ImageHeight = OldHeight;
					FileSize = OldFileSize;
				}
			} else if (Idx >= 0) { // Use file from upload temp folder
				var ar = FileName.Split(new char[] { Convert.ToChar(EW_MULTIPLE_UPLOAD_SEPARATOR) });
				if (Idx < ar.Length) {
					var fn = ar[Idx];
					var fldvar = (Index < 0) ? FldVar : FldVar.Substring(0, 1) + Index + FldVar.Substring(1);
					var file = ew_UploadTempPath(fldvar) + EW_PATH_DELIMITER + fn;
					if (File.Exists(file)) {
						Value = File.ReadAllBytes(file);
						Resize(Width, Height, Interpolation);
						try {
							bResult = SaveToFile(Path, NewFileName, Overwrite);
						} finally {							
							Value = System.DBNull.Value;
						}					
					}
				}
			}
			return bResult;
		}
	}

	// Get content type
	public static string ew_ContentType(IEnumerable<byte> data, string fn = "") {
		if (data != null && (data.Take(6).SequenceEqual(new byte[] {0x47, 0x49, 0x46, 0x38, 0x37, 0x61}) || data.Take(6).SequenceEqual(new byte[] {0x47, 0x49, 0x46, 0x38, 0x39, 0x61}))) { // gif
			return "image/gif";
		} else if (data != null && data.Take(4).SequenceEqual(new byte[] {0xFF, 0xD8, 0xFF, 0xE0}) && data.Skip(6).Take(5).SequenceEqual(new byte[] {0x4A, 0x46, 0x49, 0x46, 0x00})) { // jpg
			return "image/jpeg";
		} else if (data != null && data.Take(8).SequenceEqual(new byte[] {0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A})) { // png
			return "image/png";
		} else if (data != null && data.Take(2).SequenceEqual(new byte[] {0x42, 0x4D})) { // bmp
			return "image/bmp";
		} else if (data != null && data.Take(4).SequenceEqual(new byte[] {0x25, 0x50, 0x44, 0x46})) { // pdf
			return "application/pdf";
		} else if (fn != "") { // Use file extension to get mime type			
			var extension = Path.GetExtension(fn).Substring(1).ToLower();
			return (EW_MIME_TYPES.ContainsKey(extension)) ? EW_MIME_TYPES[extension] : "";
		} else {
			return "images";
		}
	}	

	// Return multi-value search SQL
	public static string ew_GetMultiSearchSql(ref cField Fld, string FldOpr, string FldVal)
	{
		if (FldOpr == "IS NULL" || FldOpr == "IS NOT NULL") {
			return Fld.FldExpression + " " + FldOpr;
		} else {	
			string sSql;
			string sWrk = "";
			string[] arVal = FldVal.Split(new[] {','});
			for (int i = 0; i < arVal.Length; i++) {
				string sVal = arVal[i].Trim();
				if (sVal == EW_NULL_VALUE) {
					sSql = Fld.FldExpression + " IS NULL";
				} else if (sVal == EW_NOT_NULL_VALUE) {
					sSql = Fld.FldExpression + " IS NOT NULL";
				} else if (EW_IS_MYSQL) {
					sSql = "FIND_IN_SET('" + ew_AdjustSql(sVal) + "', " + Fld.FldExpression + ")";
				} else {
					if (arVal.Length == 1 || EW_SEARCH_MULTI_VALUE_OPTION == 3) {
						sSql = Fld.FldExpression + " = '" + ew_AdjustSql(sVal) + "' OR " + ew_GetMultiSearchSqlPart(ref Fld, sVal);
					} else {
						sSql = ew_GetMultiSearchSqlPart(ref Fld, sVal);
					}
				}
				if (ew_NotEmpty(sWrk)) {
					if (EW_SEARCH_MULTI_VALUE_OPTION == 2) {
						sWrk = sWrk + " AND ";
					} else if (EW_SEARCH_MULTI_VALUE_OPTION == 3) {
						sWrk = sWrk + " OR ";
					}
				}
				sWrk = sWrk + "(" + sSql + ")";
			}
			return sWrk;
		}
	}

	// Get multi search SQL part
	public static string ew_GetMultiSearchSqlPart(ref cField Fld, string FldVal)
	{
		return Fld.FldExpression + ew_Like("'" + ew_AdjustSql(FldVal) + ",%'") + " OR " +
			Fld.FldExpression + ew_Like("'%," + ew_AdjustSql(FldVal) + ",%'") + " OR " +
			Fld.FldExpression + ew_Like("'%," + ew_AdjustSql(FldVal) + "'");
	}

	// Check if float format
	public static bool ew_IsFloatFormat(int FldType) {
		return (FldType == 4 || FldType == 5 || FldType == 131 || FldType == 6);
	}

	// Get search SQL
	public static string ew_GetSearchSql(ref cField Fld, string FldVal, string FldOpr, string FldCond, string FldVal2, string FldOpr2)
	{
		string sSql = "";
		bool bVirtual = (Fld.FldIsVirtual && Fld.FldVirtualSearch);
		string sFldExpression = (bVirtual) ? Fld.FldVirtualExpression : Fld.FldExpression;
		int FldDataType = Fld.FldDataType;
		if (ew_IsFloatFormat(Fld.FldType)) {
			FldVal = ew_StrToFloat(FldVal);
			FldVal2 = ew_StrToFloat(FldVal2);
		}
		if (bVirtual)
			FldDataType = EW_DATATYPE_STRING;
		if (FldDataType == EW_DATATYPE_NUMBER) { // Fix wrong operator
			if (FldOpr == "LIKE" || FldOpr == "STARTS WITH" || FldOpr == "ENDS WITH") {
				FldOpr = "=";
			} else if (FldOpr == "NOT LIKE") {
				FldOpr = "<>";
			}
			if (FldOpr2 == "LIKE" || FldOpr2 == "STARTS WITH" || FldOpr == "ENDS WITH") {
				FldOpr2 = "=";
			} else if (FldOpr2 == "NOT LIKE") {
				FldOpr2 = "<>";
			}
		}
		if (FldOpr == "BETWEEN") {
			var IsValidValue = (FldDataType != EW_DATATYPE_NUMBER) ||
				(FldDataType == EW_DATATYPE_NUMBER && Information.IsNumeric(FldVal) && Information.IsNumeric(FldVal2));
			if (ew_NotEmpty(FldVal) && ew_NotEmpty(FldVal2) && IsValidValue)
				sSql = sFldExpression + " BETWEEN " + ew_QuotedValue(FldVal, FldDataType) +
					" AND " + ew_QuotedValue(FldVal2, FldDataType);
		} else {

			// Handle first value
			if (FldVal == EW_NULL_VALUE || FldOpr == "IS NULL") {
				sSql = Fld.FldExpression + " IS NULL";
			} else if (FldVal == EW_NOT_NULL_VALUE || FldOpr == "IS NOT NULL") {
				sSql = Fld.FldExpression + " IS NOT NULL";
			} else {
				var IsValidValue = (FldDataType != EW_DATATYPE_NUMBER) ||
					(FldDataType == EW_DATATYPE_NUMBER && Information.IsNumeric(FldVal));
				if (ew_NotEmpty(FldVal) && IsValidValue && ew_IsValidOpr(FldOpr, FldDataType)) {
					sSql = sFldExpression + ew_SearchString(FldOpr, FldVal, FldDataType);
					if (Fld.FldDataType == EW_DATATYPE_BOOLEAN && FldVal == Fld.FalseValue && FldOpr == "=")
						sSql = "(" + sSql + " OR " + sFldExpression + " IS NULL)";
				}
			}

			// Handle second value
			string sSql2 = "";
			if (FldVal2 == EW_NULL_VALUE || FldOpr2 == "IS NULL") {
				sSql2 = Fld.FldExpression + " IS NULL";
			} else if (FldVal2 == EW_NOT_NULL_VALUE || FldOpr2 == "IS NOT NULL") {
				sSql2 = Fld.FldExpression + " IS NOT NULL";
			} else {
				var IsValidValue = (FldDataType != EW_DATATYPE_NUMBER) ||
					(FldDataType == EW_DATATYPE_NUMBER && Information.IsNumeric(FldVal2));
				if (ew_NotEmpty(FldVal2) && IsValidValue && ew_IsValidOpr(FldOpr2, FldDataType)) {
					sSql2 = sFldExpression + ew_SearchString(FldOpr2, FldVal2, FldDataType);
					if (Fld.FldDataType == EW_DATATYPE_BOOLEAN && FldVal2 == Fld.FalseValue && FldOpr2 == "=")
						sSql2 = "(" + sSql2 + " OR " + sFldExpression + " IS NULL)";
				}
			}

			// Combine SQL
			if (ew_NotEmpty(sSql2)) {
				if (ew_NotEmpty(sSql))
					sSql = "(" + sSql + " " + ((FldCond == "OR") ? "OR" : "AND") + " " + sSql2 + ")";
				else
					sSql = sSql2;
			}
		}
		return sSql;
	}

	// Return search string
	public static string ew_SearchString(string FldOpr, string FldVal, int FldType)
	{
		if (FldVal == EW_NULL_VALUE || FldOpr == "IS NULL") {
			return " IS NULL";
		} else if (FldVal == EW_NOT_NULL_VALUE || FldOpr == "IS NOT NULL") {
			return " IS NOT NULL";
		} else if (FldOpr == "LIKE") {
			return ew_Like(ew_QuotedValue("%" + FldVal + "%", FldType));
		} else if (FldOpr == "NOT LIKE") {
			return " NOT " + ew_Like(ew_QuotedValue("%" + FldVal + "%", FldType));
		} else if (FldOpr == "STARTS WITH") {
			return ew_Like(ew_QuotedValue(FldVal + "%", FldType));
		} else if (FldOpr == "ENDS WITH") {
			return ew_Like(ew_QuotedValue("%" + FldVal, FldType));
		} else {
			return " " + FldOpr + " " + ew_QuotedValue(FldVal, FldType);
		}
	}

	// Check if valid operator
	public static bool ew_IsValidOpr(string Opr, int FldType)
	{
		bool Valid = (Opr == "=" || Opr == "<" || Opr == "<=" || Opr == ">" || Opr == ">=" || Opr == "<>");
		if (FldType == EW_DATATYPE_STRING || FldType == EW_DATATYPE_MEMO) {
			Valid = Valid || Opr == "LIKE" || Opr == "NOT LIKE" || Opr == "STARTS WITH" || Opr == "ENDS WITH";
		}
		return Valid;
	}

	// Quoted name for table/field
	public static string ew_QuotedName(string Name)
	{
		return EW_DB_QUOTE_START + Name.Replace(EW_DB_QUOTE_END, EW_DB_QUOTE_END + EW_DB_QUOTE_END) + EW_DB_QUOTE_END;
	}

	// Quoted value for field type
	public static string ew_QuotedValue(object Value, int FldType)
	{
		switch (FldType) {
			case EW_DATATYPE_STRING:
			case EW_DATATYPE_MEMO:
				return "'" + ew_AdjustSql(Value) + "'";
			case EW_DATATYPE_GUID:
				if (EW_IS_MSACCESS) {
					if (Convert.ToString(Value).StartsWith("{")) {
						return Convert.ToString(Value);
					} else {
						return "{" + ew_AdjustSql(Value) + "}";
					}
				} else {
					return "'" + ew_AdjustSql(Value) + "'";
				}
				break;
			case EW_DATATYPE_DATE:
			case EW_DATATYPE_TIME:
				if (EW_IS_MSACCESS) {
					return "#" + ew_AdjustSql(Value) + "#";
				} else if (EW_IS_ORACLE) { 
					return "TO_DATE('" + ew_AdjustSql(Value) + "', 'YYYY/MM/DD HH24:MI:SS')"; 
				} else {
					return "'" + ew_AdjustSql(Value) + "'";
				}
				break;
			case EW_DATATYPE_BOOLEAN: //*** 
				if (EW_IS_MYSQL || EW_IS_ORACLE) { // ENUM('Y','N'), ENUM('y','n'), ENUM('1'/'0')
					return "'" + ew_AdjustSql(Value) + "'";
				} else { // Boolean
					return Convert.ToString(Value);
				}
			default:
				return Convert.ToString(Value);
		}
	}

	// Pad zeros before number
	public static string ew_ZeroPad(object m, int t)
	{
		return Convert.ToString(m).PadLeft(t, '0');
	}

	// Append like operator
	public static string ew_Like(string pat) {
		if (ew_NotEmpty(EW_LIKE_COLLATION_FOR_MSSQL)) {
			return  " COLLATE " + EW_LIKE_COLLATION_FOR_MSSQL + " LIKE " + pat;
		} else {
			return " LIKE " + pat;
		}
	}

	// Get script name
	public static string ew_ScriptName() {
		string sn = ew_ServerVar("SCRIPT_NAME");
		if (ew_Empty(sn)) sn = ew_ServerVar("PATH_INFO");
		if (ew_Empty(sn)) sn = ew_ServerVar("URL");
		if (ew_Empty(sn)) sn = "UNKNOWN";
		return sn;
	}

	// Get server variable by name
	public static string ew_ServerVar(string Name) {
		string str = "";
		if (ew_Request.ServerVariables[Name] != null)
			str = ew_Request.ServerVariables[Name];
		return str;
	}

	// Convert numeric value
	public static object ew_Conv(object v, int t)
	{
		if (Convert.IsDBNull(v)) return System.DBNull.Value; 
		switch (t) {
			case 20: // adBigInt
				return Convert.ToInt64(v);
			case 21: // adUnsignedBigInt
				return Convert.ToUInt64(v);
			case 2:
			case 16: // adSmallInt/adTinyInt
				return Convert.ToInt16(v);
			case 3: // adInteger
				return Convert.ToInt32(v);
			case 17:
			case 18: // adUnsignedTinyInt/adUnsignedSmallInt
				return Convert.ToUInt16(v);
			case 19: // adUnsignedInt
				return Convert.ToUInt32(v);
			case 4: // adSingle
				return Convert.ToSingle(v, System.Globalization.CultureInfo.InvariantCulture);
			case 5:
			case 6:
			case 131:
			case 139: // adDouble/adCurrency/adNumeric/adVarNumeric
				return Convert.ToDouble(v, System.Globalization.CultureInfo.InvariantCulture);
			default:
				return v;
		}
	}

	// Convert string to float format string
	public static string ew_StrToFloat(object value) {
		string val = Convert.ToString(value);
		val = val.Replace(" ", "");
		if (EW_THOUSANDS_SEP != "")
			val = val.Replace(EW_THOUSANDS_SEP, "");
		val = val.Replace(EW_DECIMAL_POINT, ".");
		return val;
	}

	// Trace (for debug only)
	public static void ew_Trace(object Msg)
	{
		try {
			string FileName = ew_MapPath("debug.txt");
			StreamWriter sw = File.AppendText(FileName);
			sw.WriteLine(Convert.ToString(Msg));
			sw.Close();
		} catch {
			if (EW_DEBUG_ENABLED) throw; 
		}
	}

	// Calculate elapsed time
	public static string ew_ElapsedTime(long tm)
	{
		double endTimer = Environment.TickCount;
		return "<div class=\"alert alert-info ewAlert\">page processing time: " + Convert.ToString((endTimer - tm) / 1000) + " seconds</div>";
	}

	// Compare values with special handling for null values
	public static bool ew_CompareValue(object v1, object v2)
	{
		if (Convert.IsDBNull(v1) && Convert.IsDBNull(v2)) {
			return true;
		} else if (Convert.IsDBNull(v1) || Convert.IsDBNull(v2)) {
			return false;
		} else {
			return ew_SameStr(v1, v2);
		}
	}

	// Adjust SQL for special characters
	public static string ew_AdjustSql(object value)
	{
		return Convert.ToString(value).Trim().Replace("'", "''"); // Adjust for single quote
	}

	// Build SELECT SQL based on different SQL part
	public static string ew_BuildSelectSql(string sSelect, string sWhere, string sGroupBy, string sHaving, string sOrderBy, string sFilter, string sSort)
	{
		string sDbWhere = sWhere;
		ew_AddFilter(ref sDbWhere, sFilter);
		string sDbOrderBy = sOrderBy;
		if (ew_NotEmpty(sSort))
			sDbOrderBy = sSort;
		string sSql = sSelect;
		if (ew_NotEmpty(sDbWhere))
			sSql += " WHERE " + sDbWhere;
		if (ew_NotEmpty(sGroupBy))
			sSql += " GROUP BY " + sGroupBy;
		if (ew_NotEmpty(sHaving))
			sSql += " HAVING " + sHaving;
		if (ew_NotEmpty(sDbOrderBy))
			sSql += " ORDER BY " + sDbOrderBy;
		return sSql;
	}

	// Load a text file
	public static string ew_LoadTxt(string fn)
	{
		string sTxt = "";
		if (ew_NotEmpty(fn)) {
			fn = ew_MapPath(fn); // Relative to script
			StreamReader sw = File.OpenText(fn); // Note: The file fn should be UTF-8 encoded text file.
			sTxt = sw.ReadToEnd();
			sw.Close();
		}
		return sTxt;
	}	

	// Write audit trail (insert/update/delete)
	public static void ew_WriteAuditTrail(string pfx, string dt, string scrpt, string user, string action, string table = "", string field = "", object keyvalue = null, object oldvalue = null, object newvalue = null)
	{
		try {
			string userwrk = user;
			if (ew_Empty(userwrk))
				userwrk = "-1"; // assume Administrator if no user
			if (!EW_AUDIT_TRAIL_TO_DATABASE) { // Write audit trail to log file
				string sHeader = "date/time" + "\t" + "script" + "\t" + "user" + "\t" + "action" + "\t" + "table" + "\t" + "field" + "\t" + "key value" + "\t" + "old value" + "\t" + "new value";
				string sMsg = dt + "\t" + scrpt + "\t" + userwrk + "\t" + action + "\t" + table + "\t" + field + "\t" + Convert.ToString(keyvalue) + "\t" + Convert.ToString(oldvalue) + "\t" + Convert.ToString(newvalue);
				string sFolder = EW_AUDIT_TRAIL_PATH;
				string sFn = pfx + "_" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
				bool bWriteHeader = !File.Exists(ew_UploadPathEx(true, sFolder) + sFn);
				StreamWriter sw = File.AppendText(ew_UploadPathEx(true, sFolder) + sFn);
				if (bWriteHeader) sw.WriteLine(sHeader); 
				sw.WriteLine(sMsg);
				sw.Close();
			} else if (ew_NotEmpty(EW_AUDIT_TRAIL_TABLE_NAME)) { // ASPX
				string sAuditSql = "INSERT INTO " + EW_AUDIT_TRAIL_TABLE_NAME +
					" (" + ew_QuotedName(EW_AUDIT_TRAIL_FIELD_NAME_DATETIME) + ", " +
					ew_QuotedName(EW_AUDIT_TRAIL_FIELD_NAME_SCRIPT) + ", " +
					ew_QuotedName(EW_AUDIT_TRAIL_FIELD_NAME_USER) + ", " +
					ew_QuotedName(EW_AUDIT_TRAIL_FIELD_NAME_ACTION) + ", " +
					ew_QuotedName(EW_AUDIT_TRAIL_FIELD_NAME_TABLE) + ", " +
					ew_QuotedName(EW_AUDIT_TRAIL_FIELD_NAME_FIELD) + ", " +
					ew_QuotedName(EW_AUDIT_TRAIL_FIELD_NAME_KEYVALUE) + ", " +
					ew_QuotedName(EW_AUDIT_TRAIL_FIELD_NAME_OLDVALUE) + ", " +
					ew_QuotedName(EW_AUDIT_TRAIL_FIELD_NAME_NEWVALUE) + ") " +
					" VALUES (" +
					ew_QuotedValue(dt, EW_DATATYPE_DATE) + ", " +
					ew_QuotedValue(scrpt, EW_DATATYPE_STRING) + ", " +
					ew_QuotedValue(userwrk, EW_DATATYPE_STRING) + ", " +
					ew_QuotedValue(action, EW_DATATYPE_STRING) + ", " +
					ew_QuotedValue(table, EW_DATATYPE_STRING) + ", " +
					ew_QuotedValue(field, EW_DATATYPE_STRING) + ", " +
					ew_QuotedValue(Convert.ToString(keyvalue), EW_DATATYPE_STRING) + ", " +
					ew_QuotedValue(Convert.ToString(oldvalue), EW_DATATYPE_STRING) + ", " +
					ew_QuotedValue(Convert.ToString(newvalue), EW_DATATYPE_STRING) + ")";
				Conn.ExecuteNonQuery(sAuditSql);
			}
		} catch {
			if (EW_DEBUG_ENABLED) throw; 
		}
	}

	// Functions for default date format
	// ANamedFormat = 0-8, where 0-4 same as VBScript
	// 5 = "yyyy/mm/dd"
	// 6 = "mm/dd/yyyy"
	// 7 = "dd/mm/yyyy"
	// 8 = Short Date + Short Time
	// 9 = "yyyy/mm/dd HH:MM:SS"
	// 10 = "mm/dd/yyyy HH:MM:SS"
	// 11 = "dd/mm/yyyy HH:MM:SS"
	// 12 - Short Date - 2 digit year (yy/mm/dd)
	// 13 - Short Date - 2 digit year (mm/dd/yy)
	// 14 - Short Date - 2 digit year (dd/mm/yy)
	// 15 - Short Date (yy/mm/dd) + Short Time (hh:mm:ss)
	// 16 - Short Date (mm/dd/yy) + Short Time (hh:mm:ss)
	// 17 - Short Date (dd/mm/yy) + Short Time (hh:mm:ss)
	// Format date time based on format type
	public static string ew_FormatDateTime(object ADate, int ANamedFormat)
	{
		string sDT;
		if (Information.IsDate(ADate)) {
			DateTime DT = Convert.ToDateTime(ADate);
			if (ANamedFormat >= 0 && ANamedFormat <= 4) {
				sDT = Strings.FormatDateTime(DT, (DateFormat)Enum.ToObject(typeof(DateFormat), ANamedFormat));
			} else if (ANamedFormat == 5 || ANamedFormat == 9) {
				sDT = DT.ToString("yyyy'" + EW_DATE_SEPARATOR + "'MM'" + EW_DATE_SEPARATOR + "'dd");
			} else if (ANamedFormat == 6 || ANamedFormat == 10) {
				sDT = DT.ToString("MM'" + EW_DATE_SEPARATOR + "'dd'" + EW_DATE_SEPARATOR + "'yyyy");
			} else if (ANamedFormat == 7 || ANamedFormat == 11) {
				sDT = DT.ToString("dd'" + EW_DATE_SEPARATOR + "'MM'" + EW_DATE_SEPARATOR + "'yyyy");
			} else if (ANamedFormat == 8) {
				sDT = Strings.FormatDateTime(DT, (DateFormat)Enum.ToObject(typeof(DateFormat), 2));
				if (DT.Hour != 0 || DT.Minute != 0 || DT.Second != 0)
					sDT += " " + DT.ToString("HH':'mm':'ss");
			} else if (ANamedFormat == 12 || ANamedFormat == 15) {
				sDT = DT.ToString("yy'" + EW_DATE_SEPARATOR + "'MM'" + EW_DATE_SEPARATOR + "'dd");
			} else if (ANamedFormat == 13 || ANamedFormat == 16) {
				sDT = DT.ToString("MM'" + EW_DATE_SEPARATOR + "'dd'" + EW_DATE_SEPARATOR + "'yy");
			} else if (ANamedFormat == 14 || ANamedFormat == 17) {
				sDT = DT.ToString("dd'" + EW_DATE_SEPARATOR + "'MM'" + EW_DATE_SEPARATOR + "'yy");	
			} else {
				return DT.ToString();
			}
			if ((ANamedFormat >= 9 && ANamedFormat <= 11) || (ANamedFormat >= 15 && ANamedFormat <= 17))
				sDT += " " + DT.ToString("HH':'mm':'ss");
			return sDT;
		} else {
			return Convert.ToString(ADate);
		}
	}

	// Unformat date time based on format type
	public static string ew_UnformatDateTime(object ADate, int ANamedFormat)
	{
		string[] arDateTime, arDatePt;
		DateTime d;
		string sDT;
		string sDate = Convert.ToString(ADate).Trim();
		if (ew_Empty(sDate)) // ASPX
            return "";
		if (sDate.StartsWith("#") && sDate.EndsWith("#") && sDate.Length > 2) // MS Access // ASPX 
			sDate = sDate.Substring(1, sDate.Length - 2);
		while (sDate.Contains("  "))
			sDate = sDate.Replace("  ", " ");
		if (Regex.IsMatch(sDate, @"^([0-9]{4})/([0][1-9]|[1][0-2])/([0][1-9]|[1|2][0-9]|[3][0|1])( (0[0-9]|1[0-9]|2[0-3]):([0-5][0-9])(:([0-5][0-9]))?)?$")) // ASPX
			return sDate;		
		arDateTime = sDate.Split(new char[] {' '});
		if (ANamedFormat == 0 && Information.IsDate(sDate)) {
			d = Convert.ToDateTime(arDateTime[0]);
			sDT = d.ToString("yyyy'/'MM'/'dd");
			if (arDateTime.Length > 0) {
				for (int i = 1; i < arDateTime.Length; i++)
					sDT = sDT + " " + arDateTime[i];
			}
			return sDT;
		} else {
			arDatePt = arDateTime[0].Split(new char[] { Convert.ToChar(EW_DATE_SEPARATOR) });
			if (arDatePt.Length == 3) {
				switch (ANamedFormat) {
					case 5:
					case 9: //yyyymmdd
						if (ew_CheckDate(arDateTime[0])) {
							sDT = arDatePt[0] + "/" + arDatePt[1].PadLeft(2, '0') + "/" + arDatePt[2].PadLeft(2, '0');							
							break;
						} else {
							return sDate;
						}
					case 6:
					case 10: //mmddyyyy
						if (ew_CheckUSDate(arDateTime[0])) {
							sDT = arDatePt[2].PadLeft(2, '0') + "/" + arDatePt[0].PadLeft(2, '0') + "/" + arDatePt[1];
							break;
						} else {
							return sDate;
						}
					case 7:
					case 11: //ddmmyyyy
						if (ew_CheckEuroDate(arDateTime[0])) {
							sDT = arDatePt[2].PadLeft(2, '0') + "/" + arDatePt[1].PadLeft(2, '0') + "/" + arDatePt[0];
							break;
						} else {
							return sDate;
						}
					case 12:
					case 15: //yymmdd
						if (ew_CheckShortDate(arDateTime[0])) {
							arDatePt[0] = ew_UnformatYear(arDatePt[0]);
							sDT = arDatePt[0] + "/" + arDatePt[1].PadLeft(2, '0') + "/" + arDatePt[2].PadLeft(2, '0');							
							break;
						} else {
							return sDate;
						}
					case 13:
					case 16: //mmddyy
						if (ew_CheckShortUSDate(arDateTime[0])) {
							arDatePt[2] = ew_UnformatYear(arDatePt[2]);
							sDT = arDatePt[2] + "/" + arDatePt[0].PadLeft(2, '0') + "/" + arDatePt[1].PadLeft(2, '0');
							break;
						} else {
							return sDate;
						}
					case 14:
					case 17: //ddmmyy
						if (ew_CheckShortEuroDate(arDateTime[0])) {
							arDatePt[2] = ew_UnformatYear(arDatePt[2]);
							sDT = arDatePt[2] + "/" + arDatePt[1].PadLeft(2, '0') + "/" + arDatePt[0].PadLeft(2, '0');
							break;
						} else {
							return sDate;
						}
					default:
						return sDate;
				}				
				if (arDateTime.Length > 1) {
					if (Information.IsDate(arDateTime[1])) // Is time
						sDT += " " + arDateTime[1];
				}
				return sDT;
			} else {
				return sDate;
			}
		}
	}

	// Format currency
	// -2 Retain all values after decimal place
	public static string ew_FormatCurrency(object Expression, int NumDigitsAfterDecimal = -1, int IncludeLeadingDigit = -2, int UseParensForNegativeNumbers = -2, int GroupDigits = -2)
	{
		if (!Information.IsNumeric(Expression)) return Convert.ToString(Expression);
		if (Convert.IsDBNull(Expression)) return String.Empty;

		// check NumDigitsAfterDecimal
		int FracDigits = -1;
		if (NumDigitsAfterDecimal == -2) { // Use all values after decimal point
			string stramt = Convert.ToString(Expression);
			string decimal_point = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
			FracDigits = (stramt.Contains(decimal_point)) ? (stramt.Length - stramt.LastIndexOf(decimal_point) - 1) : 0;
		} else if (NumDigitsAfterDecimal > -1) {
			FracDigits = NumDigitsAfterDecimal;
		}
		string res = Strings.FormatCurrency(Expression, FracDigits, (Microsoft.VisualBasic.TriState)IncludeLeadingDigit, (Microsoft.VisualBasic.TriState)UseParensForNegativeNumbers, (Microsoft.VisualBasic.TriState)GroupDigits); 
		if (EW_USE_SYSTEM_LOCALE) {
			return res; 
		} else {
			string DecimalSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.CurrencyDecimalSeparator;
			string GroupSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.CurrencyGroupSeparator;
			string Symbol = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.CurrencySymbol;
			if (Symbol != EW_CURRENCY_SYMBOL)
				res = res.Replace(Symbol, EW_CURRENCY_SYMBOL);
			string str = "";
			bool ReplaceDecimalSeparator = DecimalSeparator != EW_DECIMAL_POINT;
			bool ReplaceGroupSeparator = GroupSeparator != "" && GroupSeparator != EW_THOUSANDS_SEP; 
            foreach (char c in res) {
                if (ReplaceDecimalSeparator && ew_SameStr(c, DecimalSeparator)) {
                    str += EW_DECIMAL_POINT;
                } else if (ReplaceGroupSeparator && ew_SameStr(c, GroupSeparator)) {
                    str += EW_THOUSANDS_SEP;
                } else {
                    str += c;
                }
            }					
			return str;
		}
	}

	// Format number
	// -2 Retain all values after decimal place
	public static string ew_FormatNumber(object Expression, int NumDigitsAfterDecimal = -1, int IncludeLeadingDigit = -2, int UseParensForNegativeNumbers = -2, int GroupDigits = -2)
	{
		if (!Information.IsNumeric(Expression)) return Convert.ToString(Expression);
		if (Convert.IsDBNull(Expression)) return String.Empty;

		// check NumDigitsAfterDecimal
		int FracDigits = -1;
		if (NumDigitsAfterDecimal == -2) { // Use all values after decimal point
			string stramt = Convert.ToString(Expression);
			string decimal_point = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
			FracDigits = (stramt.Contains(decimal_point)) ? (stramt.Length - stramt.LastIndexOf(decimal_point) - 1) : 0;
		} else if (NumDigitsAfterDecimal > -1) {
			FracDigits = NumDigitsAfterDecimal;
		}
		string res = Strings.FormatNumber(Expression, FracDigits, (Microsoft.VisualBasic.TriState)IncludeLeadingDigit, (Microsoft.VisualBasic.TriState)UseParensForNegativeNumbers, (Microsoft.VisualBasic.TriState)GroupDigits);
		if (EW_USE_SYSTEM_LOCALE) {
			return res; 
		} else {
			string DecimalSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
			string GroupSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.NumberGroupSeparator;			
			bool ReplaceDecimalSeparator = DecimalSeparator != EW_DECIMAL_POINT;
			bool ReplaceGroupSeparator = GroupSeparator != "" && GroupSeparator != EW_THOUSANDS_SEP;
			string str = ""; 
            foreach (char c in res) {
                if (ReplaceDecimalSeparator && ew_SameStr(c, DecimalSeparator)) {
                    str += EW_DECIMAL_POINT;
                } else if (ReplaceGroupSeparator && ew_SameStr(c, GroupSeparator)) {
                    str += EW_THOUSANDS_SEP;
                } else {
                    str += c;
                }
            }					
			return str;
		}
	}

	// Format percent
	public static string ew_FormatPercent(object Expression,  int NumDigitsAfterDecimal = -1, int IncludeLeadingDigit = -2, int UseParensForNegativeNumbers = -2, int GroupDigits = -2)
	{
		if (!Information.IsNumeric(Expression)) return Convert.ToString(Expression);
		if (Convert.IsDBNull(Expression)) return String.Empty;
		string res = Strings.FormatPercent(Expression, NumDigitsAfterDecimal, (Microsoft.VisualBasic.TriState)IncludeLeadingDigit, (Microsoft.VisualBasic.TriState)UseParensForNegativeNumbers, (Microsoft.VisualBasic.TriState)GroupDigits);
		if (EW_USE_SYSTEM_LOCALE) {
			return res; 
		} else {
			string DecimalSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.PercentDecimalSeparator;
			string GroupSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.PercentGroupSeparator;			
			bool ReplaceDecimalSeparator = DecimalSeparator != EW_DECIMAL_POINT;
			bool ReplaceGroupSeparator = GroupSeparator != "" && GroupSeparator != EW_THOUSANDS_SEP;
			string str = ""; 
            foreach (char c in res) {
                if (ReplaceDecimalSeparator && ew_SameStr(c, DecimalSeparator)) {
                    str += EW_DECIMAL_POINT;
                } else if (ReplaceGroupSeparator && ew_SameStr(c, GroupSeparator)) {
                    str += EW_THOUSANDS_SEP;
                } else {
                    str += c;
                }
            }					
			return str;
		}
	}

	// Create a DIV as container of encrypted SQL for synchronous query
	public static void ew_CreateQuery(string id, string sql) {
		ew_Write(ew_HtmlElement("div", new Dictionary<string, string>() {{"id", id}, {"class", "ewDisplayNone"}}, ew_Encrypt(sql)));
	}

	// Output SCRIPT tag
	public static void ew_AddClientScript(string src, Dictionary<string, string> attrs = null) {
		var atts = new Dictionary<string, string>() {{"type", "text/javascript"}, {"src", src}};
		if (attrs != null) {
			foreach (KeyValuePair<string, string> kvp in attrs)
				atts.Add(kvp.Key, kvp.Value);
		}
		ew_Write(ew_HtmlElement("script", atts, "", true) + "\n");
	}

	// Output LINK tag
	public static void ew_AddStylesheet(string href, Dictionary<string, string> attrs = null) {
		var atts = new Dictionary<string, string>() {{"rel", "stylesheet"}, {"type", "text/css"}, {"href", href}};
		if (attrs != null) {
			foreach (KeyValuePair<string, string> kvp in attrs)
				atts.Add(kvp.Key, kvp.Value);
		}
		ew_Write(ew_HtmlElement("link", atts, "", false) + "\n");
	}	

	// Build HTML element
	public static string ew_HtmlElement(string tagname, Dictionary<string, string> attrs, string innerhtml = "", bool endtag = true) {
		string html = "<" + tagname;
		if (attrs != null) {
			foreach (KeyValuePair<string, string> kvp in attrs) {
				if (ew_NotEmpty(kvp.Value))
					html += " " + kvp.Key + "=\"" + ew_HtmlEncode(kvp.Value) + "\"";
			}
		}
		html += ">";
		if (ew_NotEmpty(innerhtml))
			html += innerhtml;
		if (endtag)
			html += "</" + tagname + ">";
		return html;
	}

	// XML tag name
	public static string ew_XmlTagName(string name) {
		name = name.Replace(" ", "_");
		Regex regEx = new Regex(@"^(?!XML)[a-z][\w-]*$", RegexOptions.IgnoreCase);
		if (!regEx.IsMatch(name))
			name = "_" + name;
		return name;
	}

	// Encode HTML
	public static string ew_HtmlEncode(object Expression)
	{
		return ew_Server.HtmlEncode(Convert.ToString(Expression));
	}

	// Decode HTML
	public static string ew_HtmlDecode(object Expression)
	{
		return ew_Server.HtmlDecode(Convert.ToString(Expression));
	}

	// Get title
	public static string ew_HtmlTitle(string name)
	{
		Match m = Regex.Match(name, @"\s+title\s*=\s*['""]([\s\S]*?)['""]", RegexOptions.IgnoreCase); // Match title='title'
		Match m1 = Regex.Match(name, @"\s+data-caption\s*=\s*['""]([\s\S]*?)['""]", RegexOptions.IgnoreCase); // Match data-caption='caption'
		return (m.Success) ? m.Groups[1].Value: ((m1.Success) ? m1.Groups[1].Value : name);
	}

	// Get title and image
	public static string ew_HtmlImageAndText(string name) {
		string title = "";
		if (Regex.IsMatch(name, @"<span([^>]*)>([\s\S]*?)<\/span\s*>", RegexOptions.IgnoreCase) || Regex.IsMatch(name, @"<img([^>]*)>", RegexOptions.IgnoreCase))
			title = ew_HtmlTitle(name);
		else
			title = name;
		return (title != name) ? name + "&nbsp;" + title : name;
	}

	// Encode URL
	public static string ew_UrlEncode(object Expression)
	{
		return ew_Server.UrlEncode(Convert.ToString(Expression));
	}

	// Decode URL
	public static string ew_UrlDecode(string Str)
	{
		return ew_Server.UrlDecode(Str);
	}

	// Format sequence number
	public static string ew_FormatSeqNo(object seq) {
		return Language.Phrase("SequenceNumber").Replace("%s", Convert.ToString(seq));
	}

	// Encode value for single-quoted JavaScript string
	public static string ew_JsEncode(object val)
	{
		string outstr = Convert.ToString(val).Replace("\\", "\\\\");
		outstr = outstr.Replace("'", "\\'");
		outstr = outstr.Replace("\r\n", "<br>");
		outstr = outstr.Replace("\r", "<br>");
		outstr = outstr.Replace("\n", "<br>");
		return outstr;		
	}

	// Encode value for double-quoted JavaScript string
	public static string ew_JsEncode2(object val)
	{
		string outstr = Convert.ToString(val).Replace("\\", "\\\\");
		outstr = outstr.Replace("\"", "\\\"");
		outstr = outstr.Replace("\t", "\\t");
		outstr = outstr.Replace("\r", "\\r");
		outstr = outstr.Replace("\n", "\\n");
		return outstr;
	}	

	// Encode value to single-quoted Javascript string for HTML attributes
	public static string ew_JsEncode3(object val)
	{
		string outstr = Convert.ToString(val).Replace("\\", "\\\\");
		outstr = outstr.Replace("'", "\\'");
		outstr = outstr.Replace("\"", "&quot;");
		return outstr;
	}

	// Convert a value to JSON value
	// type: string/boolean
	public static string ew_VarToJson(object val, string type = "") {
		if (Convert.IsDBNull(val) || val == null) {
			return "null";
		} else if (ew_SameText(type, "boolean") || val is bool) {
			return (ew_ConvertToBool(val)) ? "true" : "false";
		} else if (ew_SameText(type, "string") || val is string) {
			return "\"" + ew_JsEncode2(val) + "\"";
		}
		return Convert.ToString(val);
	}

	// Convert array to JSON for HTML attributes
	public static string ew_ArrayToJsonAttr(Dictionary<string, string> ar) {
		var Str = "{";
		foreach (var kvp in ar)
			Str += kvp.Key + ":'" + ew_JsEncode3(kvp.Value) + "',";
		if (Str.EndsWith(","))
			Str = Str.Substring(0, Str.Length - 1);
		Str += "}";
		return Str;
	}

	// Display field value separator
	// idx - display field index (1 or 2 or 3)
	// fld - field object
	public static string ew_ValueSeparator(int idx, cField fld)
	{
		object sep = (fld != null) ? fld.DisplayValueSeparator : ", ";
		return (ew_IsList(sep)) ? ((string[])sep)[idx - 1] : Convert.ToString(sep);
	}

	// Delimited values separator (for select-multiple or checkbox)
	// idx - zero based value index
	public static string ew_ViewOptionSeparator(int idx = -1)
	{
		return ", ";
	}

	//
	// HTML5 file upload related (start)
	//
	public static string ew_UploadTempPath(string fldvar = "") {
		if (ew_NotEmpty(fldvar))
			return ew_UploadPathEx(true, EW_UPLOAD_DEST_PATH) + EW_UPLOAD_TEMP_FOLDER_PREFIX + ew_Session.SessionID + EW_PATH_DELIMITER + fldvar;
		else
			return ew_UploadPathEx(true, EW_UPLOAD_DEST_PATH) + EW_UPLOAD_TEMP_FOLDER_PREFIX + ew_Session.SessionID;
	}

	// Render upload field to temp path
	public static void ew_RenderUploadField(cField fld, int idx = -1) {
		var fldvar = (idx < 0) ? fld.FldVar : fld.FldVar.Substring(0, 1) + idx + fld.FldVar.Substring(1);
		var folder = ew_UploadTempPath(fldvar);
		ew_CleanUploadTempPaths(); // Clean all old temp folders
		ew_CleanPath(folder); // Clean the upload folder
		if (!Directory.Exists(folder)) {
			if (!ew_CreateFolder(folder))
				ew_End("Cannot create folder: " + folder);
		}
		var thumbnailfolder = ew_PathCombine(folder, EW_UPLOAD_THUMBNAIL_FOLDER, true);
		if (!Directory.Exists(thumbnailfolder)) {
			if (!ew_CreateFolder(thumbnailfolder))
				ew_End("Cannot create folder: " + thumbnailfolder);
		}
		if (fld.FldDataType == EW_DATATYPE_BLOB) { // Blob field
			if (ew_NotEmpty(fld.Upload.DbValue)) {

				// Create upload file
				var filename = (ew_NotEmpty(fld.Upload.FileName)) ? fld.Upload.FileName : fld.FldVar.Substring(2);
				var f = ew_IncludeTrailingDelimiter(folder, true) + filename;
				ew_CreateUploadFile(ref f, (byte[])fld.Upload.DbValue);

				// Create thumbnail file
				f = ew_IncludeTrailingDelimiter(thumbnailfolder, true) + filename;
				byte[] data = (byte[])fld.Upload.DbValue;
				var width = EW_UPLOAD_THUMBNAIL_WIDTH;
				var height = EW_UPLOAD_THUMBNAIL_HEIGHT;
				ew_ResizeBinary(ref data, ref width, ref height, EW_THUMBNAIL_DEFAULT_QUALITY);
				ew_CreateUploadFile(ref f, data);
				fld.Upload.FileName = Path.GetFileName(f); // Update file name
			}
		} else { // Upload to folder
			fld.Upload.FileName = Convert.ToString(fld.Upload.DbValue); // Update file name
			if (ew_NotEmpty(fld.Upload.FileName)) {

				// Create upload file
				var filename = fld.Upload.FileName;
				string[] files;
				if (fld.UploadMultiple)
					files = filename.Split(new char[] {Convert.ToChar(EW_MULTIPLE_UPLOAD_SEPARATOR)});
				else
					files = new string[] {filename};
				for (var i = 0; i < files.Length; i++) {
					filename = files[i];
					if (ew_NotEmpty(filename)) {
						var srcfile = ew_UploadPathEx(true, fld.UploadPath) + filename;
						var f = ew_IncludeTrailingDelimiter(folder, true) + filename;
						byte[] data;
						if (!Directory.Exists(srcfile) && File.Exists(srcfile)) {
							data = File.ReadAllBytes(srcfile);
							ew_CreateUploadFile(ref f, data);
						} else {
							ew_CreateImageFromText(Language.Phrase("FileNotFound"), f);
							data = File.ReadAllBytes(f);
						}

						// Create thumbnail file
						f = ew_IncludeTrailingDelimiter(thumbnailfolder, true) + filename;
						var width = EW_UPLOAD_THUMBNAIL_WIDTH;
						var height = EW_UPLOAD_THUMBNAIL_HEIGHT;
						ew_ResizeBinary(ref data, ref width, ref height, EW_THUMBNAIL_DEFAULT_QUALITY);
						ew_CreateUploadFile(ref f, data);
					}
				}
			}
		}
	}

	// Create upload file
	public static void ew_CreateUploadFile(ref string f, byte[] data) {
		File.WriteAllBytes(f, data);
		var ext = Path.GetExtension(f);
		if (ew_Empty(ext)) {
			var ct = ew_ContentType(data.Take(11));
			switch (ct) {
				case "image/gif":
					ew_RenameFile(f, f += ".gif"); break;
				case "image/jpeg":
					ew_RenameFile(f, f += ".jpg"); break;
				case "image/png":
					ew_RenameFile(f, f += ".png"); break;
			}
		}
	}

	// Create image from text
	public static void ew_CreateImageFromText(string txt, string file, int width = EW_UPLOAD_THUMBNAIL_WIDTH, int height = 0, string font = EW_TMP_IMAGE_FONT) {
		int pt = (int)Math.Round(EW_FONT_SIZE/1.33); // 1pt = 1.33px
		double fs = Convert.ToDouble(EW_FONT_SIZE);
		int h = (height > 0) ? height : (int)Math.Round(fs / 14 * 20);
		System.Drawing.Image bitmap = new Bitmap(width, h);
		var g = Graphics.FromImage(bitmap);
		g.Clear(Color.White);
		Brush b = new SolidBrush(Color.Red);
		g.DrawString(txt, new System.Drawing.Font(font, pt), b, 0, (int)Math.Round(Convert.ToDouble((h - fs)/2)));		
		bitmap.Save(file);
		b.Dispose();
		g.Dispose();
	}

	// Clean temp upload folders
	public static void ew_CleanUploadTempPaths(string sessionid = "") {
		var folder = ew_UploadPathEx(true, EW_UPLOAD_DEST_PATH);
		if (!Directory.Exists(folder))
			return;		
		var dir = new DirectoryInfo(folder);			
		var subDirs = dir.GetDirectories();
		foreach (var dirInfo in subDirs) {
			var subfolder = dirInfo.Name;
			var tempfolder = dirInfo.FullName;		
			if (!subfolder.StartsWith(EW_UPLOAD_TEMP_FOLDER_PREFIX))
				continue;
			if (EW_UPLOAD_TEMP_FOLDER_PREFIX + sessionid == subfolder) { // Clean session folder
				ew_CleanPath(tempfolder, true);
			} else {
				if (EW_UPLOAD_TEMP_FOLDER_PREFIX + ew_Session.SessionID != subfolder) {
					if (ew_IsEmptyPath(tempfolder)) { // Empty folder
						ew_CleanPath(tempfolder, true);
					} else { // Old folder
						var lastmdtime = dirInfo.CreationTime;
						var files = dirInfo.GetFiles("*.*");
						if (((TimeSpan)(DateTime.Now - lastmdtime)).Minutes / 60 > EW_UPLOAD_TEMP_FOLDER_TIME_LIMIT || files != null && files.Length == 0)
							ew_CleanPath(tempfolder, true);
					}
				}
			}
		}
	}

	// Clean temp upload folder for a field
	public static void ew_CleanUploadTempPath(cField fld, int idx = -1) {
		var fldvar = (idx < 0) ? fld.FldVar : fld.FldVar.Substring(0, 1) + idx + fld.FldVar.Substring(1);
		var folder = ew_UploadTempPath(fldvar);
		ew_CleanPath(folder, true); // Clean the upload folder

		// Remove complete temp folder if empty
		folder = ew_UploadTempPath();
		if (Directory.Exists(folder)) {
			var files = Directory.GetFiles(folder, "*.*", System.IO.SearchOption.AllDirectories);			
			if (files != null && files.Length == 0)
				ew_CleanPath(folder, true);
		}
	}

	// Clean folder
	public static void ew_CleanPath(string folder, bool delete = false) {		
		folder = ew_IncludeTrailingDelimiter(folder, true);
		try {
			if (Directory.Exists(folder)) {
				ew_GCollect(); // ASPX

				// Delete files in the folder
				var files = Directory.GetFiles(folder);
				foreach (string f in files)
					File.Delete(f);

				// Clear sub folders
				var dirs = Directory.GetDirectories(folder);
				foreach (var tempfolder in dirs)
					ew_CleanPath(tempfolder, delete);
				if (delete)
					Directory.Delete(folder);
			}
		} catch (Exception e) {

			// Ignore
		} finally {
			ew_GCollect(); // ASPX
		}
	}

	// Check empty folder
	public static bool ew_IsEmptyPath(string folder) {
		var IsEmptyPath = true;

		// Check folder
		folder = ew_IncludeTrailingDelimiter(folder, true);
		if (Directory.Exists(folder)) {
			var files = Directory.GetFiles(folder);
			if (files != null && files.Length > 0)
				return false;
			var dirs = Directory.GetDirectories(folder);
			foreach (var tempfolder in dirs) {
				IsEmptyPath = ew_IsEmptyPath(tempfolder);
				if (!IsEmptyPath)
					return false; // No need to check further
			}
		} else {
			IsEmptyPath = false;
		}
		return IsEmptyPath;
	}

	// Get file count in folder
	public static int ew_FolderFileCount(string folder) {
		folder = ew_IncludeTrailingDelimiter(folder, true);
		if (Directory.Exists(folder)) {
			var files = Directory.GetFiles(folder);
			if (files != null)
				return files.Length;
		}
		return 0;
	}

	// HTML5 file upload (end)
	// Render repeat column table
	// rowcnt - zero based row count
	public static string ew_RepeatColumnTable(int totcnt, int rowcnt, int repeatcnt, int rendertype)
	{
		string sWrk = "";
		if (rendertype == 1) { // Render control start
			if (rowcnt == 0)
				sWrk += "<table class=\"" + EW_ITEM_TABLE_CLASSNAME + "\">"; 
			if (rowcnt % repeatcnt == 0)
				sWrk += "<tr>"; 
			sWrk += "<td>";
		} else if (rendertype == 2) {	// Render control end
			sWrk += "</td>";
			if (rowcnt % repeatcnt == repeatcnt - 1) {
				sWrk += "</tr>";
			} else if (rowcnt == totcnt) {
				for (int i = rowcnt % repeatcnt + 1; i <= repeatcnt - 1; i++)
					sWrk += "<td>&nbsp;</td>";
				sWrk += "</tr>";
			}
			if (rowcnt == totcnt)
				sWrk += "</table>"; 
		}
		return sWrk;
	}

	// Truncate memo field based on specified length, string truncated to nearest space or CrLf
	public static string ew_TruncateMemo(string memostr, int ln, bool removehtml)
	{
		string str = (removehtml) ? ew_RemoveHtml(memostr) : memostr;
		if (str.Length > 0 && str.Length > ln) {
			int k = 0;
			while (k >= 0 && k < str.Length) {
				int i = str.IndexOf(" ", k);
				int j = str.IndexOf("\r\n", k);
				if (i < 0 && j < 0) {	// Unable to truncate
					return str;
				} else {	// Get nearest space or CrLf
					if (i > 0 && j > 0) {
						k = (i < j) ? i : j; 
					} else if (i > 0) {
						k = i;
					} else if (j > 0) {
						k = j;
					}

					// Get truncated text
					if (k >= ln) {
						return str.Substring(0, k) + "...";
					} else {
						k = k + 1;
					}
				}
			}
		}
		return str;
	}	

	// Remove HTML tags from text
	public static string ew_RemoveHtml(string str)
	{
		return Regex.Replace(str, "<[^>]*>", string.Empty);
	}

	// Extract JavaScript from HTML and return converted script
	public static string ew_ExtractScript(ref string html, string classname = "") {
		MatchCollection matches = Regex.Matches(html, @"<script([^>]*)>([\s\S]*?)<\/script\s*>", RegexOptions.IgnoreCase);
		if (matches.Count == 0)
			return "";
		string scripts = "";
		foreach (Match match in matches) {
			if (Regex.IsMatch(match.Groups[1].Value, @"(\s+type\s*=\s*['""]*(text|application)\/(java|ecma)script['""]*)|^((?!\s+type\s*=).)*$", RegexOptions.IgnoreCase)) { // JavaScript
				html = html.Replace(match.Value, ""); // Remove the script from HTML
				scripts += ew_HtmlElement("script", new Dictionary<string, string>() {{"type", "text/html"}, {"class", classname}}, match.Groups[2].Value); // Convert script type and add CSS class, if specified
			}
		}
		return scripts; // Return converted scripts
	}

	// Clean email content
	public static string ew_CleanEmailContent(string content) {
		content = content.Replace("class=\"ewGrid\"", "");
		content = content.Replace("class=\"table-responsive ewGridMiddlePanel\"", "");
		content = content.Replace("table ewTable", "ewExportTable");
		return content;
	}

	// Send email
	public static bool ew_SendEmail(string sFrEmail, string sToEmail, string sCcEmail, string sBccEmail, string sSubject, string sMail, string sFormat, string sCharset, bool bSsl = false, List<string> arAttachments = null, List<string> arImages = null, System.Net.Mail.SmtpClient smtp = null)
	{
		var mail = new System.Net.Mail.MailMessage();
		if (ew_NotEmpty(sFrEmail)) {
			var m = Regex.Match(sFrEmail.Trim(), @"^(.+)<([\w.%+-]+@[\w.-]+\.[A-Z]{2,6})>$", RegexOptions.IgnoreCase);
			if (m.Success) {
				mail.From = new System.Net.Mail.MailAddress(m.Groups[2].Value, m.Groups[1].Value);
			} else {
				mail.From = new System.Net.Mail.MailAddress(sFrEmail);
			}			
		}
		if (ew_NotEmpty(sToEmail)) {
			sToEmail = sToEmail.Replace(',', ';');
			string[] arTo = sToEmail.Split(new char[] {';'});
			foreach (string strTo in arTo)
				mail.To.Add(strTo);
		}
		if (ew_NotEmpty(sCcEmail)) {
			sCcEmail = sCcEmail.Replace(',', ';');
			string[] arCC = sCcEmail.Split(new char[] {';'});
			foreach (string strCC in arCC)
				mail.CC.Add(strCC);
		}
		if (ew_NotEmpty(sBccEmail)) {
			sBccEmail = sBccEmail.Replace(',', ';');
			string[] arBcc = sBccEmail.Split(new char[] {';'});
			foreach (string strBcc in arBcc)
				mail.Bcc.Add(strBcc);
		}
		mail.Subject = sSubject;
		mail.Body = sMail;
		mail.IsBodyHtml = ew_SameText(sFormat, "html");
		if (ew_NotEmpty(sCharset) && !ew_SameText(sCharset, "iso-8859-1"))
			mail.BodyEncoding = Encoding.GetEncoding(sCharset);
		if (smtp == null) {
			smtp = new System.Net.Mail.SmtpClient();
			if (ew_NotEmpty(EW_SMTP_SERVER)) {
				smtp.Host = EW_SMTP_SERVER;
			} else {
				smtp.Host = "localhost";
			}
			if (EW_SMTP_SERVER_PORT > 0)
				smtp.Port = EW_SMTP_SERVER_PORT;
		}	
		smtp.EnableSsl = bSsl;	
		if (ew_NotEmpty(EW_SMTP_SERVER_USERNAME) && ew_NotEmpty(EW_SMTP_SERVER_PASSWORD)) {
			var smtpuser = new System.Net.NetworkCredential();
			smtpuser.UserName = EW_SMTP_SERVER_USERNAME;
			smtpuser.Password = EW_SMTP_SERVER_PASSWORD;
			smtp.UseDefaultCredentials = false;
			smtp.Credentials = smtpuser;
		}

//		if (ew_NotEmpty(sAttachmentFileName) && ew_NotEmpty(sAttachmentContent)) { // HTML
//			byte[] arByte = mail.BodyEncoding.GetBytes(sAttachmentContent);
//			var stream = new MemoryStream(arByte);
//			var data = new Attachment(stream, new ContentType(MediaTypeNames.Text.Html));
//			ContentDisposition disposition = data.ContentDisposition;
//			disposition.FileName = sAttachmentFileName;
//			mail.Attachments.Add(data);
//		} else if (ew_NotEmpty(sAttachmentFileName)) { // URL
//			var data = new Attachment(sAttachmentFileName, new ContentType(MediaTypeNames.Text.Html));
//			mail.Attachments.Add(data);
//		}

		if (arAttachments != null && arAttachments.Count > 0) {
			foreach (string fn in arAttachments)
				mail.Attachments.Add(new Attachment(fn));
		}
		if (mail.IsBodyHtml && arImages != null && arImages.Count > 0) {
			string html = mail.Body;
			foreach (string tmpimage in arImages) {
				string file = ew_UploadPathEx(true, EW_UPLOAD_DEST_PATH) + tmpimage;				
				string cid = ew_TmpImageLnk(tmpimage, "email");
				html = html.Replace(file, cid);
			}
			AlternateView htmlview = AlternateView.CreateAlternateViewFromString(html, null, "text/html");			
			foreach (string tmpimage in arImages) {
				string file = ew_UploadPathEx(true, EW_UPLOAD_DEST_PATH) + tmpimage;
				if (File.Exists(file)) {
					LinkedResource res = new LinkedResource(file);
					res.ContentId = ew_TmpImageLnk(tmpimage, "cid");				
					htmlview.LinkedResources.Add(res);
				}
			}
			mail.AlternateViews.Add(htmlview);
		}
		try {
			smtp.Send(mail);
			return true;
		} catch (Exception e) {
			gsEmailErrDesc = e.ToString();
			if (EW_DEBUG_ENABLED) throw; 
			return false;
		}
	}

	// Return path of the uploaded file relative to app root // ASPX
	public static string ew_UploadPathEx(bool PhyPath, string DestPath)
	{
        if (PhyPath) {
			if (!Regex.IsMatch(DestPath, @"^(\.|\.\.|~)[/\\]")) // Not starts with "./" or "../" or "~/"
				DestPath = "~/" + DestPath; // Prepend "~/"			
			return ew_Server.MapPath(DestPath); // In case virtual directory
		} else {
			return ew_MapPath(DestPath, false, true);
		}
	}

	// Change the file name of the uploaded file
	public static string ew_UploadFileNameEx(string Folder, string FileName)
	{
		string OutFileName;

		// By default, ewUniqueFileName() is used to get an unique file name.
		// Amend your logic here

		OutFileName = ew_UniqueFileName(Folder, FileName);

		// Return computed output file name
		return OutFileName;
	}

	// Return path of the uploaded file
	// returns global upload folder, for backward compatibility only
	public static string ew_UploadPath(bool PhyPath)
	{
		return ew_UploadPathEx(PhyPath, EW_UPLOAD_DEST_PATH);
	}

	// Change the file name of the uploaded file
	// use global upload folder, for backward compatibility only
	public static string ew_UploadFileName(string FileName)
	{
		return ew_UploadFileNameEx(ew_UploadPath(true), FileName);
	}

	// Generate an unique file name (filename(n).ext)
	public static string ew_UniqueFileName(string folder, string orifn, bool indexed = false)
	{
		if (ew_Empty(orifn))
			orifn = DateTime.Now.ToString("yyyyMMddHHmmss") + ".bin"; 
		if (orifn == ".")
			throw new Exception("Invalid file name: " + orifn); 
		if (ew_Empty(folder))
			throw new Exception("Unspecified folder"); 
		string ext = Path.GetExtension(orifn);
		string oldfn = Path.GetFileNameWithoutExtension(orifn);
		folder = ew_IncludeTrailingDelimiter(folder, true);
		if (!Directory.Exists(folder) && !ew_CreateFolder(folder))
			throw new Exception("Folder does not exist: " + folder);
		int i = 0;
		string suffix = "";
	    if (indexed) {
	        Match m = Regex.Match(@"\(\d+\)$", oldfn);
			if (m.Success) {
	            i = ew_ConvertToInt(m.Groups[1].Value);
	            i++;
	        } else {
	            i = 1;
	        }
	        suffix = "(" + Convert.ToString(i) + ")";
	    }

		// Check to see if filename exists
		string name = Regex.Replace(oldfn, @"\(\d+\)$", ""); // Remove "(n)" at the end of the file name
		while (File.Exists(folder + name + suffix + ext)) {
			i++;
			suffix = "(" + Convert.ToString(i) + ")";
		}
		return name + suffix + ext;
	}

	// Field data type
	public static int ew_FieldDataType(int fldtype) {
		switch (fldtype) {
			case 20:
			case 3:
			case 2:
			case 16:
			case 4:
			case 5:
			case 131:
			case 139:
			case 6:
			case 17:
			case 18:
			case 19:
			case 21: // Numeric
				return EW_DATATYPE_NUMBER;
			case 7:
			case 133:
			case 135: // Date
			case 146: // DateTiemOffset
				return EW_DATATYPE_DATE;
			case 134: // Time
			case 145: // Time
				return EW_DATATYPE_TIME;
			case 201:
			case 203: // Memo
				return EW_DATATYPE_MEMO;
			case 129:
			case 130:
			case 200:
			case 202: // String
				return EW_DATATYPE_STRING;
			case 11: // Boolean
				return EW_DATATYPE_BOOLEAN;
			case 72: // GUID
				return EW_DATATYPE_GUID;
			case 128:
			case 204:
			case 205: // Binary
				return EW_DATATYPE_BLOB;
			case 141: // XML
				return EW_DATATYPE_XML;
			default:
				return EW_DATATYPE_OTHER;
		}
	}

	// Current path  // ASPX
	public static string ew_CurrentPath(bool PhyPath = true) {
		string p = "";
		string ext = ".cshtml";
		string[] ar = ew_Server.MapPath(ew_ServerVar("SCRIPT_NAME")).Split(new char[] { Path.DirectorySeparatorChar }); // Split current path
		if (PhyPath) { // Physical path 

			// Check if folder
			if (Directory.Exists(ew_Server.MapPath(ew_ServerVar("SCRIPT_NAME")))) {
				p = ew_Server.MapPath(ew_ServerVar("SCRIPT_NAME"));
			} else {
				p = ew_Server.MapPath(".");		

				// Check URL routing // ASPX
				for (int i = 0; i < ar.Length; i++) {
					string tmp = String.Join(EW_PATH_DELIMITER, ar.Take(ar.Length - i));
					if (!Path.HasExtension(tmp))
						tmp = Path.ChangeExtension(tmp, ext);
					if (File.Exists(tmp)) {
						p = Path.GetDirectoryName(tmp);
						break;
					}
				}
			}
		} else { // Path relative to host		
			p = ew_ServerVar("SCRIPT_NAME");		
			string[] ar2 = ew_ServerVar("SCRIPT_NAME").Split(new char[] {'/'});

			// Check URL routing // ASPX
			for (int i = 0; i < ar.Length; i++) {
				string tmp = String.Join(EW_PATH_DELIMITER, ar.Take(ar.Length - i));
				if (!Path.HasExtension(tmp))					
					tmp = Path.ChangeExtension(tmp, ext);
				if (File.Exists(tmp)) {
					p = String.Join("/", ar2.Take(ar2.Length - i - 1));
					break;
				}			
			}
		}
		return ew_IncludeTrailingDelimiter(p, PhyPath);
	}

	// Application root // ASPX
	public static string ew_AppRoot(bool PhyPath = true) {
		string p = "";
		if (PhyPath) {
			p = ew_CurrentPath(true);

			// Use Server.MapPath
			if (!Directory.Exists(p))
				p = ew_Server.MapPath(".");		

			// Use custom path, uncomment the following line and enter your path, e.g. @"C:\Inetpub\wwwroot\MyWebRoot"
			//return @"enter your path here";

			if (!Directory.Exists(p))
				ew_End("Path of website root unknown.");
		} else {		
			p = ew_CurrentPath(false);
		}
		return ew_PathCombine(p, EW_ROOT_RELATIVE_PATH, PhyPath);
	}

	// Get path relative to app root // ASPX
	public static string ew_MapPath(string p, bool PhyPath = true, bool FromRoot = false)
	{
		if (Path.IsPathRooted(p) || p.ToLower().StartsWith("http:") || p.ToLower().StartsWith("https:"))
			return p; 
		p = p.Trim().Replace("\\", "/");
		if (p.StartsWith("~/"))
			p = p.Substring(2);
		if (FromRoot) { // relative to app root
			return ew_PathCombine(ew_AppRoot(PhyPath), p, PhyPath);
		} else { // relative to script
			return ew_PathCombine(ew_CurrentPath(PhyPath), p, PhyPath);
		}
	}

	// Get physical path relative to app root (for backward compatibility) // ASPX
	public static string ew_ServerMapPath(string p) {
		return ew_MapPath(p, true, true);
	}

	// Get path relative to a base path
	public static string ew_PathCombine(string BasePath, string RelPath, bool PhyPath)
	{
		string Delimiter = (PhyPath) ? EW_PATH_DELIMITER : "/";
		if (BasePath != Delimiter) // If BasePath = root, do not remove delimiter
			BasePath = ew_RemoveTrailingDelimiter(BasePath, PhyPath);		
		RelPath = (PhyPath) ? RelPath.Replace("/", EW_PATH_DELIMITER) : RelPath.Replace("\\", "/");
		if (RelPath.EndsWith(".")) // ASPX
			RelPath = ew_IncludeTrailingDelimiter(RelPath, PhyPath);
		int p1 = RelPath.IndexOf(Delimiter);
		string Path2 = "";
		while (p1 > -1) {
			string Path = RelPath.Substring(0, p1 + 1);
			if (Path == Delimiter || Path == "." + Delimiter) { // Skip
			} else if (Path == ".." + Delimiter) {
				int p2 = BasePath.LastIndexOf(Delimiter);
				if (p2 == 0) // BasePath = "/xxx", cannot move up
					BasePath = Delimiter;				  
				else if (p2 > -1 && !BasePath.EndsWith(".."))
					BasePath = BasePath.Substring(0, p2);
				else if (ew_NotEmpty(BasePath) && BasePath != "..")
					BasePath = "";
				else
					Path2 += ".." + Delimiter; 
			} else {
				Path2 += Path;
			}
			try {
				RelPath = RelPath.Substring(p1 + 1);
			} catch {
				RelPath = "";
			}
			p1 = RelPath.IndexOf(Delimiter);
		}
		return ((ew_NotEmpty(BasePath) && BasePath != ".") ? ew_IncludeTrailingDelimiter(BasePath, PhyPath) : "") + Path2 + RelPath; 
	}

	// Remove the last delimiter for a path
	public static string ew_RemoveTrailingDelimiter(string Path, bool PhyPath)
	{
		string Delimiter = (PhyPath) ? EW_PATH_DELIMITER : "/"; 
		while (Path.EndsWith(Delimiter))
			Path = Path.Substring(0, Path.Length - 1);
		return Path;
	}

	// Include the last delimiter for a path
	public static string ew_IncludeTrailingDelimiter(string Path, bool PhyPath)
	{
		string Delimiter = (PhyPath) ? EW_PATH_DELIMITER : "/";
		Path = ew_RemoveTrailingDelimiter(Path, PhyPath);
		return Path + Delimiter;
	}

	// Write the paths for config/debug only
	public static void ew_WriteUploadPaths()
	{
		ew_Write("EW_ROOT_RELATIVE_PATH = " + EW_ROOT_RELATIVE_PATH + "<br>");
		ew_Write("ew_AppRoot() = " + ew_AppRoot() + "<br>");
		ew_Write("APPL_PHYSICAL_PATH = " + ew_ServerVar("APPL_PHYSICAL_PATH") + "<br>");
		ew_Write("APPL_MD_PATH = " + ew_ServerVar("APPL_MD_PATH") + "<br>");
	}

	// Get current page name
	public static string ew_CurrentPage()
	{
		return ew_GetPageName(ew_ServerVar("SCRIPT_NAME"));
	}

	// Get refer page name
	public static string ew_ReferPage()
	{
		return ew_GetPageName(ew_ServerVar("HTTP_REFERER"));
	}

	// Get page name // ASPX
	public static string ew_GetPageName(string url)
	{
		if (ew_NotEmpty(url)) {
			if (url.Contains("?"))
				url = url.Substring(0, url.LastIndexOf("?")); // Remove querystring first
			string p = ew_CurrentPath(false); // Current relative path
			if (url.LastIndexOf(p) > -1)	
				url = url.Substring(url.LastIndexOf(p) + p.Length); // Remove path
			if (url.Contains("/"))
				url = url.Substring(0, url.IndexOf("/")); // Remove UrlData, if any
			return url;			
		}
		return "";
	}

	// Get full URL
	public static string ew_FullUrl()
	{
		return ew_DomainUrl() + ew_ServerVar("SCRIPT_NAME");
	}	

	// jQuery files host
	public static string ew_jQueryHost() {
		return "jquery/"; // Use local files
	}

	// jQuery version
	public static string ew_jQueryFile(string f) {
		var v = "1.11.3"; // jQuery version
		return (ew_jQueryHost() + f).Replace("%v", v);
	}

	// Get css file
	public static string ew_CssFile(string f) {
		if (EW_CSS_FLIP)
			return Regex.Replace(f, @"(.css)$", "-rtl.css", RegexOptions.IgnoreCase);
		else
			return f;
	}

	// Check if HTTPS
	public static bool ew_IsHttps() {
		return !ew_SameText(ew_ServerVar("HTTPS"), "off") & ew_NotEmpty(ew_ServerVar("HTTPS"));
	}

	// Get domain URL
	public static string ew_DomainUrl()
	{
		bool bSSL = ew_IsHttps();
		string sUrl = (bSSL) ? "https": "http";
		string sPort = ew_ServerVar("SERVER_PORT");
		string defPort = (bSSL) ? "443" : "80";
		sPort = (sPort == defPort) ? "" : ":" + sPort; 
		return sUrl + "://" + ew_ServerVar("SERVER_NAME") + sPort;
	}

	// Get current URL
	public static string ew_CurrentUrl()
	{
		string s = ew_ServerVar("SCRIPT_NAME");
		string q = ew_ServerVar("QUERY_STRING");
		if (ew_NotEmpty(q))
			s += "?" + q;
		return s;
	}

	// Get application root path (relative to domain)
	public static string ew_AppPath()
	{
		string Path = ew_ServerVar("APPL_MD_PATH");
		int pos = Path.IndexOf("Root", StringComparison.InvariantCultureIgnoreCase); // Note: IgnoreCase
		if (pos > 0)
			Path = Path.Substring(pos + 4); 
		return Path;
	}

	// Convert to full URL
	public static string ew_ConvertFullUrl(string url)
	{
		if (ew_Empty(url)) {
			return "";
		} else if (url.Contains("://")) {
			return url;
		} else {
			string sUrl = ew_FullUrl();
			return sUrl.Substring(0, sUrl.LastIndexOf("/") + 1) + url;
		}
	}

	// Get relative URL
	public static string ew_GetUrl(string url)
	{
		if (ew_NotEmpty(url) && !url.Contains("://") && !url.Contains("\\") && !url.Contains("javascript:")) {
			var path = "";
			var idx = url.LastIndexOf("/");
			if (idx > -1) {				
				path = url.Substring(0, idx);
				url = url.Substring(idx + 1); 
			}
			path = ew_PathCombine(EW_RELATIVE_PATH, path, false);
			if (ew_NotEmpty(path))
				path = ew_IncludeTrailingDelimiter(path, false);
			return path + url;
		} else {
			return url;
		}
	}

	// Check if responsive layout
	public bool ew_IsResponsiveLayout() {
		return EW_USE_RESPONSIVE_LAYOUT;
	}

	// Check if folder exists
	public static bool ew_FolderExists(string folder)
	{
		return Directory.Exists(folder);
	}

	// Check if file exists
	public static bool ew_FileExists(string file, string folder = "")
	{
		if (folder == "") { // "file" is full path
			return File.Exists(file);
		} else { // "file" is under "folder"
			return File.Exists(ew_IncludeTrailingDelimiter(folder, true) + file);
		}
	}

	// Delete file
	public static void ew_DeleteFile(string FilePath)
	{
		try {
			if (File.Exists(FilePath))
				File.Delete(FilePath);
		} finally {
			ew_GCollect(); // ASPX
		}
	}

	// Rename file
	public static void ew_RenameFile(string OldFile, string NewFile)
	{
		ew_GCollect(); // ASPX
		File.Move(OldFile, NewFile);
	}

	// Copy file // ASPX
	public static void ew_CopyFile(string SrcFile, string DestFile)
	{
		ew_GCollect(); // ASPX
		File.Copy(SrcFile, DestFile);
	}

	// Copy file // ASPX
	public static bool ew_CopyFile(string folder, string fn, string file, bool overwrite) {		
		if (File.Exists(file)) {
			var newfile = ew_UploadPathEx(true, folder) + fn;
			if (ew_CreateFolder(Path.GetDirectoryName(newfile))) {	
				ew_GCollect(); // ASPX			
				File.Copy(file, newfile, overwrite);
				return true;
			}
		}
		return false;
	}

	// Create folder
	public static bool ew_CreateFolder(string folder)
	{
		try {
			DirectoryInfo di = Directory.CreateDirectory(folder);
			return (di != null);
		} catch {
			return false;
		}
	}

	// Check if field exists in a data reader
	public static bool ew_InDataReader(ref ewDataReader dr, string FldName)
	{
		try {
			return (dr.GetOrdinal(FldName) >= 0);
		} catch {
			return false;
		}
	}

	// Calculate Hash for recordset // ASP.NET
	public static string ew_GetFldHash(object Value, int FldType) 
	{
		return MD5(ew_GetFldValueAsString(Value, FldType));
	}

	// Get field value as string
	public static string ew_GetFldValueAsString(object Value, int FldType)
	{
		if (Convert.IsDBNull(Value)) {
			return "";
		} else if (FldType == EW_DATATYPE_BLOB) {
			return ew_ByteToString((byte[])Value, EW_BLOB_FIELD_BYTE_COUNT);
		} else {
			return Convert.ToString(Value);
		}
	}

	// Convert byte to string
	public static string ew_ByteToString(object b, int l)
	{
		if (EW_BLOB_FIELD_BYTE_COUNT > 0) {
			return BitConverter.ToString((byte[])b, 0, EW_BLOB_FIELD_BYTE_COUNT);
		} else {
			return BitConverter.ToString((byte[])b);
		}
	}

	// Create temp image file from binary data
	public static string ew_TmpImage(byte[] filedata) {
		if (filedata == null)
			return ""; // ASPX
		string export = "";
		if (ew_NotEmpty(ew_Get("export")))
			export = ew_Get("export");
		else if (ew_NotEmpty(ew_Post("export")))
			export = ew_Post("export");
		else if (ew_NotEmpty(ew_Post("exporttype")))
			export = ew_Post("exporttype");	
		string folder = ew_UploadPathEx(true, EW_UPLOAD_DEST_PATH);
		string f = folder + Path.GetRandomFileName();
		using (var ms = new MemoryStream(filedata)) {
			try {
				using (var img = System.Drawing.Image.FromStream(ms)) { // ASPX
					if (img.RawFormat.Equals(ImageFormat.Gif)) {
						f = Path.ChangeExtension(f, ".gif");
					} else if (img.RawFormat.Equals(ImageFormat.Jpeg)) {
						f = Path.ChangeExtension(f, ".jpg");
					} else if (img.RawFormat.Equals(ImageFormat.Png)) {
						f = Path.ChangeExtension(f, ".png");
					} else if (img.RawFormat.Equals(ImageFormat.Bmp)) {
						f = Path.ChangeExtension(f, ".bmp");
					} else {
						return "";
					}
					img.Save(f);
				}
			} catch {}
		}
		string tmpimage = Path.GetFileName(f);
		gTmpImages.Add(tmpimage);			
		return ew_TmpImageLnk(tmpimage, export);
	}

	// Garbage collection
	public static void ew_GCollect() {

		// Force garbage collection
		GC.Collect();		

		// Wait for all finalizers to complete before continuing. 
		// Without this call to GC.WaitForPendingFinalizers,  
		// the worker loop below might execute at the same time  
		// as the finalizers. 
		// With this call, the worker loop executes only after 
		// all finalizers have been called.

		GC.WaitForPendingFinalizers();
	}	

	// Delete temp images
	public static void ew_DeleteTmpImages() {
		if (gTmpImages != null) {			
			string folder = ew_UploadPathEx(true, EW_UPLOAD_DEST_PATH);
			foreach (string tmpimage in gTmpImages) {
				string f = folder + tmpimage;
				ew_DeleteFile(f);
			}
			gTmpImages.Clear(); // ASPX
		}
	}

	// Create temp file
	public static string ew_TmpFile(string afile) {		
		if (File.Exists(afile)) { // Copy only
			string export = "";
			if (ew_NotEmpty(ew_Get("export")))
				export = ew_Get("export");
			else if (ew_NotEmpty(ew_Post("export")))
				export = ew_Post("export");
			string folder = ew_UploadPathEx(true, EW_UPLOAD_DEST_PATH);
			string f = folder + Path.GetRandomFileName();
			string ext = Path.GetExtension(afile);
			if (ew_NotEmpty(ext))
				f += ext;
			ew_CopyFile(afile, f);
			string tmpimage = Path.GetFileName(f);
			gTmpImages.Add(tmpimage);			
			return ew_TmpImageLnk(tmpimage, export);
		} else {
			return "";
		}
	}

	// Get temp image link
	public static string ew_TmpImageLnk(string file, string lnktype = "") {
		if (ew_Empty(file))
			return "";
		if (lnktype == "email" || lnktype == "cid") {
			string[] ar = file.Split(new char[] {'.'});
			var list = new List<string>(ar);
			list.RemoveAt(list.Count - 1);
			ar = list.ToArray();
			string lnk = String.Join(".", ar);
			if (lnktype == "email") lnk = "cid:" + lnk;
			return lnk;
		} else {
			return ew_UploadPathEx(true, EW_UPLOAD_DEST_PATH) + file; // Use physical path // ASPX
		}
	}

	// Invoke method of ASP.NET WebPage // ASPX
	public object ew_Invoke(string name, object[] parameters = null) {
		MethodInfo mi = this.GetType().GetMethod(name);
		if (mi != null)
			return mi.Invoke(this, parameters);
		return null;
	}

	// Invoke method of an object // ASPX
	public static object ew_Invoke(object obj, string name, object[] parameters = null) {
		MethodInfo mi = obj.GetType().GetMethod(name, BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy);
		if (mi != null)
			return mi.Invoke(obj, parameters);
		return null;
	}

	// Get Hash URL
	public static string ew_GetHashUrl(string url, string hash) {
		return url + "#" + hash;
	}

	//
	//  Form object class
	//
	public class cFormObj
	{		

		public int Index = -1; // Index to handle multiple form elements

		public string FormName = "";

		// Get form element name based on index
		public string GetIndexedName(string name)
		{
			int Pos;
			if (Index < 0) {
				return name;
			} else {
				Pos = name.IndexOf("_");
				if (Pos == 1 || Pos == 2) {
					return name.Substring(0, Pos) + Index + name.Substring(Pos);
				} else {
					return name;
				}
			}
		}

		// Has value for form element
		public bool HasValue(string name) {
			string wrkname = GetIndexedName(name);
			return (ew_Form[wrkname] != null);
		}

		// Get value for form element
		public string GetValue(string name)
		{
			string wrkname = GetIndexedName(name);
			var value = ew_Post(wrkname);
			if (FormName != "") {
				wrkname = FormName + "$" + wrkname;
				if (ew_Form[wrkname] != null)
					value = ew_Post(wrkname);
			}
			return value;
		}

		// Get upload file size
		public long GetUploadFileSize(string name)
		{
			string wrkname = GetIndexedName(name);
			if (ew_Files[wrkname] != null) {
				return ew_Files[wrkname].ContentLength;
			} else {
				return -1;
			}
		}

		// Get upload file name
		public string GetUploadFileName(string name)
		{
			string wrkname = GetIndexedName(name);
			if (ew_Files[wrkname] != null) {
				string FileName = ew_Files[wrkname].FileName;
				return Path.GetFileName(FileName);
			} else {
				return "";
			}
		}

		// Get file content type
		public string GetUploadFileContentType(string name)
		{
			string wrkname = GetIndexedName(name);
			if (ew_Files[wrkname] != null) {
				var ct = ew_Files[wrkname].ContentType;
				var ct2 = ew_ContentType(null, GetUploadFileName(name));
				return (ct2 != "") ? ct2 : ct;
			} else {
				return "";
			}
		}

		// Get upload file data
		public object GetUploadFileData(string name)
		{
			string wrkname = GetIndexedName(name);
			HttpPostedFileBase file = ew_Files[wrkname];
			if (file != null && file.ContentLength > 0) {
				int filelength = file.ContentLength;
				byte[] bindata = new byte[filelength];
				Stream fs = file.InputStream;
				fs.Seek(0, SeekOrigin.Begin);
				fs.Read(bindata, 0, filelength);				
				return bindata;
			} else {
				return System.DBNull.Value;
			}
		}

		// Get file image width
		public int GetUploadImageWidth(string name)
		{
			string wrkname = GetIndexedName(name);
			HttpPostedFileBase file = ew_Files[wrkname];
			if (file != null && file.ContentLength > 0) {
				try {
					System.Drawing.Image img = System.Drawing.Image.FromStream(file.InputStream);
					return Convert.ToInt32(img.PhysicalDimension.Width);
				} catch {
					return -1;
				}
			} else {
				return -1;
			}
		}

		// Get file image height
		public int GetUploadImageHeight(string name)
		{
			string wrkname = GetIndexedName(name);
			HttpPostedFileBase file = ew_Files[wrkname];
			if (file != null && file.ContentLength > 0) {
				try {
					System.Drawing.Image img = System.Drawing.Image.FromStream(file.InputStream);
					return Convert.ToInt32(img.PhysicalDimension.Height);
				} catch {
					return -1;
				}
			} else {
				return -1;
			}
		}
	}

	//
	// Advanced Security class
	//
	public class cAdvancedSecurityBase {

		private List<string[]> UserLevel = new List<string[]>();

		private List<string[]> UserLevelPriv = new List<string[]>();

		private List<int> UserLevelID = new List<int>();

		private List<string> UserID = new List<string>{};

		// Current User Level ID / User Level
		public int CurrentUserLevelID;

		public int CurrentUserLevel;

		// Current User ID / Parent User ID
		public string CurrentUserID;

		public string CurrentParentUserID;

		public cConnectionBase Conn;		

		// Init
		public cAdvancedSecurityBase(cConnectionBase c) {
			Conn = c;

			// User table
			// Init User Level

			CurrentUserLevelID = SessionUserLevelID;
			if (Information.IsNumeric(CurrentUserLevelID)) {
				if (CurrentUserLevelID >= -1)					
					UserLevelID.Add(CurrentUserLevelID);
			}

			// Init User ID
			CurrentUserID = Convert.ToString(SessionUserID);
			CurrentParentUserID = Convert.ToString(SessionParentUserID);

			// Load user level
			LoadUserLevel();
		}		

		// Session User ID
		public object SessionUserID {
			get { return Convert.ToString(ew_Session[EW_SESSION_USER_ID]); }
			set {
				ew_Session[EW_SESSION_USER_ID] = Convert.ToString(value).Trim();
				CurrentUserID = Convert.ToString(value).Trim();
			}
		}

		// Session parent User ID
		public object SessionParentUserID {
			get { return Convert.ToString(ew_Session[EW_SESSION_PARENT_USER_ID]); }
			set {
				ew_Session[EW_SESSION_PARENT_USER_ID] = Convert.ToString(value).Trim();
				CurrentParentUserID = Convert.ToString(value).Trim();
			}
		}

		// Current user name
		public string CurrentUserName {
			get { return Convert.ToString(ew_Session[EW_SESSION_USER_NAME]); }
			set { ew_Session[EW_SESSION_USER_NAME] = value; }
		}

		// Session User Level ID		
		public int SessionUserLevelID {
			get { return Convert.ToInt32(ew_Session[EW_SESSION_USER_LEVEL_ID]); }
			set {
				ew_Session[EW_SESSION_USER_LEVEL_ID] = value;
				CurrentUserLevelID = value;
				if (Information.IsNumeric(CurrentUserLevelID)) {
					if (CurrentUserLevelID >= -1) {					
						UserLevelID.Clear();
						UserLevelID.Add(CurrentUserLevelID);
					}
				}
			}
		}

		// Session User Level value	
		public int SessionUserLevel {
			get { return Convert.ToInt32(ew_Session[EW_SESSION_USER_LEVEL]); }
			set {
				ew_Session[EW_SESSION_USER_LEVEL] = value;
				CurrentUserLevel = value;
				if (Information.IsNumeric(CurrentUserLevelID)) {
					if (CurrentUserLevelID >= -1) {
						UserLevelID.Clear();
						UserLevelID.Add(CurrentUserLevelID);
					}
				}
			}
		}

		// Can add		
		public bool CanAdd {
			get { return ((CurrentUserLevel & EW_ALLOW_ADD) == EW_ALLOW_ADD); }
			set {
				if (value) {
					CurrentUserLevel = (CurrentUserLevel | EW_ALLOW_ADD);
				} else {
					CurrentUserLevel = (CurrentUserLevel & (~EW_ALLOW_ADD));
				}
			}
		}

		// Can delete	
		public bool CanDelete {
			get { return ((CurrentUserLevel & EW_ALLOW_DELETE) == EW_ALLOW_DELETE); }
			set {
				if (value) {
					CurrentUserLevel = (CurrentUserLevel | EW_ALLOW_DELETE);
				} else {
					CurrentUserLevel = (CurrentUserLevel & (~EW_ALLOW_DELETE));
				}
			}
		}

		// Can edit
		public bool CanEdit {
			get { return ((CurrentUserLevel & EW_ALLOW_EDIT) == EW_ALLOW_EDIT); }
			set {
				if (value) {
					CurrentUserLevel = (CurrentUserLevel | EW_ALLOW_EDIT);
				} else {
					CurrentUserLevel = (CurrentUserLevel & (~EW_ALLOW_EDIT));
				}
			}
		}

		// Can view
		public bool CanView {
			get { return ((CurrentUserLevel & EW_ALLOW_VIEW) == EW_ALLOW_VIEW); }
			set {
				if (value) {
					CurrentUserLevel = (CurrentUserLevel | EW_ALLOW_VIEW);
				} else {
					CurrentUserLevel = (CurrentUserLevel & (~EW_ALLOW_VIEW));
				}
			}
		}

		// Can list
		public bool CanList {
			get { return ((CurrentUserLevel & EW_ALLOW_LIST) == EW_ALLOW_LIST); }
			set {
				if (value) {
					CurrentUserLevel = (CurrentUserLevel | EW_ALLOW_LIST);
				} else {
					CurrentUserLevel = (CurrentUserLevel & (~EW_ALLOW_LIST));
				}
			}
		}

		// Can report		
		public bool CanReport {
			get { return ((CurrentUserLevel & EW_ALLOW_REPORT) == EW_ALLOW_REPORT); }
			set {
				if (value) {
					CurrentUserLevel = (CurrentUserLevel | EW_ALLOW_REPORT);
				} else {
					CurrentUserLevel = (CurrentUserLevel & (~EW_ALLOW_REPORT));
				}
			}
		}

		// Can search		
		public bool CanSearch {
			get { return ((CurrentUserLevel & EW_ALLOW_SEARCH) == EW_ALLOW_SEARCH); }
			set {
				if (value) {
					CurrentUserLevel = (CurrentUserLevel | EW_ALLOW_SEARCH);
				} else {
					CurrentUserLevel = (CurrentUserLevel & (~EW_ALLOW_SEARCH));
				}
			}
		}

		// Can admin		
		public bool CanAdmin {
			get { return ((CurrentUserLevel & EW_ALLOW_ADMIN) == EW_ALLOW_ADMIN); }
			set {
				if (value) {
					CurrentUserLevel = (CurrentUserLevel | EW_ALLOW_ADMIN);
				} else {
					CurrentUserLevel = (CurrentUserLevel & (~EW_ALLOW_ADMIN));
				}
			}
		}

		// Last URL
		public string LastUrl {
			get { return ew_Cookie["lasturl"]; }
		}

		// Save last URL
		public void SaveLastUrl()
		{
			string s = ew_ServerVar("SCRIPT_NAME");
			string q = ew_ServerVar("QUERY_STRING");
			if (ew_NotEmpty(q)) s = s + "?" + q; 
			if (LastUrl == s) s = ""; 
			ew_Cookie["lasturl"] = s;
		}

		// Auto login
		public bool AutoLogin()
		{
			if (ew_SameStr(ew_Cookie["autologin"], "autologin")) {
				string sUsr = ew_Cookie["username"];
				string sPwd = ew_Cookie["password"];
				sUsr = ew_Decrypt(sUsr);
				sPwd = ew_Decrypt(sPwd);
				bool bValid = ValidateUser(ref sUsr, ref sPwd, true);
				return bValid;
			} else {
				return false;
			}
		}	

		// Validate user
		public bool ValidateUser(ref string usr, ref string pwd, bool autologin)
		{
			bool result = false;
			string sFilter;
			string sSql;
			bool CustomValidateUser = false;

			// Call User Custom Validate event
			if (EW_USE_CUSTOM_LOGIN) {
				CustomValidateUser = User_CustomValidate(ref usr, ref pwd);
				if (CustomValidateUser) {
					ew_Session[EW_SESSION_STATUS] = "login";
					CurrentUserName = usr; // Load user name
				}
			}
			if (CustomValidateUser)
				return CustomValidateUser;
			if (!result && !IsPasswordExpired())
				ew_Session[EW_SESSION_STATUS] = ""; // Clear login status 
			return result;
		}

		// No user level security
		public void SetUpUserLevel() {
		}

		// Add user permission
		public void AddUserPermission(string UserLevelName, string TableName, int UserPermission)
		{
			string UserLevelID = "";

			// Get user level ID from user name
			if (ew_IsList(UserLevel)) {
				foreach (string[] row in UserLevel) {
					if (ew_SameStr(UserLevelName, row[1])) {
						UserLevelID = Convert.ToString(row[0]);
						break;
					}
				}
			}
			if (ew_IsList(UserLevelPriv) && ew_NotEmpty(UserLevelID)) {
				foreach (string[] row in UserLevelPriv) {
					if (ew_SameStr(row[0], EW_PROJECT_ID + TableName) && ew_SameStr(row[1], UserLevelID)) {
						row[2] = Convert.ToString(ew_ConvertToInt(row[2]) | UserPermission);	// Add permission
						break;
					}
				}
			}
		}

		// Delete user permission
		public void DeleteUserPermission(string UserLevelName, string TableName, int UserPermission)
		{
			string UserLevelID = "";

			// Get user level ID from user name
			if (ew_IsList(UserLevel)) {
				foreach (string[] Row in UserLevel) {
					if (ew_SameStr(UserLevelName, Row[1])) {
						UserLevelID = Convert.ToString(Row[0]);
						break;
					}
				}
			}
			if (ew_IsList(UserLevelPriv) && ew_NotEmpty(UserLevelID)) {
				foreach (string[] Row in UserLevelPriv) {
					if (ew_SameStr(Row[0], EW_PROJECT_ID + TableName) && ew_SameStr(Row[1], UserLevelID)) {
						Row[2] = Convert.ToString(ew_ConvertToInt(Row[2]) & (127 - UserPermission));	// Remove permission
						break;
					}
				}
			}
		}

		// Load current user level
		public void LoadCurrentUserLevel(string Table)
		{
			LoadUserLevel();
			SessionUserLevel = CurrentUserLevelPriv(Table);
		}

		// Get current user privilege
		private int CurrentUserLevelPriv(string TableName)
		{			
			if (IsLoggedIn) {
				return 127;
			} else {
				return 0;
			}
		}

		// Get user level ID by user level name
		public int GetUserLevelID(string UserLevelName)
		{
			if (ew_SameStr(UserLevelName, "Administrator")) {
				return -1;
			} else if (ew_NotEmpty(UserLevelName)) {
				if (ew_IsList(UserLevel)) {
					foreach (string[] Row in UserLevel) {
						if (ew_SameStr(Row[1], UserLevelName))
							return ew_ConvertToInt(Row[0]);
					}
				}
			}
			return -2;	// Unknown
		}

		// Add Add User Level by name
		public void AddUserLevel(string UserLevelName)
		{
			if (ew_Empty(UserLevelName))
				return;
			int id = GetUserLevelID(UserLevelName);
			AddUserLevelID(id);
		}

		// Add User Level by ID
		public void AddUserLevelID(int id)
		{
			if (!Information.IsNumeric(id) || id < -1)
				return;
			if (UserLevelID.IndexOf(id) < 0)
				UserLevelID.Add(id);	
		}

		// Delete User Level by name
		public void DeleteUserLevel(string UserLevelName)
		{
			if (ew_Empty(UserLevelName)) return;
			int id = GetUserLevelID(UserLevelName);
			DeleteUserLevelID(id);
		}

		// Delete User Level by ID
		public void DeleteUserLevelID(int id) {
			if (!Information.IsNumeric(id) || id < -1)
				return;
			int index = UserLevelID.IndexOf(id);
			if (index > -1)
				UserLevelID.RemoveAt(index);	
		}

		// User level list
		public string UserLevelList()
		{
			return String.Join(", ", UserLevelID);
		}

		// User level name list
		public string UserLevelNameList()
		{
			string List = "";			
			foreach (int id in UserLevelID) {
				if (ew_NotEmpty(List)) List += ", "; 
				List += ew_QuotedValue(GetUserLevelName(id), EW_DATATYPE_STRING);
			}
			return List;
		}

		// Get user privilege based on table name and user level
		public int GetUserLevelPrivEx(string TableName, int UserLevelID)
		{
			if (ew_SameStr(UserLevelID, "-1")) { // System Administrator				
				if (EW_USER_LEVEL_COMPAT) {
					return 31;	// Use old user level values
				} else {
					return 127;	// Use new user level values (separate View/Search)
				}
			} else if (UserLevelID >= 0) {
				if (ew_IsList(UserLevelPriv)) {
					foreach (string[] Row in UserLevelPriv) {
						if (ew_SameStr(Row[0], TableName) && ew_SameStr(Row[1], UserLevelID))
							return ew_ConvertToInt(Row[2]);
					}
				}
			}
			return 0;
		}

		// Get current user level name
		public string CurrentUserLevelName
		{
			get {
				return GetUserLevelName(CurrentUserLevelID);
			}
		}

		// Get user level name based on user level
		public string GetUserLevelName(int UserLevelID)
		{
			if (ew_SameStr(UserLevelID, "-1")) {
				return "Administrator";
			} else if (UserLevelID >= 0) {
				if (ew_IsList(UserLevel)) {
					foreach (string[] Row in UserLevel) {
						if (ew_SameStr(Row[0], UserLevelID)) {
							return Convert.ToString(Row[1]);
						}
					}
				}
			}
			return "";
		}

		// Display all the User Level settings (for debug only)
		public void ShowUserLevelInfo()
		{
			if (ew_IsList(UserLevel)) {
				ew_Write("User Levels:<br>");
				ew_Write("UserLevelId, UserLevelName<br>");
				foreach (string[] Row in UserLevel)
					ew_Write("&nbsp;&nbsp;" + String.Join(", ", Row) + "<br>");
			} else {
				ew_Write("No User Level definitions." + "<br>");
			}
			if (ew_IsList(UserLevelPriv)) {
				ew_Write("User Level Privs:<br>");
				ew_Write("TableName, UserLevelId, UserLevelPriv<br>");
				foreach (string[] Row in UserLevelPriv)
					ew_Write("&nbsp;&nbsp;" + String.Join(", ", Row) + "<br>");
			} else {
				ew_Write("No User Level privilege settings." + "<br>");
			}
			ew_Write("CurrentUserLevel = " + CurrentUserLevel + "<br>");
			ew_Write("User Levels = " + UserLevelList() + "<br>");
		}

		// Check privilege for List page (for menu items)
		public bool AllowList(string TableName)
		{
			return ew_ConvertToBool(CurrentUserLevelPriv(TableName) & EW_ALLOW_LIST);
		}

		// Check privilege for View page (for Allow-View / Detail-View)
		public bool AllowView(string TableName) {
			return ew_ConvertToBool(CurrentUserLevelPriv(TableName) & EW_ALLOW_VIEW);
		}

		// Check privilege for Add page (for Allow-Add / Detail-Add)
		public bool AllowAdd(string TableName)
		{
			return ew_ConvertToBool(CurrentUserLevelPriv(TableName) & EW_ALLOW_ADD);
		}

		// Check privilege for Edit page (for Detail-Edit)
		public bool AllowEdit(string TableName) {
			return ew_ConvertToBool(CurrentUserLevelPriv(TableName) & EW_ALLOW_EDIT);
		}		

		// Check if user password expired
		public bool IsPasswordExpired
		{
			get {
				return ew_SameStr(ew_Session[EW_SESSION_STATUS], "passwordexpired");
			}
		}

		// Check if user is logging in (after changing password)
		public bool IsLoggingIn
		{
			get {
				return ew_SameStr(ew_Session[EW_SESSION_STATUS], "loggingin");
			}
		}

		// Check if user is logged in
		public bool IsLoggedIn
		{
			get {
				return ew_SameStr(ew_Session[EW_SESSION_STATUS], "login");
			}
		}

		// Check if user is system administrator
		public bool IsSysAdmin
		{
			get {
				return (Convert.ToInt32(ew_Session[EW_SESSION_SYS_ADMIN]) == 1);
			}
		}

		// Check if user is administrator
		public bool IsAdmin
		{
			get {
				bool res = IsSysAdmin;
				return res;
			}
		}

		// Save user level to session
		public void SaveUserLevel()
		{
			ew_Session[EW_SESSION_AR_USER_LEVEL] = UserLevel;
			ew_Session[EW_SESSION_AR_USER_LEVEL_PRIV] = UserLevelPriv;
		}

		// Load user level from session
		public void LoadUserLevel()
		{
			if (!ew_IsList(ew_Session[EW_SESSION_AR_USER_LEVEL]) || !ew_IsList(ew_Session[EW_SESSION_AR_USER_LEVEL_PRIV])) { 
				SetUpUserLevel();
				SaveUserLevel();
			} else {
				UserLevel = (List<string[]>)ew_Session[EW_SESSION_AR_USER_LEVEL];
				UserLevelPriv = (List<string[]>)ew_Session[EW_SESSION_AR_USER_LEVEL_PRIV];
			}
		}

		// UserID Loading event
		public virtual void UserID_Loading() {

			//ew_Write("UserID Loading: " + CurrentUserID + "<br>");
		}

		// UserID Loaded event
		public virtual void UserID_Loaded() {

			//ew_Write("UserID Loaded: " + UserIDList() + "<br>");
		}

		// User Level Loaded event
		public virtual void UserLevel_Loaded() {

			//AddUserPermission(<UserLevelName>, <TableName>, <UserPermission>);
			//DeleteUserPermission(<UserLevelName>, <TableName>, <UserPermission>);

		}

		// Table Permission Loading event
		public virtual void TablePermission_Loading() {

			//ew_Write("Table Permission Loading: " + CurrentUserLevelID + "<br>");
		}

		// Table Permission Loaded event
		public virtual void TablePermission_Loaded() {

			//ew_Write("Table Permission Loaded: " + CurrentUserLevel + "<br>");
		}

		// User Custom Validate event
		public virtual bool User_CustomValidate(ref string usr, ref string pwd) {

			// Enter your custom code to validate user, return TRUE if valid.
			return false;
		}

		// User Validated event
		public virtual void User_Validated(DbDataReader rs) {

			//ew_Session["UserEmail"] = rs["Email"];
		}

		// User PasswordExpired event
		public virtual void User_PasswordExpired(DbDataReader rs) {

			//ew_Write("User_PasswordExpired");
		}
	}

	// Remove elements from OrderedDictionary by an array of keys and return the removed elements as OrderedDictionary
	public static OrderedDictionary ew_Splice(ref OrderedDictionary od, string[] keys) {
		var res = new OrderedDictionary();
		foreach (string key in keys) {
			if (od.Contains(key)) {
				res.Add(key, od[key]);
				od.Remove(key);
			}
		}
		return res;
	}

	// Extract elements from OrderedDictionary by an array of keys
	public static OrderedDictionary ew_Slice(ref OrderedDictionary od, string[] keys) {
		var res = new OrderedDictionary();
		foreach (string key in keys) {
			if (od.Contains(key))
				res.Add(key, od[key]);
		}
		return res;
	}	

	// Menu class
	public class cMenuBase
	{

		public object Id;

		public string MenuBarClassName = EW_MENUBAR_CLASSNAME;

		public string MenuClassName = EW_MENU_CLASSNAME;

		public string SubMenuClassName = EW_SUBMENU_CLASSNAME;

		public string SubMenuDropdownImage = EW_SUBMENU_DROPDOWN_IMAGE;

		public string SubMenuDropdownIconClassName = EW_SUBMENU_DROPDOWN_ICON_CLASSNAME;

		public string MenuDividerClassName = EW_MENU_DIVIDER_CLASSNAME;

		public string MenuItemClassName = EW_MENU_ITEM_CLASSNAME;

		public string SubMenuItemClassName = EW_SUBMENU_ITEM_CLASSNAME;

		public string MenuActiveItemClassName = EW_MENU_ACTIVE_ITEM_CLASS;

		public string SubMenuActiveItemClassName = EW_SUBMENU_ACTIVE_ITEM_CLASS;

		public bool MenuRootGroupTitleAsSubMenu = EW_MENU_ROOT_GROUP_TITLE_AS_SUBMENU;

		public bool ShowRightMenu = EW_SHOW_RIGHT_MENU;

		public string MenuLinkDropdownClass = "";

		public string MenuLinkClassName = "";

		public bool IsMobile = false;

		public bool IsRoot = false;

		public ArrayList ItemData = new ArrayList(); // ArrayList of cMenuItem

		// Constructor
		public cMenuBase(object MenuId, bool Mobile = false)
		{
			Id = MenuId;
			IsMobile = Mobile;
		}

		// Add a menu item
		public void AddMenuItem(int Id, string Name, string Text, string Url, int ParentId = -1, string Src = "", bool Allowed = true, bool GroupTitle = false, bool CustomUrl = false)
		{
			cMenuItem oParentMenu = null;
			var item = new cMenuItem(Id, Name, Text, Url, ParentId, Src, Allowed, GroupTitle, CustomUrl);
			item.Parent = this;
			if (!MenuItem_Adding(ref item))
				return;
			if (item.ParentId < 0) {
				AddItem(ref item);
			} else {
				if (FindItem(item.ParentId, ref oParentMenu))
					oParentMenu.AddItem(ref item, IsMobile);
			}
		}

		// Add a menu item (for backward compatibility) // ASPX
		public void AddMenuItem(int Id, string Text, string Url, int ParentId = -1, string Src = "", bool Allowed = true, bool GroupTitle = false, bool CustomUrl = false)
		{
			string Name = "mi_" + Convert.ToString(Id); 
			AddMenuItem(Id, Name, Text, Url, ParentId, Src, Allowed, GroupTitle, CustomUrl);			
		}

		// Get menu item count
		public int Count
		{
			get { return ItemData.Count; }
		}

		// Add item to internal ArrayList
		public void AddItem(ref cMenuItem item)
		{
			ItemData.Add(item);
		}

		// Clear all menu items
		public void Clear() {
			ItemData.Clear();
		}

		// Find item
		public bool FindItem(int id, ref cMenuItem outitem)
		{
			bool result = false;
			foreach (cMenuItem item in ItemData) {
				if (item.Id == id) {
					outitem = item;
					return true;
				} else if (item.SubMenu != null) {
					if (item.SubMenu.FindItem(id, ref outitem))
						return true;
				}
			}
			return result;
		}		

		// Find item by menu text
		public bool FindItemByText(string txt, ref cMenuItem outitem)
		{
			bool result = false;
			foreach (cMenuItem item in ItemData) {
				if (item.Text == txt) {
					outitem = item;
					return true;
				} else if (item.SubMenu != null) {
					if (item.SubMenu.FindItemByText(txt, ref outitem))
						return true;
				}
			}
			return result;
		}

		// Move item to position
		public void MoveItem(string Text, int Pos)
		{
			int oldpos = 0;
			int newpos = Pos;
			bool bfound = false;
			if (Pos < 0) {
				Pos = 0;
			} else if (Pos >= ItemData.Count) {
				Pos = ItemData.Count - 1;
			}
			cMenuItem CurItem = null;
			foreach (cMenuItem item in ItemData) {
				if (ew_SameStr(item.Text, Text)) {
					CurItem = item;
					break;
				}
			}
			if (CurItem != null) {
				bfound = true;
				oldpos = ItemData.IndexOf(CurItem);
			} else {
				bfound = false;
			}
			if (bfound && Pos != oldpos) {
				ItemData.RemoveAt(oldpos); // Remove old item
				if (oldpos < Pos)
					newpos -= 1; // Adjust new position
				ItemData.Insert(newpos, CurItem); // Insert new item
			}
		}

		// Check if sub menu should be shown
		public bool RenderSubMenu(cMenuItem item) {
			if (item.SubMenu != null) {
				foreach (cMenuItem subitem in item.SubMenu.ItemData) {
					if (item.SubMenu.RenderItem(subitem))
						return true;
				}
			}
			return false;
		}

		// Check if a menu item should be shown
		public bool RenderItem(cMenuItem item) {
			if (item.SubMenu != null) {
				foreach (cMenuItem subitem in item.SubMenu.ItemData) {
					if (item.SubMenu.RenderItem(subitem))
						return true;
				}
			}
			return (item.Allowed && ew_NotEmpty(item.Url));
		}

		// Check if this menu should be rendered
		public bool RenderMenu() {
			foreach (cMenuItem item in ItemData) {
				if (RenderItem(item))
					return true;
			}
			return false;
		}

		// Render the menu
		public virtual string Render(bool ret = false) {

//			var m = this;
//			if (IsRoot)
//				Menu_Rendering(ref m);

			if (!RenderMenu())
				return "";
			string str = "";	
			if (!IsMobile) {
				if (IsRoot) {	
					str = "<ul";
					if (ew_NotEmpty(Id)) {
						if (Information.IsNumeric(Id)) {
							str += " id=\"menu_" + Id + "\"";
						} else {
							str += " id=\"" + Id + "\"";
						}
					}
					str += " class=\"" + MenuClassName + "\">";
				} else {
					str = "<ul class=\"" + SubMenuClassName + "\" role=\"menu\">\n";
				}
			}						
			int gcnt = 0; // Group count
			bool gtitle = false; // Last item is group title
			int i = 0; // Menu item count
			string cururl = ew_CurrentUrl();
			cururl = cururl.Substring(cururl.LastIndexOf("/") + 1);
			foreach (cMenuItem item in ItemData) {
				if (RenderItem(item)) {	
					i++;
					string aclass = "", liclass = "";
					if (!IsMobile && gtitle && (gcnt >= 1 || IsRoot)) // add divider for previous group
						str += "<li class=\"" + MenuDividerClassName + "\"></li>\n";
					if (item.GroupTitle && (!IsRoot || !MenuRootGroupTitleAsSubMenu)) { // Group title
						gtitle = true;
						gcnt += 1;
						if (ew_NotEmpty(item.Text)) {
							if (IsMobile)
								str += "<li data-role=\"list-divider\">" + item.Text + "</li>\n";
							else
								str += "<li class=\"dropdown-header\">" + item.Text + "</li>\n";
						}
						if (item.SubMenu != null) {
							foreach (cMenuItem subitem in item.SubMenu.ItemData) {
								liclass = (subitem.SubMenu != null && RenderSubMenu(subitem)) ? SubMenuItemClassName : "";
								aclass = "";
								if (!subitem.IsCustomUrl && ew_CurrentPage() == ew_GetPageName(subitem.Url) || subitem.IsCustomUrl && cururl == subitem.Url) {
									liclass = ew_AppendClass(liclass, MenuActiveItemClassName);
									subitem.Url = "javascript:void(0);";
								}	
								if (RenderItem(subitem)) {
									if (IsMobile && item.GroupTitle)
										aclass = ew_AppendClass(aclass, "ewIndent");
									str += subitem.Render(aclass, liclass, IsMobile) + "\n"; // Create <LI>
								}
							}
						}
					} else {
						gtitle = false;
						liclass = (item.SubMenu != null && RenderSubMenu(item)) ? (IsRoot ? MenuItemClassName : SubMenuItemClassName) : "";
						aclass = "";
						if (!item.IsCustomUrl && ew_CurrentPage() == ew_GetPageName(item.Url) || item.IsCustomUrl && cururl == item.Url) {
							if (IsRoot)
								liclass = ew_AppendClass(liclass, MenuActiveItemClassName);
							else
								liclass = ew_AppendClass(liclass, SubMenuActiveItemClassName);
							item.Url = "javascript:void(0);";
						}
						str += item.Render(aclass, liclass, IsMobile) + "\n"; // Create <LI>
					}
				}
			}
			if (IsMobile) {
				str = "<ul data-role=\"listview\" data-filter=\"true\">" + str + "</ul>\n";
			} else if (IsRoot) {
				str += "</ul>\n";
				if (EW_MENUBAR_BRAND != "") {
					var brandhref = (EW_MENUBAR_BRAND_HYPERLINK == "") ? "#" : EW_MENUBAR_BRAND_HYPERLINK;
					str = "<a class=\"navbar-brand hidden-xs\" href=\"" + ew_HtmlEncode(brandhref) + "\">" + EW_MENUBAR_BRAND + "</a>" + str;
				}

				// Add right menu
				if (ShowRightMenu)
					str += "<ul class=\"nav navbar-nav navbar-right\"></ul>";
				if (MenuBarClassName != "")
					str = "<div class=\"" + MenuBarClassName + "\">" + str + "</div>";
			} else {
				str += "</ul>\n";
			}
			if (ret) // Return as string
				return str;
			ew_Write(str); // Output
			return "";
		}

		// MenuItem_Adding 
		public virtual bool MenuItem_Adding(ref cMenuItem Item) {
			return true;
		}

//		// Menu_Rendering 
//		public virtual void Menu_Rendering(ref cMenuBase Menu) {
//		}

	}

	// Menu item class
	public class cMenuItem
	{

		public int Id;

		public string Name;

		public string Text;

		public string Url;

		public int ParentId;

		public cMenuBase SubMenu = null;

		public string Source = "";

		public bool Allowed = true;

		public string Target = "";

		public bool GroupTitle = false;

		public bool IsCustomUrl = false;

		public cMenuBase Parent;

		// Constructor
		public cMenuItem(int aId, string aName, string aText, string aUrl, int aParentId = -1, string aSource = "", bool aAllowed = true, bool aGroupTitle = false, bool aCustomUrl = false)
		{
			Id = aId;
			Name = aName;
			Text = aText;
			Url = aUrl;
			ParentId = aParentId;
			Source = aSource;
			Allowed = aAllowed;
			GroupTitle = aGroupTitle;
			IsCustomUrl = aCustomUrl;			
		}

		// Add submenu item
		public void AddItem(ref cMenuItem item, bool mobile = false)
		{
			if (SubMenu == null)
				SubMenu = new cMenuBase(Id, mobile);
			SubMenu.MenuBarClassName = Parent.MenuBarClassName;
			SubMenu.MenuClassName = Parent.MenuClassName;
			SubMenu.SubMenuClassName = Parent.SubMenuClassName;
			SubMenu.SubMenuDropdownImage = Parent.SubMenuDropdownImage;
			SubMenu.SubMenuDropdownIconClassName = Parent.SubMenuDropdownIconClassName;
			SubMenu.MenuDividerClassName = Parent.MenuDividerClassName;
			SubMenu.MenuItemClassName = Parent.MenuItemClassName;
			SubMenu.SubMenuItemClassName = Parent.SubMenuItemClassName;
			SubMenu.MenuActiveItemClassName = Parent.MenuActiveItemClassName;
			SubMenu.SubMenuActiveItemClassName = Parent.SubMenuActiveItemClassName;
			SubMenu.MenuRootGroupTitleAsSubMenu = Parent.MenuRootGroupTitleAsSubMenu;
			SubMenu.MenuLinkDropdownClass = Parent.MenuLinkDropdownClass;
			SubMenu.MenuLinkClassName = Parent.MenuLinkClassName;				
			SubMenu.AddItem(ref item);
		}

		// Render
		public string Render(string aclass, string liclass, bool mobile = false) {

			// Create <A>
			Dictionary<string, string> attrs;
			var url = ew_GetUrl(Url);
			string submenuhtml;
			string text2;
			if (SubMenu != null)
				submenuhtml = SubMenu.Render(true);
			else
				submenuhtml = "";
			if (mobile) {
				url = url.Replace("#", "?chart=");
				if (url == "") url = "#";
				attrs = new Dictionary<string, string>() {{"class", aclass}, {"rel",(url != "#") ? "external" : ""}, {"href", url}, {"target", Target}};
			} else {
				if (url == "") url = "#";
				if (SubMenu != null && SubMenu.MenuLinkDropdownClass != "" && submenuhtml != "")
				aclass = ew_PrependClass(aclass, SubMenu.MenuLinkDropdownClass); // ASPX
				attrs = new Dictionary<string, string>() {{"class", aclass}, {"href", url}, {"target", Target}};
			}
			var text = Text;
			if (SubMenu != null && submenuhtml != "") {
				if (Parent.SubMenuDropdownIconClassName != "")
					text += "<span class=\"" + Parent.SubMenuDropdownIconClassName + "\"></span>";
				if (Parent.SubMenuDropdownImage != "" && ParentId == -1)
					text += Parent.SubMenuDropdownImage;
			}
			string innerhtml = ew_HtmlElement("a", attrs, text, true);
			if (SubMenu != null) {
				if (url != "#" && SubMenu.MenuLinkClassName != "" && submenuhtml != "") { // Add click link for mobile menu
					var attrs2 = new Dictionary<string, string>() {{"class", aclass}, {"href", url}};
					attrs2["class"] = "ewMenuLink";
					attrs2["href"] = url; 
					text2 = "<span class=\"" + SubMenu.MenuLinkClassName + "\"></span>";
					innerhtml = ew_HtmlElement("a", attrs2, text2) + innerhtml;
				}
				if (mobile && Url != "#")
					innerhtml += innerhtml;
				innerhtml += submenuhtml;
			}

			// Create <LI>
			attrs.Clear();
			attrs.Add("id", Name);
			attrs.Add("class", liclass);
			return ew_HtmlElement("li", attrs, innerhtml, true);
		}
	}	

	// Allow list
	public bool AllowList(string TableName)
	{
		if (Security != null) {
			return Security.AllowList(TableName);
		} else {
			return true;
		}
	}

	// Allow add
	public bool AllowAdd(string TableName)
	{
		if (Security != null) {
			return Security.AllowAdd(TableName);
		} else {
			return true;
		}
	}	

	//		
	// Validation functions
	//
	// Check date format
	// format: std/stdshort/us/usshort/euro/euroshort
	public static bool ew_CheckDateEx(string value, string format, string sep)
	{
		if (ew_Empty(value)) return true; 
		while (value.Contains("  "))
			value = value.Replace("  ", " ");
		value = value.Trim();
		string[] arDT;
		string[] arD;
		string pattern = "";
		string sYear = "";
		string sMonth = "";
		string sDay = "";
		arDT = value.Split(new char[] {' '});
		if (arDT.Length > 0) {
			Match m;
			if ((m = Regex.Match(arDT[0], @"^([0-9]{4})/([0][1-9]|[1][0-2])/([0][1-9]|[1|2][0-9]|[3][0|1])$")) != null && m.Success) { // Accept yyyy/mm/dd
				sYear = m.Groups[1].Value;
				sMonth = m.Groups[2].Value;
				sDay = m.Groups[3].Value;
			} else {
				string wrksep = "\\" + sep;
				switch (format) {
					case "std":
						pattern = "^([0-9]{4})" + wrksep + "([0]?[1-9]|[1][0-2])" + wrksep + "([0]?[1-9]|[1|2][0-9]|[3][0|1])$";
						break;
					case "us":
						pattern = "^([0]?[1-9]|[1][0-2])" + wrksep + "([0]?[1-9]|[1|2][0-9]|[3][0|1])" + wrksep + "([0-9]{4})$";
						break;
					case "euro":
						pattern = "^([0]?[1-9]|[1|2][0-9]|[3][0|1])" + wrksep + "([0]?[1-9]|[1][0-2])" + wrksep + "([0-9]{4})$";
						break;
				}
				if (!Regex.IsMatch(arDT[0], pattern)) return false; 
				arD = arDT[0].Split(new char[] {Convert.ToChar(sep)});
				switch (format) {
					case "std":
					case "stdshort":
						sYear = ew_UnformatYear(arD[0]);
						sMonth = arD[1];
						sDay = arD[2];
						break;
					case "us":
					case "usshort":
						sYear = ew_UnformatYear(arD[2]);
						sMonth = arD[0];
						sDay = arD[1];
						break;
					case "euro":
					case "euroshort":
						sYear = ew_UnformatYear(arD[2]);
						sMonth = arD[1];
						sDay = arD[0];
						break;
				}
			}
			if (!ew_CheckDay(ew_ConvertToInt(sYear), ew_ConvertToInt(sMonth), ew_ConvertToInt(sDay))) return false; 
		}
		if (arDT.Length > 1 && !ew_CheckTime(arDT[1])) return false; 
		return true;
	}

	// Unformat 2 digit year to 4 digit year
	public static string ew_UnformatYear(object year) {
		string yr = Convert.ToString(year);
		if (Information.IsNumeric(yr) && yr.Length == 2) {
			if (ew_ConvertToInt(yr) > EW_UNFORMAT_YEAR)
				return "19" + yr;
			else
				return "20" + yr;
		} else {
			return yr;
		}
	}

	// Check Date format (yyyy/mm/dd)
	public static bool ew_CheckDate(string value)
	{
		return ew_CheckDateEx(value, "std", EW_DATE_SEPARATOR);
	}

	// Check Date format (yy/mm/dd)
	public static bool ew_CheckShortDate(string value) {
		return ew_CheckDateEx(value, "stdshort", EW_DATE_SEPARATOR);
	}

	// Check US Date format (mm/dd/yyyy)
	public static bool ew_CheckUSDate(string value)
	{
		return ew_CheckDateEx(value, "us", EW_DATE_SEPARATOR);
	}

	// Check US Date format (mm/dd/yy)
	public static bool ew_CheckShortUSDate(string value) {
		return ew_CheckDateEx(value, "usshort", EW_DATE_SEPARATOR);
	}

	// Check Euro Date format (dd/mm/yyyy)
	public static bool ew_CheckEuroDate(string value)
	{
		return ew_CheckDateEx(value, "euro", EW_DATE_SEPARATOR);
	}

	// Check Euro Date format (dd/mm/yy)
	public static bool ew_CheckShortEuroDate(string value) {
		return ew_CheckDateEx(value, "euroshort", EW_DATE_SEPARATOR);
	}

	// Check day
	public static bool ew_CheckDay(int checkYear, int checkMonth, int checkDay)
	{
		int maxDay = 31;
		if (checkMonth == 4 || checkMonth == 6 || checkMonth == 9 || checkMonth == 11) {
			maxDay = 30;
		} else if (checkMonth == 2) {
			if (checkYear % 4 > 0) {
				maxDay = 28;
			} else if (checkYear % 100 == 0 && checkYear % 400 > 0) {
				maxDay = 28;
			} else {
				maxDay = 29;
			}
		}
		return (checkDay >= 1 && checkDay <= maxDay);
	}

	// Check integer
	public static bool ew_CheckInteger(string value)
	{
		if (ew_Empty(value)) return true; 
		if (value.Contains(EW_DECIMAL_POINT))
			return false;
		return ew_CheckNumber(value);
	}

	// Check number
	public static bool ew_CheckNumber(string value)
	{
		if (ew_Empty(value)) return true;
		string pat = @"^[+-]?(\d{1,3}(" + ((EW_THOUSANDS_SEP != "") ? @"\" + EW_THOUSANDS_SEP + "?" : "") + @"\d{3})*(\" +
			EW_DECIMAL_POINT + @"\d+)?|\" + EW_DECIMAL_POINT + @"\d+)$"; // Note: Do not use ew_NotEmpty(EW_THOUSANDS_SEP).
		return Regex.IsMatch(value, pat);
	}

	// Check range
	public static bool ew_CheckRange(string value, object min, object max)
	{
		if (ew_Empty(value)) return true;
		if (Information.IsNumeric(min) || Information.IsNumeric(max)) { // Number
			if (ew_CheckNumber(value)) {
				double val = Convert.ToDouble(ew_StrToFloat(value));
				if (min != null && val < Convert.ToDouble(min) || max != null && val > Convert.ToDouble(max))
					return false;
			}
		} else if (min != null && String.Compare(value, Convert.ToString(min)) < 0 || max != null && String.Compare(value, Convert.ToString(max)) > 0) // String
			return false;
		return true;
	}

	// Check time
	public static bool ew_CheckTime(string value)
	{
		if (ew_Empty(value)) return true;
		string[] Values = value.Split(new Char[] {'.', ' '}); 
		return Regex.IsMatch(Values[0], "^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?");
	}

	// Check US phone number
	public static bool ew_CheckPhone(string value)
	{
		if (ew_Empty(value)) return true; 
		return Regex.IsMatch(value, "^\\(\\d{3}\\) ?\\d{3}( |-)?\\d{4}|^\\d{3}( |-)?\\d{3}( |-)?\\d{4}");
	}

	// Check US zip code
	public static bool ew_CheckZip(string value)
	{
		if (ew_Empty(value)) return true; 
		return Regex.IsMatch(value, "^\\d{5}|^\\d{5}-\\d{4}");
	}

	// Check credit card
	public static bool ew_CheckCreditCard(string value)
	{
		if (ew_Empty(value)) return true; 
		var creditcard = new Dictionary<string, string>() {
			{"visa", "^4\\d{3}[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{4}"},
			{"mastercard", "^5[1-5]\\d{2}[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{4}"},
			{"discover", "^6011[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{4}"},
			{"amex", "^3[4,7]\\d{13}"},
			{"diners", "^3[0,6,8]\\d{12}"},
			{"bankcard", "^5610[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{4}"},
			{"jcb", "^[3088|3096|3112|3158|3337|3528]\\d{12}"},
			{"enroute", "^[2014|2149]\\d{11}"},
			{"switch", "^[4903|4911|4936|5641|6333|6759|6334|6767]\\d{12}"}
		};
		foreach (var kvp in creditcard) {
			if (Regex.IsMatch(value, kvp.Value))
				return ew_CheckSum(value);
		}
		return false;
	}

	// Check sum
	public static bool ew_CheckSum(string value)
	{
		int checksum;
		byte digit;
		value = value.Replace("-", "");
		value = value.Replace(" ", "");
		checksum = 0;
		for (int i = 2 - (value.Length % 2); i <= value.Length; i += 2) {
			checksum = checksum + Convert.ToByte(value[i - 1]);
		}
		for (int i = (value.Length % 2) + 1; i <= value.Length; i += 2) {
			digit = Convert.ToByte(Convert.ToByte(value[i - 1]) * 2);
			checksum = checksum + ((digit < 10) ? digit : (digit - 9));
		}
		return (checksum % 10 == 0);
	}

	// Check US social security number
	public static bool ew_CheckSSC(string value)
	{
		if (ew_Empty(value)) return true; 
		return Regex.IsMatch(value, "^(?!000)([0-6]\\d{2}|7([0-6]\\d|7[012]))([ -]?)(?!00)\\d\\d\\3(?!0000)\\d{4}");
	}

	// Check email
	public static bool ew_CheckEmail(string value)
	{
		if (ew_Empty(value)) return true; 
		return Regex.IsMatch(value.Trim(), @"^[\w.%+-]+@[\w.-]+\.[A-Z]{2,6}$", RegexOptions.IgnoreCase);
	}	

	// Check emails
	public static bool ew_CheckEmailList(string value, int cnt)
	{
		if (ew_Empty(value)) return true; 
		string emailList = value.Replace(",", ";");
		string[] arEmails = emailList.Split(new char[] {';'});
		if (arEmails.Length > cnt && cnt > 0)
			return false;
		foreach (string email in arEmails) {
			if (!ew_CheckEmail(email))
				return false;
		}
		return true;
	}

	// Check GUID
	public static bool ew_CheckGUID(string value)
	{
		if (ew_Empty(value)) return true; 
		return Regex.IsMatch(value, "^{{1}([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12}}{1}") || Regex.IsMatch(value, "^([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12}");
	}

	// Check file extension
	public static bool ew_CheckFileType(string value, string exts = EW_UPLOAD_ALLOWED_FILE_EXT)
	{
		if (ew_Empty(value) || ew_Empty(EW_UPLOAD_ALLOWED_FILE_EXT)) return true; 
		string extension = Path.GetExtension(value).Substring(1);
		string[] allowExt = exts.Split(new char[] {','});
		foreach (string ext in allowExt) {
			if (ew_SameText(ext, extension)) return true; 
		}
		return false;
	}

	// Check empty string
	public static bool ew_EmptyStr(object value) {
		string str = Convert.ToString(value).Replace("&nbsp;", "");
		return ew_Empty(str);
	}	

	// Check by regular expression
	public static bool ew_CheckByRegEx(string value, string pattern)
	{
		if (ew_Empty(value)) return true; 
		return Regex.IsMatch(value, pattern);
	}

	// Check by regular expression
	public static bool ew_CheckByRegEx(string value, string pattern, RegexOptions options)
	{
		if (ew_Empty(value)) return true; 
		return Regex.IsMatch(value, pattern, options);
	}

	// Get current date in standard format (yyyy/mm/dd)
	public static string ew_StdCurrentDate() {
		return DateTime.Today.ToString("yyyy'/'MM'/'dd");
	}

	// Get date in standard format (yyyy/mm/dd)
	public static string ew_StdDate(DateTime dt) {
		return dt.ToString("yyyy'/'MM'/'dd");
	}

	// Get current date and time in standard format (yyyy/mm/dd hh:mm:ss)
	public static string ew_StdCurrentDateTime() {
		return DateTime.Now.ToString("yyyy'/'MM'/'dd' 'HH':'mm':'ss");
	}

	// Get date/time in standard format (yyyy/mm/dd hh:mm:ss)
	public static string ew_StdDateTime(DateTime dt) {
		return dt.ToString("yyyy'/'MM'/'dd' 'HH':'mm':'ss");
	}

	// Encrypt password
	public static string ew_EncryptPassword(string input) {
		return MD5(input);
	}

	// Compare password	
	public static bool ew_ComparePassword(string pwd, string input) {
		if (EW_CASE_SENSITIVE_PASSWORD) {
			if (EW_ENCRYPTED_PASSWORD) {
				return (pwd == ew_EncryptPassword(input));
			} else {
				return ew_SameStr(pwd, input);
			}
		} else {
			if (EW_ENCRYPTED_PASSWORD) {
				return (pwd == ew_EncryptPassword(input.ToLower()));
			} else {
				return ew_SameText(pwd, input);
			}
		}
	}	

	// MD5
	public static string MD5(string InputStr)
	{
		var Md5Hasher = new MD5CryptoServiceProvider();
		byte[] Data = Md5Hasher.ComputeHash(Encoding.Unicode.GetBytes(InputStr));
		var sBuilder = new StringBuilder();
		for (int i = 0; i <= Data.Length - 1; i++) {
			sBuilder.Append(Data[i].ToString("x2"));
		}
		return sBuilder.ToString();
	}

	// CRC32
	public static uint CRC32(string InputStr) {
		byte[] bytes = Encoding.Unicode.GetBytes(InputStr);
		uint crc = 0xffffffff;
		uint poly	=	0xedb88320;
		uint[] table = new uint[256];
		uint temp = 0;
		for (uint i = 0; i < table.Length; ++i) {
			temp = i;
			for (int j = 8; j > 0; --j) {
				if ((temp & 1) == 1) {
					temp = (uint)((temp >> 1) ^ poly);
				} else {
					temp >>= 1;
				}
			}
			table[i] = temp;
		}
		for (int i = 0; i < bytes.Length; ++i) {
			byte index = (byte)(((crc) & 0xff) ^ bytes[i]);
			crc = (uint)((crc >> 8) ^ table[index]);
		}
		return ~crc;
	}

	// Check if object is IList
	public static bool ew_IsList(object obj)
	{
		return (obj != null) && (obj is IList);
	}

	// Check if object is IDictionary
	public static bool ew_IsDictionary(object obj)
	{
		return (obj != null) && (obj is IDictionary);
	}

	// check if a value is in a string array
	public static bool ew_Contains(object str, string[] ar)
	{
		return (new List<string>(ar)).Contains(Convert.ToString(str)); 
	}

	// check if a value is in an integer array
	public static bool ew_Contains(object i, int[] ar)
	{
		try {
			return (new List<int>(ar)).Contains(Convert.ToInt32(i));
		} catch {
			return false;
		} 
	}

	// Global random
	private static Random GlobalRandom = new Random();

	// Get a random number
	public static int ew_Random()
	{	
		lock (GlobalRandom) {
			Random NewRandom = new Random(GlobalRandom.Next());
			return NewRandom.Next();
		}
	}

	// Get query string value
	public static string ew_Get(string name)
	{
		return (ew_QueryString[name] != null) ? ew_QueryString[name] : "";
	}

	// Get form value
	public static string ew_Post(string name)
	{
		return (ew_Form[name] != null) ? ew_Form[name] : "";
	}

	// Get/set project cookie
	public static cCookie ew_Cookie = new cCookie();

	public class cCookie
	{

		public string this[string name] {
			get {
				if (ew_Request.Cookies[EW_PROJECT_NAME] != null) {
					return ew_Request.Cookies[EW_PROJECT_NAME][name];
				} else {
					return "";
				}
			}
			set {
				HttpCookie c;
				if (ew_Request.Cookies[EW_PROJECT_NAME] != null) {
					c = ew_Request.Cookies[EW_PROJECT_NAME];
				} else {
					c = new HttpCookie(EW_PROJECT_NAME);
				}
				c.Values[name] = value;
				c.Path = ew_AppPath();
				c.Expires = EW_COOKIE_EXPIRY_TIME;
				ew_Response.Cookies.Add(c);				
			}
		}
	}

	// Write literal
	public static void ew_Write(object value) {
		ew_Page.WriteLiteral(value);
	}

	// Response.WriteBinary
	public static void ew_BinaryWrite(byte[] value) {
		ew_Response.WriteBinary(value);
	}

	// Shortcut to ObjectInfo helper, usage: @ew_Print(variable)
	public HelperResult ew_Print(object value) {
		return ObjectInfo.Print(value, EW_OBJECTINFO_DEPTH, EW_OBJECTINFO_ENUMERATION_LENGTH);
	}

	// Export object info as HTML string
	public static string ew_VarExport(params object[] list) {
		string str = "";
		foreach (object value in list)
        	str += ObjectInfo.Print(value, EW_OBJECTINFO_DEPTH, EW_OBJECTINFO_ENUMERATION_LENGTH).ToHtmlString();
		return str;
    }

	// Write object info in razor page
	public static void ew_VarPrint(params object[] list) {
		foreach (object value in list)
        	ew_Write(ew_VarExport(value));
    }

	// Response.Write object info
	public static void ew_VarDump(params object[] list) {
		foreach (object value in list)
        	ew_Response.Write(ew_VarExport(value));
    }

	// Exit page // ASPX
	public static void ew_End(object value = null) {
		if (value is string) { // String => Message
			ew_Response.Write(value);
		} else if (value != null) { // Object
			ew_VarDump(value);
		}	
		ew_Response.End();
	}

	// Exit page // ASPX
	public static void ew_End(params object[] list) {
		ew_VarDump(list);
		ew_Response.End();
	}

	// Write HTTP header
	public static void ew_Header(bool cache, string charset = EW_CHARSET) {
		string export = ew_Get("export");
		ew_AddHeader("X-UA-Compatible", "IE=edge");
		if (cache || !cache && ew_IsHttps() && ew_NotEmpty(export) && export != "print") { // Allow cache
			ew_AddHeader("Cache-Control", "private, must-revalidate");
			ew_AddHeader("Pragma", "public");
		} else { // No cache

			//ew_Response.Cache.SetCacheability(HttpCacheability.NoCache);
			ew_AddHeader("Cache-Control", "private, no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
			ew_AddHeader("Pragma", "no-cache");
		}
		if (ew_NotEmpty(charset)) // Charset
			ew_Response.Charset = charset;
	}

	// Get content file extension
	public static string ew_ContentExt(IEnumerable<byte> data) {
		var ct = ew_ContentType(data.Take(11));
		switch (ct) {
			case "image/gif": return ".gif"; // Return gif
			case "image/jpeg": return ".jpg"; // Return jpg
			case "image/png": return ".png"; // Return png
			case "image/bmp": return ".bmp"; // Return bmp
			case "application/pdf": return ".pdf"; // Return pdf
			default: return ""; // Unknown extension
		}
	}

	// Add HTTP header
	public static void ew_AddHeader(string name, string value) {
		if (ew_NotEmpty(name)) // value can be empty
			ew_Response.AddHeader(name, value);
	}

	// check if allow add/delete row
	public static bool ew_AllowAddDeleteRow() {
		return true;
	}

	// Check if mobile device
	public static bool ew_IsMobile() {	

	    // Based on http://detectmobilebrowsers.com/ (Regex updated: 1 August 2014)
		string u = ew_Request.ServerVariables["HTTP_USER_AGENT"];
	    Regex b = new Regex(@"(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino", RegexOptions.IgnoreCase | RegexOptions.Multiline);
	    Regex v = new Regex(@"1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-", RegexOptions.IgnoreCase | RegexOptions.Multiline);
		return (b.IsMatch(u) || v.IsMatch(u.Substring(0, 4)));
	}

	// Convert List<OrderedDictionary> to JSON array of array
    public static string ew_ArrayToJson(List<OrderedDictionary> list, int offset = 0)
    {
        return JsonConvert.SerializeObject(list.Skip(offset).Select(od => od.Values));
    }

	// Convert object (e.g. IList<T> or IDictionary<TKey, TValue>) to JSON
    public static string ew_ArrayToJson(object obj)
    {
        return JsonConvert.SerializeObject(obj);
    }

	// Create instance by class name
	public static dynamic ew_CreateInstance(string name, object[] args = null, Type[] types = null) {
		Type t = Type.GetType(EW_PROJECT_CLASSNAME + "+" + name); // This class
		if (t == null)
			t = Type.GetType(EW_PROJECT_CLASSNAME + "_base+" + name); // Base class
		if (t == null)
			t = Type.GetType(EW_PROJECT_CLASSNAME + "_base+" + name + ",Admin_new"); // Assembly
		if (types != null)
			t = t.MakeGenericType(types);	
		return Activator.CreateInstance(t, args);
	}

	//
	// Export document classes
	//
	// Get export document object
	public static dynamic ew_ExportDocument(cTable tbl, string style) {
		return ew_CreateInstance(EW_EXPORT[gsExport.ToLower()], new object[] {tbl, style});
	}

	//
	// Base class for export
	//
	public class cExportBase {

		public dynamic Table;		

		public string Line = "";

		public string Header = "";

		public string Style = "h"; // "v"(Vertical) or "h"(Horizontal)

		public bool Horizontal = true; // Horizontal

		public int RowCnt = 0;

		public int FldCnt = 0;

		public bool ExportCustom = false;

		public StringBuilder Text = new StringBuilder();

		// Constructor
		public cExportBase(cTable tbl = null, string style = "") {
			Table = tbl;
			SetStyle(style);
		}

		// Style
		public virtual void SetStyle(string style) {
			if (ew_SameStr(style, "v") || ew_SameStr(style, "h"))
				Style = style.ToLower();		
			Horizontal = !ew_SameStr(Style, "v");
		}

		// Field caption
		public virtual void ExportCaption(ref cField fld) {
			FldCnt++;
			ExportValueEx(ref fld, fld.ExportCaption);
		}

		// Field value
		public virtual void ExportValue(ref cField fld) {
			ExportValueEx(ref fld, fld.ExportValue);
		}

		// Field aggregate
		public virtual void ExportAggregate(ref cField fld, string type) {
			FldCnt++;
			if (Horizontal) {
				var val = "";
				if ((new List<string>() {"TOTAL", "COUNT", "AVERAGE"}).Contains(type))
					val = Language.Phrase(type) + ": " + fld.ExportValue;
				ExportValueEx(ref fld, val);
			}
		}

		// Get meta tag for charset
		public virtual string CharsetMetaTag() {
			return "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=" + EW_CHARSET + "\">\r\n";
		}

		// Table header
		public virtual void ExportTableHeader() {
			Text.Append("<table class=\"ewExportTable\">");
		}

		// Export a value (caption, field value, or aggregate)
		public virtual void ExportValueEx(ref cField fld, object val, bool usestyle = true) {
			Text.Append("<td" + ((usestyle && EW_EXPORT_CSS_STYLES) ? fld.CellStyles : "") + ">");
			Text.Append(Convert.ToString(val));
			Text.Append("</td>");
		}

		// Begin a row
		public virtual void BeginExportRow(int rowcnt = 0, bool usestyle = true) {
			RowCnt++;
			FldCnt = 0;
			if (Horizontal) {
				if (rowcnt == -1) {
					Table.CssClass = "ewExportTableFooter";
				} else if (rowcnt == 0) {
					Table.CssClass = "ewExportTableHeader";
				} else {
					Table.CssClass = ((rowcnt % 2) == 1) ? "ewExportTableRow" : "ewExportTableAltRow";
				}
				Text.Append("<tr" + ((usestyle && EW_EXPORT_CSS_STYLES) ? Table.RowStyles : "") + ">");
			}
		}

		// End a row
		public virtual void EndExportRow() {
			if (Horizontal)
				Text.Append("</tr>");
		}

		// Empty row
		public virtual void ExportEmptyRow() {
			RowCnt++;
			Text.Append("<br>");
		}

		// Page break
		public virtual void ExportPageBreak() {
		}

		// Export a field
		public virtual void ExportField(ref cField fld) {
			FldCnt++;
			var wrkExportValue = "";
			if (ew_NotEmpty(fld.HrefValue2) && fld.Upload != null) { // Upload field
				if (ew_NotEmpty(fld.Upload.DbValue))
					wrkExportValue = ew_GetFileATag(fld, Convert.ToString(fld.HrefValue2));
			} else {			
				wrkExportValue = fld.ExportValue;
			}
			if (Horizontal) {
				ExportValueEx(ref fld, wrkExportValue);
			} else { // Vertical, export as a row
				RowCnt++;
				Text.Append("<tr class=\"" + ((FldCnt % 2 == 1) ? "ewExportTableRow" : "ewExportTableAltRow") + "\">" +
					"<td>" + fld.ExportCaption + "</td>");
				Text.Append("<td" + ((EW_EXPORT_CSS_STYLES) ? fld.CellStyles : "") + ">" + fld.ExportValue + "</td></tr>");
			}
		}

		// Table Footer
		public virtual void ExportTableFooter() {
			Text.Append("</table>");
		}

		// Add HTML tags
		public virtual void ExportHeaderAndFooter() {
			string header = "<html><head>\r\n";
			header += CharsetMetaTag();
			if (EW_EXPORT_CSS_STYLES && ew_NotEmpty(EW_PROJECT_STYLESHEET_FILENAME))
				header += "<style type=\"text/css\">" + ew_LoadTxt(EW_PROJECT_STYLESHEET_FILENAME) + "</style>\r\n";
			header += "</" + "head>\r\n<body>\r\n";
			Text.Insert(0, header);
			Text.Append("</body></html>");
		}

		// Export
		public virtual void Export() {
			if (!EW_DEBUG_ENABLED)
				ew_Response.Clear();
			if (ew_SameText(EW_CHARSET, "utf-8"))
				ew_BinaryWrite(new byte[] {0xEF, 0xBB, 0xBF});
			ew_Response.Write(Text.ToString());
		}
	}

	// Get file IMG tag
	public static string ew_GetFileImgTag(cField fld, string fn) {
		var html = "";
		if (ew_NotEmpty(fn)) {
			if (fld.UploadMultiple) {
				var wrkfiles = fn.Split(new char[] {Convert.ToChar(EW_MULTIPLE_UPLOAD_SEPARATOR)});
				foreach (var wrkfile in wrkfiles) {
					if (ew_NotEmpty(wrkfile)) {
						if (ew_NotEmpty(html))
							html += "<br>";
						html += "<img class=\"ewImage\" src=\"" + wrkfile + "\" alt=\"\">";
					}
				}
			} else {
				html = "<img class=\"ewImage\" src=\"" + fn + "\" alt=\"\">";
			}
		}
		return html;
	}

	// Get file anchor tag
	public static string ew_GetFileATag(cField fld, string fn) {
		string[] wrkfiles = new string[] {};
		var wrkpath = "";
		var html = "";
		if (fld.FldDataType == EW_DATATYPE_BLOB) {
			if (ew_NotEmpty(fld.Upload.DbValue))
				wrkfiles = new string[] {fn};
		} else if (fld.UploadMultiple) {
			wrkfiles = fn.Split(new char[] {Convert.ToChar(EW_MULTIPLE_UPLOAD_SEPARATOR)});
			var pos = wrkfiles[0].LastIndexOf("/");
			if (pos > -1) {
				wrkpath = wrkfiles[0].Substring(0, pos + 1); // Get path from first file name
				wrkfiles[0] = wrkfiles[0].Substring(pos + 1);
			}
		} else {
			if (ew_NotEmpty(fld.Upload.DbValue))
				wrkfiles = new string[] {fn};
		}
		foreach (var wrkfile in wrkfiles) {
			if (ew_NotEmpty(wrkfile)) {
				if (ew_NotEmpty(html))
					html += "<br>";
				var attrs = new Dictionary<string, string>() {{"href", ew_ConvertFullUrl(wrkpath + wrkfile)}};
				html += ew_HtmlElement("a", attrs, fld.FldCaption);
			}
		}
		return html;
	}

	// URL-encode file name
	public static string ew_UrlEncodeFilename(string fn) {
		string path, filename;
		if (fn.Contains("?")) {
			var arf = fn.Split(new char[] {'?'});
			fn = arf[1];
			var ar = fn.Split(new char[] {'&'});
			for (var i = 0; i < ar.Length; i++) { 
 				var p = ar[i];
				if (p.StartsWith("fn=")) {
					ar[i] = "fn=" + ew_UrlEncode(p.Substring(3));
					break;
				}
			}
			return arf[0] + "?" + String.Join("&", ar);
		}
		if (fn.Contains("/")) {
			path = Path.GetDirectoryName(fn).Replace("\\", "/");
			filename = Path.GetFileName(fn); 
		} else {
			path = "";
			filename = fn;
		}
		if (path != "")
			path = ew_IncludeTrailingDelimiter(path, false);
		return path + ew_UrlEncode(filename).Replace("+", " "); // Do not encode spaces
	}

	// Get file View Tag
	public static string ew_GetFileViewTag(cField fld, string fn) {
		if (!ew_EmptyStr(fn)) {
			string url;
			if (fld.IsBlobImage || ew_IsImageFile(fn)) {
				if (fld.FldDataType == EW_DATATYPE_BLOB) {
					url = fn;
				} else {
					url = ew_UrlEncodeFilename(fn);
					fld.HrefValue = ew_UrlEncodeFilename(Convert.ToString(fld.HrefValue));
				}
				if (ew_Empty(fld.HrefValue) && !fld.UseColorbox) {
					return "<img class=\"ewImage\" data-name=\"" + ew_HtmlEncode(fld.FldCaption) + "\" src=\"" + url + "\" alt=\"\"" + fld.ViewAttributes + ">";
				} else {
					return "<a" + fld.LinkAttributes + "><img class=\"ewImage\" data-name=\"" + ew_HtmlEncode(fld.FldCaption) + "\"  src=\"" + url + "\" alt=\"\"" + fld.ViewAttributes + "></a>";
				}
			} else {
				var name = "";
				if (fld.FldDataType == EW_DATATYPE_BLOB) {
					url = fn;
					name = (ew_NotEmpty(fld.Upload.FileName)) ? fld.Upload.FileName : fld.FldCaption;
				} else {
					url = ew_ImageNameFromUrl(fn);
					name = Path.GetFileName(url);
					url = ew_UrlEncodeFilename(url);
				}
				return "<div><a href=\"" + url + "\">" + name + "</a></div>";
			}
		} else {
			return "";
		}
	}

	// Check if image file
	public static bool ew_IsImageFile(string fn) {
		if (ew_NotEmpty(fn)) {
			fn = ew_ImageNameFromUrl(fn);
			var ext = Path.GetExtension(fn).Replace(".", "");
			return (new List<string>(EW_IMAGE_ALLOWED_FILE_EXT.Split(new char[] {','}))).Contains(ext, StringComparer.InvariantCultureIgnoreCase);
		} else {
			return false;
		}
	}

	// Get image file name from URL
	public static string ew_ImageNameFromUrl(string fn) {
		if (ew_NotEmpty(fn)) {
			if (fn.Contains("?")) { // Thumbnail URL
				fn = fn.Split(new char[] {'?'})[1];
				var ar = fn.Split(new char[] {'&'});
				foreach (var p in ar) { 
	 				if (p.StartsWith("fn="))
						return ew_UrlDecode(p.Substring(3));
				}
			}			
		}
		return fn;
	}

	//
	// Class for export to email
	// 
	public class cExportEmail: cExportBase {

		// Constructor
		public cExportEmail(cTable tbl = null, string style = ""): base(tbl, style) {}

		// Export a field
		public void ExportField(ref cField fld) {
			FldCnt++;
			string ExportValue = fld.ExportValue;
			if (fld.FldViewTag == "IMAGE") {			
				if (fld.ImageResize) {
					ExportValue = ew_GetFileImgTag(fld, fld.GetTempImage());
				} else if (ew_NotEmpty(fld.HrefValue2) && fld.Upload != null) {
					if (ew_NotEmpty(fld.Upload.DbValue))
						ExportValue = ew_GetFileATag(fld, Convert.ToString(fld.HrefValue2));
				}
			} else if (ew_IsDictionary(fld.HrefValue2)) { // Export Custom View Tag
				var ar = (Dictionary<string, object>)fld.HrefValue2;
				string fn = (ar != null && ar.ContainsKey("exportfn")) ? Convert.ToString(ar["exportfn"]) : ""; // Get export function name
				ExportValue = Convert.ToString(ew_Invoke(ew_WebPage, fn, new object[] { ar, "email" })); // ASPX
			}
			if (Horizontal) {
				ExportValueEx(ref fld, ExportValue);
			} else { // Vertical, export as a row
				RowCnt++;
				Text.Append("<tr class=\"" + ((FldCnt % 2 == 1) ? "ewExportTableRow" : "ewExportTableAltRow") + "\">" +
					"<td>" + fld.ExportCaption + "</td>");
				Text.Append("<td" + ((EW_EXPORT_CSS_STYLES) ? fld.CellStyles : "") + ">" + ExportValue + "</td></tr>");
			}
		}

		// Export
		public override void Export() {
			if (!EW_DEBUG_ENABLED)
				ew_Response.Clear();
			ew_Response.Write(Text.ToString());
		}
	}

	//
	// Class for export to HTML
	// 
	public class cExportHtml: cExportBase {		

		// Constructor
		public cExportHtml(cTable tbl = null, string style = ""): base(tbl, style) {}

		// Same as base class
	}

	//
	// Class for export to Word
	// 
	public class cExportWord: cExportBase {

		// Constructor
		public cExportWord(cTable tbl = null, string style = ""): base(tbl, style) {}

		// Export
		public override void Export() {
			if (!EW_DEBUG_ENABLED)
				ew_Response.Clear();
			ew_Response.ContentType = "application/vnd.ms-word" + ((ew_NotEmpty(EW_CHARSET)) ? ";charset=" + EW_CHARSET : "");
			ew_AddHeader("Content-Disposition", "attachment; filename=" + gsExportFile + ".doc");
			if (ew_SameText(EW_CHARSET, "utf-8"))
				ew_BinaryWrite(new byte[] {0xEF, 0xBB, 0xBF});
			ew_Response.Write(Text.ToString());
		}
	}

	//
	// Class for export to Excel
	// 
	public class cExportExcel: cExportBase {

		// Constructor
		public cExportExcel(cTable tbl = null, string style = ""): base(tbl, style) {}

		// Export a value (caption, field value, or aggregate)
		public override void ExportValueEx(ref cField fld, object val, bool usestyle = true) {
			if (fld.FldDataType == EW_DATATYPE_STRING && Information.IsNumeric(val))
				val = "=\"" + Convert.ToString(val) + "\"";
			base.ExportValueEx(ref fld, val, usestyle);
		}

		// Export
		public override void Export() {
			if (!EW_DEBUG_ENABLED)
				ew_Response.Clear();
			ew_Response.ContentType = "application/vnd.ms-excel" + ((ew_NotEmpty(EW_CHARSET)) ? ";charset=" + EW_CHARSET : "");
			ew_AddHeader("Content-Disposition", "attachment; filename=" + gsExportFile + ".xls");
			if (ew_SameStr(EW_CHARSET, "utf-8"))
				ew_BinaryWrite(new byte[] {0xEF, 0xBB, 0xBF});
			ew_Response.Write(Text.ToString());
		}
	}

	//
	// Class for export to CSV
	// 
	public class cExportCsv: cExportBase {

		public string QuoteChar = "\"";

		// Constructor
		public cExportCsv(cTable tbl = null, string style = ""): base(tbl, style) {}		

		// Style
		public void ChangeStyle(string style) {
			Horizontal = true;
		}

		// Table header
		public override void ExportTableHeader() {

			// Skip
		}

		// Export a value (caption, field value, or aggregate)
		public override void ExportValueEx(ref cField fld, object val, bool usestyle = true) {
			if (fld.FldDataType != EW_DATATYPE_BLOB) {
				if (ew_NotEmpty(Line))
					Line += ",";
				Line += QuoteChar + Convert.ToString(val).Replace(QuoteChar, QuoteChar + QuoteChar) + QuoteChar;
			}
		}

		// Begin a row
		public override void BeginExportRow(int rowcnt = 0, bool usestyle = true) {
			Line = "";
		}

		// End a row
		public override void EndExportRow() {
			Text.AppendLine(Line);
		}

		// Empty line
		public void ExportEmptyLine() {

			// Skip
		}

		// Export a field
		public override void ExportField(ref cField fld) {
			if (fld.UploadMultiple)
				ExportValueEx(ref fld, fld.Upload.DbValue);
			else
				ExportValue(ref fld);
		}

		// Table Footer
		public override void ExportTableFooter() {

			// Skip
		}

		// Add HTML tags
		public override void ExportHeaderAndFooter() {

			// Skip
		}

		// Export
		public override void Export() {
			if (!EW_DEBUG_ENABLED)
				ew_Response.Clear();
			ew_Response.ContentType = "text/csv";
			ew_AddHeader("Content-Disposition", "attachment; filename=" + gsExportFile + ".csv");
			if (ew_SameText(EW_CHARSET, "utf-8"))
				ew_BinaryWrite(new byte[] {0xEF, 0xBB, 0xBF});
			ew_Response.Write(Text.ToString());
		}
	}

	//
	// Class for export to XML
	//
	public class cExportXml: cExportBase {

		public cXMLDocument XmlDoc = new cXMLDocument();

		public bool HasParent;

		// Constructor
		public cExportXml(cTable tbl = null, string style = ""): base(tbl, style) {}

		// Style
		public override void SetStyle(string style) {}

		// Field caption
		public override void ExportCaption(ref cField fld) {}

		// Field value
		public override void ExportValue(ref cField fld) {}

		// Field aggregate
		public override void ExportAggregate(ref cField fld, string type) {}

		// Get meta tag for charset
		public override string CharsetMetaTag() {
			return "";
		}

		// Table header
		public override void ExportTableHeader() {
			HasParent = XmlDoc.DocumentElement != null;
			if (!HasParent)
				XmlDoc.AddRoot(Table.TableVar);
		}

		// Export a value (caption, field value, or aggregate)
		public override void ExportValueEx(ref cField fld, object val, bool usestyle = true) {}

		// Begin a row
		public override void BeginExportRow(int rowcnt = 0, bool usestyle = true) {
			if (rowcnt <= 0)
				return; 
			if (HasParent)
				XmlDoc.AddRow(Table.TableVar);
			else
				XmlDoc.AddRow();
		}

		// End a row
		public override void EndExportRow() {}

		// Empty row
		public override void ExportEmptyRow() {}

		// Page break
		public override void ExportPageBreak() {}

		// Export a field
		public override void ExportField(ref cField fld) {
			if (fld.FldDataType != EW_DATATYPE_BLOB) {
				object ExportValue;
				if (fld.UploadMultiple)
					ExportValue = fld.Upload.DbValue;
				else
					ExportValue = fld.ExportValue;
				if (Convert.IsDBNull(ExportValue))
					ExportValue = "<Null>";
				XmlDoc.AddField(fld.FldVar.Substring(2), ExportValue);
			}
		}

		// Table Footer
		public override void ExportTableFooter() {}

		// Add HTML tags
		public override void ExportHeaderAndFooter() {}

		// Export
		public override void Export() {
			if (!EW_DEBUG_ENABLED)
				ew_Response.Clear();
			ew_Response.ContentType = "text/xml";			
			ew_Response.Write(XmlDoc.XML());
		}
	}

	//
	// Class for export to PDF
	//
	public class cExportPdf: cExportBase {

		// Constructor
		public cExportPdf(cTable tbl, string style): base(tbl, style) {}

		// Export
		public override void Export() {
			ew_Write(Text);
		}
	}

	// Database helper class
	public class cFrescode_db<C> : IDisposable
		where C : cConnectionBase, new()
	{

		// Language
		public cLanguage Lang; // ASPX

		// Connection
		public cConnectionBase Connection;

		// Constructor
		public cFrescode_db(string ConnStr = "", string LangFolder = "", string LangId = "") {

			// Open connection
			if (Connection == null)
				Connect(ConnStr);

			// Set up language object
			if (ew_NotEmpty(LangFolder))
				this.Lang = new cLanguage(LangFolder, LangId);
			else if (Language != null)
				this.Lang = Language;
		}

		// Connect to database
		public void Connect(string ConnStr = "") {
			if (ConnStr == "") {
				Connection = new C();
			} else {
				Connection = (cConnectionBase)Activator.CreateInstance(typeof(C), new object[] { ConnStr });
			}
		}

		// Execute the query, and return the row(s) as JSON
		public string ExecuteJson(string Sql, bool FirstOnly = true) {
			if (FirstOnly) {
				var row = Connection.GetRow(Sql); 
				return (row != null) ? ew_ArrayToJson(row) : "false";
			} else {
				var ar = Connection.GetRows(Sql); 
				return (ar != null) ? ew_ArrayToJson(ar) : "false";
			}
		}

		// Execute UPDATE, INSERT, or DELETE statements
		public int Execute(string Sql) {
			return Connection.ExecuteNonQuery(Sql);
		}

		// Execute the query, and return the first column of the first row
		public object ExecuteScalar(string Sql) {
			return Connection.ExecuteScalar(Sql);
		}

		// Execute the query, and return the first row as OrderedDictionary
		public OrderedDictionary ExecuteRow(string Sql) {
			return Connection.GetRow(Sql);
		}

		// Execute the query, and return the rows as List<OrderedDictionary> // ASPX
		public List<OrderedDictionary> ExecuteRows(string Sql) {
			return Connection.GetRows(Sql);
		}

		// Execute the query, and return the datareader
		public ewDataReader ExecuteDataReader(string Sql) { // ASPX
			return Connection.OpenDataReader(Sql);
		}

		// Table CSS class name
		public string TableClass = "table table-bordered table-striped ewDbTable";

		// Get result in HTML table
		// options(Dictionary<string, object>): 
		// - fieldcaption(bool|Dictionary<string, string>)
		// - horizontal(bool)
		// - tablename(string|List<string>)
		// - tableclass(string)
		public string ExecuteHtml(string Sql, Dictionary<string, object> options = null) {
			if (options == null)
				options = new Dictionary<string, object>();
			var horizontal = options.ContainsKey("horizontal") && Convert.ToBoolean(options["horizontal"]);
			var rs = ExecuteDataReader(Sql);
			if (rs == null || !rs.HasRows || rs.FieldCount < 1)
				return "";
			string html = "", vhtml = "";
			string classname = (options.ContainsKey("tableclass") && ew_NotEmpty(options["tableclass"])) ? Convert.ToString(options["tableclass"]) : TableClass;
			int cnt = 0;
			if (rs.Read()) { // First row
				cnt++;

				// Vertical table
				vhtml = "<table class=\"" + classname + "\"><tbody>";
				for (var i = 0; i < rs.FieldCount; i++) {
					vhtml += "<tr>";
					vhtml += "<td>" + GetFieldCaption(rs.GetName(i), options) + "</td>";
					vhtml += "<td>" + Convert.ToString(rs[i]) + "</td></tr>";
				}
				vhtml += "</tbody></table>";

				// Horizontal table
				html = "<table class=\"" + classname + "\">";
				html += "<thead><tr>";
				for (var i = 0; i < rs.FieldCount; i++)
					html += "<th>" + GetFieldCaption(rs.GetName(i), options) + "</th>";
				html += "</tr></thead>";
				html += "<tbody>";
				html += "<tr>";
				for (var i = 0; i < rs.FieldCount; i++)
					html += "<td>" + Convert.ToString(rs[i]) + "</td>";
				html += "</tr>";						
			}				
			while (rs.Read()) { // Other rows
				cnt++;
				html += "<tr>";					
				for (var i = 0; i < rs.FieldCount; i++)
					html += "<td>" + Convert.ToString(rs[i]) + "</td>";
				html += "</tr>";
			}
			if (html != "")
				html += "</tbody></table>";
			return (cnt > 1 || horizontal) ? html : vhtml;
		}

		public string GetFieldCaption(string key, Dictionary<string, object> options) {
			if (options == null)
				return key;
			object tablename = options.ContainsKey("tablename") ? options["tablename"] : null;
			string caption = "";
			bool usecaption = options.ContainsKey("fieldcaption") && options["fieldcaption"] != null;
			if (usecaption) {
				if (ew_IsList(options["fieldcaption"])) {
					caption = ((Dictionary<string, string>)options["fieldcaption"])[key];
				} else if (ew_NotEmpty(Lang)) {
					if (ew_IsList(tablename)) {
						foreach (var tbl in (List<string>)tablename) {
							caption = Lang.FieldPhrase(tbl, key, "FldCaption");
							if (ew_NotEmpty(caption))
								break;
						}
					} else if (ew_NotEmpty(tablename)) {
						caption = Lang.FieldPhrase(Convert.ToString(tablename), key, "FldCaption");
					}
				}
			}
			return (ew_NotEmpty(caption)) ? caption : key;
		}

		// Dispose // ASPX
		public void Dispose() {
			Connection.Dispose();
		}
	}
}
