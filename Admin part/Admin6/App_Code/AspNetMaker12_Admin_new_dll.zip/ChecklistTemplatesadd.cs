using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET WebPage class
//
public partial class AspNetMaker12_Admin_new_base : WebPage {

	// ChecklistTemplates_add
	public static dynamic ChecklistTemplates_add {
		get { return (dynamic)ew_PageData["ChecklistTemplates_add"]; }
		set { ew_PageData["ChecklistTemplates_add"] = value; }
	}

	//
	// Page class
	//
	public class cChecklistTemplates_add_base<C, S> : cChecklistTemplates
		where C : cConnectionBase, new()
		where S : cAdvancedSecurityBase, new()
	{

		// Page ID
		public string PageID = "add";

		// Project ID
		public string ProjectID = "{6EA87CB0-ED50-4AE1-9743-D14163EABB5A}";

		// Table name
		public string TableName = "ChecklistTemplates";

		// Page object name
		public string PageObjName = "ChecklistTemplates_add";

		// Page name
		public string PageName {
			get { return ew_CurrentPage(); }
		}

		// Page URL
		public string PageUrl {
			get {
				string PageUrl = ew_CurrentPage() + "?";
				if (UseTokenInUrl) PageUrl += "t=" + TableVar + "&"; // Add page token
				return PageUrl;
			}
		}

		// Message
		public string Message {
			get { return Convert.ToString(ew_Session[EW_SESSION_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_MESSAGE] = msg;
			}
		}

		// Failure Message
		public string FailureMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_FAILURE_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_FAILURE_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_FAILURE_MESSAGE] = msg;
			}
		}

		// Success Message
		public string SuccessMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_SUCCESS_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_SUCCESS_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_SUCCESS_MESSAGE] = msg;
			}
		}

		// Warning Message
		public string WarningMessage {
			get { return Convert.ToString(ew_Session[EW_SESSION_WARNING_MESSAGE]); }
			set {
				string msg = Convert.ToString(ew_Session[EW_SESSION_WARNING_MESSAGE]); 
				ew_AddMessage(ref msg, value);
				ew_Session[EW_SESSION_WARNING_MESSAGE] = msg;
			}
		}

		// Show message
		public void ShowMessage() {
			bool hidden = false;
			string html = "";

			// Message
			string sMessage = Message;
			Message_Showing(ref sMessage, "");
			if (sMessage != "") { // Message in Session, display
				if (!hidden)
					sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sMessage;
				html += "<div class=\"alert alert-info ewInfo\">" + sMessage + "</div>";
				ew_Session[EW_SESSION_MESSAGE] = ""; // Clear message in Session
			}

			// Warning message
			var sWarningMessage = WarningMessage;
			Message_Showing(ref sWarningMessage, "warning");
			if (sWarningMessage != "") { // Message in Session, display
				if (!hidden)
					sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sWarningMessage;
				html += "<div class=\"alert alert-warning ewWarning\">" + sWarningMessage + "</div>";
				ew_Session[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
			}

			// Success message
			var sSuccessMessage = SuccessMessage;
			Message_Showing(ref sSuccessMessage, "success");
			if (sSuccessMessage != "") { // Message in Session, display
				if (!hidden)
					sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sSuccessMessage;
				html += "<div class=\"alert alert-success ewSuccess\">" + sSuccessMessage + "</div>";
				ew_Session[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
			}

			// Failure message
			var sErrorMessage = FailureMessage;
			Message_Showing(ref sErrorMessage, "failure");
			if (sErrorMessage != "") { // Message in Session, display
				if (!hidden)
					sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + sErrorMessage;
				html += "<div class=\"alert alert-danger ewError\">" + sErrorMessage + "</div>";
				ew_Session[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
			}
			ew_Write("<div class=\"ewMessageDialog\"" + ((hidden) ? " style=\"display: none;\"" : "") + ">" + html + "</div>");
		}								

		public string PageHeader = "";

		public string PageFooter = "";

		// Show Page Header
		public void ShowPageHeader() {
			string sHeader = PageHeader;
			Page_DataRendering(ref sHeader);
			if (ew_NotEmpty(sHeader)) // Header exists, display
				ew_Write("<p>" + sHeader + "</p>");
		}

		// Show Page Footer
		public void ShowPageFooter() {
			string sFooter = PageFooter;
			Page_DataRendered(ref sFooter);
			if (ew_NotEmpty(sFooter)) // Fotoer exists, display
				ew_Write("<p>" + sFooter + "</p>");
		}

		// Validate page request
		public bool IsPageRequest {
			get {
				if (UseTokenInUrl) {			
					if (ObjForm != null)
						return (TableVar == ObjForm.GetValue("t"));
					if (ew_NotEmpty(ew_Get("t")))
						return (TableVar == ew_Get("t"));
					return false;		
				} else {
					return true;
				}
			}
		}

		// Token
		public string Token = "";

		public bool CheckToken = EW_CHECK_TOKEN;

		// Valid Post
		public bool ValidPost() {
			if (!CheckToken || !IsPost)
				return true;
			if (ew_Post(EW_TOKEN_NAME) == null)
				return false;
			return Convert.ToBoolean(ew_CheckToken(ew_Post(EW_TOKEN_NAME)));
		}

		// Create Token
		public void CreateToken() {
			if (CheckToken) {
				if (ew_Empty(Token) && CheckToken) // Create token
					Token = ew_CreateToken();
				gsToken = Token; // Save to global variable
			}
		}

		//
		// Page class constructor
		//
		public cChecklistTemplates_add_base() {
			CurrentPage = this;

			// Language object
			if (Language == null)
				Language = new cLanguage();

			// Table object (ChecklistTemplates)
			if (ChecklistTemplates == null || ChecklistTemplates is cChecklistTemplates) {
				ChecklistTemplates = this;

				//CurrentTable = this;
			}

			// Start time
			StartTime = Environment.TickCount;

			// Open connection
			if (Conn == null)
				Conn = new C();
		}

		// 
		//  Page_Init
		//
		public void Page_Init() {

			// Create form object
			ObjForm = new cFormObj();
			CurrentAction = (ew_Get("a") != "") ? ew_Get("a") : ew_Post("a_list"); // Set up current action

			// Global Page Loading event
			ew_WebPage.Page_Loading();

			// Page Load event
			Page_Load();

			// Check token
			if (!ValidPost()) {
				ew_Response.Write(Language.Phrase("InvalidPostRequest"));
				Page_Terminate();
				ew_End();
			}

			// Process auto fill
			if (ew_Post("ajax") == "autofill") {

				// Process auto fill for detail table 'Checklists'
				if (ew_Post("grid") == "fChecklistsgrid") {
					if (Checklists_grid == null) Checklists_grid = new cChecklists_grid_base<C, S>();
					Checklists_grid.Page_Init();
					Page_Terminate();
					ew_End();
				}

				// Process auto fill for detail table 'ChecklistItemTemplates'
				if (ew_Post("grid") == "fChecklistItemTemplatesgrid") {
					if (ChecklistItemTemplates_grid == null) ChecklistItemTemplates_grid = new cChecklistItemTemplates_grid_base<C, S>();
					ChecklistItemTemplates_grid.Page_Init();
					Page_Terminate();
					ew_End();
				}
				string results = GetAutoFill(ew_Post("name"), ew_Post("q"));
				if (results != null) {

					// Clean output buffer
					if (!EW_DEBUG_ENABLED)
						ew_Response.Clear();
					ew_Response.Write(results);
					Page_Terminate();
					ew_End();
				}
			}

			// Create Token
			CreateToken();
		}

		//
		// Page_Terminate
		//
		public void Page_Terminate(string url = "") {

			// Page Unload event
			Page_Unload();

			// Global Page Unloaded event
			ew_WebPage.Page_Unloaded();

			// Export
			if (ew_NotEmpty(CustomExport) && CustomExport == Export && EW_EXPORT.ContainsKey(CustomExport)) {
				var sContent = "";
				sContent = Regex.Match(ew_WebPage.Output.ToString(), @"<html>[\s\S]+</html>", RegexOptions.IgnoreCase).Value;
				if (ew_Empty(gsExportFile))
					gsExportFile = TableVar;
				dynamic doc = ew_CreateInstance(EW_EXPORT[CustomExport], new object[] { ChecklistTemplates, "" }); // ASPX
				doc.Text.Append(sContent);				
				if (Export == "email") {
				} else {
					doc.Export();
				}		
				ew_DeleteTmpImages(); // Delete temp images
				ew_GCollect(); // ASPX
				ew_End();
			}
			Page_Redirecting(ref url);

			 // Close connection
			if (Conn != null)
				Conn.Close();

			// Gargage collection // ASPX
			ew_GCollect();

			// Go to URL if specified
			if (ew_NotEmpty(url)) {  // ASPX
				if (EW_DEBUG_ENABLED)
					ew_Response.Clear();
				ew_Response.Redirect(ew_MapPath(url, false)); // ASPX
			}

			//ew_End();
		}

		public string DbMasterFilter = "";

		public string DbDetailFilter = "";

		public int StartRec;

		public int Priv = 0;		

		public ewDataReader OldRecordset = null;

		public ewDataReader Recordset = null; // Reserved // ASPX

		public bool CopyRecord;		

		// 
		// Page main
		//
		public void Page_Main() {

			// Process form if post back
			if (ew_NotEmpty(ew_Post("a_add"))) {
				CurrentAction = ew_Post("a_add"); // Get form action
				CopyRecord = LoadOldRecord(); // Load old recordset
				LoadFormValues(); // Load form values
			} else { // Not post back

				// Load key from QueryString
				CopyRecord = true;
				if (ew_NotEmpty(ew_Get("Id")) || ew_Page.UrlData.Count >= 1) { // ASPX
					if (ew_NotEmpty(ew_Get("Id"))) { 
						Id.QueryStringValue = ew_Get("Id");						
					} else {
						Id.QueryStringValue = ew_Page.UrlData[0];
					}
					SetKey("Id", Id.CurrentValue); // Set up key
				} else {
					SetKey("Id", ""); // Clear key
					CopyRecord = false;
				}
				if (CopyRecord) {
					CurrentAction = "C"; // Copy record
				} else {
					CurrentAction = "I"; // Display blank record
					LoadDefaultValues(); // Load default values
				}
			}

			// Set up Breadcrumb
			SetupBreadcrumb();

			// Set up detail parameters
			SetUpDetailParms();

			// Validate form if post back
			if (ew_NotEmpty(ew_Post("a_add"))) {
				if (!ValidateForm()) {
					CurrentAction = "I"; // Form error, reset action
					EventCancelled = true; // Event cancelled
					RestoreFormValues(); // Restore form values
					FailureMessage = gsFormError;
				}
			}

			// Perform action based on action code
			switch (CurrentAction) {
				case "I": // Blank record, no action required
					break;
				case "C": // Copy an existing record
					if (!LoadRow()) { // Load record based on key
						if (ew_Empty(FailureMessage)) FailureMessage = Language.Phrase("NoRecord"); // No record found
						Page_Terminate("ChecklistTemplateslist.cshtml"); // No matching record, return to list
					}					

					// Set up detail parameters
					SetUpDetailParms();
					break;
				case "A": // Add new record
					SendEmail = true; // Send email on add success
					var rsold = Conn.GetRow(OldRecordset);
					if (OldRecordset != null) {
						OldRecordset.Close();
						OldRecordset.Dispose();
					}
					if (AddRow(rsold)) { // Add successful
						if (ew_Empty(SuccessMessage))
							SuccessMessage = Language.Phrase("AddSuccess"); // Set up success message
						string sReturnUrl = "";
						if (ew_NotEmpty(CurrentDetailTable)) // Master/detail add
							sReturnUrl = DetailUrl;
						else
							sReturnUrl = Convert.ToString(GetCustomValue("TblAddReturnPage"));
						if (ew_GetPageName(sReturnUrl) == "ChecklistTemplatesview.cshtml")
							sReturnUrl = ViewUrl; // View paging, return to view page with keyurl directly
						Page_Terminate(sReturnUrl); // Clean up and return
					} else {
						EventCancelled = true; // Event cancelled
						RestoreFormValues(); // Add failed, restore form values

						// Set up detail parameters
						SetUpDetailParms();
					}
					break;
			}

			// Render row based on row type
			RowType = EW_ROWTYPE_ADD;  // Render add type

			// Render row
			ResetAttrs();
			RenderRow();
		}

		// Confirm page
		public bool ConfirmPage = false;  // ASPX

		// Get upload files
		public void GetUploadFiles() {

			// Get upload data
		}

		// Load default values
		public void LoadDefaultValues() {
			zName.CurrentValue = System.DBNull.Value;
			zName.OldValue = zName.CurrentValue;
		}

		// Load form values
		public void LoadFormValues() {
			if (!zName.FldIsDetailKey) {
				zName.FormValue = ObjForm.GetValue("x_zName");
			}
		}

		// Restore form values
		public void RestoreFormValues() {
			LoadOldRecord();
			zName.CurrentValue = zName.FormValue;
		}

		// Load row based on key values
		public bool LoadRow() {
			string sFilter = KeyFilter;

			// Call Row Selecting event
			Row_Selecting(ref sFilter);

			// Load SQL based on filter
			CurrentFilter = sFilter;
			string sSql = SQL;

			// Write SQL for debug
			if (EW_DEBUG_ENABLED)
				ew_SetDebugMsg(sSql); // Show SQL for debugging
			var res = false;
			try {
				using (var rsrow = Conn.OpenDataReader(sSql)) {
					if (rsrow != null && rsrow.Read()) {				
						LoadRowValues(rsrow);								
						res = true;
					} else {
						return false;
					}
				}
			} catch {
				if (EW_DEBUG_ENABLED)
					throw;
			}
			return res;
		}

		// Load row values from recordset
		public void LoadRowValues(ewDataReader dr) {
			if (dr == null)
				return;
			string sDetailFilter;

			// Call Row Selected event
			var row = Conn.GetRow(dr);
			Row_Selected(ref row);
			Id.DbValue = row["Id"];
			zName.DbValue = row["Name"];
		}

		// Load DbValue from recordset
		public void LoadDbValues(OrderedDictionary row) {
			if (row == null) return;
			Id.SetDbValue(row["Id"]);
			zName.SetDbValue(row["Name"]);
		}

		// Load old record
		public bool LoadOldRecord(cConnectionBase cnn = null) {

			// Load key values from Session
			bool bValidKey = true;
			if (ew_NotEmpty(GetKey("Id")))
				Id.CurrentValue = GetKey("Id"); // Id
			else
				bValidKey = false;

			// Load old recordset
			if (bValidKey) {
				CurrentFilter = KeyFilter;
				string sSql = SQL;
				try {
					OldRecordset = (cnn != null) ? cnn.OpenDataReader(sSql) : Conn.OpenDataReader(sSql);
					if (OldRecordset != null && OldRecordset.Read())
						LoadRowValues(OldRecordset); // Load row values
					return true;
				} catch { return false; }
			} else {
				OldRecordset = null;
			}
			return bValidKey;
		}

		// Render row values based on field settings
		public void RenderRow() {

			// Call Row_Rendering event
			Row_Rendering();

			// Common render codes for all row types
			// Id
			// zName

			if (RowType == EW_ROWTYPE_VIEW) { // View row

				// Id
				Id.ViewValue = Id.CurrentValue;

				// zName
				zName.ViewValue = zName.CurrentValue;

				// zName
				zName.HrefValue = "";
				zName.TooltipValue = "";
			} else if (RowType == EW_ROWTYPE_ADD) { // Add row

				// zName
				zName.EditAttrs["class"] = "form-control";
				zName.EditValue = zName.CurrentValue; // ASPX
				zName.PlaceHolder = ew_RemoveHtml(zName.FldCaption);

				// Edit refer script
				// zName

				zName.HrefValue = "";
			}
			if (RowType == EW_ROWTYPE_ADD ||
				RowType == EW_ROWTYPE_EDIT ||
				RowType == EW_ROWTYPE_SEARCH) { // Add / Edit / Search row
				SetupFieldTitles();
			}

			// Call Row Rendered event
			if (RowType != EW_ROWTYPE_AGGREGATEINIT)
				Row_Rendered();
		}

		// Validate form
		public bool ValidateForm() {

			// Initialize form error message
			gsFormError = "";

			// Check if validation required
			if (!EW_SERVER_VALIDATE)
				return (gsFormError == "");

			// Validate detail grid
			var DetailTblVar = new List<string>(CurrentDetailTable.Split(new char[] {','}));
			if (DetailTblVar.Contains("Checklists") && Checklists.DetailAdd) {
				if (Checklists_grid == null) Checklists_grid = new cChecklists_grid_base<C, S>(); // Get detail page object
				Checklists_grid.ValidateGridForm();
			}
			if (DetailTblVar.Contains("ChecklistItemTemplates") && ChecklistItemTemplates.DetailAdd) {
				if (ChecklistItemTemplates_grid == null) ChecklistItemTemplates_grid = new cChecklistItemTemplates_grid_base<C, S>(); // Get detail page object
				ChecklistItemTemplates_grid.ValidateGridForm();
			}

			// Return validate result
			bool Valid = (ew_Empty(gsFormError));

			// Call Form_CustomValidate event
			string sFormCustomError = "";
			Valid = Valid && Form_CustomValidate(ref sFormCustomError);
			gsFormError = ew_JoinMessage(gsFormError, sFormCustomError);
			return Valid;
		}

		// Add record
		public bool AddRow(OrderedDictionary rsold = null) {
			bool result = false;
			var rsnew = new OrderedDictionary();
			string sMasterFilter = "";

			// Begin transaction
			if (ew_NotEmpty(CurrentDetailTable))
				Conn.BeginTrans();

			// Load db values from rsold
			if (rsold != null) {
				LoadDbValues(rsold);
			}
			try {

				// zName
				zName.SetDbValue(ref rsnew, zName.CurrentValue, System.DBNull.Value, false);
			} catch (Exception e) {
				if (EW_DEBUG_ENABLED) throw;
				FailureMessage = e.Message;
				return false;
			}

			// Call Row Inserting event
			bool bInsertRow = Row_Inserting(rsold, ref rsnew);
			if (bInsertRow) {
				try {	
					Insert(rsnew);
					result = true;
				} catch (Exception e) {
					if (EW_DEBUG_ENABLED) throw;
					FailureMessage = e.Message;		
					result = false;
				}
				if (result) {
				}
			} else {
				if (ew_NotEmpty(SuccessMessage) || ew_NotEmpty(FailureMessage)) {

					// Use the message, do nothing
				} else if (ew_NotEmpty(CancelMessage)) {
					FailureMessage = CancelMessage;
					CancelMessage = "";
				} else {
					FailureMessage = Language.Phrase("InsertCancelled");
				}
				result = false;
			}

			// Get insert id if necessary
			if (result) {
				Id.DbValue = Conn.GetLastInsertId();
				rsnew["Id"] = Id.DbValue;
			}

			// Add detail records
			if (result) {
				var DetailTblVar = new List<string>(CurrentDetailTable.Split(new char[] {','}));
				if (DetailTblVar.Contains("Checklists") && Checklists.DetailAdd) {
					Checklists.ChecklistTemplate_Id.SessionValue = Convert.ToString(ChecklistTemplates.Id.CurrentValue); // Set master key
					if (Checklists_grid == null) Checklists_grid = new cChecklists_grid_base<C, S>(); // Get detail page object
					result = Checklists_grid.GridInsert();
				}
				if (DetailTblVar.Contains("ChecklistItemTemplates") && ChecklistItemTemplates.DetailAdd) {
					ChecklistItemTemplates.Checklist_Id.SessionValue = Convert.ToString(ChecklistTemplates.Id.CurrentValue); // Set master key
					if (ChecklistItemTemplates_grid == null) ChecklistItemTemplates_grid = new cChecklistItemTemplates_grid_base<C, S>(); // Get detail page object
					result = ChecklistItemTemplates_grid.GridInsert();
				}
			}

			// Commit/Rollback transaction
			if (ew_NotEmpty(CurrentDetailTable)) {
				if (result) {
					Conn.CommitTrans(); // Commit transaction
				} else {
					Conn.RollbackTrans(); // Rollback transaction
				}
			}
			if (result) {

				// Call Row Inserted event
				Row_Inserted(rsold, rsnew);
			}
			return result;
		}

		// Set up detail parms based on QueryString
		public void SetUpDetailParms() {
			string sDetailTblVar = "";

			// Get the keys for master table
			if (ew_QueryString[EW_TABLE_SHOW_DETAIL] != null) { // Value may be empty
				sDetailTblVar = ew_Get(EW_TABLE_SHOW_DETAIL);
				CurrentDetailTable = sDetailTblVar;
			} else {
				sDetailTblVar = CurrentDetailTable;
			}
			if (ew_NotEmpty(sDetailTblVar)) {
				var DetailTblVar = new List<string>(sDetailTblVar.Split(new char[] {','}));
				if (DetailTblVar.Contains("Checklists")) {
					if (Checklists_grid == null)
						Checklists_grid = new cChecklists_grid_base<C, S>();
					if (Checklists_grid.DetailAdd) {
						if (CopyRecord)
							Checklists_grid.CurrentMode = "copy";
						else
							Checklists_grid.CurrentMode = "add";
						Checklists_grid.CurrentAction = "gridadd";

						// Save current master table to detail table
						Checklists_grid.CurrentMasterTable = TableVar;
						Checklists_grid.StartRecordNumber = 1;
						Checklists_grid.ChecklistTemplate_Id.FldIsDetailKey = true;
						Checklists_grid.ChecklistTemplate_Id.CurrentValue = Id.CurrentValue;
						Checklists_grid.ChecklistTemplate_Id.SessionValue = Checklists_grid.ChecklistTemplate_Id.CurrentValue;
					}
				}
				if (DetailTblVar.Contains("ChecklistItemTemplates")) {
					if (ChecklistItemTemplates_grid == null)
						ChecklistItemTemplates_grid = new cChecklistItemTemplates_grid_base<C, S>();
					if (ChecklistItemTemplates_grid.DetailAdd) {
						if (CopyRecord)
							ChecklistItemTemplates_grid.CurrentMode = "copy";
						else
							ChecklistItemTemplates_grid.CurrentMode = "add";
						ChecklistItemTemplates_grid.CurrentAction = "gridadd";

						// Save current master table to detail table
						ChecklistItemTemplates_grid.CurrentMasterTable = TableVar;
						ChecklistItemTemplates_grid.StartRecordNumber = 1;
						ChecklistItemTemplates_grid.Checklist_Id.FldIsDetailKey = true;
						ChecklistItemTemplates_grid.Checklist_Id.CurrentValue = Id.CurrentValue;
						ChecklistItemTemplates_grid.Checklist_Id.SessionValue = ChecklistItemTemplates_grid.Checklist_Id.CurrentValue;
					}
				}
			}
		}

		// Set up Breadcrumb
		public void SetupBreadcrumb() {
			Breadcrumb = new cBreadcrumb();			
			var url = ew_CurrentUrl();
			url = url.Substring(url.LastIndexOf("/") + 1);
			Breadcrumb.Add("list", TableVar, "ChecklistTemplateslist.cshtml", "", TableVar, true);
			var PageId = (CurrentAction == "C") ? "Copy" : "Add";
			url = url.Substring(url.LastIndexOf("/") + 1);
			Breadcrumb.Add("add", PageId, url);
		}

		// Page Load event
		public virtual void Page_Load() {

			//ew_Write("Page Load");
		}

		// Page Unload event
		public virtual void Page_Unload() {

			//ew_Write("Page Unload");
		}

		// Page Redirecting event
		public virtual void Page_Redirecting(ref string url) {

			//url = newurl;
		}

		// Message Showing event
		// type = ""|"success"|"failure"|"warning"
		public virtual void Message_Showing(ref string msg, string type) {

			// Note: Do not change msg outside the following 4 cases.
			if (type == "success") {

				//msg = "your success message";
			} else if (type == "failure") {

				//msg = "your failure message";
			} else if (type == "warning") {

				//msg = "your warning message";
			} else {

				//msg = "your message";
			}
		}

		// Page_Render event
		public virtual void Page_Render() {

			//ew_Write("Page Render");
		}

		// Page Data Rendering event
		public virtual void Page_DataRendering(ref string header) {

			// Example:
			//header = "your header";

		}

		// Page Data Rendered event
		public virtual void Page_DataRendered(ref string footer) {

			// Example:
			//footer = "your footer";

		}

		// Form Custom Validate event
		public virtual bool Form_CustomValidate(ref string CustomError) {

			//Return error message in CustomError
			return true;
		}
	}
}
