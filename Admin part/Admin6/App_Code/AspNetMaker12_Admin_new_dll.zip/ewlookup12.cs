using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET WebPage class
//
public partial class AspNetMaker12_Admin_new_base : WebPage {

	//
	// Page class
	//
	public class clookup<C>		
		where C : cConnectionBase, new()
	{

		// 
		// Page main
		//
		public void Page_Main() {
			if (!IsPost)
				return; // No post data
			var sql = ew_Post("s");
			sql = ew_Decrypt(sql);
			if (sql == "")
				ew_End("Missing SQL.");
			var value = "";
			if (sql.Contains("{filter}")) {
				var filters = "";
				for (var i = 0; i < 5; i++) {

					// Get the filter values (for "IN")
					var filter = ew_Decrypt(ew_Post("f" + i));
					if (filter != "") {
						value = ew_Post("v" + i);
						if (value == "") {
							if (i > 0) { // Empty parent field

								//continue; // Allow
								ew_AddFilter(ref filters, "1=0"); // Disallow
							}
							continue;
						}
						var arValue = value.Split(new[] {','});
						var fldtype = ew_ConvertToInt(ew_Post("t" + i));
						for (var j = 0; j < arValue.Length; j++) {
							arValue[j] = ew_QuotedValue(arValue[j], ew_FieldDataType(fldtype));
						}
						filter = filter.Replace("{filter_value}", String.Join(",", arValue));
						ew_AddFilter(ref filters, filter);
					}
				}
				sql = sql.Replace("{filter}", (filters != "") ? filters : "1=1");
			}

			// Get the query value (for "LIKE" or "=")
			value = ew_AdjustSql(ew_Get("q")); // Get the query value from querystring
			if (value == "") value = ew_AdjustSql(ew_Post("q")); // Get the value from post
			if (value != "") {
				sql = Regex.Replace(sql, @"LIKE '(%)?\{query_value\}%'", ew_Like("'$1{query_value}%'")); //???
				sql = sql.Replace("{query_value}", value);
			}

			// Replace {query_value_n}
			var m = Regex.Matches(sql, @"\{query_value_(\d+)\}");
			for (var i = 0; i < m.Count; i++) {
				var j = m[i].Groups[1].Value;
				var v = ew_AdjustSql(ew_Post("q" + j));
				sql = sql.Replace("{query_value_" + j + "}", v);
			}
			List<OrderedDictionary> rsarr;

			// Connect to database
			var Conn = new C();
			try {
				rsarr = Conn.GetRows(sql);
			} finally {
				Conn.Dispose();
			}

			// Output (using ew_Response) // ASPX
			ew_Response.Cache.SetCacheability(HttpCacheability.NoCache); 
			foreach (OrderedDictionary row in rsarr) {
				for (var i = 0; i < row.Count; i++) {
					var str = Convert.ToString(row[i]);
					if (ew_Empty(ew_Post("keepHTML")))
						str = ew_RemoveHtml(str);
					if (str.Contains("\r") || str.Contains("\n")) {
						if (ew_NotEmpty(ew_Post("keepCRLF"))) {
							str = str.Replace("\r", "\\r").Replace("\n", "\\n");
						} else {
							str = str.Replace("\r", " ").Replace("\n", " ");
						}
					}
					row[i] = str;
				}				
			}
			ew_Response.Write(ew_ArrayToJson(rsarr));		
			ew_End(); // ASPX
		}
	}
}
