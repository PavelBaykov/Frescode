using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET WebPage class
//
public partial class AspNetMaker12_Admin_new_base : WebPage {

	//
	// Page class
	//
	public class cewupload<C>		
		where C : cConnectionBase, new()
	{

		// Download file content
		public void DownloadFileContent() {		
			var name = ew_Get("id");			
			var filename = ew_Get(name);
			var folder = ew_UploadTempPath(name);
			var version = ew_Get("version");
			if (ew_NotEmpty(version))
				folder = ew_PathCombine(folder, version, true);

			// Show file content			
			var file = ew_IncludeTrailingDelimiter(folder, true) + filename;
			if (ew_FileExists(file)) {
				var value = File.ReadAllBytes(file); 
				ew_Response.AddHeader("Pragma", "no-cache");
				ew_Response.AddHeader("Cache-Control", "no-cache, no-store, must-revalidate");
				ew_Response.AddHeader("X-Content-Type-Options", "nosniff");
				ew_Response.ContentType = ew_ContentType(value.Take(11), filename);
				ew_Response.BinaryWrite(value);
				ew_Response.End();
			}
		}

		// Delete file
		public void DeleteFile() {
			if (ew_Get("id") != "") {
				var name = ew_Get("id");
				var filename = ew_Get(name);
				var folder = ew_UploadTempPath(name);
				ew_DeleteFile(ew_IncludeTrailingDelimiter(folder, true) + filename);
				var version = EW_UPLOAD_THUMBNAIL_FOLDER;
				folder = ew_PathCombine(folder, version, true);
				ew_DeleteFile(ew_IncludeTrailingDelimiter(folder, true) + filename);
				ew_Response.Write("{\"success\": true}");
			}
		}

		// Download file list
		public void DownloadFileList() {
			var name = ew_Get("id");
			var files = new List<object[]>();
			if (name != "") {
				var folder = ew_UploadTempPath(name);
				if (Directory.Exists(folder)) {
					var ar = Directory.GetFiles(folder);
					foreach (var file in ar) {						
						var value = File.ReadAllBytes(file);
						var filesize = value.Length;
						var filetype = ew_ContentType(value.Take(11), file);
						files.Add(new object[] {name, Path.GetFileName(file), filetype, filesize});
					}
				}
				OutputJSON(name, files);
			}
		}

		// Upload file
		public void UploadFile() {
			if (ew_Request.TotalBytes > 0) {
				var Language = new cLanguage();		
				var ObjForm = new cFormObj();
				var name = ObjForm.GetValue("id");
				var folder = ew_UploadTempPath(name);
				var exts = ObjForm.GetValue("exts");
				var filetypes = (ew_Empty(exts)) ? ".+$" : ".(" + exts.Replace(",", "|") + ")$";
				var maxsize = ew_ConvertToInt(ObjForm.GetValue("maxsize"));
				var maxfilecount = ew_ConvertToInt(ObjForm.GetValue("maxfilecount"));		
				var filename = ObjForm.GetUploadFileName(name);
				if (EW_UPLOAD_CONVERT_ACCENTED_CHARS) {
					filename = ew_HtmlEncode(filename);
					filename = Regex.Replace(filename, @"&([a-zA-Z])(uml|acute|grave|circ|tilde|cedil);", "$1");
					filename = ew_HtmlDecode(filename);
				}
				var filetype = ObjForm.GetUploadFileContentType(name);
				var filesize = ObjForm.GetUploadFileSize(name);
				var value = (byte[])ObjForm.GetUploadFileData(name);

				// Check file types
				if (!Regex.IsMatch(filename, filetypes, RegexOptions.IgnoreCase)) {
					var fileerror = Language.Phrase("UploadErrMsgAcceptFileTypes");					
					OutputJSON("files", new List<object[]>() { new object[] { name, filename, filetype, filesize, fileerror }});
					return;
				}

				// Check file size
				if (maxsize < filesize) {
					var  fileerror = Language.Phrase("UploadErrMsgMaxFileSize");					
					OutputJSON("files", new List<object[]>() { new object[] { name, filename, filetype, filesize, fileerror }});
					return;
				}

				// Check max file count
				var filecount = ew_FolderFileCount(folder);
				if (maxfilecount > 0 && maxfilecount <= filecount) {
					var fileerror = Language.Phrase("UploadErrMsgMaxNumberOfFiles");
					OutputJSON("files", new List<object[]>() { new object[] { name, filename, filetype, filesize, fileerror }});
					return;
				}

				// Delete all files in directory if replace
				var version = EW_UPLOAD_THUMBNAIL_FOLDER;				
				if (ObjForm.GetValue("replace") == "1") 
                    ew_CleanPath(folder, false);
				ew_SaveFile(folder, filename, ref value);				
				folder = ew_PathCombine(folder, version, true);
				var w = EW_UPLOAD_THUMBNAIL_WIDTH;
				var h = EW_UPLOAD_THUMBNAIL_HEIGHT;
				ew_ResizeBinary(ref value, ref w, ref h, EW_THUMBNAIL_DEFAULT_QUALITY);
				ew_SaveFile(folder, filename, ref value);
				OutputJSON("files", new List<object[]> { new object[] { name, filename, filetype, filesize } });
			}		
		}

		// Output JSON
		public void OutputJSON(string id, List<object[]> files) {
			var ar = new List<Dictionary<string, object>>();
			var baseurl = ew_ConvertFullUrl(ew_CurrentPage());
			if (ew_IsList(files)) {
				foreach (var file in files) {
					if (file.Length >= 4) {                        
						var name = Convert.ToString(file[0]);						
						var filename = Convert.ToString(file[1]);
						var fileerror = (file.Length > 4) ? Convert.ToString(file[4]) : "";						
						var url = baseurl + "?id=" + name + "&" + name + "=" + ew_UrlEncode(filename) + "&download=1";
						var version = EW_UPLOAD_THUMBNAIL_FOLDER;
						var thumbnail_url = baseurl + "?id=" + name + "&" + name + "=" + ew_UrlEncode(filename) + "&version=" + version + "&download=1";
						var delete_url = baseurl + "?id=" + name + "&" + name + "=" + ew_UrlEncode(filename) + "&delete=1";
						var obj = new Dictionary<string, object>();
						obj.Add("name", filename);
						obj.Add("size", ew_ConvertToInt(file[3]));
						obj.Add("type", Convert.ToString(file[2]));
						obj.Add("url", url);
						if (ew_NotEmpty(fileerror)) {
							obj.Add("error", fileerror);
						} else {
							obj.Add(version + "Url", thumbnail_url);
						}						
						obj.Add("deleteUrl", delete_url);
						obj.Add("deleteType", "GET"); // Use GET					
						ar.Add(obj);
					}
				}
			}

			// Set file header / content type
			ew_Response.AddHeader("Pragma", "no-cache");
			ew_Response.AddHeader("Cache-Control", "no-cache, no-store, must-revalidate");
			ew_Response.AddHeader("Content-Disposition", "inline; filename=files.json");
			ew_Response.AddHeader("X-Content-Type-Options", "nosniff");
			ew_Response.ContentType = "text/plain";

			// Output json
			ew_Response.Write("{\"" + id + "\":" + ew_ArrayToJson(ar) + "}");
		}

		// 
		// Page main
		//
		public void Page_Main() {

			// Handle download file content
			if (ew_Get("download") != "") {			
				DownloadFileContent();			
			} else if (ew_Get("delete") != "") { // Handle delete file			
				DeleteFile();		
			} else if (ew_Get("id") != "") { // Handle download file list			
				DownloadFileList();			
			} else if (ew_Request.TotalBytes > 0) { // Handle upload file (multi-part)			
				UploadFile();			
			}		
		}
	}
}
