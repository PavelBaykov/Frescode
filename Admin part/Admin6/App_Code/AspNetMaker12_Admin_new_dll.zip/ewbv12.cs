using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET WebPage class
//
public partial class AspNetMaker12_Admin_new_base : WebPage {

	// lookup
	public static cewbv ewbv;

	//
	// Page class
	//
	public class cewbv {

		// 
		// Page main
		//
		public void Page_Main() {
			ew_Response.Cache.SetCacheability(HttpCacheability.NoCache);
			int width = 0;
			int height = 0;
			int interpolation;

			// Get resize parameters
			bool resize = (ew_NotEmpty(ew_Get("resize")));		
			if (ew_NotEmpty(ew_Get("width")))
				width = ew_ConvertToInt(ew_Get("width"));
			if (ew_NotEmpty(ew_Get("height")))
				height = ew_ConvertToInt(ew_Get("height"));
			if (width <= 0 && height <= 0) {
				width = EW_THUMBNAIL_DEFAULT_WIDTH;
				height = EW_THUMBNAIL_DEFAULT_HEIGHT;
			}
			if (ew_NotEmpty(ew_Get("interpolation"))) {
				interpolation = ew_ConvertToInt(ew_Get("interpolation"));
			} else {
				interpolation = EW_THUMBNAIL_DEFAULT_QUALITY;
			}

			// Resize image from physical file
			if (ew_NotEmpty(ew_Get("fn"))) {
				string fn = ew_Get("fn");

				//fn = ew_MapPath(fn, true, true); // Physical path relative to root
				fn = ew_UploadPathEx(true, fn); // Physical path relative to root
				if (File.Exists(fn)) { // Does not support remote path
					string ext = Path.GetExtension(fn).Replace(".", "").ToLower();
					if ((new List<string>(EW_IMAGE_ALLOWED_FILE_EXT.ToLower().Split(new char[] {','}))).Contains(ext)) {
						ew_Response.ContentType = ew_GetImageContentType(fn);
						ew_BinaryWrite(ew_ResizeFileToBinary(fn, ref width, ref height, interpolation));
					}
				}				
			}
		}
	}
}
